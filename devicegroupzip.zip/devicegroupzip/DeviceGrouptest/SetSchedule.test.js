import React from 'react';
import "../../../../../../config/jest/test-setup"
import { render, screen, fireEvent, within } from '@testing-library/react';
import '@testing-library/jest-dom';
import SetSchedule from '../../components/DeviceGroup/SetSchedule';

describe('SetSchedule Component', () => {
    test('should render component - SetSchedule', () => {
        const props = {
            history: { push() { } },
            title: 'Schedule', isManage: true, subtitle: 'subtitle', currentPage: 'setSchedule', selectDaysTitle: 'Select Days',
            days: ["0", "1", "2", "3", "4", "5", "6"], startTimeTitle: 'Start Time', endTimeTitle: 'End Time', clearSchedule: 'Clear Schedule',
            back: 'Back', backHandler: jest.fn, nextHandler: jest.fn, skipHandler: jest.fn,
            next: 'Save', skip: 'Skip', deviceGroupData: {
                schedule: {
                    daysOfTheWeek: [
                        1, 2
                    ],
                    startTimeHour: "12",
                    startTimeMinute: "00",
                    stopTimeHour: "12",
                    stopTimeMinute: "00",
                    startTimeAmPm: "AM",
                    stopTimeAmPm: "PM",
                }
            }
        };
        const component = render(<SetSchedule {...props} />);
        expect(component).toBeTruthy();

        fireEvent.click(screen.getByText("Save"));
        fireEvent.click(screen.getByTestId("start-time-period-pm"));
        fireEvent.click(screen.getByTestId("end-time-period-am"));
        fireEvent.click(screen.getByTestId("clear-schedule"));
        fireEvent.click(screen.getAllByTestId("select-day")[0]);


        

        const { container } = render(<SetSchedule {...props} />);
        fireEvent.change(container.querySelector('[data-testid="start-time-hour"] select'), { target: { value: '01' } });
        fireEvent.change(container.querySelector('[data-testid="start-time-minute"] select'), { target: { value: '01' } });
        fireEvent.change(container.querySelector('[data-testid="end-time-hour"] select'), { target: { value: '01' } });
        fireEvent.change(container.querySelector('[data-testid="end-time-minute"] select'), { target: { value: '01' } });
    });
});
// describe('SetSchedule Component', () => {
//     test('should render component - SetSchedule', () => {
//         const props = {
//             history: { push() { } },
//             title: 'Schedule', isManage: true, subtitle: 'subtitle', currentPage: 'setSchedule', selectDaysTitle: 'Select Days',
//             days: [], startTimeTitle: 'Start Time', endTimeTitle: 'End Time', clearSchedule: 'Clear Schedule',
//             back: 'Back', backHandler: jest.fn, nextHandler: jest.fn, skipHandler: jest.fn,
//             next: 'Save', skip: 'Skip', deviceGroupData: {
//                 schedule: {
//                     daysOfTheWeek: [
//                         1, 2
//                     ],
//                     startTimeHour: "12",
//                     startTimeMinute: "00",
//                     stopTimeHour: "12",
//                     stopTimeMinute: "00",
//                     startTimeAmPm: "AM",
//                     stopTimeAmPm: "PM",
//                 }
//             }
//         };
//         const component = render(<SetSchedule {...props} />);
//         expect(component).toBeTruthy();

//         fireEvent.click(screen.getByText("Save"));
//         fireEvent.click(screen.getByTestId("start-time-period-pm"));
//         fireEvent.click(screen.getByTestId("end-time-period-am"));
//         fireEvent.click(screen.getByTestId("select-day"));

//         const { container } = render(<SetSchedule {...props} />);
//         fireEvent.change(container.querySelector('[data-testid="start-time-hour"] select'), { target: { value: '01' } });
//         fireEvent.change(container.querySelector('[data-testid="start-time-minute"] select'), { target: { value: '01' } });
//         fireEvent.change(container.querySelector('[data-testid="end-time-hour"] select'), { target: { value: '01' } });
//         fireEvent.change(container.querySelector('[data-testid="end-time-minute"] select'), { target: { value: '01' } });

//     });
// });