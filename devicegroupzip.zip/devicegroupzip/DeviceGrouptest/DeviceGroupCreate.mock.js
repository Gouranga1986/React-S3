export const createDeviceGroupData = {
    "pageAttributes": [
        {
            "itemKey": "pageTitle",
            "itemValue": "Create a device group",
            "itemType": null,
            "itemAttributes": {}
        },
        {
            "itemKey": "subTitle",
            "itemValue": "Device groups allow you to set parental or other controls on multiple devices at once.",
            "itemType": null,
            "itemAttributes": {}
        },
        {
            "itemKey": "breadCrumbDeviceGroup",
            "itemValue": "Device group",
            "itemType": null,
            "itemAttributes": {}
        }
    ],
    "sections": [
        {
            "sectionIndex": "0",
            "sectionId": "setDeviceGroupNameSection",
            "sectionType": null,
            "sectionComponentId": null,
            "sectionText": null,
            "dataUrl": null,
            "clickStream": null,
            "sections": [],
            "actions": [
                {
                    "actionKey": "cancelGroupCreationModal",
                    "actionValue": "openCancelGroupCreationModal",
                    "actionType": "modal",
                    "sectionKey": null,
                    "clickStream": null
                },
                {
                    "actionKey": "navigateToSelectDevices",
                    "actionValue": "selectDevicesSection",
                    "actionType": "route",
                    "sectionKey": null,
                    "clickStream": null
                }
            ],
            "contents": [
                {
                    "contentIndex": "0",
                    "contentComponentId": "groupNameComponent",
                    "contentType": null,
                    "contentActionId": null,
                    "clickStream": null,
                    "items": [
                        {
                            "itemKey": "groupNameHeading",
                            "itemType": "headingText",
                            "itemValue": "Enter a name for this device group.",
                            "itemAttributes": {}
                        },
                        {
                            "itemKey": "groupNameInput",
                            "itemType": "textBox",
                            "itemValue": "Device group name",
                            "itemAttributes": {
                                "maximumCharacters": "64"
                            }
                        },
                        {
                            "itemKey": "groupNameCancelButton",
                            "itemType": "button",
                            "itemValue": "Cancel",
                            "actionKey": "cancelGroupCreationModal",
                            "itemAttributes": {
                                "style": "white"
                            }
                        },
                        {
                            "itemKey": "groupNameNextButton",
                            "itemType": "button",
                            "itemValue": "Next",
                            "actionKey": "navigateToSelectDevices",
                            "itemAttributes": {
                                "style": "black"
                            }
                        }
                    ]
                }
            ],
            "data": {
                "connectedDevices": [
                    {
                        "deviceId": "1",
                        "ipAddress": "192.168.0.11",
                        "macId": "bc:d7:d4:cd:80:8a",
                        "name": "unknown_da:bc:d7:d4:cd:80:8a",
                        "displayName": "rename_device: bc:d7:d4:cd:80:8a",
                        "status": "Offline",
                        "displayStatus": "Offline",
                        "connectedNetwork": "Primary",
                        "connectedDeviceType": "Other",
                        "deviceConnectedVia": "Router",
                        "wifiStrength": "S",
                        "connectedSSID": "FSpFF17t6r",
                        "individualParentalControls": false,
                        "blocked": false,
                        "connectionType": "wireless",
                        "assigned": true,
                        "deviceGroupName": "ROKU",
                        "band": "5GHz",
                        "rssi": "-40 dBm",
                        "snr": "-88",
                        "ipv6Address": [
                            "fe80::d8e5:ceff:fe4b:cb4b"
                        ],
                        "bcsStatus": "Inactive"
                    },
                    {
                        "deviceId": "1",
                        "ipAddress": "192.168.1.153",
                        "macId": "0a:97:ed:74:19:ef",
                        "name": "LgTbfn23343",
                        "displayName": "LgTbfn23343",
                        "status": "Offline",
                        "displayStatus": "Offline",
                        "connectedNetwork": "Primary",
                        "connectedDeviceType": "Desktop/Laptop",
                        "deviceConnectedVia": "Router",
                        "parentalControlId": "3ca265b8-cc13-11ef-8065-ac919bb0d38e",
                        "individualParentalControls": false,
                        "blocked": false,
                        "connectionType": "wireless",
                        "location": "Living Room",
                        "assigned": true,
                        "deviceGroupName": "UAT group",
                        "band": "2.4GHz",
                        "authMode": "WPA2-Personal",
                        "hostName": "iPhone",
                        "leaseType": "DHCP",
                        "bcsStatus": "Inactive"
                    },
                    {
                        "deviceId": "2",
                        "ipAddress": "192.168.1.151",
                        "macId": "1a:3d:e1:bf:11:ed",
                        "name": "rename_device: iPhone_Edit",
                        "displayName": "rename_device: iPhone_Edit",
                        "status": "Offline",
                        "displayStatus": "Offline",
                        "connectedNetwork": "Primary",
                        "connectedDeviceType": "Desktop/Laptop",
                        "deviceConnectedVia": "Router",
                        "parentalControlId": "3ca265b8-cc13-11ef-8065-ac919bb0d38e",
                        "individualParentalControls": false,
                        "blocked": false,
                        "connectionType": "wireless",
                        "location": "",
                        "assigned": true,
                        "deviceGroupName": "UAT group",
                        "band": "2.4GHz",
                        "authMode": "WPA2-Personal",
                        "hostName": "iPhone",
                        "leaseType": "DHCP",
                        "bcsStatus": "Inactive"
                    },
                    {
                        "deviceId": "3",
                        "ipAddress": "192.168.1.154",
                        "macId": "22:e7:b0:58:92:99",
                        "name": "iPhone UAT",
                        "displayName": "iPhone UAT",
                        "status": "Online",
                        "displayStatus": "Strong Wi-Fi",
                        "connectedNetwork": "Primary",
                        "connectedDeviceType": "Phone",
                        "deviceConnectedVia": "Router",
                        "wifiStrength": "S",
                        "connectedSSID": "Verizon_PLZXJ4",
                        "individualParentalControls": false,
                        "blocked": false,
                        "connectionType": "wireless",
                        "location": "Family Room",
                        "assigned": false,
                        "band": "5GHz-full-band",
                        "authMode": "WPA2-Personal",
                        "rssi": "-65 dBm",
                        "phyRate": "6Mbps",
                        "hostName": "iPhone",
                        "leaseType": "DHCP",
                        "protocol": "802.11AX",
                        "bcsStatus": "Active"
                    },
                    {
                        "deviceId": "4",
                        "ipAddress": "192.168.1.154",
                        "macId": "8e:02:65:c2:68:69",
                        "name": "unknown_8e:02:65:c2:68:69",
                        "displayName": "rename_device: 8E:02:65:C2:68:69",
                        "status": "Offline",
                        "displayStatus": "Offline",
                        "connectedNetwork": "Primary",
                        "connectedDeviceType": "Desktop/Laptop",
                        "deviceConnectedVia": "Router",
                        "individualParentalControls": false,
                        "blocked": false,
                        "connectionType": "wireless",
                        "location": "",
                        "assigned": false,
                        "band": "2.4GHz",
                        "authMode": "None",
                        "hostName": "unknown_8e:02:65:c2:68:69",
                        "leaseType": "DHCP",
                        "bcsStatus": "Inactive"
                    },
                    {
                        "deviceId": "5",
                        "ipAddress": "192.168.1.155",
                        "macId": "a2:77:ee:d8:9c:00",
                        "name": "Galaxy-Note10-5G",
                        "displayName": "Galaxy-Note10-5G",
                        "status": "Online",
                        "displayStatus": "Strong Wi-Fi",
                        "connectedNetwork": "Primary",
                        "connectedDeviceType": "Phone",
                        "deviceConnectedVia": "Router",
                        "wifiStrength": "S",
                        "connectedSSID": "Verizon_PLZXJ4",
                        "parentalControlId": "a92f15c2-9dde-11ef-b251-ac919bb0d38e",
                        "individualParentalControls": false,
                        "blocked": false,
                        "connectionType": "wireless",
                        "location": "",
                        "assigned": true,
                        "deviceGroupName": "Regression testing",
                        "band": "5GHz-full-band",
                        "authMode": "WPA2-Personal",
                        "rssi": "-67 dBm",
                        "phyRate": "864Mbps",
                        "hostName": "Galaxy-Note10-5G",
                        "leaseType": "DHCP",
                        "protocol": "802.11AX",
                        "bcsStatus": "Active"
                    },
                    {
                        "deviceId": "6",
                        "ipAddress": "192.168.1.152",
                        "macId": "cc:a1:2b:e8:a5:94",
                        "name": "AjinkyasTCLRokuTV",
                        "displayName": "AjinkyasTCLRokuTV",
                        "status": "Online",
                        "displayStatus": "Ethernet",
                        "connectedNetwork": "Primary",
                        "connectedDeviceType": "Desktop/Laptop",
                        "deviceConnectedVia": "Router",
                        "individualParentalControls": false,
                        "blocked": false,
                        "connectionType": "wired",
                        "location": "Living Room",
                        "assigned": false,
                        "band": "Ethernet",
                        "authMode": "WPA2-Personal",
                        "hostName": "AjinkyasTCLRokuTV",
                        "leaseType": "DHCP",
                        "bcsStatus": "Active"
                    },
                    {
                        "deviceId": "1",
                        "ipAddress": "192.168.0.11",
                        "macId": "bc:d7:d4:cd:80:8b",
                        "name": "unknown_da:bc:d7:d4:cd:80:8a",
                        "displayName": "rename_device: bc:d7:d4:cd:80:8a",
                        "status": "Offline",
                        "displayStatus": "Offline",
                        "connectedNetwork": "Primary",
                        "connectedDeviceType": "Other",
                        "deviceConnectedVia": "Router",
                        "wifiStrength": "S",
                        "connectedSSID": "FSpFF17t6r",
                        "individualParentalControls": false,
                        "blocked": false,
                        "connectionType": "wireless",
                        "assigned": true,
                        "deviceGroupName": "ROKU",
                        "band": "5GHz",
                        "rssi": "-40 dBm",
                        "snr": "-88",
                        "ipv6Address": [
                            "fe80::d8e5:ceff:fe4b:cb4b"
                        ],
                        "bcsStatus": "Inactive"
                    },
                    {
                        "deviceId": "1",
                        "ipAddress": "192.168.1.153",
                        "macId": "0a:97:ed:74:19:et",
                        "name": "LgTbfn23343",
                        "displayName": "LgTbfn23343",
                        "status": "Offline",
                        "displayStatus": "Offline",
                        "connectedNetwork": "Primary",
                        "connectedDeviceType": "Desktop/Laptop",
                        "deviceConnectedVia": "Router",
                        "parentalControlId": "3ca265b8-cc13-11ef-8065-ac919bb0d38e",
                        "individualParentalControls": false,
                        "blocked": false,
                        "connectionType": "wireless",
                        "location": "Living Room",
                        "assigned": true,
                        "deviceGroupName": "UAT group",
                        "band": "2.4GHz",
                        "authMode": "WPA2-Personal",
                        "hostName": "iPhone",
                        "leaseType": "DHCP",
                        "bcsStatus": "Inactive"
                    },
                    {
                        "deviceId": "2",
                        "ipAddress": "192.168.1.151",
                        "macId": "1a:3d:e1:bf:11:er",
                        "name": "rename_device: iPhone_Edit",
                        "displayName": "rename_device: iPhone_Edit",
                        "status": "Offline",
                        "displayStatus": "Offline",
                        "connectedNetwork": "Primary",
                        "connectedDeviceType": "Desktop/Laptop",
                        "deviceConnectedVia": "Router",
                        "parentalControlId": "3ca265b8-cc13-11ef-8065-ac919bb0d38e",
                        "individualParentalControls": false,
                        "blocked": false,
                        "connectionType": "wireless",
                        "location": "",
                        "assigned": true,
                        "deviceGroupName": "UAT group",
                        "band": "2.4GHz",
                        "authMode": "WPA2-Personal",
                        "hostName": "iPhone",
                        "leaseType": "DHCP",
                        "bcsStatus": "Inactive"
                    },
                    {
                        "deviceId": "3",
                        "ipAddress": "192.168.1.154",
                        "macId": "22:e7:b0:58:92:98",
                        "name": "iPhone UAT",
                        "displayName": "iPhone UAT",
                        "status": "Online",
                        "displayStatus": "Strong Wi-Fi",
                        "connectedNetwork": "Primary",
                        "connectedDeviceType": "Phone",
                        "deviceConnectedVia": "Router",
                        "wifiStrength": "S",
                        "connectedSSID": "Verizon_PLZXJ4",
                        "individualParentalControls": false,
                        "blocked": false,
                        "connectionType": "wireless",
                        "location": "Family Room",
                        "assigned": false,
                        "band": "5GHz-full-band",
                        "authMode": "WPA2-Personal",
                        "rssi": "-65 dBm",
                        "phyRate": "6Mbps",
                        "hostName": "iPhone",
                        "leaseType": "DHCP",
                        "protocol": "802.11AX",
                        "bcsStatus": "Active"
                    },
                    {
                        "deviceId": "4",
                        "ipAddress": "192.168.1.154",
                        "macId": "8e:02:65:c2:68:68",
                        "name": "unknown_8e:02:65:c2:68:69",
                        "displayName": "rename_device: 8E:02:65:C2:68:69",
                        "status": "Offline",
                        "displayStatus": "Offline",
                        "connectedNetwork": "Primary",
                        "connectedDeviceType": "Desktop/Laptop",
                        "deviceConnectedVia": "Router",
                        "individualParentalControls": false,
                        "blocked": false,
                        "connectionType": "wireless",
                        "location": "",
                        "assigned": false,
                        "band": "2.4GHz",
                        "authMode": "None",
                        "hostName": "unknown_8e:02:65:c2:68:69",
                        "leaseType": "DHCP",
                        "bcsStatus": "Inactive"
                    },
                    {
                        "deviceId": "5",
                        "ipAddress": "192.168.1.155",
                        "macId": "a2:77:ee:d8:9c:01",
                        "name": "Galaxy-Note10-5G",
                        "displayName": "Galaxy-Note10-5G",
                        "status": "Online",
                        "displayStatus": "Strong Wi-Fi",
                        "connectedNetwork": "Primary",
                        "connectedDeviceType": "Phone",
                        "deviceConnectedVia": "Router",
                        "wifiStrength": "S",
                        "connectedSSID": "Verizon_PLZXJ4",
                        "parentalControlId": "a92f15c2-9dde-11ef-b251-ac919bb0d38e",
                        "individualParentalControls": false,
                        "blocked": false,
                        "connectionType": "wireless",
                        "location": "",
                        "assigned": true,
                        "deviceGroupName": "Regression testing",
                        "band": "5GHz-full-band",
                        "authMode": "WPA2-Personal",
                        "rssi": "-67 dBm",
                        "phyRate": "864Mbps",
                        "hostName": "Galaxy-Note10-5G",
                        "leaseType": "DHCP",
                        "protocol": "802.11AX",
                        "bcsStatus": "Active"
                    },
                    {
                        "deviceId": "6",
                        "ipAddress": "192.168.1.152",
                        "macId": "cc:a1:2b:e8:a5:9h",
                        "name": "AjinkyasTCLRokuTV",
                        "displayName": "AjinkyasTCLRokuTV",
                        "status": "Online",
                        "displayStatus": "Ethernet",
                        "connectedNetwork": "Primary",
                        "connectedDeviceType": "Desktop/Laptop",
                        "deviceConnectedVia": "Router",
                        "individualParentalControls": false,
                        "blocked": false,
                        "connectionType": "wired",
                        "location": "Living Room",
                        "assigned": false,
                        "band": "Ethernet",
                        "authMode": "WPA2-Personal",
                        "hostName": "AjinkyasTCLRokuTV",
                        "leaseType": "DHCP",
                        "bcsStatus": "Active"
                    },
                    {
                        "deviceId": "4",
                        "ipAddress": "192.168.1.154",
                        "macId": "8e:02:65:c2:68:6g",
                        "name": "unknown_8e:02:65:c2:68:69",
                        "displayName": "rename_device: 8E:02:65:C2:68:69",
                        "status": "Offline",
                        "displayStatus": "Offline",
                        "connectedNetwork": "Primary",
                        "connectedDeviceType": "Desktop/Laptop",
                        "deviceConnectedVia": "Router",
                        "individualParentalControls": false,
                        "blocked": false,
                        "connectionType": "wireless",
                        "location": "",
                        "assigned": false,
                        "band": "2.4GHz",
                        "authMode": "None",
                        "hostName": "unknown_8e:02:65:c2:68:69",
                        "leaseType": "DHCP",
                        "bcsStatus": "Inactive"
                    },
                    {
                        "deviceId": "5",
                        "ipAddress": "192.168.1.155",
                        "macId": "a2:77:ee:d8:9c:07",
                        "name": "Galaxy-Note10-5G",
                        "displayName": "Galaxy-Note10-5G",
                        "status": "Online",
                        "displayStatus": "Strong Wi-Fi",
                        "connectedNetwork": "Primary",
                        "connectedDeviceType": "Phone",
                        "deviceConnectedVia": "Router",
                        "wifiStrength": "S",
                        "connectedSSID": "Verizon_PLZXJ4",
                        "parentalControlId": "a92f15c2-9dde-11ef-b251-ac919bb0d38e",
                        "individualParentalControls": false,
                        "blocked": false,
                        "connectionType": "wireless",
                        "location": "",
                        "assigned": true,
                        "deviceGroupName": "Regression testing",
                        "band": "5GHz-full-band",
                        "authMode": "WPA2-Personal",
                        "rssi": "-67 dBm",
                        "phyRate": "864Mbps",
                        "hostName": "Galaxy-Note10-5G",
                        "leaseType": "DHCP",
                        "protocol": "802.11AX",
                        "bcsStatus": "Active"
                    },
                    {
                        "deviceId": "6",
                        "ipAddress": "192.168.1.152",
                        "macId": "cc:a1:2b:e8:a5:96",
                        "name": "AjinkyasTCLRokuTV",
                        "displayName": "AjinkyasTCLRokuTV",
                        "status": "Online",
                        "displayStatus": "Ethernet",
                        "connectedNetwork": "Primary",
                        "connectedDeviceType": "Desktop/Laptop",
                        "deviceConnectedVia": "Router",
                        "individualParentalControls": false,
                        "blocked": false,
                        "connectionType": "wired",
                        "location": "Living Room",
                        "assigned": false,
                        "band": "Ethernet",
                        "authMode": "WPA2-Personal",
                        "hostName": "AjinkyasTCLRokuTV",
                        "leaseType": "DHCP",
                        "bcsStatus": "Active"
                    }
                ],
                "deviceGroups": [
                    {
                        "name": "ROKU",
                        "parentalControlId": "9a77b346-d6bd-11ef-83ce-4cabf8d39086",
                        "devices": [
                            "bc:d7:d4:cd:80:8a",
                            "d8:31:34:36:e7:24"
                        ]
                    },
                    {
                        "name": "MOBILE",
                        "parentalControlId": "b26512a0-d6bd-11ef-83ce-4cabf8d39086",
                        "devices": [
                            "3e:17:0e:d8:ad:90",
                            "b6:28:bc:f2:29:b5"
                        ]
                    },
                    {
                        "name": "Regression testing",
                        "parentalControlId": "a92f15c2-9dde-11ef-b251-ac919bb0d38e",
                        "devices": [
                            "a2:77:ee:d8:9c:00"
                        ]
                    },
                    {
                        "name": "UAT group",
                        "parentalControlId": "3ca265b8-cc13-11ef-8065-ac919bb0d38e",
                        "devices": [
                            "0a:97:ed:74:19:ef",
                            "1a:3d:e1:bf:11:ed"
                        ]
                    }
                ]
            }
        },
        {
            "sectionIndex": "1",
            "sectionId": "selectDevicesSection",
            "sectionType": null,
            "sectionComponentId": null,
            "sectionText": null,
            "dataUrl": null,
            "clickStream": null,
            "sections": [],
            "actions": [
                {
                    "actionKey": "navigateToGroupName",
                    "actionValue": "setDeviceGroupNameSection",
                    "actionType": "route",
                    "sectionKey": null,
                    "clickStream": null
                },
                {
                    "actionKey": "scheduleDowntime",
                    "actionValue": "scheduleDowntimeSection",
                    "actionType": "route",
                    "sectionKey": null,
                    "clickStream": null
                },
                {
                    "actionKey": "cancelGroupCreationModal",
                    "actionValue": "openCancelGroupCreationModal",
                    "actionType": "modal",
                    "sectionKey": null,
                    "clickStream": null
                }
            ],
            "contents": [
                {
                    "contentIndex": "0",
                    "contentComponentId": "groupNameLeft",
                    "contentType": null,
                    "contentActionId": null,
                    "clickStream": null,
                    "items": [
                        {
                            "itemKey": "selectDevicesEditModePageHeading",
                            "itemType": "headingText",
                            "itemValue": "Add or remove devices",
                            "itemAttributes": {}
                        },
                        {
                            "itemKey": "selectDevicesHeading",
                            "itemType": "headingText",
                            "itemValue": "Select or switch your devices.",
                            "itemAttributes": {}
                        },
                        {
                            "itemKey": "selectDevicesText",
                            "itemType": "text",
                            "itemValue": "Select unassigned devices or switch devices from another device group to this one. Each group can have up to 16 devices.",
                            "itemAttributes": {}
                        },
                        {
                            "itemKey": "sortDevices",
                            "itemType": "dropDown",
                            "itemValue": "Sort by:",
                            "itemAttributes": {
                                "listItems": "A-Z,Z-A"
                            }
                        },
                        {
                            "itemKey": "searchDevices",
                            "itemType": "searchBar",
                            "itemValue": "Search device",
                            "itemAttributes": {}
                        },
                        {
                            "itemKey": "selectDevicesSubText",
                            "itemType": "text",
                            "itemValue": "Assigned to ##GROUP_NAME##",
                            "itemAttributes": {
                                "itemValueOnSelect": "This device will be moved to the group: ##NEW_GROUP_NAME##",
                                "assigned": "true"
                            }
                        },
                        {
                            "itemKey": "selectDevicesBackButton",
                            "itemType": "button",
                            "itemValue": "Back",
                            "actionKey": "scheduleDowntime",
                            "itemAttributes": {
                                "style": "white"
                            }
                        },
                        {
                            "itemKey": "selectDevicesNextButton",
                            "itemType": "button",
                            "itemValue": "Next",
                            "actionKey": "scheduleDowntime",
                            "itemAttributes": {
                                "style": "black"
                            }
                        },
                        {
                            "itemKey": "selectDevicesAddButton",
                            "itemType": "button",
                            "itemValue": "Add",
                            "actionKey": null,
                            "itemAttributes": {
                                "style": "black"
                            }
                        },
                        {
                            "itemKey": "cancelSelectDevices",
                            "itemType": "link",
                            "itemValue": "Cancel",
                            "actionKey": "cancelGroupCreationModal",
                            "itemAttributes": {}
                        }
                    ]
                }
            ],
            "data": {}
        },
        {
            "sectionIndex": "2",
            "sectionId": "scheduleDowntimeSection",
            "sectionType": null,
            "sectionComponentId": null,
            "sectionText": null,
            "dataUrl": null,
            "clickStream": null,
            "sections": [],
            "actions": [
                {
                    "actionKey": "cancelGroupCreationModal",
                    "actionValue": "openCancelGroupCreationModal",
                    "actionType": "modal",
                    "sectionKey": null,
                    "clickStream": null
                }
            ],
            "contents": [
                {
                    "contentIndex": "0",
                    "contentComponentId": "setScheduleComponent",
                    "contentType": null,
                    "contentActionId": null,
                    "clickStream": null,
                    "items": [
                        {
                            "itemKey": "setScheduleHeading",
                            "itemType": "headingText",
                            "itemValue": "Set a downtime schedule.",
                            "itemAttributes": {
                                "edit": "Edit downtime schedule"
                            }
                        },
                        {
                            "itemKey": "setScheduleDesc",
                            "itemType": "text",
                            "itemValue": "Select recurring days and times to pause internet access on the devices in this group. You can make exceptions for certain websites later or create multiple downtime schedules.",
                            "itemAttributes": {}
                        },
                        {
                            "itemKey": "setScheduleDayChips",
                            "itemType": "chip",
                            "itemValue": "Select one or multiple days",
                            "itemAttributes": {
                                "ddotValues": "Sun,Mon,Tue,Wed,Thu,Fri,Sat",
                                "mdotValues": "Su,Mo,Tu,We,Th,Fr,Sa"
                            }
                        },
                        {
                            "itemKey": "startTimeDropDown",
                            "itemType": "dropDown",
                            "itemValue": "Start time",
                            "itemAttributes": {
                                "mdotText": "Start"
                            }
                        },
                        {
                            "itemKey": "setScheduleTimeRadioButtons",
                            "itemType": "radioButton",
                            "itemValue": "",
                            "itemAttributes": {
                                "radioButtonItems": "AM,PM"
                            }
                        },
                        {
                            "itemKey": "endTimeDropDown",
                            "itemType": "dropDown",
                            "itemValue": "End time",
                            "itemAttributes": {
                                "mdotText": "End"
                            }
                        },
                        {
                            "itemKey": "clearSchedule",
                            "itemType": "link",
                            "itemValue": "Clear schedule",
                            "itemAttributes": {}
                        },
                        {
                            "itemKey": "setScheduleBackButton",
                            "itemType": "button",
                            "itemValue": "Back",
                            "actionKey": null,
                            "itemAttributes": {
                                "style": "white"
                            }
                        },
                        {
                            "itemKey": "setScheduleSkipButton",
                            "itemType": "button",
                            "itemValue": "Skip",
                            "actionKey": null,
                            "itemAttributes": {
                                "style": "black"
                            }
                        },
                        {
                            "itemKey": "setScheduleNextButton",
                            "itemType": "button",
                            "itemValue": "Next",
                            "actionKey": null,
                            "itemAttributes": {
                                "style": "black"
                            }
                        },
                        {
                            "itemKey": "setScheduleSaveButton",
                            "itemType": "button",
                            "itemValue": "Save",
                            "actionKey": null,
                            "itemAttributes": {
                                "style": "black"
                            }
                        },
                        {
                            "itemKey": "setScheduleCancelButton",
                            "itemType": "link",
                            "itemValue": "Cancel",
                            "actionKey": "cancelGroupCreationModal",
                            "itemAttributes": {}
                        }
                    ]
                },
                {
                    "contentIndex": "1",
                    "contentComponentId": "setScheduleSummaryPane",
                    "contentType": null,
                    "contentActionId": null,
                    "clickStream": null,
                    "items": [
                        {
                            "itemKey": "selectedDevicesHeading",
                            "itemType": "text",
                            "itemValue": "Selected devices",
                            "itemAttributes": {}
                        }
                    ]
                }
            ],
            "data": {}
        },
        {
            "sectionIndex": "3",
            "sectionId": "addExceptionsSection",
            "sectionType": null,
            "sectionComponentId": null,
            "sectionText": null,
            "dataUrl": null,
            "clickStream": null,
            "sections": [],
            "actions": [
                {
                    "actionKey": "cancelGroupCreationModal",
                    "actionValue": "openCancelGroupCreationModal",
                    "actionType": "modal",
                    "sectionKey": null,
                    "clickStream": null
                }
            ],
            "contents": [
                {
                    "contentIndex": "0",
                    "contentComponentId": "addExceptionsComponent",
                    "contentType": null,
                    "contentActionId": null,
                    "clickStream": null,
                    "items": [
                        {
                            "itemKey": "addExceptionsHeading",
                            "itemType": "headingText",
                            "itemValue": "Websites allowed during downtime",
                            "itemAttributes": {
                                "edit": "Add allowed websites"
                            }
                        },
                        {
                            "itemKey": "addExceptionsDesc",
                            "itemType": "text",
                            "itemValue": "Allow access to certain websites during downtime.",
                            "itemAttributes": {
                                "edit": "These websites can be accessed even during downtime."
                            }
                        },
                        {
                            "itemKey": "addExceptionsText",
                            "itemType": "text",
                            "itemValue": "During downtime, do you want to allow access to certain websites?",
                            "itemAttributes": {}
                        },
                        {
                            "itemKey": "addExceptionsInput",
                            "itemType": "textBox",
                            "itemValue": "Add websites",
                            "itemAttributes": {
                                "helperText": "Example: www.verizon.com",
                                "helperTextOnError": "Please input website only, not webpage address.",
                                "itemLinkOnAdd": "Remove ??TBD??"
                            }
                        },
                        {
                            "itemKey": "removeAllExceptionsButton",
                            "itemType": "link",
                            "itemValue": "Remove all",
                            "actionKey": null,
                            "itemAttributes": {}
                        },
                        {
                            "itemKey": "addExceptionsBackButton",
                            "itemType": "button",
                            "itemValue": "Back",
                            "actionKey": null,
                            "itemAttributes": {
                                "style": "white"
                            }
                        },
                        {
                            "itemKey": "addExceptionsSkipButton",
                            "itemType": "button",
                            "itemValue": "Skip",
                            "actionKey": null,
                            "itemAttributes": {
                                "style": "black"
                            }
                        },
                        {
                            "itemKey": "addExceptionsNextButton",
                            "itemType": "button",
                            "itemValue": "Next",
                            "actionKey": null,
                            "itemAttributes": {
                                "style": "black"
                            }
                        },
                        {
                            "itemKey": "addExceptionsSaveButton",
                            "itemType": "button",
                            "itemValue": "Save",
                            "actionKey": null,
                            "itemAttributes": {
                                "style": "black"
                            }
                        },
                        {
                            "itemKey": "addExceptionsCancelButton",
                            "itemType": "link",
                            "itemValue": "Cancel",
                            "actionKey": "cancelGroupCreationModal",
                            "itemAttributes": {}
                        }
                    ]
                },
                {
                    "contentIndex": "1",
                    "contentComponentId": "addExceptionsSummaryPane",
                    "contentType": null,
                    "contentActionId": null,
                    "clickStream": null,
                    "items": [
                        {
                            "itemKey": "selectedDevicesHeading",
                            "itemType": "text",
                            "itemValue": "Selected devices",
                            "itemAttributes": {}
                        },
                        {
                            "itemKey": "downtimeScheduleHeading",
                            "itemType": "text",
                            "itemValue": "Downtime schedule",
                            "itemAttributes": {}
                        }
                    ]
                }
            ],
            "data": {}
        },
        {
            "sectionIndex": "4",
            "sectionId": "reviewGroupSection",
            "sectionType": null,
            "sectionComponentId": null,
            "sectionText": null,
            "dataUrl": null,
            "clickStream": null,
            "sections": [],
            "actions": [
                {
                    "actionKey": "removeDeviceModal",
                    "actionValue": "openRemoveDeviceModal",
                    "actionType": "modal",
                    "sectionKey": null,
                    "clickStream": null
                },
                {
                    "actionKey": "removeAllDevicesModal",
                    "actionValue": "openRemoveAllDevicesModal",
                    "actionType": "modal",
                    "sectionKey": null,
                    "clickStream": null
                },
                {
                    "actionKey": "removeWebsiteModal",
                    "actionValue": "openRemoveWebsiteModal",
                    "actionType": "modal",
                    "sectionKey": null,
                    "clickStream": null
                },
                {
                    "actionKey": "removeAllWebsitesModal",
                    "actionValue": "openRemoveAllWebsitesModal",
                    "actionType": "modal",
                    "sectionKey": null,
                    "clickStream": null
                }
            ],
            "contents": [
                {
                    "contentIndex": "0",
                    "contentComponentId": "reviewGroupName",
                    "contentType": null,
                    "contentActionId": null,
                    "clickStream": null,
                    "items": [
                        {
                            "itemKey": "reviewGroupNameHeading",
                            "itemType": "headingText",
                            "itemValue": "Review ##GROUP_NAME## details.",
                            "itemAttributes": {}
                        },
                        {
                            "itemKey": "reviewGroupNameText",
                            "itemType": "text",
                            "itemValue": "Review the details for your device group before you create it.",
                            "itemAttributes": {}
                        },
                        {
                            "itemKey": "reviewGroupNameInput",
                            "itemType": "textBox",
                            "itemValue": "Group name",
                            "itemAttributes": {
                                "maximumCharacters": "64"
                            }
                        }
                    ]
                },
                {
                    "contentIndex": "1",
                    "contentComponentId": "reviewSelectedDevices",
                    "contentType": null,
                    "contentActionId": null,
                    "clickStream": null,
                    "items": [
                        {
                            "itemKey": "reviewSelectedDevicesHeading",
                            "itemType": "headingText",
                            "itemValue": "Selected devices",
                            "itemAttributes": {}
                        },
                        {
                            "itemKey": "removeDeviceLink",
                            "itemType": "link",
                            "itemValue": "Remove",
                            "actionKey": "removeDeviceModal",
                            "itemAttributes": {}
                        },
                        {
                            "itemKey": "addDevicesLink",
                            "itemType": "link",
                            "itemValue": "Add devices",
                            "actionKey": null,
                            "itemAttributes": {}
                        },
                        {
                            "itemKey": "removeAllDevicesLink",
                            "itemType": "link",
                            "itemValue": "Remove all",
                            "actionKey": "removeAllDevicesModal",
                            "itemAttributes": {}
                        },
                        {
                            "itemKey": "selectedDevicesEmptyStateText",
                            "itemType": "text",
                            "itemValue": "No selected devices yet. Please add devices to this group to manage downtime schedule and website exceptions.",
                            "itemAttributes": {}
                        }
                    ]
                },
                {
                    "contentIndex": "2",
                    "contentComponentId": "reviewDowntimeSchedule",
                    "contentType": null,
                    "contentActionId": null,
                    "clickStream": null,
                    "items": [
                        {
                            "itemKey": "reviewDowntimeScheduleHeading",
                            "itemType": "headingText",
                            "itemValue": "Downtime schedule",
                            "itemAttributes": {}
                        },
                        {
                            "itemKey": "scheduleDowntimeLink",
                            "itemType": "link",
                            "itemValue": "Edit schedule",
                            "actionKey": null,
                            "itemAttributes": {
                                "itemValueOnEmpty": "Set schedule"
                            }
                        },
                        {
                            "itemKey": "downtimeScheduleEmptyStateText",
                            "itemType": "text",
                            "itemValue": "No downtime schedule yet.",
                            "itemAttributes": {}
                        }
                    ]
                },
                {
                    "contentIndex": "3",
                    "contentComponentId": "reviewWebsiteExceptions",
                    "contentType": null,
                    "contentActionId": null,
                    "clickStream": null,
                    "items": [
                        {
                            "itemKey": "reviewWebsiteExceptionsHeading",
                            "itemType": "headingText",
                            "itemValue": "Websites allowed during downtime",
                            "itemAttributes": {}
                        },
                        {
                            "itemKey": "removeExceptionLink",
                            "itemType": "link",
                            "itemValue": "Remove",
                            "actionKey": "removeWebsiteModal",
                            "itemAttributes": {}
                        },
                        {
                            "itemKey": "addExceptionLink",
                            "itemType": "link",
                            "itemValue": "Add websites",
                            "actionKey": null,
                            "itemAttributes": {}
                        },
                        {
                            "itemKey": "removeAllExceptionsLink",
                            "itemType": "link",
                            "itemValue": "Remove all",
                            "actionKey": "removeAllWebsitesModal",
                            "itemAttributes": {}
                        },
                        {
                            "itemKey": "websiteExceptionsEmptyStateText",
                            "itemType": "text",
                            "itemValue": "No website exceptions yet.",
                            "itemAttributes": {}
                        },
                        {
                            "itemKey": "websiteExceptionsWithoutScheduleText",
                            "itemType": "text",
                            "itemValue": "Please set downtime schedule to add website exceptions",
                            "itemAttributes": {}
                        }
                    ]
                },
                {
                    "contentIndex": "4",
                    "contentComponentId": "reviewGroupButtons",
                    "contentType": null,
                    "contentActionId": null,
                    "clickStream": null,
                    "items": [
                        {
                            "itemKey": "reviewGroupBackButton",
                            "itemType": "button",
                            "itemValue": "Back",
                            "itemAttributes": {
                                "style": "white"
                            }
                        },
                        {
                            "itemKey": "reviewGroupCreateButton",
                            "itemType": "button",
                            "itemValue": "Create",
                            "actionKey": null,
                            "itemAttributes": {
                                "style": "black"
                            }
                        },
                        {
                            "itemKey": "reviewGroupCancelLink",
                            "itemType": "link",
                            "itemValue": "Cancel",
                            "actionKey": "cancelGroupCreationModal",
                            "itemAttributes": {}
                        }
                    ]
                }
            ],
            "data": {}
        },
        {
            "sectionIndex": "5",
            "sectionId": "createDeviceGroupModalSection",
            "sectionType": null,
            "sectionComponentId": null,
            "sectionText": null,
            "dataUrl": null,
            "clickStream": null,
            "sections": [],
            "actions": [],
            "contents": [
                {
                    "contentIndex": "0",
                    "contentComponentId": "cancelGroupCreationModal",
                    "contentType": null,
                    "contentActionId": null,
                    "clickStream": null,
                    "items": [
                        {
                            "itemKey": "cancelGroupCreationHeading",
                            "itemType": "headingText",
                            "itemValue": "Are you sure you want to cancel creating your device group?",
                            "itemAttributes": {}
                        },
                        {
                            "itemKey": "cancelGroupCreationText",
                            "itemType": "text",
                            "itemValue": "You'll lose all the progress you've made so far.",
                            "itemAttributes": {}
                        },
                        {
                            "itemKey": "backBtn",
                            "itemType": "button",
                            "itemValue": "Back",
                            "itemAttributes": {
                                "style": "black"
                            }
                        },
                        {
                            "itemKey": "confirmBtn",
                            "itemType": "button",
                            "itemValue": "Confirm",
                            "itemAttributes": {
                                "style": "white"
                            }
                        }
                    ]
                },
                {
                    "contentIndex": "1",
                    "contentComponentId": "removeDeviceModal",
                    "contentType": null,
                    "contentActionId": null,
                    "clickStream": null,
                    "items": [
                        {
                            "itemKey": "removeDeviceHeading",
                            "itemType": "headingText",
                            "itemValue": "Are you sure you want to remove this device?",
                            "itemAttributes": {}
                        },
                        {
                            "itemKey": "removeDeviceText",
                            "itemType": "text",
                            "itemValue": "Devices can always be added back later.",
                            "itemAttributes": {}
                        },
                        {
                            "itemKey": "removeDeviceConfirmButton",
                            "itemType": "button",
                            "itemValue": "Remove",
                            "itemAttributes": {
                                "style": "black"
                            }
                        },
                        {
                            "itemKey": "removeDeviceCancelButton",
                            "itemType": "button",
                            "itemValue": "Cancel",
                            "itemAttributes": {
                                "style": "white"
                            }
                        }
                    ]
                },
                {
                    "contentIndex": "2",
                    "contentComponentId": "removeAllDevicesModal",
                    "contentType": null,
                    "contentActionId": null,
                    "clickStream": null,
                    "items": [
                        {
                            "itemKey": "removeAllDevicesHeading",
                            "itemType": "headingText",
                            "itemValue": "Are you sure you want to remove all devices from this group?",
                            "itemAttributes": {}
                        },
                        {
                            "itemKey": "removeAllDevicesConfirmButton",
                            "itemType": "button",
                            "itemValue": "Remove all devices",
                            "itemAttributes": {
                                "style": "black"
                            }
                        },
                        {
                            "itemKey": "removeAllDevicesCancelButton",
                            "itemType": "button",
                            "itemValue": "Cancel",
                            "itemAttributes": {
                                "style": "white"
                            }
                        }
                    ]
                },
                {
                    "contentIndex": "3",
                    "contentComponentId": "removeWebsiteModal",
                    "contentType": null,
                    "contentActionId": null,
                    "clickStream": null,
                    "items": [
                        {
                            "itemKey": "removeWebsiteHeading",
                            "itemType": "headingText",
                            "itemValue": "Are you sure you want to remove this allowed website?",
                            "itemAttributes": {}
                        },
                        {
                            "itemKey": "removeWebsiteConfirmButton",
                            "itemType": "button",
                            "itemValue": "Remove website",
                            "itemAttributes": {
                                "style": "black"
                            }
                        },
                        {
                            "itemKey": "removeWebsiteCancelButton",
                            "itemType": "button",
                            "itemValue": "Cancel",
                            "itemAttributes": {
                                "style": "white"
                            }
                        }
                    ]
                },
                {
                    "contentIndex": "4",
                    "contentComponentId": "removeAllWebsitesModal",
                    "contentType": null,
                    "contentActionId": null,
                    "clickStream": null,
                    "items": [
                        {
                            "itemKey": "removeAllWebsitesHeading",
                            "itemType": "headingText",
                            "itemValue": "Are you sure you want to remove all allowed websites?",
                            "itemAttributes": {}
                        },
                        {
                            "itemKey": "removeAllWebsitesConfirmButton",
                            "itemType": "button",
                            "itemValue": "Remove all websites",
                            "itemAttributes": {
                                "style": "black"
                            }
                        },
                        {
                            "itemKey": "removeAllWebsitesCancelButton",
                            "itemType": "button",
                            "itemValue": "Cancel",
                            "itemAttributes": {
                                "style": "white"
                            }
                        }
                    ]
                }
            ],
            "data": {}
        },
        {
            "sectionIndex": "6",
            "sectionId": "createDeviceGroupStaticSection",
            "sectionType": null,
            "sectionComponentId": null,
            "sectionText": null,
            "dataUrl": null,
            "clickStream": null,
            "sections": [],
            "actions": [],
            "contents": [
                {
                    "contentIndex": "0",
                    "contentComponentId": "deviceGroupInfoMessages",
                    "contentType": null,
                    "contentActionId": null,
                    "clickStream": null,
                    "items": [
                        {
                            "itemKey": "selectDevicesLimitNotification",
                            "itemType": "text",
                            "itemValue": "You've reached the maximum amount of devices per group",
                            "itemAttributes": {}
                        }
                    ]
                },
                {
                    "contentIndex": "1",
                    "contentComponentId": "deviceGroupErrorMessages",
                    "contentType": null,
                    "contentActionId": null,
                    "clickStream": null,
                    "items": [
                        {
                            "itemKey": "createGroupErrorMessageRouter",
                            "itemType": "text",
                            "itemValue": "We are having issues connecting to the router. Please make sure the router is connected to the internet.",
                            "itemAttributes": {}
                        }
                    ]
                }
            ],
            "data": {}
        }
    ]
};

export const deviceGroupDetailsData = {
    "pageAttributes": [
      {
        "itemKey": "pageTitle",
        "itemValue": "Create a device group"
      },
      {
        "itemKey": "subTitle",
        "itemValue": "Device groups allow you to set parental or other controls on multiple devices at once."
      },
      {
        "itemKey": "breadCrumbDeviceGroup",
        "itemValue": "Device group"
      }
    ],
    "sections": [
      {
        "sectionIndex": "0",
        "sectionId": "setDeviceGroupNameSection",
        "actions": [
          {
            "actionType": "modal",
            "actionValue": "openCancelGroupCreationModal",
            "actionKey": "cancelGroupCreationModal"
          },
          {
            "actionType": "route",
            "actionValue": "selectDevicesSection",
            "actionKey": "navigateToSelectDevices"
          }
        ],
        "contents": [
          {
            "contentIndex": "0",
            "contentComponentId": "groupNameComponent",
            "items": [
              {
                "itemKey": "groupNameHeading",
                "itemType": "headingText",
                "itemValue": "Enter a name for this device group.",
                "itemAttributes": {}
              },
              {
                "itemKey": "groupNameInput",
                "itemType": "textBox",
                "itemValue": "Device group name",
                "itemAttributes": {
                  "maximumCharacters": "64"
                }
              },
              {
                "itemKey": "groupNameCancelButton",
                "itemType": "button",
                "itemValue": "Cancel",
                "itemAttributes": {
                  "style": "white"
                },
                "actionKey": "cancelGroupCreationModal"
              },
              {
                "itemKey": "groupNameNextButton",
                "itemType": "button",
                "itemValue": "Next",
                "itemAttributes": {
                  "style": "black"
                },
                "actionKey": "navigateToSelectDevices"
              }
            ]
          }
        ],
        "data": {
             "connectedDevices": [
                 {
                     "deviceId": "1",
                     "ipAddress": "192.168.0.11",
                     "macId": "bc:d7:d4:cd:80:8a",
                     "name": "unknown_da:bc:d7:d4:cd:80:8a",
                     "displayName": "rename_device: bc:d7:d4:cd:80:8a",
                     "status": "Offline",
                     "displayStatus": "Offline",
                     "connectedNetwork": "Primary",
                     "connectedDeviceType": "Other",
                     "deviceConnectedVia": "Router",
                     "wifiStrength": "S",
                     "connectedSSID": "FSpFF17t6r",
                     "individualParentalControls": false,
                     "blocked": false,
                     "connectionType": "wireless",
                     "assigned": true,
                     "deviceGroupName": "ROKU",
                     "band": "5GHz",
                     "rssi": "-40 dBm",
                     "snr": "-88",
                     "ipv6Address": [
                         "fe80::d8e5:ceff:fe4b:cb4b"
                     ],
                     "bcsStatus": "Inactive"
                 },
                 {
                     "deviceId": "1",
                     "ipAddress": "192.168.1.153",
                     "macId": "0a:97:ed:74:19:ef",
                     "name": "LgTbfn23343",
                     "displayName": "LgTbfn23343",
                     "status": "Offline",
                     "displayStatus": "Offline",
                     "connectedNetwork": "Primary",
                     "connectedDeviceType": "Desktop/Laptop",
                     "deviceConnectedVia": "Router",
                     "parentalControlId": "3ca265b8-cc13-11ef-8065-ac919bb0d38e",
                     "individualParentalControls": false,
                     "blocked": false,
                     "connectionType": "wireless",
                     "location": "Living Room",
                     "assigned": true,
                     "deviceGroupName": "UAT group",
                     "band": "2.4GHz",
                     "authMode": "WPA2-Personal",
                     "hostName": "iPhone",
                     "leaseType": "DHCP",
                     "bcsStatus": "Inactive"
                 },
                 {
                     "deviceId": "2",
                     "ipAddress": "192.168.1.151",
                     "macId": "1a:3d:e1:bf:11:ed",
                     "name": "rename_device: iPhone_Edit",
                     "displayName": "rename_device: iPhone_Edit",
                     "status": "Offline",
                     "displayStatus": "Offline",
                     "connectedNetwork": "Primary",
                     "connectedDeviceType": "Desktop/Laptop",
                     "deviceConnectedVia": "Router",
                     "parentalControlId": "3ca265b8-cc13-11ef-8065-ac919bb0d38e",
                     "individualParentalControls": false,
                     "blocked": false,
                     "connectionType": "wireless",
                     "location": "",
                     "assigned": true,
                     "deviceGroupName": "UAT group",
                     "band": "2.4GHz",
                     "authMode": "WPA2-Personal",
                     "hostName": "iPhone",
                     "leaseType": "DHCP",
                     "bcsStatus": "Inactive"
                 },
                 {
                     "deviceId": "3",
                     "ipAddress": "192.168.1.154",
                     "macId": "22:e7:b0:58:92:99",
                     "name": "iPhone UAT",
                     "displayName": "iPhone UAT",
                     "status": "Online",
                     "displayStatus": "Strong Wi-Fi",
                     "connectedNetwork": "Primary",
                     "connectedDeviceType": "Phone",
                     "deviceConnectedVia": "Router",
                     "wifiStrength": "S",
                     "connectedSSID": "Verizon_PLZXJ4",
                     "individualParentalControls": false,
                     "blocked": false,
                     "connectionType": "wireless",
                     "location": "Family Room",
                     "assigned": false,
                     "band": "5GHz-full-band",
                     "authMode": "WPA2-Personal",
                     "rssi": "-65 dBm",
                     "phyRate": "6Mbps",
                     "hostName": "iPhone",
                     "leaseType": "DHCP",
                     "protocol": "802.11AX",
                     "bcsStatus": "Active"
                 },
                 {
                     "deviceId": "4",
                     "ipAddress": "192.168.1.154",
                     "macId": "8e:02:65:c2:68:69",
                     "name": "unknown_8e:02:65:c2:68:69",
                     "displayName": "rename_device: 8E:02:65:C2:68:69",
                     "status": "Offline",
                     "displayStatus": "Offline",
                     "connectedNetwork": "Primary",
                     "connectedDeviceType": "Desktop/Laptop",
                     "deviceConnectedVia": "Router",
                     "individualParentalControls": false,
                     "blocked": false,
                     "connectionType": "wireless",
                     "location": "",
                     "assigned": false,
                     "band": "2.4GHz",
                     "authMode": "None",
                     "hostName": "unknown_8e:02:65:c2:68:69",
                     "leaseType": "DHCP",
                     "bcsStatus": "Inactive"
                 },
                 {
                     "deviceId": "5",
                     "ipAddress": "192.168.1.155",
                     "macId": "a2:77:ee:d8:9c:00",
                     "name": "Galaxy-Note10-5G",
                     "displayName": "Galaxy-Note10-5G",
                     "status": "Online",
                     "displayStatus": "Strong Wi-Fi",
                     "connectedNetwork": "Primary",
                     "connectedDeviceType": "Phone",
                     "deviceConnectedVia": "Router",
                     "wifiStrength": "S",
                     "connectedSSID": "Verizon_PLZXJ4",
                     "parentalControlId": "a92f15c2-9dde-11ef-b251-ac919bb0d38e",
                     "individualParentalControls": false,
                     "blocked": false,
                     "connectionType": "wireless",
                     "location": "",
                     "assigned": true,
                     "deviceGroupName": "Regression testing",
                     "band": "5GHz-full-band",
                     "authMode": "WPA2-Personal",
                     "rssi": "-67 dBm",
                     "phyRate": "864Mbps",
                     "hostName": "Galaxy-Note10-5G",
                     "leaseType": "DHCP",
                     "protocol": "802.11AX",
                     "bcsStatus": "Active"
                 },
                 {
                     "deviceId": "6",
                     "ipAddress": "192.168.1.152",
                     "macId": "cc:a1:2b:e8:a5:94",
                     "name": "AjinkyasTCLRokuTV",
                     "displayName": "AjinkyasTCLRokuTV",
                     "status": "Online",
                     "displayStatus": "Ethernet",
                     "connectedNetwork": "Primary",
                     "connectedDeviceType": "Desktop/Laptop",
                     "deviceConnectedVia": "Router",
                     "individualParentalControls": false,
                     "blocked": false,
                     "connectionType": "wired",
                     "location": "Living Room",
                     "assigned": false,
                     "band": "Ethernet",
                     "authMode": "WPA2-Personal",
                     "hostName": "AjinkyasTCLRokuTV",
                     "leaseType": "DHCP",
                     "bcsStatus": "Active"
                 },
                 {
                     "deviceId": "1",
                     "ipAddress": "192.168.0.11",
                     "macId": "bc:d7:d4:cd:80:8b",
                     "name": "unknown_da:bc:d7:d4:cd:80:8a",
                     "displayName": "rename_device: bc:d7:d4:cd:80:8a",
                     "status": "Offline",
                     "displayStatus": "Offline",
                     "connectedNetwork": "Primary",
                     "connectedDeviceType": "Other",
                     "deviceConnectedVia": "Router",
                     "wifiStrength": "S",
                     "connectedSSID": "FSpFF17t6r",
                     "individualParentalControls": false,
                     "blocked": false,
                     "connectionType": "wireless",
                     "assigned": true,
                     "deviceGroupName": "ROKU",
                     "band": "5GHz",
                     "rssi": "-40 dBm",
                     "snr": "-88",
                     "ipv6Address": [
                         "fe80::d8e5:ceff:fe4b:cb4b"
                     ],
                     "bcsStatus": "Inactive"
                 },
                 {
                     "deviceId": "1",
                     "ipAddress": "192.168.1.153",
                     "macId": "0a:97:ed:74:19:et",
                     "name": "LgTbfn23343",
                     "displayName": "LgTbfn23343",
                     "status": "Offline",
                     "displayStatus": "Offline",
                     "connectedNetwork": "Primary",
                     "connectedDeviceType": "Desktop/Laptop",
                     "deviceConnectedVia": "Router",
                     "parentalControlId": "3ca265b8-cc13-11ef-8065-ac919bb0d38e",
                     "individualParentalControls": false,
                     "blocked": false,
                     "connectionType": "wireless",
                     "location": "Living Room",
                     "assigned": true,
                     "deviceGroupName": "UAT group",
                     "band": "2.4GHz",
                     "authMode": "WPA2-Personal",
                     "hostName": "iPhone",
                     "leaseType": "DHCP",
                     "bcsStatus": "Inactive"
                 },
                 {
                     "deviceId": "2",
                     "ipAddress": "192.168.1.151",
                     "macId": "1a:3d:e1:bf:11:er",
                     "name": "rename_device: iPhone_Edit",
                     "displayName": "rename_device: iPhone_Edit",
                     "status": "Offline",
                     "displayStatus": "Offline",
                     "connectedNetwork": "Primary",
                     "connectedDeviceType": "Desktop/Laptop",
                     "deviceConnectedVia": "Router",
                     "parentalControlId": "3ca265b8-cc13-11ef-8065-ac919bb0d38e",
                     "individualParentalControls": false,
                     "blocked": false,
                     "connectionType": "wireless",
                     "location": "",
                     "assigned": true,
                     "deviceGroupName": "UAT group",
                     "band": "2.4GHz",
                     "authMode": "WPA2-Personal",
                     "hostName": "iPhone",
                     "leaseType": "DHCP",
                     "bcsStatus": "Inactive"
                 },
                 {
                     "deviceId": "3",
                     "ipAddress": "192.168.1.154",
                     "macId": "22:e7:b0:58:92:98",
                     "name": "iPhone UAT",
                     "displayName": "iPhone UAT",
                     "status": "Online",
                     "displayStatus": "Strong Wi-Fi",
                     "connectedNetwork": "Primary",
                     "connectedDeviceType": "Phone",
                     "deviceConnectedVia": "Router",
                     "wifiStrength": "S",
                     "connectedSSID": "Verizon_PLZXJ4",
                     "individualParentalControls": false,
                     "blocked": false,
                     "connectionType": "wireless",
                     "location": "Family Room",
                     "assigned": false,
                     "band": "5GHz-full-band",
                     "authMode": "WPA2-Personal",
                     "rssi": "-65 dBm",
                     "phyRate": "6Mbps",
                     "hostName": "iPhone",
                     "leaseType": "DHCP",
                     "protocol": "802.11AX",
                     "bcsStatus": "Active"
                 },
                 {
                     "deviceId": "4",
                     "ipAddress": "192.168.1.154",
                     "macId": "8e:02:65:c2:68:68",
                     "name": "unknown_8e:02:65:c2:68:69",
                     "displayName": "rename_device: 8E:02:65:C2:68:69",
                     "status": "Offline",
                     "displayStatus": "Offline",
                     "connectedNetwork": "Primary",
                     "connectedDeviceType": "Desktop/Laptop",
                     "deviceConnectedVia": "Router",
                     "individualParentalControls": false,
                     "blocked": false,
                     "connectionType": "wireless",
                     "location": "",
                     "assigned": false,
                     "band": "2.4GHz",
                     "authMode": "None",
                     "hostName": "unknown_8e:02:65:c2:68:69",
                     "leaseType": "DHCP",
                     "bcsStatus": "Inactive"
                 },
                 {
                     "deviceId": "5",
                     "ipAddress": "192.168.1.155",
                     "macId": "a2:77:ee:d8:9c:01",
                     "name": "Galaxy-Note10-5G",
                     "displayName": "Galaxy-Note10-5G",
                     "status": "Online",
                     "displayStatus": "Strong Wi-Fi",
                     "connectedNetwork": "Primary",
                     "connectedDeviceType": "Phone",
                     "deviceConnectedVia": "Router",
                     "wifiStrength": "S",
                     "connectedSSID": "Verizon_PLZXJ4",
                     "parentalControlId": "a92f15c2-9dde-11ef-b251-ac919bb0d38e",
                     "individualParentalControls": false,
                     "blocked": false,
                     "connectionType": "wireless",
                     "location": "",
                     "assigned": true,
                     "deviceGroupName": "Regression testing",
                     "band": "5GHz-full-band",
                     "authMode": "WPA2-Personal",
                     "rssi": "-67 dBm",
                     "phyRate": "864Mbps",
                     "hostName": "Galaxy-Note10-5G",
                     "leaseType": "DHCP",
                     "protocol": "802.11AX",
                     "bcsStatus": "Active"
                 },
                 {
                     "deviceId": "6",
                     "ipAddress": "192.168.1.152",
                     "macId": "cc:a1:2b:e8:a5:9h",
                     "name": "AjinkyasTCLRokuTV",
                     "displayName": "AjinkyasTCLRokuTV",
                     "status": "Online",
                     "displayStatus": "Ethernet",
                     "connectedNetwork": "Primary",
                     "connectedDeviceType": "Desktop/Laptop",
                     "deviceConnectedVia": "Router",
                     "individualParentalControls": false,
                     "blocked": false,
                     "connectionType": "wired",
                     "location": "Living Room",
                     "assigned": false,
                     "band": "Ethernet",
                     "authMode": "WPA2-Personal",
                     "hostName": "AjinkyasTCLRokuTV",
                     "leaseType": "DHCP",
                     "bcsStatus": "Active"
                 },
                 {
                     "deviceId": "4",
                     "ipAddress": "192.168.1.154",
                     "macId": "8e:02:65:c2:68:6g",
                     "name": "unknown_8e:02:65:c2:68:69",
                     "displayName": "rename_device: 8E:02:65:C2:68:69",
                     "status": "Offline",
                     "displayStatus": "Offline",
                     "connectedNetwork": "Primary",
                     "connectedDeviceType": "Desktop/Laptop",
                     "deviceConnectedVia": "Router",
                     "individualParentalControls": false,
                     "blocked": false,
                     "connectionType": "wireless",
                     "location": "",
                     "assigned": false,
                     "band": "2.4GHz",
                     "authMode": "None",
                     "hostName": "unknown_8e:02:65:c2:68:69",
                     "leaseType": "DHCP",
                     "bcsStatus": "Inactive"
                 },
                 {
                     "deviceId": "5",
                     "ipAddress": "192.168.1.155",
                     "macId": "a2:77:ee:d8:9c:07",
                     "name": "Galaxy-Note10-5G",
                     "displayName": "Galaxy-Note10-5G",
                     "status": "Online",
                     "displayStatus": "Strong Wi-Fi",
                     "connectedNetwork": "Primary",
                     "connectedDeviceType": "Phone",
                     "deviceConnectedVia": "Router",
                     "wifiStrength": "S",
                     "connectedSSID": "Verizon_PLZXJ4",
                     "parentalControlId": "a92f15c2-9dde-11ef-b251-ac919bb0d38e",
                     "individualParentalControls": false,
                     "blocked": false,
                     "connectionType": "wireless",
                     "location": "",
                     "assigned": true,
                     "deviceGroupName": "Regression testing",
                     "band": "5GHz-full-band",
                     "authMode": "WPA2-Personal",
                     "rssi": "-67 dBm",
                     "phyRate": "864Mbps",
                     "hostName": "Galaxy-Note10-5G",
                     "leaseType": "DHCP",
                     "protocol": "802.11AX",
                     "bcsStatus": "Active"
                 },
                 {
                     "deviceId": "6",
                     "ipAddress": "192.168.1.152",
                     "macId": "cc:a1:2b:e8:a5:96",
                     "name": "AjinkyasTCLRokuTV",
                     "displayName": "AjinkyasTCLRokuTV",
                     "status": "Online",
                     "displayStatus": "Ethernet",
                     "connectedNetwork": "Primary",
                     "connectedDeviceType": "Desktop/Laptop",
                     "deviceConnectedVia": "Router",
                     "individualParentalControls": false,
                     "blocked": false,
                     "connectionType": "wired",
                     "location": "Living Room",
                     "assigned": false,
                     "band": "Ethernet",
                     "authMode": "WPA2-Personal",
                     "hostName": "AjinkyasTCLRokuTV",
                     "leaseType": "DHCP",
                     "bcsStatus": "Active"
                 }
             ],
             "deviceGroups": [
                 {
                     "name": "ROKU",
                     "parentalControlId": "9a77b346-d6bd-11ef-83ce-4cabf8d39086",
                     "devices": [
                         "bc:d7:d4:cd:80:8a",
                         "d8:31:34:36:e7:24"
                     ]
                 },
                 {
                     "name": "MOBILE",
                     "parentalControlId": "b26512a0-d6bd-11ef-83ce-4cabf8d39086",
                     "devices": [
                         "3e:17:0e:d8:ad:90",
                         "b6:28:bc:f2:29:b5"
                     ]
                 },
                 {
                     "name": "Regression testing",
                     "parentalControlId": "a92f15c2-9dde-11ef-b251-ac919bb0d38e",
                     "devices": [
                         "a2:77:ee:d8:9c:00"
                     ]
                 },
                 {
                     "name": "UAT group",
                     "parentalControlId": "3ca265b8-cc13-11ef-8065-ac919bb0d38e",
                     "devices": [
                         "0a:97:ed:74:19:ef",
                         "1a:3d:e1:bf:11:ed"
                     ]
                 }
             ]
           }
      },
      {
        "sectionIndex": "1",
        "sectionId": "selectDevicesSection",
        "actions": [
          {
            "actionType": "route",
            "actionValue": "setDeviceGroupNameSection",
            "actionKey": "navigateToGroupName"
          }
        ],
        "contents": [
          {
            "contentIndex": "0",
            "contentComponentId": "groupNameLeft",
            "items": [
              {
                "itemKey": "selectDevicesEditModePageHeading",
                "itemType": "headingText",
                "itemValue": "Add devices",
                "itemAttributes": {}
              },
              {
                "itemKey": "selectDevicesText",
                "itemType": "text",
                "itemValue": "Select unassigned devices or switch devices from another device group to this one.",
                "itemAttributes": {}
              },
              {
                "itemKey": "sortDevices",
                "itemType": "dropDown",
                "itemValue": "Sort by:",
                "itemAttributes": {
                  "listItems": "A-Z,Z-A"
                }
              },
              {
                "itemKey": "searchDevices",
                "itemType": "searchBar",
                "itemValue": "Search device",
                "itemAttributes": {}
              },
              {
                "itemKey": "selectDevicesSubText",
                "itemType": "text",
                "itemValue": "Assigned to ##GROUP_NAME##",
                "itemAttributes": {
                  "assigned": "true",
                  "itemValueOnSelect": "This device will be moved to the group: ##NEW_GROUP_NAME##"
                }
              },
              {
                "itemKey": "selectDevicesAddButton",
                "itemType": "button",
                "itemValue": "Add",
                "itemAttributes": {
                  "style": "black"
                }
              },
              {
                "itemKey": "selectDevicesCancelButton",
                "itemType": "button",
                "itemValue": "Cancel",
                "itemAttributes": {
                  "style": "white"
                }
              }
            ]
          }
        ],
        "data": {}
      },
      {
        "sectionIndex": "2",
        "sectionId": "scheduleDowntimeSection",
        "actions": [
          {
            "actionType": "modal",
            "actionValue": "openCancelGroupCreationModal",
            "actionKey": "cancelGroupCreationModal"
          }
        ],
        "contents": [
          {
            "contentIndex": "0",
            "contentComponentId": "setScheduleComponent",
            "items": [
              {
                "itemKey": "setScheduleHeading",
                "itemType": "headingText",
                "itemValue": "Set downtime schedule.",
                "itemAttributes": {
                  "edit": "Edit downtime schedule"
                }
              },
              {
                "itemKey": "setScheduleDesc",
                "itemType": "text",
                "itemValue": "Select recurring days and times to pause internet access on the devices in this group. You can make exceptions for certain websites later or create multiple downtime schedules.",
                "itemAttributes": {}
              },
              {
                "itemKey": "setScheduleDayChips",
                "itemType": "chip",
                "itemValue": "Select one or multiple days",
                "itemAttributes": {
                  "ddotValues": "Sun,Mon,Tue,Wed,Thu,Fri,Sat",
                  "mdotValues": "Su,Mo,Tu,We,Th,Fr,Sa"
                }
              },
              {
                "itemKey": "startTimeDropDown",
                "itemType": "dropDown",
                "itemValue": "Start time",
                "itemAttributes": {
                  "mdotText": "Start"
                }
              },
              {
                "itemKey": "setScheduleTimeRadioButtons",
                "itemType": "radioButton",
                "itemAttributes": {
                  "radioButtonItems": "AM,PM"
                }
              },
              {
                "itemKey": "endTimeDropDown",
                "itemType": "dropDown",
                "itemValue": "End time",
                "itemAttributes": {
                  "mdotText": "End"
                }
              },
              {
                "itemKey": "clearSchedule",
                "itemType": "link",
                "itemValue": "Clear schedule",
                "itemAttributes": {}
              },
              {
                "itemKey": "setScheduleSetButton",
                "itemType": "button",
                "itemValue": "Set",
                "itemAttributes": {
                  "style": "black"
                }
              },
              {
                "itemKey": "setScheduleCancelButton",
                "itemType": "button",
                "itemValue": "Cancel",
                "itemAttributes": {
                  "style": "white"
                }
              }
            ]
          },
          {
            "contentIndex": "1",
            "contentComponentId": "setScheduleSummaryPane",
            "items": [
              {
                "itemKey": "selectedDevicesHeading",
                "itemType": "text",
                "itemValue": "Selected devices",
                "itemAttributes": {}
              }
            ]
          }
        ],
        "data": {}
      },
      {
        "sectionIndex": "3",
        "sectionId": "addExceptionsSection",
        "actions": [
          {
            "actionType": "modal",
            "actionValue": "openCancelGroupCreationModal",
            "actionKey": "cancelGroupCreationModal"
          }
        ],
        "contents": [
          {
            "contentIndex": "0",
            "contentComponentId": "addExceptionsComponent",
            "items": [
              {
                "itemKey": "addExceptionsHeading",
                "itemType": "headingText",
                "itemValue": "Add allowed websites",
                "itemAttributes": {
                  "edit": "Add allowed websites"
                }
              },
              {
                "itemKey": "addExceptionsDesc",
                "itemType": "text",
                "itemValue": "These websites can be accessed even during downtime.",
                "itemAttributes": {
                  "edit": "These websites can be accessed even during downtime."
                }
              },
              {
                "itemKey": "addExceptionsInput",
                "itemType": "textBox",
                "itemValue": "Website",
                "itemAttributes": {
                  "helperTextOnError": "Please input website only, not webpage address.",
                  "itemLinkOnAdd": "Remove"
                }
              },
              {
                "itemKey": "addExceptionsSaveButton",
                "itemType": "button",
                "itemValue": "Save",
                "itemAttributes": {
                  "style": "black"
                }
              },
              {
                "itemKey": "addExceptionsCancelButton",
                "itemType": "button",
                "itemValue": "Cancel",
                "itemAttributes": {
                  "style": "white"
                }
              }
            ]
          },
          {
            "contentIndex": "1",
            "contentComponentId": "addExceptionsSummaryPane",
            "items": [
              {
                "itemKey": "selectedDevicesHeading",
                "itemType": "text",
                "itemValue": "Selected devices",
                "itemAttributes": {}
              },
              {
                "itemKey": "downtimeScheduleHeading",
                "itemType": "text",
                "itemValue": "Downtime schedule",
                "itemAttributes": {}
              }
            ]
          }
        ],
        "data": {}
      },
      {
        "sectionIndex": "4",
        "sectionId": "addKeywordsSection",
        "contents": [
          {
            "contentIndex": "0",
            "contentComponentId": "addKeywordsComponent",
            "items": [
              {
                "itemKey": "addKeywordsHeading",
                "itemType": "headingText",
                "itemValue": "Add allowed keywords",
                "itemAttributes": {}
              },
              {
                "itemKey": "addKeywordsDesc",
                "itemType": "text",
                "itemValue": "These keywords can be accessed even during downtime.",
                "itemAttributes": {}
              },
              {
                "itemKey": "addKeywordsInput",
                "itemType": "textBox",
                "itemValue": "Keyword",
                "itemAttributes": {
                  "helperTextOnError": "Please input website only, not webpage address.",
                  "itemLinkOnAdd": "Remove"
                }
              },
              {
                "itemKey": "addWebsitesSaveButton",
                "itemType": "button",
                "itemValue": "Save",
                "itemAttributes": {
                  "style": "black"
                }
              },
              {
                "itemKey": "addWebsitesCancelButton",
                "itemType": "button",
                "itemValue": "Cancel",
                "itemAttributes": {
                  "style": "white"
                }
              }
            ]
          },
          {
            "contentIndex": "1",
            "contentComponentId": "addKeywordsSummaryPane",
            "items": [
              {
                "itemKey": "selectedDevicesHeading",
                "itemType": "text",
                "itemValue": "Selected devices",
                "itemAttributes": {}
              },
              {
                "itemKey": "downtimeScheduleHeading",
                "itemType": "text",
                "itemValue": "Downtime schedule",
                "itemAttributes": {}
              }
            ]
          }
        ],
        "data": {}
      },
      {
        "sectionIndex": "5",
        "sectionId": "reviewGroupSection",
        "actions": [
          {
            "actionType": "modal",
            "actionValue": "openRemoveDeviceModal",
            "actionKey": "removeDeviceModal"
          },
          {
            "actionType": "modal",
            "actionValue": "openRemoveLastDeviceModal",
            "actionKey": "removeLastDeviceModal"
          },
          {
            "actionType": "modal",
            "actionValue": "openRemoveWebsiteModal",
            "actionKey": "removeWebsiteModal"
          },
          {
            "actionType": "modal",
            "actionValue": "openRemoveAllWebsitesModal",
            "actionKey": "removeAllWebsitesModal"
          },
          {
            "actionType": "modal",
            "actionValue": "selectDevicesSection",
            "actionKey": "addDevicesModal"
          },
          {
            "actionType": "modal",
            "actionValue": "scheduleDowntimeSection",
            "actionKey": "editDowntimeModal"
          },
          {
            "actionType": "modal",
            "actionValue": "addExceptionsSection",
            "actionKey": "addExceptionModal"
          },
          {
            "actionType": "modal",
            "actionValue": "addKeywordsSection",
            "actionKey": "addKeywordsModal"
          }
        ],
        "contents": [
          {
            "contentIndex": "0",
            "contentComponentId": "reviewGroupName",
            "items": [
              {
                "itemKey": "reviewGroupNameInput",
                "itemType": "textBox",
                "itemValue": "Group name",
                "itemAttributes": {
                  "maximumCharacters": "64"
                }
              }
            ]
          },
          {
            "contentIndex": "1",
            "contentComponentId": "reviewSelectedDevices",
            "items": [
              {
                "itemKey": "reviewSelectedDevicesHeading",
                "itemType": "headingText",
                "itemValue": "Assign devices (##DEVICES_NUMBER##/16)",
                "itemAttributes": {}
              },
              {
                "itemKey": "removeDeviceLink",
                "itemType": "link",
                "itemValue": "Remove",
                "itemAttributes": {},
                "actionKey": "removeDeviceModal"
              },
              {
                "itemKey": "addDevicesLink",
                "itemType": "link",
                "itemValue": "Add devices",
                "itemAttributes": {},
                "actionKey": "addDevicesModal"
              },
              {
                "itemKey": "removeLastDeviceLink",
                "itemType": "link",
                "itemValue": "Remove",
                "itemAttributes": {},
                "actionKey": "removeLastDeviceModal"
              },
              {
                "itemKey": "selectedDevicesEmptyStateText",
                "itemType": "text",
                "itemValue": "Select unassigned devices or switch devices from another device group to this one.",
                "itemAttributes": {}
              }
            ]
          },
          {
            "contentIndex": "2",
            "contentComponentId": "reviewDowntimeSchedule",
            "items": [
              {
                "itemKey": "reviewDowntimeScheduleHeading",
                "itemType": "headingText",
                "itemValue": "Set downtime schedule",
                "itemAttributes": {}
              },
              {
                "itemKey": "scheduleDowntimeLink",
                "itemType": "link",
                "itemValue": "Edit downtime schedule",
                "itemAttributes": {
                  "itemValueOnEmpty": "Set downtime schedule"
                },
                "actionKey": "editDowntimeModal"
              },
              {
                "itemKey": "downtimeScheduleEmptyStateText",
                "itemType": "text",
                "itemValue": "Select recurring days and times to pause internet access on the devices in this group.",
                "itemAttributes": {}
              }
            ]
          },
          {
            "contentIndex": "3",
            "contentComponentId": "reviewWebsiteExceptions",
            "items": [
              {
                "itemKey": "reviewWebsiteExceptionsHeading",
                "itemType": "headingText",
                "itemValue": "Allowed websites",
                "itemAttributes": {}
              },
              {
                "itemKey": "removeExceptionLink",
                "itemType": "link",
                "itemValue": "Remove",
                "itemAttributes": {},
                "actionKey": "removeWebsiteModal"
              },
              {
                "itemKey": "addExceptionLink",
                "itemType": "link",
                "itemValue": "Add allowed websites",
                "itemAttributes": {},
                "actionKey": "addExceptionModal"
              },
              {
                "itemKey": "removeAllExceptionsLink",
                "itemType": "link",
                "itemValue": "Remove all",
                "itemAttributes": {},
                "actionKey": "removeAllWebsitesModal"
              },
              {
                "itemKey": "websiteExceptionsEmptyStateText",
                "itemType": "text",
                "itemValue": "Select websites to allow during downtime.",
                "itemAttributes": {}
              },
              {
                "itemKey": "websiteExceptionsWithoutScheduleText",
                "itemType": "text",
                "itemValue": "Please set downtime schedule to add website exceptions",
                "itemAttributes": {}
              }
            ]
          },
          {
            "contentIndex": "4",
            "contentComponentId": "reviewKeywordExceptions",
            "items": [
              {
                "itemKey": "reviewKeywordExceptionsHeading",
                "itemType": "headingText",
                "itemValue": "Allowed keywords",
                "itemAttributes": {}
              },
              {
                "itemKey": "removeKeywordExceptionLink",
                "itemType": "link",
                "itemValue": "Remove",
                "itemAttributes": {},
                "actionKey": "removeWebsiteModal"
              },
              {
                "itemKey": "addKeywordExceptionLink",
                "itemType": "link",
                "itemValue": "Add allowed keywords",
                "itemAttributes": {},
                "actionKey": "addKeywordsModal"
              },
              {
                "itemKey": "removeAllKeywordExceptionsLink",
                "itemType": "link",
                "itemValue": "Remove all",
                "itemAttributes": {},
                "actionKey": "removeAllWebsitesModal"
              },
              {
                "itemKey": "keywordExceptionsEmptyStateText",
                "itemType": "text",
                "itemValue": "Select keywords to allow during downtime.",
                "itemAttributes": {}
              },
              {
                "itemKey": "websiteExceptionsWithoutScheduleText",
                "itemType": "text",
                "itemValue": "Please set downtime schedule to add keyword exceptions",
                "itemAttributes": {}
              }
            ]
          },
          {
            "contentIndex": "5",
            "contentComponentId": "reviewGroupButtons",
            "items": [
              {
                "itemKey": "reviewGroupCancelButton",
                "itemType": "button",
                "itemValue": "Cancel",
                "itemAttributes": {
                  "style": "white"
                },
                "actionKey": "cancelGroupCreationModal"
              },
              {
                "itemKey": "reviewGroupCreateButton",
                "itemType": "button",
                "itemValue": "Create",
                "itemAttributes": {
                  "style": "black"
                }
              }
            ]
          }
        ],
        "data": {}
      },
      {
        "sectionIndex": "6",
        "sectionId": "createDeviceGroupModalSection",
        "contents": [
          {
            "contentIndex": "0",
            "contentComponentId": "cancelGroupCreationModal",
            "items": [
              {
                "itemKey": "cancelGroupCreationHeading",
                "itemType": "headingText",
                "itemValue": "Are you sure you want to cancel creating your device group?",
                "itemAttributes": {}
              },
              {
                "itemKey": "cancelGroupCreationText",
                "itemType": "text",
                "itemValue": "You'll lose all the progress you've made so far.",
                "itemAttributes": {}
              },
              {
                "itemKey": "backBtn",
                "itemType": "button",
                "itemValue": "Back",
                "itemAttributes": {
                  "style": "black"
                }
              },
              {
                "itemKey": "confirmBtn",
                "itemType": "button",
                "itemValue": "Confirm",
                "itemAttributes": {
                  "style": "white"
                }
              }
            ]
          },
          {
            "contentIndex": "1",
            "contentComponentId": "removeDeviceModal",
            "items": [
              {
                "itemKey": "removeDeviceHeading",
                "itemType": "headingText",
                "itemValue": "Are you sure you want to remove device from this group?",
                "itemAttributes": {}
              },
              {
                "itemKey": "removeDeviceText",
                "itemType": "text",
                "itemValue": "Devices can always be added back later.",
                "itemAttributes": {}
              },
              {
                "itemKey": "removeDeviceConfirmButton",
                "itemType": "button",
                "itemValue": "Remove",
                "itemAttributes": {
                  "style": "black"
                }
              },
              {
                "itemKey": "removeDeviceCancelButton",
                "itemType": "button",
                "itemValue": "Cancel",
                "itemAttributes": {
                  "style": "white"
                }
              }
            ]
          },
          {
            "contentIndex": "2",
            "contentComponentId": "removeLastDeviceModal",
            "items": [
              {
                "itemKey": "removeLastDeviceHeading",
                "itemType": "headingText",
                "itemValue": "Device groups need to have at least one device, if you delete the last device, it will also delete the group.",
                "itemAttributes": {}
              },
              {
                "itemKey": "removeLastDeviceConfirmButton",
                "itemType": "button",
                "itemValue": "Remove device",
                "itemAttributes": {
                  "style": "black"
                }
              },
              {
                "itemKey": "removeLastDeviceCancelButton",
                "itemType": "button",
                "itemValue": "Cancel",
                "itemAttributes": {
                  "style": "white"
                }
              }
            ]
          },
          {
            "contentIndex": "3",
            "contentComponentId": "removeWebsiteModal",
            "items": [
              {
                "itemKey": "removeWebsiteHeading",
                "itemType": "headingText",
                "itemValue": "Are you sure you want to remove this allowed website?",
                "itemAttributes": {}
              },
              {
                "itemKey": "removeWebsiteConfirmButton",
                "itemType": "button",
                "itemValue": "Remove website",
                "itemAttributes": {
                  "style": "black"
                }
              },
              {
                "itemKey": "removeWebsiteCancelButton",
                "itemType": "button",
                "itemValue": "Cancel",
                "itemAttributes": {
                  "style": "white"
                }
              }
            ]
          },
          {
            "contentIndex": "4",
            "contentComponentId": "removeAllWebsitesModal",
            "items": [
              {
                "itemKey": "removeAllWebsitesHeading",
                "itemType": "headingText",
                "itemValue": "Are you sure you want to remove all allowed websites?",
                "itemAttributes": {}
              },
              {
                "itemKey": "removeAllWebsitesConfirmButton",
                "itemType": "button",
                "itemValue": "Remove all websites",
                "itemAttributes": {
                  "style": "black"
                }
              },
              {
                "itemKey": "removeAllWebsitesCancelButton",
                "itemType": "button",
                "itemValue": "Cancel",
                "itemAttributes": {
                  "style": "white"
                }
              }
            ]
          },
          {
            "contentIndex": "5",
            "contentComponentId": "deleteDeviceGroupModal",
            "items": [
              {
                "itemKey": "deleteDeviceGroupHeading",
                "itemType": "headingText",
                "itemValue": "Are you sure you want to delete this device group?",
                "itemAttributes": {}
              },
              {
                "itemKey": "deleteDeviceGroupConfirmButton",
                "itemType": "button",
                "itemValue": "Delete device group",
                "itemAttributes": {
                  "style": "black"
                }
              },
              {
                "itemKey": "removeAllWebsitesCancelButton",
                "itemType": "button",
                "itemValue": "Cancel",
                "itemAttributes": {
                  "style": "white"
                }
              }
            ]
          },
          {
            "contentIndex": "6",
            "contentComponentId": "removeKeywordModal",
            "items": [
              {
                "itemKey": "removeKeywordHeading",
                "itemType": "headingText",
                "itemValue": "Are you sure you want to remove this allowed keyword?",
                "itemAttributes": {}
              },
              {
                "itemKey": "removeKeywordConfirmButton",
                "itemType": "button",
                "itemValue": "Remove keyword",
                "itemAttributes": {
                  "style": "black"
                }
              },
              {
                "itemKey": "removeKeywordCancelButton",
                "itemType": "button",
                "itemValue": "Cancel",
                "itemAttributes": {
                  "style": "white"
                }
              }
            ]
          },
          {
            "contentIndex": "7",
            "contentComponentId": "removeAllKeywordsModal",
            "items": [
              {
                "itemKey": "removeAllKeywordsHeading",
                "itemType": "headingText",
                "itemValue": "Are you sure you want to remove all allowed keywords?",
                "itemAttributes": {}
              },
              {
                "itemKey": "removeAllKeywordsConfirmButton",
                "itemType": "button",
                "itemValue": "Remove all keywords",
                "itemAttributes": {
                  "style": "black"
                }
              },
              {
                "itemKey": "removeAllKeywordsCancelButton",
                "itemType": "button",
                "itemValue": "Cancel",
                "itemAttributes": {
                  "style": "white"
                }
              }
            ]
          },
          {
            "contentIndex": "8",
            "contentComponentId": "deviceGroupErrorMessages",
            "items": [
              {
                "itemKey": "removeGroupErrorMessage",
                "itemType": "text",
                "itemValue": "Device group could not be deleted. Please try again later.",
                "itemAttributes": {}
              }
            ]
          }
        ],
        "data": {}
      },
      {
        "sectionIndex": "7",
        "sectionId": "createDeviceGroupStaticSection",
        "contents": [
          {
            "contentIndex": "0",
            "contentComponentId": "deviceGroupInfoMessages",
            "items": [
              {
                "itemKey": "selectDevicesLimitNotification",
                "itemType": "text",
                "itemValue": "You've reached the maximum amount of devices per group",
                "itemAttributes": {}
              }
            ]
          },
          {
            "contentIndex": "1",
            "contentComponentId": "deviceGroupErrorMessages",
            "items": [
              {
                "itemKey": "createGroupErrorMessageRouter",
                "itemType": "text",
                "itemValue": "We are having issues connecting to the router. Please make sure the router is connected to the internet.",
                "itemAttributes": {}
              },
              {
                "itemKey": "reviewPageNoDevicesErrorMessage",
                "itemType": "text",
                "itemValue": "Device groups need to have at least one device. Please select a device.",
                "itemAttributes": {}
              }
            ]
          }
        ],
        "data": {}
      }
    ],
    "usageNewLandingFlag": false,
    "updateNickNameFlag": false,
    "assignDeviceFFlag": false,
    "fwaUpsFlag": false,
    "secondNumberPerkDisplayFFlag": false,
    "elvisEnabledFFlag": false,
    "deceasedFlag": false
};