import React from 'react';
import "../../../../../../config/jest/test-setup"
import { render, screen, fireEvent } from '@testing-library/react';
import { combineReducers } from 'redux';
import { Provider } from 'react-redux';
import configureStore from '../../../../../shared/store/configureStore';
import '@testing-library/jest-dom';
import DeviceGroupDetails from '../../components/DeviceGroup/DeviceGroupDetails';
import { deviceGroupDetailsData } from './DeviceGroupCreate.mock';

jest.mock('../../components/DeviceGroup/AllDetails', () => {
    return ({ openRemoveModal, setShowRemoveWebsiteModal, setShowRemoveAllWebsitesModal, addDeviceHandler, editScheduleHandler, addExceptionHandler,addKeywordHandler, clearAllNotificationStatus,
        setShowRemoveKeywordModal,setShowRemoveAllKeywordModal }) => <>
        <button onClick={() => openRemoveModal('bc:d7:d4:cd:80:8a')}>Remove Modal</button>
        <button onClick={() => setShowRemoveWebsiteModal(0)}>Remove Website</button>
        <button onClick={() => setShowRemoveAllWebsitesModal(0)}>Remove All Websites</button>
        <button onClick={() => setShowRemoveKeywordModal(0)}>Remove keyword</button>
        <button onClick={() => setShowRemoveAllKeywordModal(0)}>Remove All keywords</button>
        <button onClick={addDeviceHandler}>Add Device</button>
        <button onClick={editScheduleHandler}>Edit Schedule</button>
        <button onClick={addExceptionHandler}>Add Exception</button>
        <button onClick={addKeywordHandler}>Add Keyword</button>
        <button onClick={clearAllNotificationStatus}>Clear All Notifications</button>
    </>
});

jest.mock('../../components/DeviceGroup/SelectDevices', () => {
    return ({ saveHandler, backHandler, setMaxDevices }) => <>
        <button data-testid='update-device-cta' onClick={() => saveHandler([])}></button>
        <button data-testid='back-device-cta' onClick={backHandler}></button>
        <button data-testid='max-device-cta' onClick={() => setMaxDevices(true)}></button>
    </>
});

jest.mock('../../components/DeviceGroup/SetSchedule', () => {
    return ({ nextHandler, skipHandler }) => <>
        <button data-testid='update-schedule-cta' onClick={() => nextHandler({})}></button>
        <button data-testid='clear-schedule-cta' onClick={skipHandler}></button>
    </>
});

jest.mock('../../components/DeviceGroup/AddException', () => {
    return ({ nextHandler }) => <>
        <button data-testid='update-website-cta' onClick={() => nextHandler([])}></button>
    </>
});
jest.mock('../../components/DeviceGroup/AddKeyword', () => {
    return ({ nextHandler }) => <>
        <button data-testid='update-keyword-cta' onClick={() => nextHandler([])}></button>
    </>
});

jest.mock('../../components/DeviceGroup/RemoveModal', () => {
    return ({ confirmClick, onClose }) => <>
        <button data-testid='remove-device-confirm' onClick={confirmClick}></button>
        <button data-testid='remove-device-close' onClick={onClose}></button>
    </>
});

describe('All Devices Component', () => {
    test('should render component - DeviceGroupDetails', () => {
        const props = { history: { push() { } } };
        const routerLandingInitialState = {
            getDeviceGroupDetailsAPIData: deviceGroupDetailsData, createDeviceGroupData: {
                page: 'manage',
                name: "Verizon Office",
                devices: [
                    "bc:d7:d4:cd:80:8a",
                    "0a:97:ed:74:19:ef"
                ],
                schedule: {
                    daysOfTheWeek: [
                        1, 2
                    ],
                    "startTimeHour": "01",
                    "startTimeMinute": "00",
                    "stopTimeHour": "01",
                    "stopTimeMinute": "00",
                    "startTimeAmPm": "AM",
                    "stopTimeAmPm": "PM",
                },
                "websiteExceptions": [
                        {
                            "type": 0,
                            "value": "www.cartoonnetwork.com"
                        },
                        {
                            "type": 0,
                            "value": "www.yamaha.com"
                        }
                    ],
                    "keywordExceptions": [
                        {
                            "type": 1,
                            "value": "Avengers"
                        },
                        {
                            "type": 1,
                            "value": "pokemon"
                        }
                    ]

            }
        };
        const routerLandingReducer = (state = routerLandingInitialState) => state;
        const appReducer = combineReducers({ Router: routerLandingReducer });
        const testRootReducer = (state) => appReducer(state);

        const testStore = configureStore(testRootReducer);
        const component = render(
            <Provider store={testStore}>
                <DeviceGroupDetails {...props} />
            </Provider>
        );
        expect(component).toBeTruthy();

        fireEvent.click(screen.getByText('Remove Modal'));
        fireEvent.click(screen.getByTestId('remove-device-confirm'));
    });
    test('should render component - DeviceGroupDetails', () => {
        const props = { history: { push() { } } };
        const routerLandingInitialState = {
            getDeviceGroupDetailsAPIData: deviceGroupDetailsData, createDeviceGroupData: {
                page: 'manage',
                name: "Verizon Office",
                devices: [
                    "bc:d7:d4:cd:80:8a",
                    "0a:97:ed:74:19:ef"
                ],
                schedule: {
                    daysOfTheWeek: [
                        1, 2
                    ],
                    "startTimeHour": "01",
                    "startTimeMinute": "00",
                    "stopTimeHour": "01",
                    "stopTimeMinute": "00",
                    "startTimeAmPm": "AM",
                    "stopTimeAmPm": "PM",
                },
                "websiteExceptions": [
                        {
                            "type": 0,
                            "value": "www.cartoonnetwork.com"
                        },
                        {
                            "type": 0,
                            "value": "www.yamaha.com"
                        }
                    ],
                    "keywordExceptions": [
                        {
                            "type": 1,
                            "value": "Avengers"
                        },
                        {
                            "type": 1,
                            "value": "pokemon"
                        }
                    ]

            }
        };
        const routerLandingReducer = (state = routerLandingInitialState) => state;
        const appReducer = combineReducers({ Router: routerLandingReducer });
        const testRootReducer = (state) => appReducer(state);

        const testStore = configureStore(testRootReducer);
        const component = render(
            <Provider store={testStore}>
                <DeviceGroupDetails {...props} />
            </Provider>
        );
        expect(component).toBeTruthy();

        fireEvent.click(screen.getByText('Clear All Notifications'));
        fireEvent.click(screen.getByTestId('removeGrpBtn'));
        fireEvent.click(screen.getByTestId('remove-device-confirm'));
    });
    
    test('should render component - DeviceGroupDetails', () => {
        const props = { history: { push() { } } };
        const routerLandingInitialState = {
            getDeviceGroupDetailsAPIData: deviceGroupDetailsData, createDeviceGroupData: {
                page: 'manage',
                name: "Verizon Office",
                devices: [
                    "bc:d7:d4:cd:80:8a",
                    "0a:97:ed:74:19:ef"
                ],
                schedule: {
                    daysOfTheWeek: [
                        1, 2
                    ],
                    "startTimeHour": "01",
                    "startTimeMinute": "00",
                    "stopTimeHour": "01",
                    "stopTimeMinute": "00",
                    "startTimeAmPm": "AM",
                    "stopTimeAmPm": "PM",
                },
                "websiteExceptions": [
                        {
                            "type": 0,
                            "value": "www.cartoonnetwork.com"
                        },
                        {
                            "type": 0,
                            "value": "www.yamaha.com"
                        }
                    ],
                    "keywordExceptions": [
                        {
                            "type": 1,
                            "value": "Avengers"
                        },
                        {
                            "type": 1,
                            "value": "pokemon"
                        }
                    ]

            }
        };
        const routerLandingReducer = (state = routerLandingInitialState) => state;
        const appReducer = combineReducers({ Router: routerLandingReducer });
        const testRootReducer = (state) => appReducer(state);

        const testStore = configureStore(testRootReducer);
        const component = render(
            <Provider store={testStore}>
                <DeviceGroupDetails {...props} />
            </Provider>
        );
        expect(component).toBeTruthy();

        fireEvent.click(screen.getByText('Remove Modal'));
        fireEvent.click(screen.getByTestId('remove-device-close'));
    });
    test('should render component - DeviceGroupDetails', () => {
        const props = { history: { push() { } } };
        const routerLandingInitialState = {
            getDeviceGroupDetailsAPIData: deviceGroupDetailsData, createDeviceGroupData: {
                page: 'manage',
                name: "Verizon Office",
                devices: [
                    "bc:d7:d4:cd:80:8a"
                ],
                schedule: {
                    daysOfTheWeek: [
                        1, 2
                    ],
                    "startTimeHour": "01",
                    "startTimeMinute": "00",
                    "stopTimeHour": "01",
                    "stopTimeMinute": "00",
                    "startTimeAmPm": "AM",
                    "stopTimeAmPm": "PM",
                },
                "websiteExceptions": [
                        {
                            "type": 0,
                            "value": "www.cartoonnetwork.com"
                        },
                        {
                            "type": 0,
                            "value": "www.yamaha.com"
                        }
                    ],
                    "keywordExceptions": [
                        {
                            "type": 1,
                            "value": "Avengers"
                        },
                        {
                            "type": 1,
                            "value": "pokemon"
                        }
                    ]

            }
        };
        const routerLandingReducer = (state = routerLandingInitialState) => state;
        const appReducer = combineReducers({ Router: routerLandingReducer });
        const testRootReducer = (state) => appReducer(state);

        const testStore = configureStore(testRootReducer);
        const component = render(
            <Provider store={testStore}>
                <DeviceGroupDetails {...props} />
            </Provider>
        );
        expect(component).toBeTruthy();

        fireEvent.click(screen.getByText('Remove Website'));
    });
    test('should render component - DeviceGroupDetails', () => {
        const props = { history: { push() { } } };
        const routerLandingInitialState = {
            getDeviceGroupDetailsAPIData: deviceGroupDetailsData, createDeviceGroupData: {
                page: 'manage',
                name: "Verizon Office",
                devices: [
                    "bc:d7:d4:cd:80:8a"
                ],
                schedule: {
                    daysOfTheWeek: [
                        1, 2
                    ],
                    "startTimeHour": "01",
                    "startTimeMinute": "00",
                    "stopTimeHour": "01",
                    "stopTimeMinute": "00",
                    "startTimeAmPm": "AM",
                    "stopTimeAmPm": "PM",
                },
                "websiteExceptions": [
                        {
                            "type": 0,
                            "value": "www.cartoonnetwork.com"
                        },
                        {
                            "type": 0,
                            "value": "www.yamaha.com"
                        }
                    ],
                    "keywordExceptions": [
                        {
                            "type": 1,
                            "value": "Avengers"
                        },
                        {
                            "type": 1,
                            "value": "pokemon"
                        }
                    ]

            }
        };
        const routerLandingReducer = (state = routerLandingInitialState) => state;
        const appReducer = combineReducers({ Router: routerLandingReducer });
        const testRootReducer = (state) => appReducer(state);

        const testStore = configureStore(testRootReducer);
        const component = render(
            <Provider store={testStore}>
                <DeviceGroupDetails {...props} />
            </Provider>
        );
        expect(component).toBeTruthy();

        fireEvent.click(screen.getByText('Add Device'));
    });
    test('should render component - DeviceGroupDetails', () => {
        const props = { history: { push() { } } };
        const routerLandingInitialState = {
            getDeviceGroupDetailsAPIData: deviceGroupDetailsData, createDeviceGroupData: {
                page: 'manage',
                name: "Verizon Office",
                devices: [
                    "bc:d7:d4:cd:80:8a"
                ],
                schedule: {
                    daysOfTheWeek: [
                        1, 2
                    ],
                    "startTimeHour": "01",
                    "startTimeMinute": "00",
                    "stopTimeHour": "01",
                    "stopTimeMinute": "00",
                    "startTimeAmPm": "AM",
                    "stopTimeAmPm": "PM",
                },
                "websiteExceptions": [
                        {
                            "type": 0,
                            "value": "www.cartoonnetwork.com"
                        },
                        {
                            "type": 0,
                            "value": "www.yamaha.com"
                        }
                    ],
                    "keywordExceptions": [
                        {
                            "type": 1,
                            "value": "Avengers"
                        },
                        {
                            "type": 1,
                            "value": "pokemon"
                        }
                    ]

            }
        };
        const routerLandingReducer = (state = routerLandingInitialState) => state;
        const appReducer = combineReducers({ Router: routerLandingReducer });
        const testRootReducer = (state) => appReducer(state);

        const testStore = configureStore(testRootReducer);
        const component = render(
            <Provider store={testStore}>
                <DeviceGroupDetails {...props} />
            </Provider>
        );
        expect(component).toBeTruthy();

        fireEvent.click(screen.getByText('Edit Schedule'));
    });
    test('should render component - DeviceGroupDetails', () => {
        const props = { history: { push() { } } };
        const routerLandingInitialState = {
            getDeviceGroupDetailsAPIData: deviceGroupDetailsData, createDeviceGroupData: {
                page: 'manage',
                name: "Verizon Office",
                devices: [
                    "bc:d7:d4:cd:80:8a"
                ],
                schedule: {
                    daysOfTheWeek: [
                        1, 2
                    ],
                    "startTimeHour": "01",
                    "startTimeMinute": "00",
                    "stopTimeHour": "01",
                    "stopTimeMinute": "00",
                    "startTimeAmPm": "AM",
                    "stopTimeAmPm": "PM",
                },
                "websiteExceptions": [
                        {
                            "type": 0,
                            "value": "www.cartoonnetwork.com"
                        },
                        {
                            "type": 0,
                            "value": "www.yamaha.com"
                        }
                    ],
                    "keywordExceptions": [
                        {
                            "type": 1,
                            "value": "Avengers"
                        },
                        {
                            "type": 1,
                            "value": "pokemon"
                        }
                    ]

            }
        };
        const routerLandingReducer = (state = routerLandingInitialState) => state;
        const appReducer = combineReducers({ Router: routerLandingReducer });
        const testRootReducer = (state) => appReducer(state);

        const testStore = configureStore(testRootReducer);
        const component = render(
            <Provider store={testStore}>
                <DeviceGroupDetails {...props} />
            </Provider>
        );
        expect(component).toBeTruthy();

        fireEvent.click(screen.getByText('Add Exception'));
    });    
    test('should render component - DeviceGroupDetails', () => {
        const props = { history: { push() { } } };
        const routerLandingInitialState = {
            getDeviceGroupDetailsAPIData: deviceGroupDetailsData, createDeviceGroupData: {
                page: 'selectDevices',
                name: "Verizon Office",
                devices: [
                    "bc:d7:d4:cd:80:8a"
                ],
                schedule: {
                    daysOfTheWeek: [
                        1, 2
                    ],
                    "startTimeHour": "01",
                    "startTimeMinute": "00",
                    "stopTimeHour": "01",
                    "stopTimeMinute": "00",
                    "startTimeAmPm": "AM",
                    "stopTimeAmPm": "PM",
                },
                "websiteExceptions": [
                        {
                            "type": 0,
                            "value": "www.cartoonnetwork.com"
                        },
                        {
                            "type": 0,
                            "value": "www.yamaha.com"
                        }
                    ],
                    "keywordExceptions": [
                        {
                            "type": 1,
                            "value": "Avengers"
                        },
                        {
                            "type": 1,
                            "value": "pokemon"
                        }
                    ]

            }
        };
        const routerLandingReducer = (state = routerLandingInitialState) => state;
        const appReducer = combineReducers({ Router: routerLandingReducer });
        const testRootReducer = (state) => appReducer(state);

        const testStore = configureStore(testRootReducer);
        const component = render(
            <Provider store={testStore}>
                <DeviceGroupDetails {...props} />
            </Provider>
        );
        expect(component).toBeTruthy();

        fireEvent.click(screen.getByTestId('update-device-cta'));
        fireEvent.click(screen.getByTestId('max-device-cta'));        
        fireEvent.click(screen.getByTestId('back-device-cta'));
    });
    test('should render component - DeviceGroupDetails', () => {
        const props = { history: { push() { } } };
        const routerLandingInitialState = {
            getDeviceGroupDetailsAPIData: deviceGroupDetailsData, createDeviceGroupData: {
                page: 'setSchedule',
                name: "Verizon Office",
                devices: [
                    "bc:d7:d4:cd:80:8a"
                ],
                schedule: {
                    daysOfTheWeek: [1, 2],
                    "startTimeHour": "01",
                    "startTimeMinute": "00",
                    "stopTimeHour": "01",
                    "stopTimeMinute": "00",
                    "startTimeAmPm": "AM",
                    "stopTimeAmPm": "PM",
                },
                "websiteExceptions": [
                        {
                            "type": 0,
                            "value": "www.cartoonnetwork.com"
                        },
                        {
                            "type": 0,
                            "value": "www.yamaha.com"
                        }
                    ],
                    "keywordExceptions": [
                        {
                            "type": 1,
                            "value": "Avengers"
                        },
                        {
                            "type": 1,
                            "value": "pokemon"
                        }
                    ]

            }
        };
        const routerLandingReducer = (state = routerLandingInitialState) => state;
        const appReducer = combineReducers({ Router: routerLandingReducer });
        const testRootReducer = (state) => appReducer(state);

        const testStore = configureStore(testRootReducer);
        const component = render(
            <Provider store={testStore}>
                <DeviceGroupDetails {...props} />
            </Provider>
        );
        expect(component).toBeTruthy();

        fireEvent.click(screen.getByTestId('update-schedule-cta'));
        fireEvent.click(screen.getByTestId('clear-schedule-cta'));
    });
    test('should render component - DeviceGroupDetails', () => {
        const props = { history: { push() { } } };
        const routerLandingInitialState = {
            getDeviceGroupDetailsAPIData: deviceGroupDetailsData, createDeviceGroupData: {
                page: 'exception',
                name: "Verizon Office",
                devices: [
                    "bc:d7:d4:cd:80:8a"
                ],
                schedule: {
                    daysOfTheWeek: [1, 2],
                    "startTimeHour": "01",
                    "startTimeMinute": "00",
                    "stopTimeHour": "01",
                    "stopTimeMinute": "00",
                    "startTimeAmPm": "AM",
                    "stopTimeAmPm": "PM",
                },
                "websiteExceptions": [
                        {
                            "type": 0,
                            "value": "www.cartoonnetwork.com"
                        },
                        {
                            "type": 0,
                            "value": "www.yamaha.com"
                        }
                    ],
                    "keywordExceptions": [
                        {
                            "type": 1,
                            "value": "Avengers"
                        },
                        {
                            "type": 1,
                            "value": "pokemon"
                        }
                    ]

            }
        };
        const routerLandingReducer = (state = routerLandingInitialState) => state;
        const appReducer = combineReducers({ Router: routerLandingReducer });
        const testRootReducer = (state) => appReducer(state);

        const testStore = configureStore(testRootReducer);
        const component = render(
            <Provider store={testStore}>
                <DeviceGroupDetails {...props} />
            </Provider>
        );
        expect(component).toBeTruthy();

        fireEvent.click(screen.getByTestId('update-website-cta'));
    });
    test('should render component - DeviceGroupDetails', () => {
        const props = { history: { push() { } } };
        const routerLandingInitialState = {
            getDeviceGroupDetailsAPIData: deviceGroupDetailsData, createDeviceGroupData: {
                page: 'keyword',
                name: "Verizon Office",
                devices: [
                    "bc:d7:d4:cd:80:8a"
                ],
                schedule: {
                    daysOfTheWeek: [1, 2],
                    "startTimeHour": "01",
                    "startTimeMinute": "00",
                    "stopTimeHour": "01",
                    "stopTimeMinute": "00",
                    "startTimeAmPm": "AM",
                    "stopTimeAmPm": "PM",
                },
                "websiteExceptions": [
                        {
                            "type": 0,
                            "value": "www.cartoonnetwork.com"
                        },
                        {
                            "type": 0,
                            "value": "www.yamaha.com"
                        }
                    ],
                    "keywordExceptions": [
                        {
                            "type": 1,
                            "value": "Avengers"
                        },
                        {
                            "type": 1,
                            "value": "pokemon"
                        }
                    ]

            }
        };
        const routerLandingReducer = (state = routerLandingInitialState) => state;
        const appReducer = combineReducers({ Router: routerLandingReducer });
        const testRootReducer = (state) => appReducer(state);

        const testStore = configureStore(testRootReducer);
        const component = render(
            <Provider store={testStore}>
                <DeviceGroupDetails {...props} />
            </Provider>
        );
        expect(component).toBeTruthy();

        fireEvent.click(screen.getByTestId('update-keyword-cta'));
    });
});
    
test('should show success message when updateDeviceSuccess is called', () => {
    const props = { history: { push() { } } };
    const successMsgs = { addDevicesSuccessMessage: 'Device selection successfully updated.' };
    const routerLandingInitialState = {
        getDeviceGroupDetailsAPIData: deviceGroupDetailsData, createDeviceGroupData: {
            page: 'manage',
            name: "Verizon Office",
            devices: [
                "bc:d7:d4:cd:80:8a",
                "0a:97:ed:74:19:ef"
            ],
            schedule: {
                daysOfTheWeek: [
                    1, 2
                ],
                "startTimeHour": "01",
                "startTimeMinute": "00",
                "stopTimeHour": "01",
                "stopTimeMinute": "00",
                "startTimeAmPm": "AM",
                "stopTimeAmPm": "PM",
            },
            "websiteExceptions": [
                        {
                            "type": 0,
                            "value": "www.cartoonnetwork.com"
                        },
                        {
                            "type": 0,
                            "value": "www.yamaha.com"
                        }
                    ],
                    "keywordExceptions": [
                        {
                            "type": 1,
                            "value": "Avengers"
                        },
                        {
                            "type": 1,
                            "value": "pokemon"
                        }
                    ]

        }
    };
    const routerLandingReducer = (state = routerLandingInitialState) => state;
    const appReducer = combineReducers({ Router: routerLandingReducer });
    const testRootReducer = (state) => appReducer(state);

    const testStore = configureStore(testRootReducer);
    const component = render(
        <Provider store={testStore}>
            <DeviceGroupDetails {...props} />
        </Provider>
    );
    expect(component).toBeTruthy();

    const { getByText } = component;

    fireEvent.click(getByText('Add or remove devices'));
    fireEvent.click(getByText('Save'));
    
    // Call the updateDeviceHandler function
    updateDeviceHandler(devicesSelected);
    
    // Assert that the success message is shown
    expect(DeviceGroupDetails).toHaveBeenCalled();
    expect(dispatchMock).toHaveBeenCalledWith(updateCreateDeviceGroupObj({ devices: devicesSelected }));
    expect(getByText(successMsgs.addDevicesSuccessMessage)).toBeInTheDocument();
    });