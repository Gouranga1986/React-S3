import React from 'react';
import '@testing-library/jest-dom';
import { render, screen, fireEvent } from '@testing-library/react';
import SelectDevices from '../../components/DeviceGroup/SelectDevices';

// Mocking dependencies
jest.mock('@vds/selects', () => ({
    DropdownSelect: ({ children, ...props }) => {
        const handleChange = (event) => {
            // Call the onChange handler passed as a prop
            if (props.onChange) {
                props.onChange(event);
            }
        };

        return (
            <select {...props} onChange={handleChange}>
                {children}
            </select>
        );
    },
}));




jest.mock('../../../../../shared/utilities/util', () => ({
    arraysHaveSameElements: (arr1, arr2) => {
        // Simple check for test purposes
        return JSON.stringify(arr1) === JSON.stringify(arr2);
    },
}));

const mockProps = {
    title: 'Select Devices',
    subtitle: 'Choose devices to add to the group',
    currentPage: 'page-1',
    sortLabel: 'Sort by:',
    sortOptions: ['a-z', 'z-a'],
    searchLabel: 'Search',
    devicesSelected: [],
    devices: [
        { macId: '1', displayName: 'Device 1' },
        { macId: '2', displayName: 'Device 2', deviceGroupName: 'Group A' },
        { macId: '3', displayName: 'Device 3' },
    ],
    setMaxDevices: jest.fn(),
    updateSelectedDevices: jest.fn(),
    deviceGroupName: 'New Group',
    existingGroupName: '##group_name##',
    assignToNewGroup: 'Assigned to ##new_group_name##',
    back: 'Back',
    backHandler: jest.fn(),
    save: 'Save',
    saveHandler: jest.fn(),
    cancel: 'Cancel',
    cancelHandler: jest.fn(),
    isManage: false,
};

describe('SelectDevices Component', () => {
    beforeEach(() => {
        render(<SelectDevices {...mockProps} />);
    });

    it('renders the component with correct props', () => {
        expect(screen.getByText(mockProps.title)).toBeInTheDocument();
        expect(screen.getByText(mockProps.subtitle)).toBeInTheDocument();
    });

    it('updates selected devices on checkbox click', () => {
        const checkbox = screen.queryAllByTestId('test-input')[0];
        fireEvent.click(checkbox);
        expect(mockProps.setMaxDevices).toHaveBeenCalledWith(false);
    });

    it('searches devices based on input', () => {
        const searchInput = screen.getByTestId('search-devices');
        fireEvent.change(searchInput, { target: { value: 'Device 2' } });
        expect(screen.getByText('Device 2')).toBeVisible();
        expect(screen.queryByText('Device 1')).not.toBeInTheDocument();
    });

    it('sorts devices based on dropdown selection', () => {
        const sortDropdown = screen.queryAllByTestId('sd-sort-dropdown')[0];
        fireEvent.change(sortDropdown, { target: { value: 'z-a' } });
        fireEvent.change(sortDropdown, { target: { value: 'a-z' } });
    });

    it('handles save button click', () => {
        // first select device
        const checkbox = screen.queryAllByTestId('test-input')[0];
        fireEvent.click(checkbox);
        const saveButton = screen.getByText('Save');
        fireEvent.click(saveButton);
        expect(mockProps.updateSelectedDevices).toHaveBeenCalled();
        expect(mockProps.saveHandler).toHaveBeenCalled();
    });
});

