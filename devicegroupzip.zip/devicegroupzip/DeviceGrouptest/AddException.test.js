import React from 'react';
import '@testing-library/jest-dom';
import { render, screen, fireEvent } from '@testing-library/react';
import AddException from '../../components/DeviceGroup/AddException';

describe('Addexception Component', () => {
    const mockWebsitesData = ['example.com', 'test.net'];
    const mockProps = {
        title: 'Test Title',
        subtitle: 'Test Subtitle',
        subheader: 'Test Subheader',
        errorText: 'Invalid URL format',
        websitesData: [...mockWebsitesData],
        openCancelModal: jest.fn(),
        cancel: 'Cancel',
        isManage: false,
        helperText: 'Enter valid website URL',
        removeAll: 'Remove All',
        backHandler: jest.fn(),
        back: 'Back',
        nextHandler: jest.fn(),
        next: 'Next',
        skip: 'Skip',
        inputLabel: 'Website URL'
    };

    beforeEach(() => {
        render(<AddException {...mockProps} />);
    });

    it('renders the component with correct elements and initial data', () => {
        expect(screen.getByTestId('exception')).toHaveTextContent(mockProps.title);
        expect(screen.getByText(mockProps.subtitle)).toBeInTheDocument();
        expect(screen.getByText(mockProps.subheader)).toBeInTheDocument();
        expect(screen.getByTestId('website-input')).toBeInTheDocument();
        expect(screen.getByText(mockProps.helperText)).toBeInTheDocument();

        mockWebsitesData.forEach((website, index) => {
            expect(screen.getByText(website)).toBeInTheDocument();
            expect(screen.getByTestId(`remove-btn-${index}`)).toBeInTheDocument();
        });

        expect(screen.getByTestId('remove-all-btn')).toBeInTheDocument();
        expect(screen.getByTestId('next-btn')).toBeInTheDocument();
        expect(screen.getByTestId('back-btn')).toBeInTheDocument();
        expect(screen.getByText(mockProps.cancel)).toBeInTheDocument();
    });

    it('handles website URL input change', () => {
        const inputElement = screen.getByTestId('website-input');
        const testUrl = 'newsite.org';
        fireEvent.change(inputElement, { target: { value: testUrl } });
        expect(inputElement.value).toBe(testUrl);
    });

    it('validates and adds a valid website URL', () => {
        const inputElement = screen.getByTestId('website-input');
        const validUrl = 'validwebsite.com';
        fireEvent.change(inputElement, { target: { value: validUrl } });
        fireEvent.click(screen.getByTestId('add-btn'));

        expect(screen.getByText(validUrl)).toBeInTheDocument();
        expect(screen.queryByTestId('error-message')).not.toBeInTheDocument();
    });

    it('displays an error for invalid website URL', () => {
        const inputElement = screen.getByTestId('website-input');
        const invalidUrl = 'invalid-url';
        fireEvent.change(inputElement, { target: { value: invalidUrl } });
        fireEvent.click(screen.getByTestId('add-btn'));

        expect(screen.getByTestId('error-message')).toHaveTextContent(mockProps.errorText);
    });

    it('removes a website URL from the list', () => {
        const removeButtonIndex = 0;
        fireEvent.click(screen.getByTestId(`remove-btn-${removeButtonIndex}`));
        expect(screen.queryByText(mockWebsitesData[removeButtonIndex])).not.toBeInTheDocument();
    });

    it('removes all website URLs from the list', () => {
        fireEvent.click(screen.getByTestId('remove-all-btn'));
        mockWebsitesData.forEach((website) => {
            expect(screen.queryByText(website)).not.toBeInTheDocument();
        });
    });

    it('calls the appropriate handler functions on button clicks', () => {
        fireEvent.click(screen.getByTestId('next-btn'));
        expect(mockProps.nextHandler).toHaveBeenCalled();

        fireEvent.click(screen.getByTestId('back-btn'));
        expect(mockProps.backHandler).toHaveBeenCalled();

        fireEvent.click(screen.getByText(mockProps.cancel));
        expect(mockProps.openCancelModal).toHaveBeenCalled();
    });
});
