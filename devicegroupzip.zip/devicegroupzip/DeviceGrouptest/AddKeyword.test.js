import React from 'react';
import '@testing-library/jest-dom';
import { render, screen, fireEvent } from '@testing-library/react';
import Addkeyword from '../../components/DeviceGroup/AddKeyword';

describe('AddKeyword Component', () => {
  const mockKeywordData = ['keyword1', 'keyword2'];
  const mockTitle = 'Test Title';
  const mockSubtitle = 'Test Subtitle';
  const mockSubheader = 'Test Subheader';
  const mockErrorText = 'Test Error Text';
  const mockHelperText = 'Test Helper Text';
  const mockRemoveAll = 'Test Remove All';
  const mockBack = 'Test Back';
  const mockNext = 'Test Next';
  const mockSkip = 'Test Skip';
  const mockInputLabel = 'Test Input Label';
  const mockCancel = 'Test Cancel';

  const mockOpenCancelModal = jest.fn();
  const mockCancelHandler = jest.fn();
  const mockBackHandler = jest.fn();
  const mockNextHandler = jest.fn();

  beforeEach(() => {
    render(
      <Addkeyword
        title={mockTitle}
        subtitle={mockSubtitle}
        subheader={mockSubheader}
        errorText={mockErrorText}
        keywordData={mockKeywordData}
        openCancelModal={mockOpenCancelModal}
        cancel={mockCancel}
        isManage={false}
        helperText={mockHelperText}
        removeAll={mockRemoveAll}
        backHandler={mockBackHandler}
        back={mockBack}
        nextHandler={mockNextHandler}
        next={mockNext}
        skip={mockSkip}
        inputLabel={mockInputLabel}
      />
    );
  });

  it('renders the component with correct data', () => {
    // expect(screen.getByTestId('keyword')).toHaveTextContent(mockTitle);
    expect(screen.getByText(mockTitle)).toBeInTheDocument();
    expect(screen.getByText(mockSubtitle)).toBeInTheDocument();
    expect(screen.getByText(mockSubheader)).toBeInTheDocument();
    expect(screen.getByLabelText(mockInputLabel)).toBeInTheDocument();
    expect(screen.getByText(mockHelperText)).toBeInTheDocument();
    expect(screen.getByText(mockKeywordData[0])).toBeInTheDocument();
    expect(screen.getByText(mockKeywordData[1])).toBeInTheDocument();
    expect(screen.getByText(mockRemoveAll)).toBeInTheDocument();
    expect(screen.getByText(mockNext)).toBeInTheDocument();
    expect(screen.getByText(mockBack)).toBeInTheDocument();
    expect(screen.getByText(mockCancel)).toBeInTheDocument();
  });

  it('adds a new keyword on input and button click', () => {
    const inputElement = screen.getByTestId('keyword-input');
    const addButton = screen.getByTestId('add-btn');

    fireEvent.change(inputElement, { target: { value: 'keyword3' } });
    fireEvent.click(addButton);

    expect(screen.getByText('keyword3')).toBeInTheDocument();
  });

  it('validates keyword input and displays error message', () => {
    const inputElement = screen.getByTestId('keyword-input');
    const addButton = screen.getByTestId('add-btn');

    fireEvent.change(inputElement, { target: { value: 'keyword invalid' } });
    fireEvent.click(addButton);

    expect(screen.getByTestId('error-message')).toHaveTextContent(
      mockErrorText
    );
  });

  it('removes a keyword on remove button click', () => {
    const removeButton = screen.getByTestId('remove-btn-0');

    fireEvent.click(removeButton);

    expect(screen.queryByText('keyword1')).not.toBeInTheDocument();
  });

  it('removes all keywords on remove all button click', () => {
    const removeAllButton = screen.getByTestId('remove-all-btn');

    fireEvent.click(removeAllButton);

    expect(screen.queryByTestId('keyword-item')).not.toBeInTheDocument();
  });

  it('calls the next handler with keywords on next button click', () => {
    const nextButton = screen.getByTestId('next-btn');

    fireEvent.click(nextButton);

    expect(mockNextHandler).toHaveBeenCalledWith(mockKeywordData);
  });

  it('calls the back handler on back button click', () => {
    const backButton = screen.getByTestId('back-btn');

    fireEvent.click(backButton);

    expect(mockBackHandler).toHaveBeenCalled();
  });

  it('calls the cancel modal handler on cancel link click', () => {
    const cancelLink = screen.getByText(mockCancel);

    fireEvent.click(cancelLink);

    expect(mockOpenCancelModal).toHaveBeenCalled();
  });

  it('displays skip button when there are no keywords', () => {
    render(
      <Addkeyword
        title={mockTitle}
        subtitle={mockSubtitle}
        subheader={mockSubheader}
        errorText={mockErrorText}
        keywordData={[]}
        openCancelModal={mockOpenCancelModal}
        cancel={mockCancel}
        isManage={false}
        helperText={mockHelperText}
        removeAll={mockRemoveAll}
        backHandler={mockBackHandler}
        back={mockBack}
        nextHandler={mockNextHandler}
        next={mockNext}
        skip={mockSkip}
        inputLabel={mockInputLabel}
      />
    );

    expect(screen.getByText(mockSkip)).toBeInTheDocument();
  });
});

