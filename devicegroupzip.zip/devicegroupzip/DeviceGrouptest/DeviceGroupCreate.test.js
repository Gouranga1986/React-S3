import React, {useState} from 'react';
import "../../../../../../config/jest/test-setup"
import { render, screen, fireEvent, waitFor } from '@testing-library/react';
import '@testing-library/jest-dom';
import { combineReducers } from 'redux';
import { Provider } from 'react-redux';
import configureStore from '../../../../../shared/store/configureStore';
import '@testing-library/jest-dom';
import CreateDeviceGroup from '../../components/DeviceGroup/CreateDeviceGroup';
import CancelModal from '../../components/DeviceGroup/CancelModal';
import { createDeviceGroupData } from './DeviceGroupCreate.mock';
import { getCreateDeviceGroup, createNewDeviceGroup, initCreateDeviceGroup, updateCreateDeviceGroupObj } from '../../actions/allDevicesListAction';
import rootReducer from "../../../reducers";
import httpClient from '../../../../../shared/services/httpClient';
import RemoveModal from '../../components/DeviceGroup/RemoveModal';

jest.mock('../../../../../shared/services/httpClient', () => ({
    ...jest.requireActual('../../../../../shared/services/httpClient'),
    postHttpClientRequest: jest.fn()
}));

describe('All Devices Component', () => {

    test('Create Device Group API Calls', () => {
        const store = configureStore(rootReducer);
        httpClient?.postHttpClientRequest?.mockImplementation((url) => {
            return Promise.resolve({ status: 200, data: { body: { ...createDeviceGroupData, errorCode: '00' }, responseInfo: { responseCode: '00' } } });
        });
        store.dispatch(createNewDeviceGroup({ hashedMtn: 'dasdsad' }));
        store.dispatch(getCreateDeviceGroup({ hashedMtn: 'diusahusjaskbd' }));
        store.dispatch(initCreateDeviceGroup({}));
        store.dispatch(updateCreateDeviceGroupObj({}));
        window.location.hostname = 'localhost';
        store.dispatch(getCreateDeviceGroup({ hashedMtn: 'diusahusjaskbd' }));
    });

    test('Create Device Group API Call - 01 Error code', () => {
        const store = configureStore(rootReducer);
        httpClient?.postHttpClientRequest?.mockImplementation((url) => {
            return Promise.resolve({ status: 200, data: {} });
        });
        store.dispatch(getCreateDeviceGroup({ hashedMtn: 'diusahusjaskbd' }));
    });

    test('should render component - New CreateDeviceGroup - source - HomeInternet Landing', () => {
        const props = { history: { push() { } } };
        const routerLandingInitialState = { createDeviceGroupAPIData: createDeviceGroupData };
        const routerLandingReducer = (state = routerLandingInitialState) => state;
        const appReducer = combineReducers({ Router: routerLandingReducer });
        const testRootReducer = (state) => appReducer(state);

        const testStore = configureStore(testRootReducer);
        const component = render(
            <Provider store={testStore}>
                <CreateDeviceGroup {...props} />
            </Provider>
        );
        expect(component).toBeTruthy();

        const Home = screen.getByTestId('Home');
        expect(Home).toBeInTheDocument();
        fireEvent.click(Home);

    });

    test('should render component - New CreateDeviceGroup - source - AllDevicesList', () => {
        const props = { history: { push() { } } };
        const routerLandingInitialState = { createDeviceGroupAPIData: createDeviceGroupData, createDeviceGroupSource: 'allDevicesList' };
        const routerLandingReducer = (state = routerLandingInitialState) => state;
        const appReducer = combineReducers({ Router: routerLandingReducer });
        const testRootReducer = (state) => appReducer(state);

        const testStore = configureStore(testRootReducer);
        const component = render(
            <Provider store={testStore}>
                <CreateDeviceGroup {...props} />
            </Provider>
        );
        expect(component).toBeTruthy();

        const Home = screen.getByTestId('Home');
        expect(Home).toBeInTheDocument();
        fireEvent.click(Home);
    });

    test('should render component - New CreateDeviceGroup - store data', () => {
        const props = { history: { push() { } } };
        const routerLandingInitialState = { createDeviceGroupAPIData: createDeviceGroupData, createDeviceGroupData: { page: 'setName', name: 'Fox', devices: [] } };
        const routerLandingReducer = (state = routerLandingInitialState) => state;
        const appReducer = combineReducers({ Router: routerLandingReducer });
        const testRootReducer = (state) => appReducer(state);

        const testStore = configureStore(testRootReducer);
        const component = render(
            <Provider store={testStore}>
                <CreateDeviceGroup {...props} />
            </Provider>
        );
        expect(component).toBeTruthy();

        const Home = screen.getByTestId('Home');
        expect(Home).toBeInTheDocument();
        fireEvent.click(Home);

        const Next = screen.getByText('Next');
        expect(Next).toBeInTheDocument();
        fireEvent.click(Next);

        const groupNameInput = screen.getByTestId('group-name-input');
        expect(groupNameInput).toBeInTheDocument();
        fireEvent.change(groupNameInput, { target: { value: 'Jake Group' } });

    });

    test('should render component - New CreateDeviceGroup - store data', () => {
        const props = { history: { push() { } } };
        const routerLandingInitialState = { createDeviceGroupAPIData: createDeviceGroupData, createDeviceGroupData: { page: 'selectDevices', name: 'Fox', devices: [] } };
        const routerLandingReducer = (state = routerLandingInitialState) => state;
        const appReducer = combineReducers({ Router: routerLandingReducer });
        const testRootReducer = (state) => appReducer(state);

        const testStore = configureStore(testRootReducer);
        const component = render(
            <Provider store={testStore}>
                <CreateDeviceGroup {...props} />
            </Provider>
        );
        expect(component).toBeTruthy();

        const Home = screen.getByTestId('Home');
        expect(Home).toBeInTheDocument();
        fireEvent.click(Home);

        const DeviceCheckBox = screen.getAllByTestId('test-input')[0];
        expect(DeviceCheckBox).toBeInTheDocument();
        fireEvent.click(DeviceCheckBox);

        const Back = screen.getByText('Back');
        expect(Back).toBeInTheDocument();
        fireEvent.click(Back);
    });

    test('should render component - New CreateDeviceGroup - store data', () => {
        const props = { history: { push() { } } };
        const routerLandingInitialState = {
            createDeviceGroupAPIData: createDeviceGroupData, createDeviceGroupData: {
                page: 'selectDevices', name: 'Fox',
                devices: ["bc:d7:d4:cd:80:8a", "0a:97:ed:74:19:ef", "1a:3d:e1:bf:11:ed", "22:e7:b0:58:92:99", "8e:02:65:c2:68:69", "a2:77:ee:d8:9c:00",
                    "cc:a1:2b:e8:a5:94", "bc:d7:d4:cd:80:8b", "0a:97:ed:74:19:et", "1a:3d:e1:bf:11:er", "22:e7:b0:58:92:98", "8e:02:65:c2:68:68",
                    "a2:77:ee:d8:9c:01", "cc:a1:2b:e8:a5:9h", "8e:02:65:c2:68:6g", "a2:77:ee:d8:9c:07", "cc:a1:2b:e8:a5:96"]
            }
        };
        const routerLandingReducer = (state = routerLandingInitialState) => state;
        const appReducer = combineReducers({ Router: routerLandingReducer });
        const testRootReducer = (state) => appReducer(state);

        const testStore = configureStore(testRootReducer);
        const component = render(
            <Provider store={testStore}>
                <CreateDeviceGroup {...props} />
            </Provider>
        );
        expect(component).toBeTruthy();

        const Home = screen.getByTestId('Home');
        expect(Home).toBeInTheDocument();
        fireEvent.click(Home);

        const DeviceCheckBox = screen.getAllByTestId('test-input')[0];
        expect(DeviceCheckBox).toBeInTheDocument();
        fireEvent.click(DeviceCheckBox);

        const Back = screen.getByText('Back');
        expect(Back).toBeInTheDocument();
        fireEvent.click(Back);

        const Cancel = screen.getByText('Cancel');
        expect(Cancel).toBeInTheDocument();
        fireEvent.click(Cancel);
    });

    test('should render component - New CreateDeviceGroup - store data', () => {
        const props = { history: { push() { } } };
        const routerLandingInitialState = {
            createDeviceGroupAPIData: createDeviceGroupData, createDeviceGroupData: {
                page: 'selectDevices', name: 'Fox', isEdit: true,
                devices: ["bc:d7:d4:cd:80:8a", "0a:97:ed:74:19:ef", "1a:3d:e1:bf:11:ed", "22:e7:b0:58:92:99", "8e:02:65:c2:68:69", "a2:77:ee:d8:9c:00",
                    "cc:a1:2b:e8:a5:94", "bc:d7:d4:cd:80:8b", "0a:97:ed:74:19:et", "1a:3d:e1:bf:11:er", "22:e7:b0:58:92:98", "8e:02:65:c2:68:68",
                    "a2:77:ee:d8:9c:01", "cc:a1:2b:e8:a5:9h", "8e:02:65:c2:68:6g", "a2:77:ee:d8:9c:07", "cc:a1:2b:e8:a5:96"]
            }
        };
        const routerLandingReducer = (state = routerLandingInitialState) => state;
        const appReducer = combineReducers({ Router: routerLandingReducer });
        const testRootReducer = (state) => appReducer(state);

        const testStore = configureStore(testRootReducer);
        const component = render(
            <Provider store={testStore}>
                <CreateDeviceGroup {...props} />
            </Provider>
        );
        expect(component).toBeTruthy();

        const Home = screen.getByTestId('Home');
        expect(Home).toBeInTheDocument();
        fireEvent.click(Home);

        const DeviceCheckBox = screen.getAllByTestId('test-input')[1];
        expect(DeviceCheckBox).toBeInTheDocument();
        fireEvent.click(DeviceCheckBox);

        const Back = screen.getByText('Back');
        expect(Back).toBeInTheDocument();
        fireEvent.click(Back);
        
        const Save = screen.getByText('Save');
        expect(Save).toBeInTheDocument();
        fireEvent.click(Save);

        const Cancel = screen.getByText('Cancel');
        expect(Cancel).toBeInTheDocument();
        fireEvent.click(Cancel);
    });


    test("should show validation error for valid website input", async () => {

        const props = { history: { push() { } } };
        const routerLandingInitialState = {
            createDeviceGroupAPIData: createDeviceGroupData, createDeviceGroupData: {
                page: 'exception',
                name: "Verizon Office",
                devices: [
                    "bc:d7:d4:cd:80:8a",
                    "0a:97:ed:74:19:ef"
                ],
                schedule: {
                    daysOfTheWeek: [
                        1, 2
                    ],
                    "startTimeHour": "01",
                    "startTimeMinute": "00",
                    "stopTimeHour": "01",
                    "stopTimeMinute": "00",
                    "startTimeAmPm": "AM",
                    "stopTimeAmPm": "PM",
                }
            }
        };
        const routerLandingReducer = (state = routerLandingInitialState) => state;
        const appReducer = combineReducers({ Router: routerLandingReducer });
        const testRootReducer = (state) => appReducer(state);

        const testStore = configureStore(testRootReducer);
        const component = render(
            <Provider store={testStore}>
                <CreateDeviceGroup {...props} />
            </Provider>
        );

        const input = screen.getByTestId("website-input");
        fireEvent.change(input, { target: { value: "" } });

        const addButton = screen.getByTestId("add-btn");
        fireEvent.click(addButton);

        await waitFor(() => { 
            const errorMessage = screen.getByText("Please input website only, not webpage address.");
            expect(errorMessage).toBeInTheDocument()
        });
    });

    test("should not show validation error for valid website input", async () => {

        const props = { history: { push() { } } };
        const routerLandingInitialState = {
            createDeviceGroupAPIData: createDeviceGroupData, createDeviceGroupData: {
                page: 'exception',
                name: "Verizon Office",
                devices: [
                    "bc:d7:d4:cd:80:8a",
                    "0a:97:ed:74:19:ef"
                ],
                schedule: {
                    daysOfTheWeek: [
                        1, 2
                    ],
                    "startTimeHour": "01",
                    "startTimeMinute": "00",
                    "stopTimeHour": "01",
                    "stopTimeMinute": "00",
                    "startTimeAmPm": "AM",
                    "stopTimeAmPm": "PM",
                }
            }
        };
        const routerLandingReducer = (state = routerLandingInitialState) => state;
        const appReducer = combineReducers({ Router: routerLandingReducer });
        const testRootReducer = (state) => appReducer(state);

        const testStore = configureStore(testRootReducer);
        const component = render(
            <Provider store={testStore}>
                <CreateDeviceGroup {...props} />
            </Provider>
        );

        const input = screen.getByTestId("website-input");
        fireEvent.change(input, { target: { value: "www.verizon.com" } });

        await waitFor(() => {
            expect(screen.queryByTestId("error-message")).not.toBeInTheDocument();
        })
    });



    test("should remove a specific website from the list", async () => {

        const props = { history: { push() { } } };
        const routerLandingInitialState = {
            createDeviceGroupAPIData: createDeviceGroupData, createDeviceGroupData: {
                page: 'exception',
                name: "Verizon Office",
                devices: [
                    "bc:d7:d4:cd:80:8a",
                    "0a:97:ed:74:19:ef"
                ],
                schedule: {
                    daysOfTheWeek: [
                        1, 2
                    ],
                    "startTimeHour": "01",
                    "startTimeMinute": "00",
                    "stopTimeHour": "01",
                    "stopTimeMinute": "00",
                    "startTimeAmPm": "AM",
                    "stopTimeAmPm": "PM",
                }
            }
        };
        const routerLandingReducer = (state = routerLandingInitialState) => state;
        const appReducer = combineReducers({ Router: routerLandingReducer });
        const testRootReducer = (state) => appReducer(state);

        const testStore = configureStore(testRootReducer);
        const component = render(
            <Provider store={testStore}>
                <CreateDeviceGroup {...props} />
            </Provider>
        );

        const input = screen.getByTestId("website-input");
        fireEvent.change(input, { target: { value: "www.verizon.com" } });

        const addButton = screen.getByTestId("add-btn");
        fireEvent.click(addButton);

        await waitFor(() =>
            expect(screen.getByTestId("website-item")).toBeInTheDocument()
        )

        const removeButton = screen.getByTestId("remove-btn-0");
        fireEvent.click(removeButton);

        await waitFor(() =>
            expect(screen.queryByTestId("website-item")).not.toBeInTheDocument()
        )

    });

    test("should remove a specific website from the list", async () => {

        const props = { history: { push() { } } };
        const routerLandingInitialState = {
            createDeviceGroupAPIData: createDeviceGroupData, createDeviceGroupData: {
                page: 'exception', isEdit: true,
                name: "Verizon Office",
                devices: [
                    "bc:d7:d4:cd:80:8a",
                    "0a:97:ed:74:19:ef"
                ],
                schedule: {
                    daysOfTheWeek: [
                        1, 2
                    ],
                    "startTimeHour": "01",
                    "startTimeMinute": "00",
                    "stopTimeHour": "01",
                    "stopTimeMinute": "00",
                    "startTimeAmPm": "AM",
                    "stopTimeAmPm": "PM",
                },
                exception: ['wewe.fsdf.fsd']
            }
        };
        const routerLandingReducer = (state = routerLandingInitialState) => state;
        const appReducer = combineReducers({ Router: routerLandingReducer });
        const testRootReducer = (state) => appReducer(state);

        const testStore = configureStore(testRootReducer);
        const component = render(
            <Provider store={testStore}>
                <CreateDeviceGroup {...props} />
            </Provider>
        );

    });

    test("should remove all websites from the list", async () => {

        const props = { history: { push() { } } };
        const routerLandingInitialState = {
            createDeviceGroupAPIData: createDeviceGroupData, createDeviceGroupData: {
                page: 'exception',
                name: "Verizon Office",
                devices: [
                    "bc:d7:d4:cd:80:8a",
                    "0a:97:ed:74:19:ef"
                ],
                schedule: {
                    daysOfTheWeek: [
                        1, 2
                    ],
                    "startTimeHour": "01",
                    "startTimeMinute": "00",
                    "stopTimeHour": "01",
                    "stopTimeMinute": "00",
                    "startTimeAmPm": "AM",
                    "stopTimeAmPm": "PM",
                }
            }
        };
        const routerLandingReducer = (state = routerLandingInitialState) => state;
        const appReducer = combineReducers({ Router: routerLandingReducer });
        const testRootReducer = (state) => appReducer(state);

        const testStore = configureStore(testRootReducer);
        const component = render(
            <Provider store={testStore}>
                <CreateDeviceGroup {...props} />
            </Provider>
        );

        const input = screen.getByTestId("website-input");
        fireEvent.change(input, { target: { value: "www.verizon.com" } });
        fireEvent.click(screen.getByTestId("add-btn"));

        fireEvent.change(input, { target: { value: "www.google.com" } });
        fireEvent.click(screen.getByTestId("add-btn"));

        await waitFor(() =>
            expect(screen.getAllByTestId("website-item")).toHaveLength(2)
        )

        await waitFor(() =>
            expect(screen.getByTestId("remove-all-btn")).toBeInTheDocument()
        )
        fireEvent.click(screen.getByTestId("remove-all-btn"));

        await waitFor(() =>
            expect(screen.queryByTestId("website-item")).not.toBeInTheDocument()
        )
    });


    test("should navigate to the previous page when Back button is clicked", async () => {

        const props = { history: { push() { } } };
        const routerLandingInitialState = {
            createDeviceGroupAPIData: createDeviceGroupData, createDeviceGroupData: {
                page: 'exception',
                name: "Verizon Office",
                devices: [
                    "bc:d7:d4:cd:80:8a",
                    "0a:97:ed:74:19:ef"
                ],
                schedule: {
                    daysOfTheWeek: [
                        1, 2
                    ],
                    "startTimeHour": "01",
                    "startTimeMinute": "00",
                    "stopTimeHour": "01",
                    "stopTimeMinute": "00",
                    "startTimeAmPm": "AM",
                    "stopTimeAmPm": "PM",
                }
            }
        };
        const routerLandingReducer = (state = routerLandingInitialState) => state;
        const appReducer = combineReducers({ Router: routerLandingReducer });
        const testRootReducer = (state) => appReducer(state);

        const testStore = configureStore(testRootReducer);
        const component = render(
            <Provider store={testStore}>
                <CreateDeviceGroup {...props} />
            </Provider>
        );

        const backButton = screen.getByTestId("back-btn");
        expect(backButton).toBeInTheDocument();

        expect(screen.queryByTestId("exception-page")).not.toBeInTheDocument();
        fireEvent.click(backButton);
        await waitFor(() =>
            expect(screen.getByTestId("exception")).toBeInTheDocument()
        )

    });

    test("should display Next button after adding website", async () => {

        const props = { history: { push() { } } };
        const routerLandingInitialState = {
            createDeviceGroupAPIData: createDeviceGroupData, createDeviceGroupData: {
                page: 'exception',
                name: "Verizon Office",
                devices: [
                    "bc:d7:d4:cd:80:8a",
                    "0a:97:ed:74:19:ef"
                ],
                schedule: {
                    daysOfTheWeek: [
                        1, 2
                    ],
                    "startTimeHour": "01",
                    "startTimeMinute": "00",
                    "stopTimeHour": "01",
                    "stopTimeMinute": "00",
                    "startTimeAmPm": "AM",
                    "stopTimeAmPm": "PM",
                }
            }
        };
        const routerLandingReducer = (state = routerLandingInitialState) => state;
        const appReducer = combineReducers({ Router: routerLandingReducer });
        const testRootReducer = (state) => appReducer(state);

        const testStore = configureStore(testRootReducer);
        const component = render(
            <Provider store={testStore}>
                <CreateDeviceGroup {...props} />
            </Provider>
        );

        const input = screen.getByTestId("website-input");
        const addButton = screen.getByTestId("add-btn");

        fireEvent.change(input, { target: { value: "www.verizon.com" } });
        fireEvent.click(addButton);

        await waitFor(() =>
            expect(screen.getByTestId("website-item")).toBeInTheDocument()
        )

        await waitFor(() =>
            expect(screen.getByTestId("next-btn")).toBeInTheDocument()
        )
        fireEvent.click(screen.getByTestId("next-btn"));

        await waitFor(() =>
            expect(screen.getByText("Next")).toBeInTheDocument()
        )
        await waitFor(() =>
            expect(screen.getByText("Cancel")).toBeInTheDocument()
        )

    });

    // test("should remove all websites from the list", async() => {

    //     const props = { history: { push() { } } };
    //     const routerLandingInitialState = {
    //         createDeviceGroupAPIData: createDeviceGroupData, createDeviceGroupData: {
    //             page: 'exception',
    //         name: "Verizon Office",
    //         devices: [
    //             "bc:d7:d4:cd:80:8a",
    //             "0a:97:ed:74:19:ef"
    //         ],
    //         schedule: {
    //             daysOfTheWeek: [
    //                 1, 2
    //             ],
    //             "startTimeHour": "01",
    //             "startTimeMinute": "00",
    //             "stopTimeHour": "01",
    //             "stopTimeMinute": "00",
    //             "startTimeAmPm": "AM",
    //             "stopTimeAmPm": "PM",
    //         }
    //     } 
    //     };
    //     const routerLandingReducer = (state = routerLandingInitialState) => state;
    //     const appReducer = combineReducers({ Router: routerLandingReducer });
    //     const testRootReducer = (state) => appReducer(state);

    //     const testStore = configureStore(testRootReducer);
    //     const component = render(
    //         <Provider store={testStore}>
    //             <CreateDeviceGroup {...props} />
    //         </Provider>
    //     );

    //     const addButton = screen.getByTestId("add-btn");
    //     fireEvent.click(addButton);
    //     fireEvent.click(addButton);

    //     await waitFor(() => 
    //         expect(screen.getAllByTestId("website-item").length).toBe(2)
    //     )

    //     await waitFor(() => 
    //         expect(screen.getByTestId("remove-all-btn")).toBeInTheDocument()
    //     )
    //     // const removeAllButton = await screen.findByTestId("remove-all-btn");
    //     // fireEvent.click(screen.getByTestId("remove-all-btn"));

    //     await waitFor(() => 
    //         expect(screen.queryByTestId("website-item")).toBeNull()
    //     )
    // });


    // test("should remove all websites", async () => {

    //     const props = { history: { push() { } } };
    //     const routerLandingInitialState = {
    //         createDeviceGroupAPIData: createDeviceGroupData, createDeviceGroupData: {
    //             page: 'exception',
    //         name: "Verizon Office",
    //         devices: [
    //             "bc:d7:d4:cd:80:8a",
    //             "0a:97:ed:74:19:ef"
    //         ],
    //         schedule: {
    //             daysOfTheWeek: [
    //                 1, 2
    //             ],
    //             "startTimeHour": "01",
    //             "startTimeMinute": "00",
    //             "stopTimeHour": "01",
    //             "stopTimeMinute": "00",
    //             "startTimeAmPm": "AM",
    //             "stopTimeAmPm": "PM",
    //         }
    //     } 
    //     };
    //     const routerLandingReducer = (state = routerLandingInitialState) => state;
    //     const appReducer = combineReducers({ Router: routerLandingReducer });
    //     const testRootReducer = (state) => appReducer(state);

    //     const testStore = configureStore(testRootReducer);
    //     const component = render(
    //         <Provider store={testStore}>
    //             <CreateDeviceGroup {...props} />
    //         </Provider>
    //     );

    //     const addButton = screen.getByTestId("add-btn");
    //     act(() => {
    //         fireEvent.click(addButton);
    //         fireEvent.click(addButton);
    //     })

    //     await waitFor(() => 
    //         expect(screen.getByTestId("remove-all-btn")).toBeInTheDocument()
    //     )
    //     act(() => {
    //         fireEvent.click(screen.getByTestId("remove-all-btn"));
    //     })

    //     await waitFor(() => 
    //         expect(screen.queryByTestId("website-item")).toBeNull()
    //     )
    // });

    // test("should remove all websites from the list", async() => {

    //     const props = { history: { push() { } } };
    //     const routerLandingInitialState = {
    //         createDeviceGroupAPIData: createDeviceGroupData, createDeviceGroupData: {
    //             page: 'exception',
    //         name: "Verizon Office",
    //         devices: [
    //             "bc:d7:d4:cd:80:8a",
    //             "0a:97:ed:74:19:ef"
    //         ],
    //         schedule: {
    //             daysOfTheWeek: [
    //                 1, 2
    //             ],
    //             "startTimeHour": "01",
    //             "startTimeMinute": "00",
    //             "stopTimeHour": "01",
    //             "stopTimeMinute": "00",
    //             "startTimeAmPm": "AM",
    //             "stopTimeAmPm": "PM",
    //         }
    //     } 
    //     };
    //     const routerLandingReducer = (state = routerLandingInitialState) => state;
    //     const appReducer = combineReducers({ Router: routerLandingReducer });
    //     const testRootReducer = (state) => appReducer(state);

    //     const testStore = configureStore(testRootReducer);
    //     const component = render(
    //         <Provider store={testStore}>
    //             <CreateDeviceGroup {...props} />
    //         </Provider>
    //     );

    //     const addButton = screen.getByTestId("add-btn");
    //     fireEvent.click(addButton);
    //     fireEvent.click(addButton);

    //     const removeAllButton = await screen.findByTestId("remove-all-btn");
    //     fireEvent.click(removeAllButton);

    //     expect(screen.getByTestId("website-list")).toBeEmptyDOMElement();
    // });

    test('should render component - New CreateDeviceGroup - store data', () => {
        const props = { history: { push() { } } };
        const routerLandingInitialState = {
            createDeviceGroupAPIData: createDeviceGroupData, createDeviceGroupData: {
                page: 'selectDevices', name: 'Fox',
                devices: ["0a:97:ed:74:19:ef", "1a:3d:e1:bf:11:ed", "22:e7:b0:58:92:99", "8e:02:65:c2:68:69", "a2:77:ee:d8:9c:00",
                    "cc:a1:2b:e8:a5:94", "bc:d7:d4:cd:80:8b", "0a:97:ed:74:19:et", "1a:3d:e1:bf:11:er", "22:e7:b0:58:92:98", "8e:02:65:c2:68:68",
                    "a2:77:ee:d8:9c:01", "cc:a1:2b:e8:a5:9h", "8e:02:65:c2:68:6g", "a2:77:ee:d8:9c:07", "cc:a1:2b:e8:a5:96"]
            }
        };
        const routerLandingReducer = (state = routerLandingInitialState) => state;
        const appReducer = combineReducers({ Router: routerLandingReducer });
        const testRootReducer = (state) => appReducer(state);

        const testStore = configureStore(testRootReducer);
        const component = render(
            <Provider store={testStore}>
                <CreateDeviceGroup {...props} />
            </Provider>
        );
        expect(component).toBeTruthy();

        const Home = screen.getByTestId('Home');
        expect(Home).toBeInTheDocument();
        fireEvent.click(Home);

        const AllDevices = screen.getByText('All devices /');
        expect(AllDevices).toBeInTheDocument();
        fireEvent.click(AllDevices);

        const DeviceCheckBox = screen.getAllByTestId('test-input')[0];
        expect(DeviceCheckBox).toBeInTheDocument();
        fireEvent.click(DeviceCheckBox);

        const Back = screen.getByText('Back');
        expect(Back).toBeInTheDocument();
        fireEvent.click(Back);

        const Cancel = screen.getByText('Cancel');
        expect(Cancel).toBeInTheDocument();
        fireEvent.click(Cancel);

        const SortSelect = screen.getByLabelText('Sort by:');
        expect(SortSelect).toBeInTheDocument();
        fireEvent.change(SortSelect, { target: { value: 'A-Z' } });
        fireEvent.change(SortSelect, { target: { value: 'Z-A' } });

        const SearchInput = screen.getByTestId('search-devices');
        expect(SearchInput).toBeInTheDocument();
        fireEvent.change(SearchInput, { target: { value: 'lg' } });
    });
    test('should render component - New CreateDeviceGroup - store data', () => {
        const props = { history: { push() { } } };
        const routerLandingInitialState = {
            createDeviceGroupAPIData: createDeviceGroupData, createDeviceGroupData: {
                page: 'exception',
                name: "Verizon Office",
                devices: [
                    "bc:d7:d4:cd:80:8a",
                    "0a:97:ed:74:19:ef"
                ],
                schedule: {
                    daysOfTheWeek: [
                        1, 2
                    ],
                    "startTimeHour": "01",
                    "startTimeMinute": "00",
                    "stopTimeHour": "01",
                    "stopTimeMinute": "00",
                    "startTimeAmPm": "AM",
                    "stopTimeAmPm": "PM",
                }
            }
        };
        const routerLandingReducer = (state = routerLandingInitialState) => state;
        const appReducer = combineReducers({ Router: routerLandingReducer });
        const testRootReducer = (state) => appReducer(state);

        const testStore = configureStore(testRootReducer);
        const component = render(
            <Provider store={testStore}>
                <CreateDeviceGroup {...props} />
            </Provider>
        );
        expect(component).toBeTruthy();

        const Home = screen.getByTestId('Home');
        expect(Home).toBeInTheDocument();
        fireEvent.click(Home);

        const AllDevices = screen.getByText('All devices /');
        expect(AllDevices).toBeInTheDocument();
        fireEvent.click(AllDevices);

        const Back = screen.getByText('Back');
        expect(Back).toBeInTheDocument();
        fireEvent.click(Back);

        const Cancel = screen.getByText('Cancel');
        expect(Cancel).toBeInTheDocument();
        fireEvent.click(Cancel);
    });

    test('Should render component - CancelModal', () => {
        const props = { history: { push() { } } };
        const routerLandingInitialState = {};
        const routerLandingReducer = (state = routerLandingInitialState) => state;
        const appReducer = combineReducers({ Router: routerLandingReducer });
        const testRootReducer = (state) => appReducer(state);

        const testStore = configureStore(testRootReducer);
        const component = render(
            <Provider store={testStore}>
                <CancelModal isOpen backBtn='Back' confirmBtn='Confirm' />
            </Provider>
        );
        expect(component).toBeTruthy();
        
    });
    test('Should render component - RemoveModal', () => {
        const props = { history: { push() { } } };
        const routerLandingInitialState = {};
        const routerLandingReducer = (state = routerLandingInitialState) => state;
        const appReducer = combineReducers({ Router: routerLandingReducer });
        const testRootReducer = (state) => appReducer(state);

        const testStore = configureStore(testRootReducer);
        const component = render(
            <Provider store={testStore}>
                <RemoveModal isOpen backBtn='Cancel' confirmBtn='Remove'  />
            </Provider>
        );
        expect(component).toBeTruthy();

    });

    test('should render component - New CreateDeviceGroup - Set Schedule page', () => {
        const props = { history: { push() { } } };
        const routerLandingInitialState = {
            createDeviceGroupAPIData: createDeviceGroupData, createDeviceGroupData: {
                page: 'setSchedule', name: 'Fox',
                devices: ["0a:97:ed:74:19:ef", "1a:3d:e1:bf:11:ed"]
            }
        };
        const routerLandingReducer = (state = routerLandingInitialState) => state;
        const appReducer = combineReducers({ Router: routerLandingReducer });
        const testRootReducer = (state) => appReducer(state);

        const testStore = configureStore(testRootReducer);
        const component = render(
            <Provider store={testStore}>
                <CreateDeviceGroup {...props} />
            </Provider>
        );
        expect(component).toBeTruthy();

        const Skip = screen.getByText('Skip');
        expect(Skip).toBeInTheDocument();
        fireEvent.click(Skip);
    });

    test('should render component - New CreateDeviceGroup - Set Schedule page', () => {
        const props = { history: { push() { } } };
        const routerLandingInitialState = {
            createDeviceGroupAPIData: createDeviceGroupData, createDeviceGroupData: {
                page: 'setSchedule', name: 'Fox', isEdit: true,
                devices: ["0a:97:ed:74:19:ef", "1a:3d:e1:bf:11:ed"],
                schedule: {
                    daysOfTheWeek: [
                        1, 2
                    ],
                    "startTimeHour": "01",
                    "startTimeMinute": "00",
                    "stopTimeHour": "01",
                    "stopTimeMinute": "00",
                    "startTimeAmPm": "AM",
                    "stopTimeAmPm": "PM",
                }
            }
        };
        const routerLandingReducer = (state = routerLandingInitialState) => state;
        const appReducer = combineReducers({ Router: routerLandingReducer });
        const testRootReducer = (state) => appReducer(state);

        const testStore = configureStore(testRootReducer);
        const component = render(
            <Provider store={testStore}>
                <CreateDeviceGroup {...props} />
            </Provider>
        );
        expect(component).toBeTruthy();

    });

    test('should render component - New CreateDeviceGroup - Set Schedule page', () => {
        const props = { history: { push() { } } };
        const routerLandingInitialState = {
            createDeviceGroupAPIData: createDeviceGroupData, createDeviceGroupData: {
                page: 'setSchedule', name: 'Fox',
                devices: ["0a:97:ed:74:19:ef", "1a:3d:e1:bf:11:ed"]
            }
        };
        const routerLandingReducer = (state = routerLandingInitialState) => state;
        const appReducer = combineReducers({ Router: routerLandingReducer });
        const testRootReducer = (state) => appReducer(state);

        const testStore = configureStore(testRootReducer);
        const component = render(
            <Provider store={testStore}>
                <CreateDeviceGroup {...props} />
            </Provider>
        );
        expect(component).toBeTruthy();

        const Back = screen.getByText('Back');
        expect(Back).toBeInTheDocument();
        fireEvent.click(Back);
    });

    test('should render component - New CreateDeviceGroup - Set Schedule page', () => {
        const props = { history: { push() { } } };
        const routerLandingInitialState = {
            createDeviceGroupAPIData: createDeviceGroupData, createDeviceGroupData: {
                page: 'setSchedule', name: 'Fox',
                devices: ["0a:97:ed:74:19:ef", "1a:3d:e1:bf:11:ed"]
            }
        };
        const routerLandingReducer = (state = routerLandingInitialState) => state;
        const appReducer = combineReducers({ Router: routerLandingReducer });
        const testRootReducer = (state) => appReducer(state);

        const testStore = configureStore(testRootReducer);
        const component = render(
            <Provider store={testStore}>
                <CreateDeviceGroup {...props} />
            </Provider>
        );
        expect(component).toBeTruthy();

        const Sunday = screen.getByText('Sun');
        expect(Sunday).toBeInTheDocument();
        fireEvent.click(Sunday);

        const Next = screen.getByText('Next');
        expect(Next).toBeInTheDocument();
        fireEvent.click(Next);

    });

    test('should render component - New CreateDeviceGroup - Set Schedule page', () => {
        const props = { history: { push() { } } };
        const routerLandingInitialState = {
            createDeviceGroupAPIData: createDeviceGroupData, createDeviceGroupData: {
                page: 'setSchedule', name: 'Fox',
                devices: ["0a:97:ed:74:19:ef", "1a:3d:e1:bf:11:ed"]
            }
        };
        const routerLandingReducer = (state = routerLandingInitialState) => state;
        const appReducer = combineReducers({ Router: routerLandingReducer });
        const testRootReducer = (state) => appReducer(state);

        const testStore = configureStore(testRootReducer);
        const component = render(
            <Provider store={testStore}>
                <CreateDeviceGroup {...props} />
            </Provider>
        );
        expect(component).toBeTruthy();

        const Sunday = screen.getByText('Sun');
        expect(Sunday).toBeInTheDocument();
        fireEvent.click(Sunday);

        const clearSchedule = screen.getByText('Clear schedule');
        expect(clearSchedule).toBeInTheDocument();
        fireEvent.click(clearSchedule);
    });

    test('should render component - New CreateDeviceGroup - Set Schedule page', () => {
        const props = { history: { push() { } } };
        const routerLandingInitialState = {
            createDeviceGroupAPIData: createDeviceGroupData, createDeviceGroupData: {
                page: 'setSchedule', name: 'Fox',
                devices: ["0a:97:ed:74:19:ef", "1a:3d:e1:bf:11:ed"]
            }
        };
        const routerLandingReducer = (state = routerLandingInitialState) => state;
        const appReducer = combineReducers({ Router: routerLandingReducer });
        const testRootReducer = (state) => appReducer(state);

        const testStore = configureStore(testRootReducer);
        const component = render(
            <Provider store={testStore}>
                <CreateDeviceGroup {...props} />
            </Provider>
        );
        expect(component).toBeTruthy();

        const Sunday = screen.getByText('Sun');
        expect(Sunday).toBeInTheDocument();
        fireEvent.click(Sunday);
        fireEvent.click(Sunday);
    });

    test('should render component - New CreateDeviceGroup - Set Schedule page', () => {
        const props = { history: { push() { } } };
        const routerLandingInitialState = {
            createDeviceGroupAPIData: createDeviceGroupData, createDeviceGroupData: {
                page: 'setSchedule', name: 'Fox',
                devices: ["0a:97:ed:74:19:ef", "1a:3d:e1:bf:11:ed"]
            }
        };
        const routerLandingReducer = (state = routerLandingInitialState) => state;
        const appReducer = combineReducers({ Router: routerLandingReducer });
        const testRootReducer = (state) => appReducer(state);

        const testStore = configureStore(testRootReducer);
        const component = render(
            <Provider store={testStore}>
                <CreateDeviceGroup {...props} />
            </Provider>
        );
        expect(component).toBeTruthy();

        const Sunday = screen.getByText('Sun');
        expect(Sunday).toBeInTheDocument();
        fireEvent.click(Sunday);

        // const select = screen.getAllByLabelText('');
        // expect(select[0]).toBeInTheDocument();
        // fireEvent.click(Sunday);

        // fireEvent.change(select[0], { target: { value: '01' } });
        // fireEvent.change(select[1], { target: { value: '01' } });
        // fireEvent.change(select[2], { target: { value: '01' } });
        // fireEvent.change(select[3], { target: { value: '01' } });
    });

    test('should render component - New CreateDeviceGroup - Review page', () => {
        const props = { history: { push() { } } };
        const routerLandingInitialState = {
            createDeviceGroupAPIData: createDeviceGroupData, createDeviceGroupData: {
                page: 'review', name: 'Fox',
                devices: []
            }
        };
        const routerLandingReducer = (state = routerLandingInitialState) => state;
        const appReducer = combineReducers({ Router: routerLandingReducer });
        const testRootReducer = (state) => appReducer(state);

        const testStore = configureStore(testRootReducer);
        const component = render(
            <Provider store={testStore}>
                <CreateDeviceGroup {...props} />
            </Provider>
        );
        expect(component).toBeTruthy();

        const groupNameInput = screen.getByTestId('group-name-input');
        expect(groupNameInput).toBeInTheDocument();
        fireEvent.change(groupNameInput, { target: { value: 'Jake Group' } });
        const Create = screen.getByText('Create');       
        expect(Create).toBeInTheDocument();
        fireEvent.click(Create);
        const Cancel = screen.getByText('Cancel');       
        expect(Cancel).toBeInTheDocument();
        fireEvent.click(ancel);
    });

    test('should render component - New CreateDeviceGroup - Review page', () => {
        const props = { history: { push() { } } };
        const routerLandingInitialState = {
            createDeviceGroupAPIData: createDeviceGroupData, createDeviceGroupData: {
                page: 'review', name: 'Fox',
                devices: ["0a:97:ed:74:19:ef", "1a:3d:e1:bf:11:ed"],
                schedule: { daysOfTheWeek: [] }
            }
        };
        const routerLandingReducer = (state = routerLandingInitialState) => state;
        const appReducer = combineReducers({ Router: routerLandingReducer });
        const testRootReducer = (state) => appReducer(state);

        const testStore = configureStore(testRootReducer);
        const component = render(
            <Provider store={testStore}>
                <CreateDeviceGroup {...props} />
            </Provider>
        );
        expect(component).toBeTruthy();

        const Create = screen.getByText('Create');
        expect(Create).toBeInTheDocument();
        fireEvent.click(Create);
        
        const Back = screen.getByText('Back');
        expect(Back).toBeInTheDocument();
        fireEvent.click(Back);
    });

    test('should render component - New CreateDeviceGroup - Review page', () => {
        const props = { history: { push() { } } };
        const routerLandingInitialState = {
            createDeviceGroupAPIData: createDeviceGroupData, createDeviceGroupData: {
                page: 'review', name: 'Fox',
                devices: ["0a:97:ed:74:19:ef", "1a:3d:e1:bf:11:ed"],
                schedule: {
                    daysOfTheWeek: [
                        1, 2
                    ],
                    startTimeHour: "01",
                    startTimeMinute: "00",
                    stopTimeHour: "01",
                    stopTimeMinute: "00",
                    startTimeAmPm: "AM",
                    stopTimeAmPm: "PM",
                }
            }
        };
        const routerLandingReducer = (state = routerLandingInitialState) => state;
        const appReducer = combineReducers({ Router: routerLandingReducer });
        const testRootReducer = (state) => appReducer(state);

        const testStore = configureStore(testRootReducer);
        const component = render(
            <Provider store={testStore}>
                <CreateDeviceGroup {...props} />
            </Provider>
        );
        expect(component).toBeTruthy();

        const Create = screen.getByText('Create');
        expect(Create).toBeInTheDocument();
        fireEvent.click(Create);
    });

    test('should render component - New CreateDeviceGroup - Review page', () => {
        const props = { history: { push() { } } };
        const routerLandingInitialState = {
            createDeviceGroupAPIData: createDeviceGroupData, createDeviceGroupData: {
                page: 'review', name: 'Fox',
                devices: ["0a:97:ed:74:19:ef", "1a:3d:e1:bf:11:ed"],
                schedule: {
                    daysOfTheWeek: [
                        1, 2
                    ],
                    startTimeHour: "01",
                    startTimeMinute: "00",
                    stopTimeHour: "01",
                    stopTimeMinute: "00",
                    startTimeAmPm: "AM",
                    stopTimeAmPm: "PM",
                },
                exception: ['lkasdj.asdlj.asljkd']
            }
        };
        const routerLandingReducer = (state = routerLandingInitialState) => state;
        const appReducer = combineReducers({ Router: routerLandingReducer });
        const testRootReducer = (state) => appReducer(state);

        const testStore = configureStore(testRootReducer);
        const component = render(
            <Provider store={testStore}>
                <CreateDeviceGroup {...props} />
            </Provider>
        );
        expect(component).toBeTruthy();

        const Create = screen.getByText('Create');
        expect(Create).toBeInTheDocument();
        fireEvent.click(Create);
        
        const addDevice = screen.getByText('Add devices');
        expect(addDevice).toBeInTheDocument();
        fireEvent.click(addDevice);
    });

    test('should render component - New CreateDeviceGroup - Review page', () => {
        const props = { history: { push() { } } ,confirmClick:jest.fn()};
        const routerLandingInitialState = {
            createDeviceGroupAPIData: createDeviceGroupData, createDeviceGroupData: {
                page: 'review', name: 'Fox',
                devices: ["0a:97:ed:74:19:ef", "1a:3d:e1:bf:11:ed"],
                schedule: {
                    daysOfTheWeek: [
                        1, 2
                    ],
                    startTimeHour: "01",
                    startTimeMinute: "00",
                    stopTimeHour: "01",
                    stopTimeMinute: "00",
                    startTimeAmPm: "AM",
                    stopTimeAmPm: "PM",
                },
                exception: ['lkasdj.asdlj.asljkd']
            }
        };
        const routerLandingReducer = (state = routerLandingInitialState) => state;
        const appReducer = combineReducers({ Router: routerLandingReducer });
        const testRootReducer = (state) => appReducer(state);

        const testStore = configureStore(testRootReducer);
        const component = render(
            <Provider store={testStore}>
                <CreateDeviceGroup {...props} />
            </Provider>
        );
        expect(component).toBeTruthy();

        const Remove = screen.getAllByTestId('remove-device')[0];
        expect(Remove).toBeInTheDocument();
        fireEvent.click(Remove);

        const RemoveAll = screen.getByTestId('remove-all-device');
        expect(RemoveAll).toBeInTheDocument();
        fireEvent.click(RemoveAll);
    });
    
    
    test('should render component - Edit Schedule', async() => {
        const mockSetCurrentPage = jest.fn();
        const props = { history: { push: jest.fn() }, setCurrentPage: mockSetCurrentPage };
        const routerLandingInitialState = {
            createDeviceGroupAPIData: createDeviceGroupData, createDeviceGroupData: {
                page: 'review', name: 'Fox',
                devices: ["0a:97:ed:74:19:ef", "1a:3d:e1:bf:11:ed"],
                schedule: {
                    daysOfTheWeek: [
                        1, 2
                    ],
                    startTimeHour: "01",
                    startTimeMinute: "00",
                    stopTimeHour: "01",
                    stopTimeMinute: "00",
                    startTimeAmPm: "AM",
                    stopTimeAmPm: "PM",
                },
                exception: ['lkasdj.asdlj.asljkd']
            }
        };
        const routerLandingReducer = (state = routerLandingInitialState) => state;
        const appReducer = combineReducers({ Router: routerLandingReducer });
        const testRootReducer = (state) => appReducer(state);

        const testStore = configureStore(testRootReducer);
        const component = render(
            <Provider store={testStore}>
                <CreateDeviceGroup {...props} />
            </Provider>
        );
        expect(component).toBeTruthy();

        await waitFor(() => {
            const editSchedule = screen.getByText('Edit schedule');
            expect(editSchedule).toBeInTheDocument();
            fireEvent.click(editSchedule);
        })
    })
    
    
    test('should render component - Set Schedule', async() => {
        const mockSetCurrentPage = jest.fn();
        const props = { history: { push: jest.fn() }, setCurrentPage: mockSetCurrentPage };
        const routerLandingInitialState = {
            createDeviceGroupAPIData: createDeviceGroupData, createDeviceGroupData: {
                page: 'review', name: 'Fox',
                devices: ["0a:97:ed:74:19:ef", "1a:3d:e1:bf:11:ed"],
                schedule: {
                    daysOfTheWeek: [],
                },
                exception: ['lkasdj.asdlj.asljkd']
            }
        };
        const routerLandingReducer = (state = routerLandingInitialState) => state;
        const appReducer = combineReducers({ Router: routerLandingReducer });
        const testRootReducer = (state) => appReducer(state);

        const testStore = configureStore(testRootReducer);
        const component = render(
            <Provider store={testStore}>
                <CreateDeviceGroup {...props} />
            </Provider>
        );
        expect(component).toBeTruthy();

        await waitFor(() => {
            const setSchedule = screen.getByText('Set schedule');
            expect(setSchedule).toBeInTheDocument();
            fireEvent.click(setSchedule);
        })
    })
    test('should render component - Add Website', async() => {
        const mockSetCurrentPage = jest.fn();
        const props = { history: { push: jest.fn() }, setCurrentPage: mockSetCurrentPage };
        const routerLandingInitialState = {
            createDeviceGroupAPIData: createDeviceGroupData, createDeviceGroupData: {
                page: 'review', name: 'Fox',
                devices: ["0a:97:ed:74:19:ef", "1a:3d:e1:bf:11:ed"],
                schedule: {
                    daysOfTheWeek: [
                        1, 2
                    ],
                    startTimeHour: "01",
                    startTimeMinute: "00",
                    stopTimeHour: "01",
                    stopTimeMinute: "00",
                    startTimeAmPm: "AM",
                    stopTimeAmPm: "PM",
                },
                exception: ['lkasdj.asdlj.asljkd']
            }
        };
        const routerLandingReducer = (state = routerLandingInitialState) => state;
        const appReducer = combineReducers({ Router: routerLandingReducer });
        const testRootReducer = (state) => appReducer(state);

        const testStore = configureStore(testRootReducer);
        const component = render(
            <Provider store={testStore}>
                <CreateDeviceGroup {...props} />
            </Provider>
        );
        expect(component).toBeTruthy();

        await waitFor(() => {
            const addWebsites = screen.getByText('Add websites');
            expect(addWebsites).toBeInTheDocument();
            fireEvent.click(addWebsites);
        })
    })
    test('should render component - Add Keyword', async() => {
        const mockSetCurrentPage = jest.fn();
        const props = { history: { push: jest.fn() }, setCurrentPage: mockSetCurrentPage };
        const routerLandingInitialState = {
            createDeviceGroupAPIData: createDeviceGroupData, createDeviceGroupData: {
                page: 'review', name: 'Fox',
                devices: ["0a:97:ed:74:19:ef", "1a:3d:e1:bf:11:ed"],
                schedule: {
                    daysOfTheWeek: [
                        1, 2
                    ],
                    startTimeHour: "01",
                    startTimeMinute: "00",
                    stopTimeHour: "01",
                    stopTimeMinute: "00",
                    startTimeAmPm: "AM",
                    stopTimeAmPm: "PM",
                },
                "websiteExceptions": [
                    {
                        "type": 0,
                        "value": "www.cartoonnetwork.com"
                    },
                    {
                        "type": 0,
                        "value": "www.yamaha.com"
                    }
                ],
                "keywordExceptions": [
                    {
                        "type": 1,
                        "value": "Avengers"
                    },
                    {
                        "type": 1,
                        "value": "pokemon"
                    }
                ]
            }
        };
        const routerLandingReducer = (state = routerLandingInitialState) => state;
        const appReducer = combineReducers({ Router: routerLandingReducer });
        const testRootReducer = (state) => appReducer(state);

        const testStore = configureStore(testRootReducer);
        const component = render(
            <Provider store={testStore}>
                <CreateDeviceGroup {...props} />
            </Provider>
        );
        expect(component).toBeTruthy();

        await waitFor(() => {
            const addWebsites = screen.getByText('Add Keywords');
            expect(addWebsites).toBeInTheDocument();
            fireEvent.click(addWebsites);
        })
    })
});

