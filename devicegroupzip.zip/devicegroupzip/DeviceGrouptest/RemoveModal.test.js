import React from 'react';
import "../../../../../../config/jest/test-setup"
import { render, screen, fireEvent } from '@testing-library/react';
import '@testing-library/jest-dom';
import { combineReducers } from 'redux';
import { Provider } from 'react-redux';
import configureStore from '../../../../../shared/store/configureStore';
import rootReducer from "../../../reducers";
import CreateDeviceGroup from '../../components/DeviceGroup/CreateDeviceGroup';
import { createDeviceGroupData } from './DeviceGroupCreate.mock';
import { createNewDeviceGroup } from '../../actions/allDevicesListAction';
import httpClient from '../../../../../shared/services/httpClient';

jest.mock('../../components/DeviceGroup/RemoveModal', () => {
    return ({ title, body, confirmBtn, cancelBtn, onClose, confirmClick }) => <>
        <div>{title}</div>
        {body && <div>{body}</div>}
        <div onClick={confirmClick}>{confirmBtn}</div>
        <div onClick={onClose}>{cancelBtn}</div>
    </>
});

jest.mock('../../../../../shared/services/httpClient', () => ({
    ...jest.requireActual('../../../../../shared/services/httpClient'),
    postHttpClientRequest: jest.fn()
}));

describe('All Devices Component', () => {

    test('Create Device Group API Call - 01 Error code', () => {
        const store = configureStore(rootReducer);
        httpClient?.postHttpClientRequest?.mockImplementation((url) => {
            return Promise.resolve({ status: 200, data: {} });
        });
        store.dispatch(createNewDeviceGroup({ hashedMtn: 'dasdsad' }, jest.fn, jest.fn));
    });

    test('should render component - New CreateDeviceGroup - Review page', () => {
        const props = { history: { push() { } } ,confirmClick:jest.fn()};
        const routerLandingInitialState = {
            createDeviceGroupAPIData: createDeviceGroupData, createDeviceGroupData: {
                page: 'review', name: 'Fox',
                devices: ["0a:97:ed:74:19:ef", "1a:3d:e1:bf:11:ed"],
                schedule: {
                    daysOfTheWeek: [
                        1, 2
                    ],
                    startTimeHour: "01",
                    startTimeMinute: "00",
                    stopTimeHour: "01",
                    stopTimeMinute: "00",
                    startTimeAmPm: "AM",
                    stopTimeAmPm: "PM",
                },
                exception: ['lkasdj.asdlj.asljkd', 'verizon.com']
            }
        };
        const routerLandingReducer = (state = routerLandingInitialState) => state;
        const appReducer = combineReducers({ Router: routerLandingReducer });
        const testRootReducer = (state) => appReducer(state);

        const testStore = configureStore(testRootReducer);
        const component = render(
            <Provider store={testStore}>
                <CreateDeviceGroup {...props} />
            </Provider>
        );
        expect(component).toBeTruthy();

        const Remove = screen.getAllByTestId('remove-device')[0];
        expect(Remove).toBeInTheDocument();
        fireEvent.click(Remove);

        const RemoveAll = screen.getByTestId('remove-all-device');
        expect(RemoveAll).toBeInTheDocument();
        fireEvent.click(RemoveAll);
        
        const RemoveWebsite = screen.getAllByTestId('remove-website')[0];
        expect(RemoveWebsite).toBeInTheDocument();
        fireEvent.click(RemoveWebsite);

        const confirmRemoveWebsite = screen.getByText('Remove website');
        expect(confirmRemoveWebsite).toBeInTheDocument();
        fireEvent.click(confirmRemoveWebsite);

        const RemoveAllWebsites = screen.getByTestId('remove-all-websites');
        expect(RemoveAllWebsites).toBeInTheDocument();
        fireEvent.click(RemoveAllWebsites);
        
        const confirmRemoveAllWebsites = screen.getByText('Remove all websites');
        expect(confirmRemoveAllWebsites).toBeInTheDocument();
        fireEvent.click(confirmRemoveAllWebsites);

        const RemoveKeyword = screen.getAllByTestId('remove-keyword')[0];
        expect(RemoveKeyword).toBeInTheDocument();
        fireEvent.click(RemoveKeyword);

        const RemoveAllKeyword = screen.getByTestId('remove-all-keywords');
        expect(RemoveAllKeyword).toBeInTheDocument();
        fireEvent.click(RemoveAllKeyword);
    });
    
});