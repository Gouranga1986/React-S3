import React from 'react';
import "../../../../../../config/jest/test-setup"
import { render, screen, fireEvent } from '@testing-library/react';
import { combineReducers } from 'redux';
import { Provider } from 'react-redux';
import configureStore from '../../../../../shared/store/configureStore';
import '@testing-library/jest-dom';
import DeviceGroupDetails from '../../components/DeviceGroup/DeviceGroupDetails';
import { deviceGroupDetailsData, createDeviceGroupData } from './DeviceGroupCreate.mock';
import { getCreateDeviceGroup, createNewDeviceGroup, initCreateDeviceGroup, updateCreateDeviceGroupObj, getDeviceGroupDetails, updatedeviceGroup, clearNotificationStatus } from '../../actions/allDevicesListAction';
import rootReducer from "../../../reducers";
import httpClient from '../../../../../shared/services/httpClient';

jest.mock('../../components/DeviceGroup/AllDetails', () => {
    return ({ title, nameChangeHandler, addDeviceHandler, addDevice }) => <>
        <div>{title}</div>
        <input data-testid='group-name-input' onChange={nameChangeHandler}>{}</input>
        <div className='device-group-review-add-device' data-testid='add-device-handler' onClick={addDeviceHandler}>{addDevice}</div>
    </>
});
jest.mock('../../../../../shared/services/httpClient', () => ({
    ...jest.requireActual('../../../../../shared/services/httpClient'),
    postHttpClientRequest: jest.fn()
}));

describe('All Devices Component', () => {

    test('Create Device Group API Calls', () => {
        const store = configureStore(rootReducer);
        httpClient?.postHttpClientRequest?.mockImplementation((url) => {
            return Promise.resolve({ status: 200, data: { body: { ...createDeviceGroupData, errorCode: '00' }, responseInfo: { responseCode: '00' } } });
        });
        store.dispatch(createNewDeviceGroup({ hashedMtn: 'dasdsad' }, jest.fn, jest.fn));
        store.dispatch(getDeviceGroupDetails({ hashedMtn: 'dasdsad' }));
        store.dispatch(getCreateDeviceGroup({ hashedMtn: 'diusahusjaskbd' }));
        store.dispatch(initCreateDeviceGroup({}));
        store.dispatch(updateCreateDeviceGroupObj({}));
        store.dispatch(clearNotificationStatus());
        store.dispatch(updatedeviceGroup({ parentalControlId: '', hashedMtn: 'avc',groupName:'Verizon', flowType: "Group Name",isEnabled:true,accessType:1 },()=>{},()=>{}))
        window.location.hostname = 'localhost';
        store.dispatch(getCreateDeviceGroup({ hashedMtn: 'diusahusjaskbd' }));
    });
    test('Create Device Group API Call - 01 Error code', () => {
        const store = configureStore(rootReducer);
        httpClient?.postHttpClientRequest?.mockImplementation((url) => {
            return Promise.resolve({ status: 200, data: {} });
        });
        store.dispatch(getCreateDeviceGroup({ hashedMtn: 'diusahusjaskbd' }));
        store.dispatch(getDeviceGroupDetails({ hashedMtn: 'dasdsad' }));
        store.dispatch(updatedeviceGroup({ parentalControlId: '', hashedMtn: 'avc',groupName:'Verizon', flowType: "Group Name",isEnabled:false,accessType:1 },false))
    });
    
   
    test("show remove  Modal and confirm remove", () => {
   
        const removeGrpBtn = screen.getByTestId("removeGrpBtn");
        expect(removeGrpBtn).toBeInTheDocument();
        fireEvent.click(removeGrpBtn);
    
        const confirmBtn = screen.getByText("Confirm"); 
        expect(confirmBtn).toBeInTheDocument();
        fireEvent.click(confirmBtn);
    
      });


    test('should render component - DeviceGroupDetails', () => {
        const props = { history: { push() { } } };
        const routerLandingInitialState = { getDeviceGroupDetailsAPIData: deviceGroupDetailsData };
        const routerLandingReducer = (state = routerLandingInitialState) => state;
        const appReducer = combineReducers({ Router: routerLandingReducer });
        const testRootReducer = (state) => appReducer(state);

        const testStore = configureStore(testRootReducer);
        const component = render(
            <Provider store={testStore}>
                <DeviceGroupDetails {...props} />
            </Provider>
        );
        expect(component).toBeTruthy();

        const Home = screen.getByTestId('Home');
        expect(Home).toBeInTheDocument();
        fireEvent.click(Home);
        const Alldevices = screen.getByText('All devices /');
        expect(Alldevices).toBeInTheDocument();
        fireEvent.click(Alldevices);
        const GroupNameInput = screen.getByTestId('group-name-input');
        expect(GroupNameInput).toBeInTheDocument();
        fireEvent.change(GroupNameInput, {target: {value: "test"}});
        const AddDeviceHandler = screen.getByTestId('add-device-handler');
        expect(AddDeviceHandler).toBeInTheDocument();
        fireEvent.click(AddDeviceHandler);

    });
});