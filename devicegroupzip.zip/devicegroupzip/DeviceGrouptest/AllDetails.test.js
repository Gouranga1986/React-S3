import React from 'react';
import "../../../../../../config/jest/test-setup"
import { render, screen, fireEvent, waitFor } from '@testing-library/react';
import '@testing-library/jest-dom';
import AllDetails from '../../components/DeviceGroup/AllDetails';
import { createDeviceGroupData } from './DeviceGroupCreate.mock';
import { combineReducers } from "redux";
import configureStore from '../../../../../shared/store/configureStore';
import { Provider } from 'react-redux';
import httpClient from '../../../../../shared/services/httpClient';

jest.mock('../../../../../shared/services/httpClient', () => ({
    ...jest.requireActual('../../../../../shared/services/httpClient'),
    postHttpClientRequest: jest.fn()
}));

describe('All Details Component', () => {
    test('should render component - AllDetails', () => {
        const props = {
            history: { push() { } }, title: "test", subtitle: "test", editNameLabel: "test", nameMaxCharacters: "test",
            nameError: false, nameChangeHandler: jest.fn, deviceTitle: "test",
            removeDevice: "test", addDevice: "test", addDeviceHandler: jest.fn, noDevicesText: "test", scheduleTitle: "test", scheduleDays: "test", editSchedule: "test", editScheduleHandler: jest.fn,
            noScheduleText: "test", setSchedule: "test", websiteTitle: "test", websites: ["test", "test"], removeWebsite: "test", addException: "test",keywords:["test", "test"],keywordTitle:"test",
            addKeyword:"test", noKeywordText:"test",addKeywordHandler:jest.fn, addExceptionHandler: jest.fn, removeAllWebsite: "test",removeAllKeyword:"test",
            noWebsiteScheduleText: "test", noWebsiteText: "test", deviceGroupName: "test", clearAllNotificationStatus: jest.fn(),isManage:true,resetDeviceGroupName:"test",setResetDeviceGroupName:jest.fn,accessType:1,isEnabled:true,
            selectedDevices: ["0a:97:ed:74:19:ef", "1a:3d:e1:bf:11:ed"],
            devices: [
                { macId: "0a:97:ed:74:19:ef", displayName: "test" },
                { macId: "1a:3d:e1:bf:11:ed", displayName: 'iPhone' }
            ], openRemoveModal: jest.fn,
            setShowRemoveWebsiteModal: jest.fn, setShowRemoveAllWebsitesModal: jest.fn,
            setShowRemoveAllWebsitesModal: jest.fn,setShowRemoveAllWebsitesModal:jest.fn,
            setShowRemoveKeywordModal: jest.fn,
            setShowRemoveAllKeywordModal:jest.fn,
        };
        const routerLandingInitialState = {
            createDeviceGroupAPIData: createDeviceGroupData, createDeviceGroupData: {
                page: 'review', name: 'Fox',
                devices: ["0a:97:ed:74:19:ef", "1a:3d:e1:bf:11:ed"],
                schedule: {
                    daysOfTheWeek: [
                        1, 2
                    ],
                }
            }
        };
        const routerLandingReducer = (state = routerLandingInitialState) => state;
        const appReducer = combineReducers({ Router: routerLandingReducer });
        const testRootReducer = (state) => appReducer(state);

        const testStore = configureStore(testRootReducer);
        const component = render(
            <Provider store={testStore}>
                <AllDetails {...props} />
            </Provider>
        );
        expect(component).toBeTruthy();

        const RemoveWebsite = screen.getAllByTestId('remove-website')[0];
        expect(RemoveWebsite).toBeInTheDocument();
        fireEvent.click(RemoveWebsite);
        const RemoveAllWebsites = screen.getByTestId('remove-all-websites');
        expect(RemoveAllWebsites).toBeInTheDocument();
        fireEvent.click(RemoveAllWebsites);
        const RemoveKeyword = screen.getByTestId('remove-keyword')[0];
        expect(RemoveKeyword).toBeInTheDocument();
        fireEvent.click(RemoveKeyword);
        const RemoveAllKeywords = screen.getByTestId('remove-all-keywords');
        expect(RemoveAllKeywords).toBeInTheDocument();
        fireEvent.click(RemoveAllKeywords);

    });
    test('should render component - AllDetails Save', async() => {
        const successfn=jest.fn();
        const failfn=jest.fn();
        httpClient?.postHttpClientRequest?.mockImplementation((url) => {
            return Promise.resolve({ status: 200, data: { body: { ...createDeviceGroupData, errorCode: '01' }, responseInfo: { responseCode: '01' } } });
        });
        const props = {
            history: { push() { } }, title: "test", subtitle: "test", editNameLabel: "test", nameMaxCharacters: "test",
            nameError: false, nameChangeHandler: jest.fn, deviceTitle: "test",
            removeDevice: "test", addDevice: "test", addDeviceHandler: jest.fn, noDevicesText: "test", scheduleTitle: "test", scheduleDays: "test", editSchedule: "test", editScheduleHandler: jest.fn,
            noScheduleText: "test", setSchedule: "test", websiteTitle: "test", websites: ["test", "test"], removeWebsite: "test", keywords:["test", "test"],addException: "test",keywordTitle:"test", addExceptionHandler: jest.fn,removeAllKeyword:"test",removeKeyword:"test",addKeyword:"test", addKeywordHandler:jest.fn, removeAllWebsite: "test",
            noWebsiteScheduleText: "test", noWebsiteText: "test", deviceGroupName: "test1", clearAllNotificationStatus: jest.fn(),isManage:true,resetDeviceGroupName:"test",setResetDeviceGroupName:jest.fn,accessType:1,isEnabled:true,setDeviceGroupName:jest.fn,
            selectedDevices: ["0a:97:ed:74:19:ef", "1a:3d:e1:bf:11:ed"],renameError:jest.fn,renameSuccess:jest.fn,
            devices: [
                { macId: "0a:97:ed:74:19:ef", displayName: "test" },
                { macId: "1a:3d:e1:bf:11:ed", displayName: 'iPhone' }
            ], openRemoveModal: jest.fn,
            setShowRemoveWebsiteModal: jest.fn, setShowRemoveAllWebsitesModal: jest.fn,setShowRemoveAllWebsitesModal:jest.fn,
            setShowRemoveAllWebsitesModal:jest.fn,
            setShowRemoveKeywordModal: jest.fn,
            setShowRemoveAllKeywordModal:jest.fn,
        };
        const routerLandingInitialState = {
            createDeviceGroupAPIData: createDeviceGroupData, createDeviceGroupData: {
                page: 'review', name: 'Fox',
                devices: ["0a:97:ed:74:19:ef", "1a:3d:e1:bf:11:ed"],
                schedule: {
                    daysOfTheWeek: [
                        1, 2
                    ],
                }
            }
        };
        const routerLandingReducer = (state = routerLandingInitialState) => state;
        const appReducer = combineReducers({ Router: routerLandingReducer });
        const testRootReducer = (state) => appReducer(state);

        const testStore = configureStore(testRootReducer);
        const component = render(
            <Provider store={testStore}>
                <AllDetails {...props} />
            </Provider>
        );
        expect(component).toBeTruthy();
        const InputBox = screen.getByTestId('group-name-input');
        expect(InputBox).toBeInTheDocument();
        fireEvent.change(InputBox, { target: { value: 'a' } })
        await waitFor(() => {
            const SaveBtn = screen.getByTestId('btn-save-manage');
            expect(SaveBtn).toBeInTheDocument();
            fireEvent.click(SaveBtn);
            const CancelBtn = screen.getByTestId('btn-cancel-manage');
            expect(CancelBtn).toBeInTheDocument();
            fireEvent.click(CancelBtn);
        });
        
        await store.dispatch(updatedeviceGroup({ parentalControlId: '', hashedMtn: 'avc',groupName:'Verizon', flowType: "Group Name",isEnabled:false,accessType:1 },successfn,failfn));
        expect(httpClient.postHttpClientRequest).toHaveBeenCalledTimes(1);
        expect(successfn).toHaveBeenCalledTimes();
    });
    test('should render component - AllDetails Save', async() => {
        const successfn=jest.fn();
        const failfn=jest.fn();
        httpClient?.postHttpClientRequest?.mockImplementation((url) => {
            return Promise.resolve({ status: 200, data: { body: { ...createDeviceGroupData, errorCode: '00' }, responseInfo: { responseCode: '00' } } });
        });
        
        const props = {
            history: { push() { } }, title: "test", subtitle: "test", editNameLabel: "test", nameMaxCharacters: "test",
            nameError: false, nameChangeHandler: jest.fn, deviceTitle: "test",
            removeDevice: "test", addDevice: "test", addDeviceHandler: jest.fn, noDevicesText: "test", scheduleTitle: "test", scheduleDays: "test", editSchedule: "test", editScheduleHandler: jest.fn,
            noScheduleText: "test", setSchedule: "test", websiteTitle: "test", websites: ["test", "test"], removeWebsite: "test",keywords:["test", "test"], addException: "test",keywordTitle:"test", addKeyword:"test", addKeywordHandler:jest.fn,removeAllKeyword:"test",removeAllKeyword:"test",removeAllKeyword:"test",addExceptionHandler: jest.fn, removeAllWebsite: "test",
            noWebsiteScheduleText: "test", noWebsiteText: "test", deviceGroupName: "test1", clearAllNotificationStatus: jest.fn(),isManage:true,resetDeviceGroupName:"test",setResetDeviceGroupName: jest.fn,accessType:1,isEnabled:true,setDeviceGroupName:jest.fn,
            selectedDevices: ["0a:97:ed:74:19:ef", "1a:3d:e1:bf:11:ed"],renameError:jest.fn,renameSuccess:jest.fn,
            devices: [
                { macId: "0a:97:ed:74:19:ef", displayName: "test" },
                { macId: "1a:3d:e1:bf:11:ed", displayName: 'iPhone' }
            ], openRemoveModal: jest.fn,
            setShowRemoveWebsiteModal: jest.fn, setShowRemoveAllWebsitesModal: jest.fn,setShowRemoveAllWebsitesModal:jest.fn,
            setShowRemoveAllWebsitesModal:jest.fn,
            setShowRemoveKeywordModal: jest.fn,
            setShowRemoveAllKeywordModal:jest.fn,
        };
        const routerLandingInitialState = {
            createDeviceGroupAPIData: createDeviceGroupData, createDeviceGroupData: {
                page: 'review', name: 'Fox',
                devices: ["0a:97:ed:74:19:ef", "1a:3d:e1:bf:11:ed"],
                schedule: {
                    daysOfTheWeek: [
                        1, 2
                    ],
                }
            }
        };
        const routerLandingReducer = (state = routerLandingInitialState) => state;
        const appReducer = combineReducers({ Router: routerLandingReducer });
        const testRootReducer = (state) => appReducer(state);

        const testStore = configureStore(testRootReducer);
        const component = render(
            <Provider store={testStore}>
                <AllDetails {...props} />
            </Provider>
        );
        expect(component).toBeTruthy();
        const InputBox = screen.getByTestId('group-name-input');
        expect(InputBox).toBeInTheDocument();
        fireEvent.change(InputBox, { target: { value: 'a' } })
        await waitFor(() => {
            const SaveBtn = screen.getByTestId('btn-save-manage');
            expect(SaveBtn).toBeInTheDocument();
            fireEvent.click(SaveBtn);
            const CancelBtn = screen.getByTestId('btn-cancel-manage');
            expect(CancelBtn).toBeInTheDocument();
            fireEvent.click(CancelBtn);
        });
        
        await store.dispatch(updatedeviceGroup({ parentalControlId: '', hashedMtn: 'avc',groupName:'Verizon', flowType: "Group Name",isEnabled:false,accessType:1 },successfn,failfn));
        expect(httpClient.postHttpClientRequest).toHaveBeenCalledTimes(1);
        expect(successfn).toHaveBeenCalledTimes();
    });
    test('AllDetails component - when deviceGroupName is empty/null', () => {
        const props = {
            history: { push() { } }, title: "test", subtitle: "test", editNameLabel: "test", nameMaxCharacters: "test",
            nameError: false, nameChangeHandler: jest.fn, deviceTitle: "test",
            removeDevice: "test", addDevice: "test", addDeviceHandler: jest.fn, noDevicesText: "test", scheduleTitle: "test", scheduleDays: "test", editSchedule: "test", editScheduleHandler: jest.fn,
            noScheduleText: "test", setSchedule: "test", websiteTitle: "test", websites: ["test", "test"], removeWebsite: "test",addException: "test",keywordTitle:"test",addKeyword:"test",keywords:["test", "test"],noKeywordText:"test", addKeywordHandler:jest.fn, addExceptionHandler: jest.fn, removeAllWebsite: "test",
            noWebsiteScheduleText: "test", noWebsiteText: "test", deviceGroupName: "",accessType:2,isEnabled:false,
            selectedDevices: ["0a:97:ed:74:19:ef", "1a:3d:e1:bf:11:ed"],
            devices: [
                { macId: "0a:97:ed:74:19:ef", displayName: "test" },
                { macId: "1a:3d:e1:bf:11:ed", displayName: 'iPhone' }
            ], openRemoveModal: jest.fn,
            setShowRemoveWebsiteModal: jest.fn, setShowRemoveAllWebsitesModal: jest.fn,setShowRemoveAllWebsitesModal:jest.fn,
            setShowRemoveAllWebsitesModal:jest.fn,
            setShowRemoveKeywordModal: jest.fn,
            setShowRemoveAllKeywordModal:jest.fn,
        };
        const routerLandingInitialState = {
            createDeviceGroupAPIData: createDeviceGroupData, createDeviceGroupData: {
                page: 'review', name: 'Fox',
                devices: ["0a:97:ed:74:19:ef", "1a:3d:e1:bf:11:ed"],
                schedule: {
                    daysOfTheWeek: [
                        1, 2
                    ],
                }
            }
        };
        const routerLandingReducer = (state = routerLandingInitialState) => state;
        const appReducer = combineReducers({ Router: routerLandingReducer });
        const testRootReducer = (state) => appReducer(state);

        const testStore = configureStore(testRootReducer);
        const component = render(
            <Provider store={testStore}>
                <AllDetails {...props} />
            </Provider>
        );
        expect(component).toBeTruthy();

        const removeDevice = screen.getAllByTestId('remove-device')[0];
        expect(removeDevice).toBeInTheDocument();
        fireEvent.click(removeDevice);

    });
    test('should render - EmptyExceptionState', () => {
        const props = {
            history: { push() { } }, title: "test", subtitle: "test", editNameLabel: "test", nameMaxCharacters: "test",
            nameError: false, nameChangeHandler: jest.fn, deviceTitle: "test",
            removeDevice: "test", addDevice: "test", addDeviceHandler: jest.fn, noDevicesText: "test", scheduleTitle: "test", scheduleDays: "test", editSchedule: "test", editScheduleHandler: jest.fn,
            noScheduleText: "test", setSchedule: "test", websiteTitle: "test", websites: ["test", "test"], removeWebsite: "test", addException: "test",keywordTitle:"test",keywords:["test", "test"],addKeyword:"test", addKeywordHandler:jest.fn, addExceptionHandler: jest.fn, removeAllWebsite: "test",
            noWebsiteScheduleText: "test", noWebsiteText: "test", deviceGroupName: "test",accessType:1,isEnabled:true,
            selectedDevices: ["0a:97:ed:74:19:ef", "1a:3d:e1:bf:11:ed"],
            devices: [
                { macId: "0a:97:ed:74:19:ef", displayName: "test" },
                { macId: "1a:3d:e1:bf:11:ed", displayName: 'iPhone' }
            ], openRemoveModal: jest.fn,
            setShowRemoveWebsiteModal: jest.fn, setShowRemoveAllWebsitesModal: jest.fn,
            setShowRemoveKeywordModal: jest.fn,
            setShowRemoveAllKeywordModal:jest.fn,
        };
        const routerLandingInitialState = {
            createDeviceGroupAPIData: createDeviceGroupData, createDeviceGroupData: {
                page: 'review', name: 'Fox',
                devices: ["0a:97:ed:74:19:ef", "1a:3d:e1:bf:11:ed"],
                schedule: {
                    daysOfTheWeek: [],
                },
                exception: []
            }
        };
        const routerLandingReducer = (state = routerLandingInitialState) => state;
        const appReducer = combineReducers({ Router: routerLandingReducer });
        const testRootReducer = (state) => appReducer(state);

        const testStore = configureStore(testRootReducer);
        const component = render(
            <Provider store={testStore}>
                <AllDetails {...props} />
            </Provider>
        );
        expect(component).toBeTruthy();

    });
    test('should render - EmptyExceptionState - when schedule and websites both are empty/null', () => {
        const props = {
            history: { push() { } }, title: "test", subtitle: "test", editNameLabel: "test", nameMaxCharacters: "test",
            nameError: false, nameChangeHandler: jest.fn, deviceTitle: "test",
            removeDevice: "test", addDevice: "test", addDeviceHandler: jest.fn, noDevicesText: "test", scheduleTitle: "test", scheduleDays: "test", editSchedule: "test", editScheduleHandler: jest.fn,
            noScheduleText: "test", setSchedule: "test", websiteTitle: "test", websites: ["test", "test"], removeWebsite: "test", addException: "test",keywordTitle:"test",keywords:["test", "test"],addKeyword:"test", addKeywordHandler:jest.fn, addExceptionHandler: jest.fn, removeAllWebsite: "test",
            noWebsiteScheduleText: "test", noWebsiteText: "test", deviceGroupName: "test",accessType:1,isEnabled:true,
            selectedDevices: ["0a:97:ed:74:19:ef", "1a:3d:e1:bf:11:ed"],
            devices: [
                { macId: "0a:97:ed:74:19:ef", displayName: "test" },
                { macId: "1a:3d:e1:bf:11:ed", displayName: 'iPhone' }
            ], openRemoveModal: jest.fn,
            setShowRemoveWebsiteModal: jest.fn, 
            setShowRemoveAllWebsitesModal:jest.fn,
            setShowRemoveKeywordModal: jest.fn,
            setShowRemoveAllKeywordModal:jest.fn,
            
        };
        const routerLandingInitialState = {
            createDeviceGroupAPIData: createDeviceGroupData, createDeviceGroupData: {
                page: 'review', name: 'Fox',
                devices: ["0a:97:ed:74:19:ef", "1a:3d:e1:bf:11:ed"],
                schedule: {
                    daysOfTheWeek: [1, 2],
                },
                exception: []
            }
        };
        const routerLandingReducer = (state = routerLandingInitialState) => state;
        const appReducer = combineReducers({ Router: routerLandingReducer });
        const testRootReducer = (state) => appReducer(state);

        const testStore = configureStore(testRootReducer);
        const component = render(
            <Provider store={testStore}>
                <AllDetails {...props} />
            </Provider>
        );
        expect(component).toBeTruthy();

    });
});