import React, { useState, useEffect } from 'react';
import { useSelector, useDispatch } from 'react-redux';
import { getDeviceGroupDetails, updateCreateDeviceGroupObj, clearNotificationStatus } from '../../actions';
import { updatedeviceGroup } from '../../actions/allDevicesListAction';
import Loader from '../loader/loader';
import { createItemKeyValObj } from './CreateDeviceGroup';
import ManageDetails from './AllDetails';
import SelectDevices from './SelectDevices';
import SetSchedule from './SetSchedule';
import AddException from './AddException';
import Addkeyword from './AddKeyword';
import common from '../../../../../shared/utilities/util';
import { Button } from '@vds/buttons';
import RemoveModal from './RemoveModal';
import { Notification } from '@vds/notifications';
import {
    Modal, ModalTitle, ModalBody, ModalFooter,
  } from '@vds/modals';


const getItemValue = common.getItemValue;
const getSectionById = common.getSectionById;
const getContentByComponentId = common.getContentByComponentId;

export const SchedulePreview = ({ title, days, daysText, deviceGroupData }) => <div className='device-group-preview-container device-group-downtime-preview-container'>
    <div className='device-group-devices-preview-title'>{title}</div>
    <div className='device-group-devices-preview-list-container'>
        {Array.isArray(days) && days?.map(day =>
            <ul key={'review-selected-day-' + day}>
                <li>{daysText?.[day]}</li>
            </ul>
        )}
        <div className='scheduleTime'>
            <p>{deviceGroupData?.schedule?.startTimeHour + ':' + deviceGroupData?.schedule?.startTimeMinute + ' ' + deviceGroupData?.schedule?.startTimeAmPm
                + '-' + deviceGroupData?.schedule?.stopTimeHour + ':' + deviceGroupData?.schedule?.stopTimeMinute + ' ' + deviceGroupData?.schedule?.stopTimeAmPm}</p>
        </div>
    </div>
</div>;

const DeviceGroupDetails = ({ history }) => {

    const dispatch = useDispatch();
    const homeInternet = useSelector((state) => state.Router.homeInternet);
    const hashedMtn = getItemValue(homeInternet?.pageAttributes, 'hashedMtn');
    const getDeviceGroupDetailsFetching = useSelector((state) => state.Router.getDeviceGroupDetailsFetching);
    const getDeviceGroupDetailsAPIData = useSelector((state) => state.Router.getDeviceGroupDetailsAPIData);
    const deviceGroupData = useSelector((state) => state.Router.createDeviceGroupData);
    const deviceGroupSections = getDeviceGroupDetailsAPIData?.sections;
    const dataLoaded = Array.isArray(deviceGroupSections);

    const navigateTo = (path, state = {}) => history?.push({ pathname: path, state });
    const redirectToHome = () => navigateTo('/routerlanding');
    const redirectToAllDevicesList = (state = {}) => navigateTo('/allDevicesList', state);

    const [deviceGroupName, setDeviceGroupName] = useState('');
    const [resetDeviceGroupName, setResetDeviceGroupName] = useState('');
    const [parentalControlId, setParentalControlId] = useState('');
    const [managePageData, setManagePageData] = useState({});
    const [removeModalData, setRemoveModalData] = useState({});
    const [showRemoveModal, setShowRemoveModal] = useState(false);
    const [isEnabled, setIsEnabled] = useState();
    const [accessType, setAccessType] = useState();
    // Remove Device Modal Data
    const [removeDeviceModalData, setRemoveDeviceModalData] = useState({});
    const [showRemoveDeviceModal, setShowRemoveDeviceModal] = useState(false);
    const closeRemoveDeviceModal = () => setShowRemoveDeviceModal(false);

    // Remove Website Modal Data
    const [removeWebsiteModalData, setRemoveWebsiteModalData] = useState({ one: {}, all: {} });
    const [showRemoveWebsiteModal, setShowRemoveWebsiteModal] = useState(false);
    const closeRemoveWebsiteModal = () => setShowRemoveWebsiteModal(false);
    const [showRemoveAllWebsitesModal, setShowRemoveAllWebsitesModal] = useState(false);
    const closeRemoveAllWebsitesModal = () => setShowRemoveAllWebsitesModal(false);

     //Remove Keywords modal data
     const [removeKeywordModalData, setRemoveKeywordModalData] = useState({ one: {}, all: {} });
     const [showRemoveKeywordModal, setShowRemoveKeywordModal] = useState(false);
     const closeRemoveKeywordModal = () => setShowRemoveKeywordModal(false);
     const [showRemoveAllKeywordModal, setShowRemoveAllKeywordModal] = useState(false);
     const closeRemoveAllKeywordModal = () => setShowRemoveAllKeywordModal(false);

    // Select Devices Page Data
    const [selectDevicesPageData, setSelectDevicesPageData] = useState({});
    const [maxDevices, setMaxDevices] = useState(false);

    // Opening and Closing of Modal
    const [showSelectDevicesModal,setShowSelectDevicesModal] = useState(false);
    const [showEditScheduleModal, setShowEditScheduleModal] = useState(false);
    const [showAddExceptionModal, setShowAddExceptionModal] = useState(false);
    const [showAddKeywordModal, setShowAddKeywordModal] = useState(false);


    // Set Schedule Page Data
    const [schedulePageData, setSchedulePageData] = useState({});

    //Website Exception Page Data
    const [websiteExceptionPageData, setWebsiteExceptionPageData] = useState({});
    const [websiteExceptionRight, setWebsiteExceptionRight] = useState({});
    const [exceptionsData,setExceptionsData] = useState({});

    //Keyword exception Page Data
    const [keywordPageData, setKeywordPageData] = useState({});
    const [keywordRight, setKeywordRight] = useState({});
    const [keywordsData,setKeywordsData] = useState({});

    // Success & Error Messages
    const [successMsgs, setSuccessMsg] = useState({});
    const [errorMsgs, setErrorMsg] = useState({});
    // Notification
    const [showSuccessNotification, setShowSuccessNotification] = useState(false);
    const [showErrorNotification, setShowErrorNotification] = useState(false);
    // Close All Notifications
    const closeNotification = () => {
        setShowErrorNotification(false);
        setShowSuccessNotification(false);
    }
    // Update Device Group Details
    const updateDeviceGroupDetails = (reqData, onSuccess, onError) => {
        closeNotification();
        dispatch(updatedeviceGroup(reqData, onSuccess, onError));
    }

    const clearAllNotificationStatus = () => dispatch(clearNotificationStatus());
    const openRemoveModal = () => {
        setShowRemoveModal(true);
    };

    const showSuccessData = (renameSuccess) => {
        setShowSuccessNotification(renameSuccess)
    }
    const showErrorData = (renameError) => {
        setShowErrorNotification(renameError)
    }
    // Delete Group Success
    const onDeleteGroupSuccess = () => redirectToAllDevicesList({ deleteGroupSuccess: successMsgs?.deleteDeviceGroupSuccessMessage });

    const closeRemoveModal = () => setShowRemoveModal(false);
    const confirmRemoveDevice = () => {
        closeRemoveModal();
        const parentalControlId = deviceGroupSections[0].data.parentalControlId;
        let reqData =
        {
            "hashedMtn": hashedMtn,
            "parentalControlId": parentalControlId,
            "flowType": "DELETE_GROUP"
        }
        isEnabled !== '' && isEnabled !== undefined && (reqData.isEnabled = isEnabled);
        accessType !== '' && accessType !== undefined && (reqData.accessType = accessType);
        const onRemoveGroupError = () => setShowErrorNotification(errorMsgs?.removeGroupError);
        updateDeviceGroupDetails(reqData, onDeleteGroupSuccess, onRemoveGroupError);
    }
    const initLoad = () => {

        // Select Devices Component
        const selectDevicesSection = getSectionById(deviceGroupSections, 'selectDevicesSection');
        const connectedDevices = selectDevicesSection?.data?.connectedDevices;
        const selectDevicesContent = getContentByComponentId(selectDevicesSection?.contents, 'groupNameLeft');
        setSelectDevicesPageData({ ...createItemKeyValObj(selectDevicesContent?.items), connectedDevices });

        // Device Group Data
        const manageGroupSection = getSectionById(deviceGroupSections, 'manageDeviceGroupSection');
        const manageGroupData = manageGroupSection?.data;
        const manageGroupName = manageGroupData?.groupName;
        const parentalControlId = manageGroupData?.parentalControlId;
        setDeviceGroupName(manageGroupName);
        setResetDeviceGroupName(manageGroupName);
        setParentalControlId(parentalControlId);
        let groupData = {
            isManage: true, page: 'manage', name: manageGroupName, parentalControlId: parentalControlId, connectedDevices: connectedDevices,
            devices: manageGroupData?.deviceMacNameList?.map(device => device?.macId)
        };
        manageGroupData?.accessType && setAccessType(manageGroupData?.accessType);
        if (manageGroupData?.isEnabled) {
            setIsEnabled(manageGroupData?.isEnabled);
            groupData.schedule = {
                daysOfTheWeek: manageGroupData?.daysOfTheWeek,
                startTimeHour: manageGroupData?.startTimeHour,
                startTimeMinute: manageGroupData?.startTimeMinute,
                startTimeAmPm: manageGroupData?.startTimePeriod,
                stopTimeHour: manageGroupData?.stopTimeHour,
                stopTimeMinute: manageGroupData?.stopTimeMinute,
                stopTimeAmPm: manageGroupData?.stopTimePeriod,
            }
            if (manageGroupData?.websiteExceptions?.length > 0) {
                groupData.exception = manageGroupData?.websiteExceptions?.map(exception => exception?.value);
                setExceptionsData(groupData.exception);

            }
            if (manageGroupData?.keywordExceptions?.length > 0) {
                groupData.keyword = manageGroupData?.keywordExceptions?.map(keyword => keyword?.value);
                setKeywordsData(groupData.keyword);
            }
        }
        dispatch(updateCreateDeviceGroupObj(groupData));

        // Manage Page
        const manageGroupContents = manageGroupSection?.contents;
        const groupName = getContentByComponentId(manageGroupContents, 'manageGroupName');
        const tileContent = getContentByComponentId(manageGroupContents, 'deviceTileComponent');
        const groupDevices = getContentByComponentId(manageGroupContents, 'manageDeviceGroupSelectedDevices');
        const groupSchedule = getContentByComponentId(manageGroupContents, 'manageDeviceGroupDowntimeSchedule');
        const groupException = getContentByComponentId(manageGroupContents, 'manageDeviceGroupWebsiteExceptions');
        const groupKeywordException = getContentByComponentId(manageGroupContents, 'manageDeviceGroupKeywordsExceptions');

        const removeGroupDevice = getSectionById(deviceGroupSections, 'createDeviceGroupModalSection');
        const removeModalObj = getContentByComponentId(removeGroupDevice?.contents, 'deleteDeviceGroupModal');
        const removeDeviceGroupErrorMessagesItems = getContentByComponentId(removeGroupDevice?.contents, 'deviceGroupErrorMessages')?.items;
        const removeDeviceData = createItemKeyValObj(removeModalObj?.items);

        setManagePageData({
            header: createItemKeyValObj(getDeviceGroupDetailsAPIData?.pageAttributes),
            name: createItemKeyValObj(groupName?.items),
            devices: createItemKeyValObj(groupDevices?.items),
            schedule: createItemKeyValObj(groupSchedule?.items),
            exception: createItemKeyValObj(groupException?.items),
            keyword:createItemKeyValObj(groupKeywordException?.items),
            tile: createItemKeyValObj(tileContent?.items),
            createError: getItemValue(removeDeviceGroupErrorMessagesItems, 'removeGroupErrorMessage'),
            //successMsg: getItemValue(removeDeviceGroupErrorMessagesItems, 'removeGroupSuccessMessage')
        });
        setRemoveModalData({
            title: removeDeviceData?.deleteDeviceGroupHeading,
            confirmBtn: removeDeviceData?.deleteDeviceGroupConfirmButton?.value,
            cancelBtn: removeDeviceData?.removeAllWebsitesCancelButton?.value
        });

        // Remove Device Modal Section
        const removeDeviceModalContent = getContentByComponentId(removeGroupDevice?.contents, 'removeDeviceModal');
        const removeDeviceModalObj = createItemKeyValObj(removeDeviceModalContent?.items);
        setRemoveDeviceModalData({
            title: removeDeviceModalObj?.removeDeviceHeading, body: removeDeviceModalObj?.removeDeviceText,
            confirmBtn: removeDeviceModalObj?.removeDeviceConfirmButton?.value,
            cancelBtn: removeDeviceModalObj?.removeDeviceCancelButton?.value,
            lastDeviceTitle: 'Device groups need to have at least one device, if you delete the last device, it will also delete the group.',
            lastDeviceConfirmBtn: 'Remove device'
        });

        // Remove Website Modal Section
        const removeWebsiteModalContent = getContentByComponentId(removeGroupDevice?.contents, 'removeWebsiteModal');
        const removeWebsiteModalObj = createItemKeyValObj(removeWebsiteModalContent?.items);
        const removeAllWebsitesModalContent = getContentByComponentId(removeGroupDevice?.contents, 'removeAllWebsitesModal');
        const removeAllWebsitesModalObj = createItemKeyValObj(removeAllWebsitesModalContent?.items);
        setRemoveWebsiteModalData({
            one: {
                title: removeWebsiteModalObj?.removeWebsiteHeading,
                confirmBtn: removeWebsiteModalObj?.removeWebsiteConfirmButton?.value,
                cancelBtn: removeWebsiteModalObj?.removeWebsiteCancelButton?.value
            },
            all: {
                title: removeAllWebsitesModalObj?.removeAllWebsitesHeading,
                confirmBtn: removeAllWebsitesModalObj?.removeAllWebsitesConfirmButton?.value,
                cancelBtn: removeAllWebsitesModalObj?.removeAllWebsitesCancelButton?.value
            }
        });

        //Remove keyword modal section
         const removekeywordModalContent = getContentByComponentId(removeGroupDevice?.contents, 'removeKeywordModal');
         const removeKeywordModalObj = createItemKeyValObj(removekeywordModalContent?.items);
         const removeAllKeywordModalContent = getContentByComponentId(removeGroupDevice?.contents, 'removeAllKeywordsModal');
         const removeAllKeywordModalObj = createItemKeyValObj(removeAllKeywordModalContent?.items);
        setRemoveKeywordModalData({
            one: {
                title: removeKeywordModalObj?.removeKeywordHeading,
                confirmBtn: removeKeywordModalObj?.removeKeywordConfirmButton?.value,
                cancelBtn: removeKeywordModalObj?.removeKeywordCancelButton?.value
            },
            all: {
                title: removeAllKeywordModalObj?.removeAllKeywordsHeading,
                confirmBtn: removeAllKeywordModalObj?.removeAllKeywordsConfirmButton?.value,
                cancelBtn: removeAllKeywordModalObj?.removeAllKeywordsCancelButton?.value
            }
        });

        // Set Schedule Component
        const scheduleSection = getSectionById(deviceGroupSections, 'scheduleDowntimeSection');
        const scheduleContents = scheduleSection?.contents;
        const setScheduleContent = getContentByComponentId(scheduleContents, 'setScheduleComponent');
        const setScheduleSummaryContent = getContentByComponentId(scheduleContents, 'setScheduleSummaryPane');
        setSchedulePageData({ input: createItemKeyValObj(setScheduleContent?.items), summary: createItemKeyValObj(setScheduleSummaryContent?.items) });

        //AddWebsite Exception
        const websiteExceptionSection = getSectionById(deviceGroupSections, 'addExceptionsSection');
        const websiteExceptionContent = getContentByComponentId(websiteExceptionSection?.contents, 'addExceptionsComponent');
        setWebsiteExceptionPageData(createItemKeyValObj(websiteExceptionContent?.items));
        const websiteExceptionSummary = getContentByComponentId(websiteExceptionSection?.contents, 'addExceptionsSummaryPane');
        setWebsiteExceptionRight(createItemKeyValObj(websiteExceptionSummary?.items));

        //AddKeyword exception
        const keywordExceptionSection = getSectionById(deviceGroupSections, 'addKeywordsSection');
        const keywordExceptionContent = getContentByComponentId(keywordExceptionSection?.contents, 'addKeywordsComponent');
        setKeywordPageData(createItemKeyValObj(keywordExceptionContent?.items));
        const keywordExceptionSummary = getContentByComponentId(keywordExceptionSection?.contents, 'addKeywordsSummaryPane');
        setKeywordRight(createItemKeyValObj(keywordExceptionSummary?.items));

        // Success Messages
        const successMessagesContents = getSectionById(deviceGroupSections, 'manageDeviceGroupStaticSection')?.contents;
        let successMessages = {};
        successMessagesContents?.forEach(({ contentComponentId }) => {
            successMessages = { ...successMessages, ...createItemKeyValObj(getContentByComponentId(successMessagesContents, contentComponentId)?.items) };
        });
        setSuccessMsg(successMessages);

        // Error Messages
        setErrorMsg({
            removeGroupError: {
                title: getItemValue(removeDeviceGroupErrorMessagesItems, 'removeGroupErrorMessage'),
                subtitle: null
            },
            removeDeviceError: {
                title: 'We’re having trouble removing devices from this device group.',
                subtitle: 'Please try again later.'
            },
            updateError: {
                title: successMessages?.routerErrorMessage,
                subtitle: successMessages?.routerErrorMessageSubText
            }
        });
    }

    // const setPage = (page) => {
    //     closeNotification();
    //     setMaxDevices(false);
    //     dispatch(updateCreateDeviceGroupObj({ page }));
    // }
    // const goToManage = () => setPage('manage');

    const goToDevices = () => {
        //setPage('selectDevices');
        setShowSelectDevicesModal(true);
    }
    const goToSchedule = () => {
        // setPage('setSchedule');
        setShowEditScheduleModal(true);
    }
    const goToExceptions = () => {
        //setPage('exception');
        setShowAddExceptionModal(true);
    }
    const goToKeyword = () => {
        //setPage('exception');
        setShowAddKeywordModal(true);
    }
    const updateDeviceHandler = (devicesSelected) => {
        let reqData = {
            hashedMtn: hashedMtn, parentalControlId: deviceGroupData?.parentalControlId,
            flowType: 'ADD_OR_REMOVE_DEVICES',
            devices: devicesSelected
        }
        isEnabled !== '' && isEnabled !== undefined && (reqData.isEnabled = isEnabled);
        accessType !== '' && accessType !== undefined && (reqData.accessType = accessType);
        const updateDeviceSuccess = () => {
            dispatch(updateCreateDeviceGroupObj({ devices: devicesSelected }));
            //goToManage();
            setShowSuccessNotification(successMsgs?.addDevicesSuccessMessage);
        }
        const updateDeviceError = () => setShowErrorNotification(errorMsgs?.updateError);
        updateDeviceGroupDetails(reqData, updateDeviceSuccess, updateDeviceError);
        setShowSelectDevicesModal(false);
    }

    const removeDeviceHandler = () => {
        closeRemoveDeviceModal();
        const updatedDevicesList = deviceGroupData?.devices?.filter(mac => showRemoveDeviceModal !== mac);
        const isLastDevice = updatedDevicesList?.length === 0;
        let reqData = {
            hashedMtn: hashedMtn, parentalControlId: deviceGroupData?.parentalControlId,
            flowType: !isLastDevice ? 'REMOVE_DEVICE' : 'DELETE_GROUP_LAST_DEVICE'
        }
        isEnabled !== '' && isEnabled !== undefined && (reqData.isEnabled = isEnabled);
        accessType !== '' && accessType !== undefined && (reqData.accessType = accessType);
        if (!isLastDevice) reqData.devices = updatedDevicesList;
        const removeDeviceSuccess = () => {
            if (isLastDevice) {
                onDeleteGroupSuccess();
            } else {
                dispatch(updateCreateDeviceGroupObj({ devices: updatedDevicesList }));
                setShowSuccessNotification(successMsgs?.removeDevicesSuccessMessage);    
            }
        }
        const removeDeviceError = () => setShowErrorNotification(errorMsgs?.removeDeviceError);
        updateDeviceGroupDetails(reqData, removeDeviceSuccess, removeDeviceError);
    }

    const updateScheduleHandler = ({ selectedDays, startTime, endTime }) => {
        let reqData = {
            hashedMtn: hashedMtn, parentalControlId: deviceGroupData?.parentalControlId,
            flowType: 'UPDATE_SCHEDULE',
            daysOfTheWeek: selectedDays,
            startTimeHour: startTime.hour,
            startTimeMinute: startTime.minute,
            startTimePeriod: startTime.period,
            stopTimeHour: endTime.hour,
            stopTimeMinute: endTime.minute,
            stopTimePeriod: endTime.period
        }
        isEnabled !== '' && isEnabled !== undefined && (reqData.isEnabled = isEnabled);
        accessType !== '' && accessType !== undefined && (reqData.accessType = accessType);
        const updateScheduleSuccess = () => {
            dispatch(updateCreateDeviceGroupObj({
                schedule: {
                    daysOfTheWeek: selectedDays,
                    startTimeHour: startTime.hour,
                    startTimeMinute: startTime.minute,
                    startTimeAmPm: startTime.period,
                    stopTimeHour: endTime.hour,
                    stopTimeMinute: endTime.minute,
                    stopTimeAmPm: endTime.period
                }
            }));
            //goToManage();
            setShowEditScheduleModal(false);
            setShowSuccessNotification(successMsgs?.downtimeScheduleSuccessMessage);
        }
        const updateError = () => setShowErrorNotification(errorMsgs?.updateError);
        updateDeviceGroupDetails(reqData, updateScheduleSuccess, updateError);
    }

    /* istanbul ignore next */
    const clearScheduleHandler = () => {
        let reqData = {
            hashedMtn: hashedMtn, parentalControlId: deviceGroupData?.parentalControlId,
            flowType: 'CLEAR_SCHEDULE'
        }
        isEnabled !== '' && isEnabled !== undefined && (reqData.isEnabled = isEnabled);
        accessType !== '' && accessType !== undefined && (reqData.accessType = accessType);
        const updateScheduleSuccess = () => {
            dispatch(updateCreateDeviceGroupObj({ schedule: {}, exception: [] }));
            //goToManage();
            setShowSuccessNotification(successMsgs?.downtimeScheduleSuccessMessage);
        }
        const updateError = () => setShowErrorNotification(errorMsgs?.updateError);
        updateDeviceGroupDetails(reqData, updateScheduleSuccess, updateError);
        setShowEditScheduleModal(false);
    }

    /* istanbul ignore next */
    const removeWebsiteHandler = () => {
        closeRemoveWebsiteModal();
        const updatedWebsitesList = deviceGroupData?.exception?.filter((_, index) => index != showRemoveWebsiteModal);
        const updatedKeywordsList = deviceGroupData?.keyword.length >0 ? deviceGroupData?.keyword?.map(site => ({ type: 1, value: site })) :[];
        let reqData = {
            hashedMtn: hashedMtn, parentalControlId: deviceGroupData?.parentalControlId,
            flowType: 'REMOVE_WEBSITE_EXCEPTION', websiteExceptions: updatedWebsitesList?.map(site => ({ type: 0, value: site })), 
            keywordExceptions:updatedKeywordsList
        }
        isEnabled !== '' && isEnabled !== undefined && (reqData.isEnabled = isEnabled);
        accessType !== '' && accessType !== undefined && (reqData.accessType = accessType);
        const removeWebsiteSuccess = () => {
            dispatch(updateCreateDeviceGroupObj({ exception: updatedWebsitesList }))
            setExceptionsData(updatedWebsitesList);
            setShowSuccessNotification(successMsgs?.removeExceptionSuccessMessage);
        }
        const updateError = () => setShowErrorNotification(errorMsgs?.updateError);
        updateDeviceGroupDetails(reqData, removeWebsiteSuccess, updateError);
    }
    const removeKeywordHandler = () => {
        closeRemoveKeywordModal();
        const updatedKeywordsList = deviceGroupData?.keyword?.filter((_, index) => index != showRemoveKeywordModal);
        const updatedWebsitesList = deviceGroupData?.exception.length >0 ? deviceGroupData?.exception?.map(site => ({ type: 0, value: site })) :[];

        let reqData = {
            hashedMtn: hashedMtn, parentalControlId: deviceGroupData?.parentalControlId,
            flowType: 'REMOVE_KEYWORD_EXCEPTION', keywordExceptions: updatedKeywordsList?.map(site => ({ type: 1, value: site })),
            websiteExceptions:updatedWebsitesList
        }
        isEnabled !== '' && isEnabled !== undefined && (reqData.isEnabled = isEnabled);
        accessType !== '' && accessType !== undefined && (reqData.accessType = accessType);
        const removeKeywordSuccess = () => {
            dispatch(updateCreateDeviceGroupObj({ keyword: updatedKeywordsList }))
            setKeywordsData(updatedKeywordsList);
            setShowSuccessNotification(successMsgs?.removeKeywordsSuccessMessage);
        }
        const updateError = () => setShowErrorNotification(errorMsgs?.updateError);
        updateDeviceGroupDetails(reqData, removeKeywordSuccess, updateError);
    }

    /* istanbul ignore next */
    const removeAllWebsitesHandler = () => {
        closeRemoveAllWebsitesModal();
        const updatedKeywordsList = deviceGroupData?.keyword.length >0 ? deviceGroupData?.keyword?.map(site => ({ type: 1, value: site })) :[];
        let reqData = {
            hashedMtn: hashedMtn, parentalControlId: deviceGroupData?.parentalControlId,
            flowType: 'REMOVE_ALL_WEBSITE_EXCEPTIONS', websiteExceptions: [],keywordExceptions: updatedKeywordsList
        }
        isEnabled !== '' && isEnabled !== undefined && (reqData.isEnabled = isEnabled);
        accessType !== '' && accessType !== undefined && (reqData.accessType = accessType);
        const removeAllWebsitesSuccess = () => {
            dispatch(updateCreateDeviceGroupObj({ exception: [] }));
            setExceptionsData([]);
            setShowSuccessNotification(successMsgs?.removeAllExceptionsSuccessMessage);
        }
        const updateError = () => setShowErrorNotification(errorMsgs?.updateError);
        updateDeviceGroupDetails(reqData, removeAllWebsitesSuccess, updateError);
    }
    const removeAllKeywordHandler = () => {
        closeRemoveAllKeywordModal();
        const updatedWebsitesList = deviceGroupData?.exception.length >0 ? deviceGroupData?.exception?.map(site => ({ type: 0, value: site })) :[];
        let reqData = {
            hashedMtn: hashedMtn, parentalControlId: deviceGroupData?.parentalControlId,
            flowType: 'REMOVE_ALL_KEYWORD_EXCEPTIONS', keywordExceptions: [],websiteExceptions: updatedWebsitesList
        }
        isEnabled !== '' && isEnabled !== undefined && (reqData.isEnabled = isEnabled);
        accessType !== '' && accessType !== undefined && (reqData.accessType = accessType);
        const removeAllWebsitesSuccess = () => {
            dispatch(updateCreateDeviceGroupObj({ keyword: [] }));
            setKeywordsData([]);
            setShowSuccessNotification(successMsgs?.removeAllKeywordsSuccessMessage);
        }
        const updateError = () => setShowErrorNotification(errorMsgs?.updateError);
        updateDeviceGroupDetails(reqData, removeAllWebsitesSuccess, updateError);
    }

    /* istanbul ignore next */
    const updateWebsitesHandler = (websitesSelected) => {
        let reqData = {
            hashedMtn: hashedMtn, parentalControlId: deviceGroupData?.parentalControlId,
            flowType: 'ADD_OR_REMOVE_WEBSITE_EXCEPTIONS',
            websiteExceptions: websitesSelected?.map(value => ({ type: 0, value })),
            keywordExceptions: keywordsData.length > 0 ? keywordsData?.map(value => ({ type: 1, value })): []

        }
        isEnabled !== '' && isEnabled !== undefined && (reqData.isEnabled = isEnabled);
        accessType !== '' && accessType !== undefined && (reqData.accessType = accessType);
        const updateWebsitesSuccess = () => {
            dispatch(updateCreateDeviceGroupObj({ exception: websitesSelected }));
            setExceptionsData(websitesSelected);
           // goToManage();
            setShowAddExceptionModal(false);
            setShowSuccessNotification(successMsgs?.addExceptionSuccessMessage);
        }
        const updateError = () => setShowErrorNotification(errorMsgs?.updateError);
        updateDeviceGroupDetails(reqData, updateWebsitesSuccess, updateError);
    }

    const updateKeywordHandler = (keywordsSelected) => {
        let reqData = {
            hashedMtn: hashedMtn, parentalControlId: deviceGroupData?.parentalControlId,
            flowType: 'ADD_OR_REMOVE_KEYWORD_EXCEPTIONS',
            websiteExceptions: exceptionsData.length>0?exceptionsData?.map(value => ({ type: 0, value })):[],
            keywordExceptions: keywordsSelected?.map(value => ({ type: 1, value }))
        }
         isEnabled !== '' && isEnabled !== undefined && (reqData.isEnabled = isEnabled);
         accessType !== '' && accessType !== undefined && (reqData.accessType = accessType);
        const updateKeywordSuccess = () => {
            dispatch(updateCreateDeviceGroupObj({ keyword: keywordsSelected }));
            setKeywordsData(keywordsSelected);
           // goToManage();
           setShowAddKeywordModal(false);
            setShowSuccessNotification(successMsgs?.addKeywordsSuccessMessage);
        }
        const updateError = () => setShowErrorNotification(errorMsgs?.updateError);
        updateDeviceGroupDetails(reqData, updateKeywordSuccess, updateError);
    }

    //Set Schedule popup section
    const onEditScheduleModalChange = (flag) => {
        if (!flag)  {
            setShowEditScheduleModal(false);
        }
    }
    const onAddExceptionModalChange = (flag) => {
        if (!flag)  {
            setShowAddExceptionModal(false);
        }
    }
    const onSelectDevicesChange = (flag) =>{
        if(!flag){
            setShowSelectDevicesModal(false);
        }
    }
    const onAddKeywordModalChange = (flag) => {
        if (!flag)  {
            setShowAddKeywordModal(false);
        }
    }

    const titleOfSelectedDevices = (() => {
        const count = deviceGroupData?.devices?.length;
        const title= managePageData?.devices?.manageDeviceGroupSelectedDevicesHeading.replace("##DEVICES_NUMBER##",count)
        return title
     })

    useEffect(() => {
        if (dataLoaded) initLoad();
    }, [getDeviceGroupDetailsAPIData]);

    useEffect(() => {
        if (!getDeviceGroupDetailsFetching) {
            dispatch(getDeviceGroupDetails({ parentalControlId: deviceGroupData?.parentalControlId, hashedMtn: hashedMtn }));
            dispatch(clearNotificationStatus());
        }
    }, []);

    return <>
        <Loader />
        {showRemoveDeviceModal && <RemoveModal isOpen={showRemoveDeviceModal} {...removeDeviceModalData}
            onClose={closeRemoveDeviceModal} confirmClick={removeDeviceHandler}
            title={deviceGroupData?.devices?.length > 1 ? removeDeviceModalData?.title : removeDeviceModalData?.lastDeviceTitle}
            body={deviceGroupData?.devices?.length > 1 ? removeDeviceModalData?.body : null}
            confirmBtn={deviceGroupData?.devices?.length > 1 ? removeDeviceModalData?.confirmBtn : removeDeviceModalData?.lastDeviceConfirmBtn}
        />}
        {showRemoveKeywordModal && <RemoveModal isOpen={showRemoveKeywordModal} {...removeKeywordModalData?.one} onClose={closeRemoveKeywordModal} confirmClick={removeKeywordHandler} />}
        {showRemoveAllKeywordModal && <RemoveModal isOpen={showRemoveAllKeywordModal} {...removeKeywordModalData?.all} onClose={closeRemoveAllKeywordModal} confirmClick={removeAllKeywordHandler} />}
        {showRemoveWebsiteModal && <RemoveModal isOpen={showRemoveWebsiteModal} {...removeWebsiteModalData?.one} onClose={closeRemoveWebsiteModal} confirmClick={removeWebsiteHandler} />}
        {showRemoveAllWebsitesModal && <RemoveModal isOpen={showRemoveAllWebsitesModal} {...removeWebsiteModalData?.all} onClose={closeRemoveAllWebsitesModal} confirmClick={removeAllWebsitesHandler} />}
        {!getDeviceGroupDetailsFetching && getDeviceGroupDetailsAPIData && Object.keys(getDeviceGroupDetailsAPIData).length > 0 &&
            <div className='fwa-container new-device-group-container'>
                {showSuccessNotification && <div className='device-group-create-api-error-notification-container'>
                    <Notification type='success' title={showSuccessNotification} onCloseButtonClick={closeNotification} />
                </div>}
                {showErrorNotification && <div className='device-group-create-api-error-notification-container'>
                    <Notification type='error' title={showErrorNotification?.title} subtitle={showErrorNotification?.subtitle} disableFocus hideCloseButton />
                </div>}
                <div className='edit-wifi-nav'>
                    <li className='breadcrumb-link' onClick={redirectToHome} data-testid='Home'>Home /</li>
                    <li className='breadcrumb-link' onClick={redirectToAllDevicesList}>All devices /</li>
                    <li className='edit-wifi-nav-select'>{managePageData?.header?.breadCrumbManageDeviceGroup}</li>
                </div>
                <div className={'device-group-header '}>
                    {(deviceGroupData?.page === 'selectDevices') ?
                        <h1>{selectDevicesPageData?.selectDevicesEditModePageHeading}</h1> : <>
                            <h1>{managePageData?.header?.pageTitle?.replace('##GroupName##', deviceGroupData?.name)}</h1>
                            <h5>{managePageData?.header?.subTitle}</h5>
                        </>}
                </div>
                {maxDevices && <div className='notification-container'>
                    <Notification type='info' title='You’ve reached the maximum amount of devices per group.' onCloseButtonClick={() => setMaxDevices(false)} />
                </div>}
                <div className='device-group-body-container manage-group-body'>
                    <div className='left-pane-main'>
                        {deviceGroupData?.page === 'manage' && <ManageDetails
                            title={managePageData?.name?.manageDeviceGroupNameHeading}
                            editNameLabel={managePageData?.name?.manageGroupNameInput?.value} nameMaxCharacters={managePageData?.name?.manageGroupNameInput?.maximumCharacters}
                            nameError={deviceGroupName?.length > parseInt(managePageData?.name?.manageGroupNameInput?.maximumCharacters)} nameChangeHandler={(e) => setDeviceGroupName(e?.target?.value)}
                            setDeviceGroupName={setDeviceGroupName}
                            successNotification={successMsgs?.renameDeviceGroupUpdatedNotification}
                            isManage
                            renameSuccess={showSuccessData}
                            errorNotification={errorMsgs?.updateError}
                            renameError={showErrorData}
                            resetDeviceGroupName={resetDeviceGroupName}
                            setResetDeviceGroupName = {setResetDeviceGroupName}
                            isEnabled={isEnabled}
                            accessType={accessType}
                            clearAllNotificationStatus={clearAllNotificationStatus}
                            cancel={managePageData?.name?.renameDeviceGroupCancelButton?.value} save={managePageData?.name?.renameDeviceGroupSaveButton?.value} hashedMtn={hashedMtn}
                            deviceTitle={titleOfSelectedDevices()} removeDevice={managePageData?.devices?.removeDeviceLink} addDevice={managePageData?.devices?.addDevicesLink}
                            addDeviceHandler={goToDevices} noDevicesText={'No selected devices yet. Please add devices to this group to manage downtime schedule and website exceptions.'}
                            scheduleTitle={managePageData?.schedule?.manageDeviceGroupDowntimeScheduleHeading} scheduleDays={['Sun', 'Mon', 'Tue', 'Wed', 'Thu', 'Fri', 'Sat']}
                            editSchedule={managePageData?.schedule?.scheduleDowntimeLink.value} setSchedule={managePageData?.schedule?.scheduleDowntimeLink?.itemValueOnEmpty}
                            noScheduleText={managePageData?.schedule?.downtimeScheduleEmptyStateText}
                            websiteTitle={managePageData?.exception?.manageDeviceGroupWebsiteExceptionsHeading} websites={deviceGroupData?.exception} removeWebsite={managePageData?.exception?.removeExceptionLink}
                            addException={managePageData?.exception?.addExceptionLink} addExceptionHandler={goToExceptions} removeAllWebsite={managePageData?.exception?.removeAllExceptionsLink}
                            noWebsiteScheduleText={managePageData?.exception?.websiteExceptionsWithoutScheduleText} noWebsiteText={managePageData?.exception?.websiteExceptionEmptyStateText}
                            deviceGroupName={deviceGroupName} parentalControlId={parentalControlId} selectedDevices={deviceGroupData?.devices} devices={deviceGroupData?.connectedDevices}
                            openRemoveModal={(mac) => setShowRemoveDeviceModal(mac)} editScheduleHandler={goToSchedule}
                            keywordTitle={managePageData?.keyword?.manageDeviceGroupKeywordsExceptionsHeading}
                            keywords={deviceGroupData?.keyword}
                            addKeyword={managePageData?.keyword?.addKeywordsLink}
                            addKeywordHandler={goToKeyword}
                            removeKeyword={managePageData?.keyword?.removeKeywordsLink}
                            removeAllKeyword={managePageData?.keyword?.removeAllKeywordsLink}
                            noKeywordScheduleText={managePageData?.keyword?.keywordsExceptionsWithoutScheduleText} noKeywordText={managePageData?.keyword?.keywordsExceptionEmptyStateText}
                            setShowRemoveKeywordModal={(keywordIndex) => setShowRemoveKeywordModal(keywordIndex)} setShowRemoveAllKeywordModal={() => setShowRemoveAllKeywordModal(true)}
                            setShowRemoveWebsiteModal={(websiteIndex) => setShowRemoveWebsiteModal(websiteIndex)} setShowRemoveAllWebsitesModal={() => setShowRemoveAllWebsitesModal(true)} />}
                    </div>
                    <div className='right-pane'>
                        {deviceGroupData?.page === 'manage' ? <div className='create-device-group-preview-container manage-group'>
                            <div className='device-group-name-lg-badge'>{deviceGroupData?.name?.slice(0, 2)}</div>
                            <div className='device-group-name-text-value'>{deviceGroupData?.name}</div>
                            <div className='device-group-tile-buttons'>
                                <Button use='secondary' data-testid="removeGrpBtn" onClick={openRemoveModal}>{managePageData?.tile?.deleteDeviceGroupButton?.value}</Button>
                                {showRemoveModal && <RemoveModal isOpen={showRemoveModal} {...removeModalData} onClose={closeRemoveModal} confirmClick={confirmRemoveDevice} />}
                            </div>
                        </div> : <div className='create-device-group-preview-container detailed-preview-contianer'>
                            <div className='device-group-preview-container device-group-name-preview-container'>
                                <div className='device-group-name-lg-badge sm-badge'>{deviceGroupName?.slice(0, 2)}</div>
                                <div className='device-group-name-text-value'>{deviceGroupName}</div>
                            </div>
                            <div className='device-group-preview-container device-group-devices-preview-container'>
                                <div className='device-group-devices-preview-title'>Devices</div>
                                <div className='device-group-devices-preview-list-container'>
                                    {deviceGroupData?.devices?.map(selectDevice => <div key={'device-mac-' + selectDevice} className='device-group-preview-device-name'>
                                        {deviceGroupData?.connectedDevices?.filter(device => device.macId === selectDevice)[0]?.displayName}
                                    </div>)}
                                </div>
                            </div>
                            {deviceGroupData?.page === 'exception' && <SchedulePreview title={websiteExceptionRight?.downtimeScheduleHeading} deviceGroupData={deviceGroupData}
                                days={deviceGroupData?.schedule?.daysOfTheWeek} daysText={schedulePageData?.input?.setScheduleDayChips?.ddotValues?.split(',')} />}
                        </div>}
                    </div>
                </div>
            </div>}
            {showSelectDevicesModal
            && (
                <Modal className="" opened={showSelectDevicesModal} onOpenedChange={onSelectDevicesChange}>
                    <ModalTitle>
                        <div className="create-device-group-cancel-modal-title">Add devices</div>
                    </ModalTitle>
                    <ModalBody>
                    <div className='device-group-body-container manage-group-body'>
                    <div className='left-pane'>
                    <SelectDevices
                            isManage
                            currentPage={'selectDevices'} subtitle={selectDevicesPageData?.selectDevicesText}
                            sortLabel={selectDevicesPageData?.sortDevices?.value} sortOptions={selectDevicesPageData?.sortDevices?.listItems?.split(',')}
                            searchLabel={selectDevicesPageData?.searchDevices} devices={selectDevicesPageData?.connectedDevices} devicesSelected={deviceGroupData?.devices}
                            deviceGroupName={deviceGroupName} assignToNewGroup={selectDevicesPageData?.selectDevicesSubText?.itemValueOnSelect}
                            existingGroupName={selectDevicesPageData?.selectDevicesSubText?.value} back={selectDevicesPageData?.selectDevicesCancelButton?.value} backHandler={()=> {setShowSelectDevicesModal(false)}}
                            save={selectDevicesPageData?.selectDevicesAddButton?.value} saveHandler={(devicesSelected) => updateDeviceHandler(devicesSelected)} saveDisabled={true} setMaxDevices={setMaxDevices}
                        />
                        </div>
                        </div>
                    </ModalBody>
                    
                </Modal>

            )}
            {showEditScheduleModal 
            && (
                <Modal className="" opened={showEditScheduleModal} onOpenedChange={onEditScheduleModalChange}>
                    <ModalTitle>
                        <div className="create-device-group-cancel-modal-title">Edit Schedule</div>
                    </ModalTitle>
                    <ModalBody>
                    <div className='device-group-body-container manage-group-body'>
                    <div className='left-pane'>
                        <SetSchedule
                            isManage
                            subtitle={schedulePageData?.input?.setScheduleDesc} currentPage={'setSchedule'} selectDaysTitle={schedulePageData?.input?.setScheduleDayChips?.value}
                            days={schedulePageData?.input?.setScheduleDayChips?.ddotValues?.split(',')} startTimeTitle={schedulePageData?.input?.startTimeDropDown?.value}
                            endTimeTitle={schedulePageData?.input?.endTimeDropDown?.value} clearSchedule={schedulePageData?.input?.clearSchedule}
                            back={schedulePageData?.input?.setScheduleCancelButton?.value} backHandler={()=> setShowEditScheduleModal(false)}
                            deviceGroupData={deviceGroupData} nextHandler={(scheduleData) => updateScheduleHandler(scheduleData)} skipHandler={clearScheduleHandler}
                            next={schedulePageData?.input?.setScheduleSetButton?.value}
                            skip={schedulePageData?.input?.setScheduleSetButton?.value}
                        />
                        </div>
                        </div>
                    </ModalBody>
                    
                </Modal>
                
            )}
            {showAddExceptionModal
            && (
                <Modal className="" opened={showAddExceptionModal} onOpenedChange={onAddExceptionModalChange}>
                    <ModalTitle>
                        <div className="create-device-group-cancel-modal-title">Add allowed websites</div>
                    </ModalTitle>
                    <ModalBody>
                    <div className='device-group-body-container manage-group-body'>
                    <div className='left-pane'>
                    <AddException
                            isManage 
                            subtitle={websiteExceptionPageData?.addExceptionsDesc?.edit} inputLabel={websiteExceptionPageData?.addExceptionsInput?.value}
                            errorText={websiteExceptionPageData?.addExceptionsInput?.helperTextOnError} 
                            backHandler={()=> setShowAddExceptionModal(false)} back={websiteExceptionPageData?.addExceptionsCancelButton?.value} nextHandler={(sites) => updateWebsitesHandler(sites)} skip={websiteExceptionPageData?.addExceptionsSaveButton?.value}
                            next={websiteExceptionPageData?.addExceptionsSaveButton?.value} websitesData={deviceGroupData?.exception || []}
                        />
                        </div>
                        </div>
                    </ModalBody>
                    
                </Modal>
                
            )}
            {showAddKeywordModal
            && (
                <Modal className="" opened={showAddKeywordModal} onOpenedChange={onAddKeywordModalChange}>
                    <ModalTitle>
                        <div className="create-device-group-cancel-modal-title">Add allowed Keyword</div>
                    </ModalTitle>
                    <ModalBody>
                    <div className='device-group-body-container manage-group-body'>
                    <div className='left-pane'>
                    <Addkeyword
                            isManage 
                            subtitle={keywordPageData?.addKeywordsDesc?.edit}  inputLabel={keywordPageData?.addKeywordsInput?.value}
                            helperText={keywordPageData?.addKeywordsInput?.helperText} errorText={keywordPageData?.addKeywordsInput?.helperTextOnError} removeAll={keywordPageData?.removeAllKeywordsLink}
                            backHandler={()=> setShowAddKeywordModal(false)} back={keywordPageData?.addKeywordsCancelButton?.value} nextHandler={(sites) => updateKeywordHandler(sites)} skip={keywordPageData?.addKeywordsSaveButton?.value}
                            next={keywordPageData?.addKeywordsSaveButton?.value} keywordData={deviceGroupData?.keyword || []}
                        />
                        </div>
                        </div>
                    </ModalBody>
                    
                </Modal>
                
            )}
    </>;
}

export default DeviceGroupDetails;