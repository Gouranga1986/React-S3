import React, { useState, useReducer, useEffect } from 'react';
import { Button } from '@vds/buttons';
import { DropdownSelect } from '@vds/selects';

const SetSchedule = ({ title, subtitle, currentPage, selectDaysTitle, days, startTimeTitle, deviceGroupData, isManage,
    clearSchedule, endTimeTitle, back, backHandler, cancel, openCancelModal, next, nextHandler, skip, skipHandler }) => {

    const createArray = (length, fromZero) => Array.from({ length }, (val, index) => (fromZero ? index : (index + 1)).toString().padStart(2, 0));
    const hoursArray = createArray(12);
    const minutesArray = createArray(60, true);

    const [selectedDays, setSelectedDays] = useState([]);
    const timeAction = (state, { type, value }) => {
        switch (type) {
            case 'hour': return { ...state, hour: value };
            case 'minute': return { ...state, minute: value };
            case 'period': return { ...state, period: value };
            case 'clear': return { hour: '12', minute: '00', period: 'AM' };
            case 'all': return { hour: value?.hour, minute: value?.minute, period: value?.period };
        }
    }
    const [startTime, setStartTime] = useReducer(timeAction, { hour: '12', minute: '00', period: 'AM' });
    const [endTime, setEndTime] = useReducer(timeAction, { hour: '12', minute: '00', period: 'AM' });
    const [initHideEndTime, setInitHideEndTime] = useState(true);

    const toggleDaysOfWeekSelection = (dayIndex) => {
        let tempDays = [...selectedDays];
        if (tempDays.includes(dayIndex)) tempDays.splice(tempDays.indexOf(dayIndex), 1);
        else tempDays.push(dayIndex);
        setSelectedDays(tempDays);
    }

    const clearScheduleHandler = () => {
        setSelectedDays([]);
        setStartTime({ type: 'clear' });
        setEndTime({ type: 'clear' });
    }

    useEffect(() => {
        if (selectedDays?.length > 0) setInitHideEndTime(false);
    }, [selectedDays]);

    useEffect(() => {
        if (deviceGroupData?.schedule?.daysOfTheWeek?.length > 0) {
            setSelectedDays(deviceGroupData?.schedule?.daysOfTheWeek);
            setStartTime({
                type: 'all', value:
                {
                    hour: deviceGroupData?.schedule?.startTimeHour,
                    minute: deviceGroupData?.schedule?.startTimeMinute,
                    period: deviceGroupData?.schedule?.startTimeAmPm
                }
            });
            setEndTime({
                type: 'all', value:
                {
                    hour: deviceGroupData?.schedule?.stopTimeHour,
                    minute: deviceGroupData?.schedule?.stopTimeMinute,
                    period: deviceGroupData?.schedule?.stopTimeAmPm
                }
            });

        }
    }, [deviceGroupData]);

    return <>
        <div className='left-pane-title select-devices-title'>{title}</div>
        <div className='left-pane-subtitle'>{subtitle}</div>
        <div className={'left-pane-body ' + currentPage}>

            <div className='downtime-selection-container'>
                <div className='downtime-selection-days'>
                    <div className='downtime-selection-days-title'>{selectDaysTitle}</div>
                    <div className='downtime-selection-days-box-container'  >
                        {days?.map((day, dayIndex) => <div key={'day-' + day}
                                data-testid='select-day'
                                className={'downtime-selection-day-box ' + (selectedDays.includes(dayIndex) ? 'selected-day' : '')}
                                onClick={() => toggleDaysOfWeekSelection(dayIndex)}
                            >{day}</div>)}
                    </div>
                </div>
                <div className='downtime-selection-time-container'>
                    <div className='downtime-selection-time-container start-time'>
                        <div className='downtime-selection-time-title start-time'>{startTimeTitle}</div>
                        <div className='downtime-selection-time-dropdown-container start-time'>
                            <div className='downtime-selection-time-hour start-time' data-testid='start-time-hour'>
                                <DropdownSelect readOnly={selectedDays?.length === 0} onChange={(e) => setStartTime({ type: 'hour', value: e?.target?.value })}>
                                    {hoursArray.map(hourValue => <option selected={startTime.hour === hourValue} key={'start-hour-val-' + hourValue}>{hourValue}</option>)}
                                </DropdownSelect>
                            </div>
                            <div className='downtime-selection-time-colon start-time'>:</div>
                            <div className='downtime-selection-time-minute start-time' data-testid='start-time-minute'>
                                <DropdownSelect readOnly={selectedDays?.length === 0} onChange={(e) => setStartTime({ type: 'minute', value: e?.target?.value })}>
                                    {minutesArray.map(minuteValue => <option selected={startTime.minute === minuteValue} key={'start-minute-val-' + minuteValue}>{minuteValue}</option>)}
                                </DropdownSelect>
                            </div>
                            <div className={'downtime-selection-time-am-pm start-time ' + (selectedDays?.length === 0 ? 'period-disabled' : '')} >
                                {['AM', 'PM'].map(val => <div key={'start-' + val} data-testid={'start-time-period-' + val.toLowerCase()} onClick={() => selectedDays?.length > 0 && setStartTime({ type: 'period', value: val })}
                                    className={`downtime-selection-time-${val.toLowerCase()} start-time`}>
                                    <div className={`downtime-selection-time-${val.toLowerCase()}-radio start-time`}>
                                        {(startTime.period === val) && <div className={`downtime-selection-time-${val.toLowerCase()}-radio-selection start-time`}></div>}
                                    </div>
                                    <div className={`downtime-selection-time-${val.toLowerCase()}-label start-time`}>{val}</div>
                                </div>)}
                            </div>
                        </div>
                        {!initHideEndTime && <>
                            <div className='downtime-selection-time-title end-time'>{endTimeTitle}</div>
                            <div className='downtime-selection-time-dropdown-container end-time'>
                                <div className='downtime-selection-time-hour end-time' data-testid='end-time-hour'>
                                    <DropdownSelect readOnly={selectedDays.length === 0} onChange={(e) => setEndTime({ type: 'hour', value: e?.target?.value })}>
                                        {hoursArray.map(hourValue => <option selected={endTime.hour === hourValue} key={'end-hour-val-' + hourValue}>{hourValue}</option>)}
                                    </DropdownSelect>
                                </div>
                                <div className='downtime-selection-time-colon end-time'>:</div>
                                <div className='downtime-selection-time-minute end-time' data-testid='end-time-minute'>
                                    <DropdownSelect readOnly={selectedDays.length === 0} onChange={(e) => setEndTime({ type: 'minute', value: e?.target?.value })}>
                                        {minutesArray.map(minuteValue => <option selected={endTime.minute === minuteValue} key={'end-minute-val-' + minuteValue}>{minuteValue}</option>)}
                                    </DropdownSelect>
                                </div>
                                <div className={'downtime-selection-time-am-pm end-time ' + (selectedDays.length === 0 ? 'period-disabled' : '')}>
                                    {['AM', 'PM'].map(val => <div key={'end-' + val} data-testid={'end-time-period-' + val.toLowerCase()} onClick={() => selectedDays.length > 0 && setEndTime({ type: 'period', value: val })}
                                        className={`downtime-selection-time-${val.toLowerCase()} end-time`}>
                                        <div className={`downtime-selection-time-${val.toLowerCase()}-radio end-time`}>
                                            {(endTime.period === val) && <div className={`downtime-selection-time-${val.toLowerCase()}-radio-selection end-time`}></div>}
                                        </div>
                                        <div className={`downtime-selection-time-${val.toLowerCase()}-label end-time`}>{val}</div>
                                    </div>)}
                                </div>
                            </div>
                            {(selectedDays.length > 0) && <div className='downtime-selection-clear-schedule' data-testid='clear-schedule' onClick={clearScheduleHandler}>{clearSchedule}</div>}
                        </>}
                    </div>
                </div>
            </div>

            <div className='device-group-buttons'>
                {(selectedDays.length > 0) ?
                    <Button disabled={(startTime?.hour === endTime?.hour) && (startTime?.minute === endTime?.minute) && (startTime?.period === endTime?.period)}
                        onClick={() => nextHandler({ selectedDays, startTime, endTime })}>{next}</Button> :
                    <Button onClick={skipHandler}>{skip}</Button>}
                <Button use='secondary' onClick={backHandler}>{back}</Button>
            </div>
        </div>
    </>;
}

export default SetSchedule;