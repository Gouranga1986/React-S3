import React, { useEffect, useState } from 'react';
import { useSelector, useDispatch } from 'react-redux';
import { Input } from '@vds/inputs';
import { Button } from '@vds/buttons';
import { Accordion, AccordionDetail, AccordionHeader, AccordionItem, AccordionTitle } from '@vds/accordions';
import { updatedeviceGroup, updateCreateDeviceGroupObj } from '../../actions';

const EmptyExceptionState = ({ noWebsiteScheduleText, noWebsiteText, deviceGroupData, addException, addExceptionHandler }) =>
    ((!deviceGroupData?.schedule?.daysOfTheWeek) || (deviceGroupData?.schedule?.daysOfTheWeek?.length === 0)) ?
        <div className='device-group-review-no-devices no-bb'>{noWebsiteScheduleText}</div> :
        <>
            <div className='device-group-review-no-devices'>{noWebsiteText}</div>
            <div className='device-group-review-device-actions'>
                <div className='device-group-review-add-device' onClick={addExceptionHandler}>{addException}</div>
            </div>
        </>;
const EmptyKeywordState = ({ noKeywordScheduleText, noKeywordText, deviceGroupData, addKeyword, addKeywordHandler }) =>
    ((!deviceGroupData?.schedule?.daysOfTheWeek) || (deviceGroupData?.schedule?.daysOfTheWeek?.length === 0)) ?
        <div className='device-group-review-no-devices no-bb'>{noKeywordScheduleText}</div> :
        <>
            <div className='device-group-review-no-devices'>{noKeywordText}</div>
            <div className='device-group-review-device-actions'>
                <div className='device-group-review-add-device' onClick={addKeywordHandler}>{addKeyword}</div>
            </div>
        </>;

const AllDetails = ({ title, subtitle, editNameLabel, nameMaxCharacters, nameError, nameChangeHandler, deviceTitle, save, cancel, hashedMtn,
    removeDevice, addDevice, addDeviceHandler, noDevicesText, scheduleTitle, scheduleDays, editSchedule, editScheduleHandler,
    noScheduleText, setSchedule,keywordTitle,keywords,addKeyword,addKeywordHandler, websiteTitle, websites, removeWebsite, addException, addExceptionHandler, removeAllWebsite,
    noWebsiteScheduleText, noWebsiteText, noKeywordScheduleText,noKeywordText, deviceGroupName, parentalControlId, selectedDevices, devices, openRemoveModal,
    setShowRemoveWebsiteModal,setShowRemoveKeywordModal,setShowRemoveAllKeywordModal,removeKeyword,removeAllKeyword, successNotification, renameSuccess, errorNotification, renameError, setShowRemoveAllWebsitesModal, resetDeviceGroupName,setResetDeviceGroupName, setDeviceGroupName, clearAllNotificationStatus,isManage,accessType,isEnabled }) => {

    const dispatch = useDispatch();

    const deviceGroupData = useSelector((state) => state.Router.createDeviceGroupData);
    const [saveDisabled, setSaveDisabled] = useState(true);
    const [isEdit, setIsEdit] = useState(false);
    const onSave = () => {
        clearAllNotificationStatus();
        const updatedDeviceData = {
            name: deviceGroupName,
        }
        const onRenameSuccess = () => {
            renameSuccess(successNotification);
            dispatch(updateCreateDeviceGroupObj(updatedDeviceData));
            setResetDeviceGroupName(deviceGroupName);
            setIsEdit(false);
        }
        const renameErrorNotification = () => renameError(errorNotification)
        let reqData = { parentalControlId: parentalControlId, hashedMtn: hashedMtn, groupName: deviceGroupName, flowType: "UPDATE_GROUP_NAME" };
        isEnabled !== '' && isEnabled !== undefined && (reqData.isEnabled = isEnabled);
        accessType !== '' && accessType !== undefined && (reqData.accessType = accessType);
        dispatch(updatedeviceGroup(reqData,onRenameSuccess, renameErrorNotification));
    }
    const onCancel = () => {
        setDeviceGroupName(resetDeviceGroupName);
        setIsEdit(false);
    }
    useEffect(() => {
        const disabledBtn = !deviceGroupName || deviceGroupName?.length > parseInt(nameMaxCharacters)
        setSaveDisabled(disabledBtn);
    }, [deviceGroupName]);
    useEffect(() => {
        if (deviceGroupName === resetDeviceGroupName) setIsEdit(false);
        else setIsEdit(true);
    }, [deviceGroupName])

    return <>
        <div className='left-pane-title select-devices-title'>{title}</div>
        {subtitle && <div className='left-pane-subtitle'>{subtitle}</div>}
        <div className='device-group-review-name-container'>
            <div className='device-group-review-name-label'>{editNameLabel}</div>
            <div className='device-group-review-name-text'>
                <Input data-testid='group-name-input' value={deviceGroupName || ''} onChange={nameChangeHandler}
                    errorText={`Must be 1-${nameMaxCharacters} characters long`} error={nameError} />
                { isManage && isEdit && <div className='device-group-buttons button-manage-margin'>
                    <Button use='secondary' data-testid="btn-cancel-manage" onClick={() => onCancel()}>{cancel}</Button>
                    <Button data-testid="btn-save-manage" onClick={() => onSave()} disabled={saveDisabled}>{save}</Button>
                </div>}
            </div>
        </div>
        <div className='device-group-accordions'>
            <Accordion topLine={false} bottomLine>
                <AccordionItem>
                    <AccordionHeader trigger={{ type: 'icon', alignment: 'top' }} bold>
                        <AccordionTitle>{deviceTitle}</AccordionTitle>
                    </AccordionHeader>
                    <AccordionDetail>
                        <div className='device-group-review-devices-container'>
                            {(selectedDevices?.length > 0) ? <>
                                {selectedDevices?.map(selectDevice => <div key={'device-mac-' + selectDevice} className='device-group-review-device-detail'>
                                    <div className='device-group-review-device-name'>{devices?.filter(device => device.macId === selectDevice)[0]?.displayName}</div>
                                    <div className='device-group-review-device-remove' data-testid='remove-device' onClick={() => openRemoveModal(selectDevice)}>{removeDevice}</div>
                                </div>)}
                                <div className='device-group-review-device-actions'>
                                    <div className='device-group-review-add-device' onClick={addDeviceHandler}>{addDevice}</div>
                                </div>
                            </>
                                : <>
                                    <div className='device-group-review-no-devices'>{noDevicesText}</div>
                                    <div className='device-group-review-device-actions'>
                                        <div className='device-group-review-add-device' onClick={addDeviceHandler}>{addDevice}</div>
                                    </div>
                                </>}
                        </div>
                    </AccordionDetail>
                </AccordionItem>
                <AccordionItem>
                    <AccordionHeader trigger={{ type: 'icon', alignment: 'top' }} bold>
                        <AccordionTitle>{scheduleTitle}</AccordionTitle>
                    </AccordionHeader>
                    <AccordionDetail>
                        <div className='device-group-review-schedule-container'>
                            {((deviceGroupData?.schedule?.daysOfTheWeek?.length > 0) ? <>
                                <div className='device-group-review-schedule-days-box-container downtime-selection-days-box-container'>
                                    {deviceGroupData?.schedule?.daysOfTheWeek?.map(day => <div key={'day-' + day}
                                        className='downtime-selection-day-box selected-day'>{scheduleDays[day]}</div>)}
                                </div>
                                <div className='device-group-review-schedule-time'>
                                    {deviceGroupData?.schedule?.startTimeHour}:{deviceGroupData?.schedule?.startTimeMinute} {deviceGroupData?.schedule?.startTimeAmPm} - {deviceGroupData?.schedule?.stopTimeHour}:{deviceGroupData?.schedule?.stopTimeMinute} {deviceGroupData?.schedule?.stopTimeAmPm}
                                </div>
                                <div className='device-group-review-device-actions'>
                                    <div data-testid="edit-schedule" className='device-group-review-add-device' onClick={editScheduleHandler}>{editSchedule}</div>
                                </div>
                            </> : <>
                                <div className='device-group-review-no-devices'>{noScheduleText}</div>
                                <div className='device-group-review-device-actions'>
                                    <div className='device-group-review-add-device' onClick={editScheduleHandler}>{setSchedule}</div>
                                </div>
                            </>)}
                        </div>
                    </AccordionDetail>
                </AccordionItem>
                <AccordionItem>
                    <AccordionHeader trigger={{ type: 'icon', alignment: 'top' }} bold>
                        <AccordionTitle>{websiteTitle}</AccordionTitle>
                    </AccordionHeader>
                    <AccordionDetail>
                        <div className='device-group-review-exceptions-container'>
                            {((deviceGroupData?.schedule?.daysOfTheWeek?.length > 0) && (websites?.length > 0)) ? <>
                                {websites?.map((exception, index) => <div key={'exception-website-' + exception} className='device-group-review-device-detail'>
                                    <div className='device-group-review-device-name'>{exception}</div>
                                    <div className='device-group-review-device-remove' data-testid='remove-website' onClick={() => setShowRemoveWebsiteModal(index.toString())}>{removeWebsite}</div>
                                </div>)}
                                <div className='device-group-review-device-actions'>
                                    <div className='device-group-review-add-device' onClick={addExceptionHandler}>{addException}</div>
                                    <div className='device-group-review-remove-all-device' data-testid='remove-all-websites' onClick={() => setShowRemoveAllWebsitesModal(true)}>{removeAllWebsite}</div>
                                </div>
                            </> : <EmptyExceptionState deviceGroupData={deviceGroupData} noWebsiteScheduleText={noWebsiteScheduleText} noWebsiteText={noWebsiteText} addException={addException} addExceptionHandler={addExceptionHandler} />}
                        </div>
                    </AccordionDetail>
                </AccordionItem>
                <AccordionItem>
                    <AccordionHeader trigger={{ type: 'icon', alignment: 'top' }} bold>
                        <AccordionTitle>{keywordTitle}</AccordionTitle>
                    </AccordionHeader>
                    <AccordionDetail>
                        <div className='device-group-review-exceptions-container'>
                            {((deviceGroupData?.schedule?.daysOfTheWeek?.length > 0) && (keywords?.length > 0)) ? <>
                                {keywords?.map((keyword, index) => <div key={'exception-keyword-' + keyword} className='device-group-review-device-detail'>
                                    <div className='device-group-review-device-name'>{keyword}</div>
                                    <div className='device-group-review-device-remove' data-testid='remove-keyword' onClick={() => setShowRemoveKeywordModal(index.toString())}>{removeKeyword}</div>
                                </div>)}
                                <div className='device-group-review-device-actions'>
                                    <div className='device-group-review-add-device' onClick={addKeywordHandler}>{addKeyword}</div>
                                    <div className='device-group-review-remove-all-device' data-testid='remove-all-keywords' onClick={() => setShowRemoveAllKeywordModal(true)}>{removeAllKeyword}</div>
                                </div>
                            </> : <EmptyKeywordState deviceGroupData={deviceGroupData} noKeywordScheduleText={noKeywordScheduleText} noKeywordText={noKeywordText} addKeyword={addKeyword} addKeywordHandler={addKeywordHandler} />}
                        </div>
                    </AccordionDetail>
                </AccordionItem>
            </Accordion>
        </div>
    </>
}

export default AllDetails;