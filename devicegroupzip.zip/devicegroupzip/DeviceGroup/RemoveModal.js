import React from 'react';
import {
  Modal, ModalTitle, ModalBody, ModalFooter,
} from '@vds/modals';
import { Button } from '@vds/buttons';

const RemoveModal = (props) => {
  const isOpen = props?.isOpen;
  const onClose = props?.onClose;

  /* istanbul ignore next */
  const onOpenedChange = (flag) => {
    if (!flag) onClose(flag);
  };

  return (
    <>
      {isOpen
            && (
            <Modal className="" opened={isOpen} disableOutsideClick onOpenedChange={onOpenedChange}>
              <ModalTitle>
                <div className="create-device-group-cancel-modal-title">{props?.title}</div>
              </ModalTitle>
              {props?.body && <ModalBody>
                <div className="create-device-group-cancel-modal-body">{props?.body}</div>
              </ModalBody>}
              <ModalFooter>
                <div className="create-device-group-cancel-modal-footer">
                  <Button className="confirm-btn" onClick={props?.confirmClick}>{props?.confirmBtn}</Button>
                  <Button className="back-btn" use="secondary" onClick={onClose}>{props?.cancelBtn}</Button>
                </div>
              </ModalFooter>
            </Modal>
            )}
    </>
  );
};

export default RemoveModal;