import React, { useState } from "react";
import { Input } from '@vds/inputs';
import { Button } from '@vds/buttons';

const AddException = ({
    title, subtitle, subheader, errorText, websitesData, openCancelModal, cancel, isManage,
    helperText, removeAll, backHandler, back, nextHandler, next, skip, inputLabel
}) => {

    //Exception Website Data
    const [websites, setWebsites] = useState(websitesData);
    const [websiteUrl, setWebsiteUrl] = useState('');
    const [urlError, setUrlError] = useState(false);

    const updateWebsiteUrl = (site) => {
        setUrlError(false);
        setWebsiteUrl(site);
    };

    const addWebsite = () => {
        const isUrlGood = /^(?:www\.)?[a-zA-Z0-9-]+(\.[a-zA-Z]{2,})+$/.test(websiteUrl.trim());
        setWebsiteUrl('');
        if (isUrlGood) setWebsites((prevExceptions) => [...prevExceptions, websiteUrl]);
        else setUrlError(true);
    }

    const removeWebsiteData = (index) => setWebsites((prevException) => prevException?.filter((_, i) => i != index));
    const removeAllExceptionData = () => setWebsites([]);
    const addSkipHandler = () => nextHandler(websites);

    return <>
        <div data-testid='exception' className='left-pane-title exception'>{title}</div>
        <div className='left-pane-message'>{subtitle}</div>
        <div className='left-pane-body exception'>
            <div className='left-pane-body-subTitle'>{subheader}</div>
            <div className='device-group-name-input device-group-text-input'>
                <Input label={inputLabel}
                    className={urlError ? 'addWebsiteError' : ''}
                    data-testid='website-input'
                    type='text'
                    value={websiteUrl}
                    onChange={(e) => updateWebsiteUrl(e?.target?.value)} />
                {urlError && <span className='errorIcon'>
                    <svg width="81" height="44" viewBox="0 0 81 44" fill="none" xmlns="http://www.w3.org/2000/svg">
                        <path d="M22.0013 30.3334C21.7079 30.3341 21.4174 30.2766 21.1464 30.1643C20.8754 30.0519 20.6294 29.8869 20.4226 29.6788L14.321 23.5772C13.9028 23.1583 13.668 22.5907 13.668 21.9989C13.668 21.407 13.9028 20.8394 14.321 20.4206L20.4235 14.3189C20.8426 13.9014 21.41 13.6669 22.0016 13.6667C22.5931 13.6666 23.1607 13.9007 23.58 14.318L29.6816 20.4205C30.0998 20.8393 30.3346 21.407 30.3346 21.9988C30.3346 22.5907 30.0998 23.1583 29.6816 23.5771L23.58 29.6788C23.3733 29.8869 23.1273 30.052 22.8563 30.1644C22.5853 30.2768 22.2947 30.3342 22.0013 30.3334ZM15.057 21.1566C14.8342 21.3803 14.7091 21.6831 14.7091 21.9989C14.7091 22.3146 14.8342 22.6174 15.057 22.8411L21.1595 28.9428C21.3861 29.1599 21.6879 29.2812 22.0018 29.2812C22.3157 29.2812 22.6174 29.1599 22.844 28.9428L28.9456 22.8411C29.1684 22.6174 29.2935 22.3146 29.2935 21.9989C29.2935 21.6831 29.1684 21.3803 28.9456 21.1566L22.844 15.055C22.6201 14.8326 22.3173 14.7077 22.0018 14.7077C21.6862 14.7077 21.3834 14.8326 21.1595 15.055L15.057 21.1566ZM21.2123 25.9342H22.7864V24.3758H21.2123V25.9342ZM21.2123 20.3698L21.7317 22.8096H22.2591L22.7864 20.3698V18.0638H21.2123V20.3698Z" fill="black" /></svg>
                </span>}
                <span data-testid="add-btn" className="addWebsite" onClick={addWebsite}>Add</span>
                {urlError && (<p data-testid="error-message" className="errorText">{errorText}</p>)}
                {!urlError && <p className='errorText'>{helperText}</p>}
            </div>
            <ul data-testid='website-list'>
                {websites?.map((data, index) => (
                    <li key={data} data-testid='website-item'>{data}<button data-testid={`remove-btn-${index}`} onClick={() => removeWebsiteData(index)}>Remove</button></li>
                ))}
            </ul>
            {websites?.length > 1 && (<button data-testid='remove-all-btn' className='removeAllItem' onClick={removeAllExceptionData}>{removeAll}</button>)}
            <div className='device-group-buttons'>
                {websites?.length === 0 ?
                    <Button onClick={addSkipHandler}>{skip}</Button> :
                    <Button data-testid="next-btn" onClick={addSkipHandler}>{next}</Button>}
                <Button data-testid="back-btn" use='secondary' onClick={backHandler}>{back}</Button>
            </div>
            {!isManage && <div className='cancel-link-container' onClick={openCancelModal}>{cancel}</div>}
        </div>
    </>;
};

export default AddException;