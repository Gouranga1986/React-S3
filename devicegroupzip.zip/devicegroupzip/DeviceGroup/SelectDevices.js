import React, { useState, useEffect } from 'react';
import { DropdownSelect } from '@vds/selects';
import { Checkbox } from '@vds/checkboxes';
import { Button } from '@vds/buttons';
import common from '../../../../../shared/utilities/util';

const SelectDevices = ({
    title, subtitle, currentPage, sortLabel, sortOptions, searchLabel, devicesSelected, devices, setMaxDevices, updateSelectedDevices,
    deviceGroupName, existingGroupName, assignToNewGroup,unassignValue,unassignToNewGroup, back, backHandler, save, saveHandler, cancel, cancelHandler, isManage
}) => {

    const [devicesNextDisabled, setDevicesNextDisabled] = useState(true);
    const [modifiedDevices, setModifiedDevices] = useState(devices);
    const [selectedDevices, setSelectedDevices] = useState(devicesSelected);
    const [sortBy, setSortBy] = useState('');
    const [searchVal, setSearchVal] = useState('');

    const toggleDeviceSelection = (macId, selected) => {
        setMaxDevices(false);
        let tempSelectedDevices = JSON.parse(JSON.stringify(selectedDevices));
        if (selected) {
            if (tempSelectedDevices?.length < 16)
                tempSelectedDevices?.push(macId);
            else setMaxDevices(true);
        }
        else tempSelectedDevices?.splice(tempSelectedDevices?.indexOf(macId), 1);
        setSelectedDevices(tempSelectedDevices);
    }

    const ascendingSort = (a, b) => {
        if (a?.displayName === b?.displayName) return 0;
        return a?.displayName > b?.displayName ? 1 : -1;
    };
    const descendingSort = (a, b) => {
        if (a?.displayName === b?.displayName) return 0;
        return a?.displayName < b?.displayName ? 1 : -1;
    }

    useEffect(() => {
        if (devices?.length > 0) {
            let tempDevices = JSON.parse(JSON.stringify(devices));
            if (searchVal) {
                const searchRegex = new RegExp(searchVal, 'i');
                tempDevices = tempDevices?.filter(tempDeviceObj => searchRegex?.test(tempDeviceObj?.displayName));
            }
            if (sortBy) {
                if (/a-z/i.test(sortBy)) {
                    tempDevices?.sort(ascendingSort);
                } else if (/z-a/i.test(sortBy)) {
                    tempDevices?.sort(descendingSort);
                }
            }
            setModifiedDevices(tempDevices);
        }
    }, [sortBy, searchVal]);

    useEffect(() => {
        const noDevices = selectedDevices.length === 0;
        const sameDevicesSelected = common.arraysHaveSameElements(selectedDevices, devicesSelected);
        setDevicesNextDisabled(noDevices || (isManage && sameDevicesSelected));
    }, [selectedDevices]);

    const saveClickHandler = () => {
        updateSelectedDevices?.(selectedDevices);
        saveHandler(selectedDevices);
    }
    const unassignedSubtitle = (deviceObj) => {
        return selectedDevices?.includes(deviceObj?.macId)
        ? (assignToNewGroup?.replace(/##NEW_GROUP_NAME##/, deviceGroupName))
        : (existingGroupName?.replace(/##GROUP_NAME##/, deviceObj?.deviceGroupName));
    }
    const assignedSubtitle = (deviceObj) => {
        return selectedDevices?.includes(deviceObj?.macId) ? (unassignToNewGroup?.replace(/##NEW_GROUP_NAME##/, deviceGroupName)) : unassignValue ;
        
    }
    return <>
        <div className='left-pane-title select-devices-title'>{title}</div>
        <div className='left-pane-subtitle'>{subtitle}</div>
        <div className={'left-pane-body ' + currentPage}>
            <div className='devices-sort-search-container'>
                <div className='devices-sort-container'>
                    <DropdownSelect readOnly={false} label={sortLabel} inlineLabel onChange={(e) => setSortBy(e?.target?.value)}>
                        <option></option>
                        {Array.isArray(sortOptions) && sortOptions?.map((option) => <option key={'key-' + option}>{option}</option>)}
                    </DropdownSelect>
                </div>
                <div className='devices-search-container'>
                    <input data-testid='search-devices' placeholder={searchLabel} onChange={(e) => setSearchVal(e?.target?.value)} />
                </div>
            </div>
            <div className='device-group-devices-list-container'>
                {Array.isArray(modifiedDevices) &&
                    modifiedDevices?.map(deviceObj => <div key={'device-key-' + deviceObj?.macId}
                        className={'create-group-device-container ' + (deviceObj?.deviceGroupName ? 'existing-group' : '')}>
                        <div className='create-group-device-checkbox-container'>
                            <Checkbox selected={selectedDevices?.includes(deviceObj?.macId)} onChange={(e, v) => toggleDeviceSelection(deviceObj?.macId, v?.selected)} />
                        </div>
                        <div className='create-group-device-label-container'>
                            <div className='create-group-device-title'>{deviceObj?.displayName}</div>
                            {/* {console.log("deviceObj === ",deviceObj)} */}
                            {deviceObj?.deviceGroupName ? <div className='create-group-device-subtitle'>
                                {unassignedSubtitle(deviceObj)}
                            </div> : <div className='create-group-device-subtitle'>
                                {assignedSubtitle(deviceObj)}
                            </div>}
                        </div>
                    </div>)}
            </div>
            <div className='device-group-buttons'>
                <Button disabled={devicesNextDisabled} onClick={saveClickHandler}>{save}</Button>
                <Button use='secondary' onClick={backHandler}>{back}</Button>
            </div>
            {!isManage && <div className='cancel-link-container' onClick={cancelHandler}>{cancel}</div>}
        </div>
    </>
}
export default SelectDevices;