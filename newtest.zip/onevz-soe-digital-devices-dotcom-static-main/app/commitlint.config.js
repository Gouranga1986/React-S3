const matchApplication = /(Digital|Assisted-CS|Conversational|Marketing-Home|Platform|SOR|x\/CIO)\s/;
const matchDomain = /(ACT-\d+|PCT-\d+)\s/;
const matchTicket = /([A-Za-z0-9]+-\d+)\s/;
const matchType = /(build|chore|ci|docs|feat|fix|perf|refactor|revert|style|test|defect|story):\s/;
const matchSubject = /([^[].+)/;

const Configuration = {
  extends: ['@commitlint/config-conventional'],
  ignores: [
    (commit) => (commit === 'NSAT-98 version update' || commit === 'Update .gitlab-ci.yml version'),
  ],
  parserPreset: {
    parserOpts: {
      headerPattern: new RegExp(
        `^${matchApplication.source}${matchDomain.source}${matchTicket.source}${matchType.source}${matchSubject.source}`
      ),
      headerCorrespondence: ['application', 'domain', 'ticket', 'type', 'subject'],
    },

  },
  plugins: [
    {
      rules: {
        'header-match-team-pattern': (parsed) => {
          const {
            application, domain, ticket, type, subject,
          } = parsed;
          console.log(`Application-${application} Domain-${domain} Ticket-${ticket} Type-${type} Subject-${subject}`);
          // const ticketRegex = /(CXTDT-\w+|PRFX-\w+|DIGIP-\w+|DE323-\w+|PPM-\w+|PRODDEF-\w+|MSF2NSA-\w+|RAFR-\w+|VZWYZDF-\w+|DCMP-\w+|BAYOU-\w+|EVVF-\w+|DOPMO-\w+|EXTAIS-\w+|PRODDED-\w+|NSADT-\w+|ACT-\w+|OBPPAY-\w+|PCCGR-\w+|CHAN-\w+|SALE-\w+|PHVM-\w+|ENFUL-\w+|ONE-\w+|VZWFB-\w+|VZ-\w+|VBP-\w+|VCG-\w+|VBG-\w+|VZWYZDO-\w+|OBPNBS-\w+|CXPD-\w+|CXPAD-\w+|ENFUL-\w+|PSTGRO-\w+|VCGBH-\w+|UPFPMT-\w+|BVVJ-\w+|CRED-\w+|PREGRO-\w+)/;
          if (application === null || domain === null || ticket === null || type === null || subject === null) {
            return [
              false,
              'wrong commit message, please follow format - `Digital ACT-015 CXTDT-411115 defect: Fixed issue with user login.`',
            ];
          }
          // if (!ticketRegex.test(ticket)) {
          //   return [
          //     false,
          //     'Please add ticket number, Example DOPMO-158669',
          //   ];
          // }
          return [true, ''];
        },
      },
    },
  ],
  rules: {
    'header-match-team-pattern': [2, 'always'],
    'subject-case': [2, 'always', ['sentence-case']], // Setting a standard so folks will follow, chose against lower-case to allow JIRA tickects
    'type-enum': [0, 'always'],
  },
  helpUrl: `

  * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * *
  *                                                                                             *
  *  Please ensure that you are following conventional commits format for your commit messages. *
  *  Do not bypass this commit hook as the server will not allow you to push your changes.      *
  *                                                                                             *
  *  https://www.conventionalcommits.org/                                                       *
  *                                                                                             *
  *  For additional help you can reach out to Aiswarya,Vibhore or Karthick                      *
  *                                                                                             *
  * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * *
`,
};

module.exports = Configuration;

