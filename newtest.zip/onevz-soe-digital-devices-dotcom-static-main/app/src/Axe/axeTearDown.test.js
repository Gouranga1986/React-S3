import { cleanup } from '@testing-library/react';
import { axe } from 'jest-axe';
import { LocalStorage } from 'node-localstorage';
import { createHtmlReport } from 'axe-html-reporter';
import { exec } from 'shelljs';

const fs = require('fs');
const path = require('path');
const getDirName = require('path').dirname;
const { axe: { enable } } = require('../../package.json');

const isWindows = process.platform === 'win32';
const manualAxeReport = exec('git config --global core.DotCom.fetchAxeReport', { silent: true })?.toString()?.trim();

const TestEmptyComponent = () => {
  describe('Axe Components Testing', () => {
    test('Accessibility Testing on test case', () => {

    });
  });
};

if ((process.platform === 'darwin' || process.platform === 'win32') && enable) {
  const generateReport = (results, testPath) => {
    const reportHTML = createHtmlReport({
      results,
      options: {
        projectKey: 'Axe Report',
      },
    });
    const file = `AxeReports/${testPath.split(isWindows ? '\\src\\' : '/src/')[1]}.html`;
    if (!fs.existsSync(file)) {
      fs.mkdirSync(getDirName(file), {
        recursive: true,
      });
    }
    fs.writeFileSync(file, reportHTML);
  };

  afterEach(cleanup);
  const TestAxeComponent = () => {
    describe('Axe Components Testing', () => {
      let overAllResults = {};
      const localStorage = new LocalStorage(path.resolve(__dirname, '../../local-storage'), Number.MAX_VALUE);
      let outputHtml = localStorage.getItem('outputHtml');
      outputHtml = outputHtml ? JSON.parse(outputHtml) : outputHtml;

      let stagedFiles = exec('git diff --name-only --cached', { silent: true });
      stagedFiles = (`${stagedFiles.toString().replace(/\n/g, ' ')}`).toString();
      let stagedFilesList = stagedFiles.split(' ');
      stagedFilesList = stagedFilesList.filter((item) => {
        const ignorePatterns = item?.toLowerCase()?.match(/(asset|apidata|reducer|action|hook|selector|saga|api|bootstrap|store|routing|public)/g) || [];
        if (ignorePatterns.length === 0) return item;
        return false;
      }).map((stagedFile) => {
        let file = stagedFile.replace('tests/', '').replace('app/src/', '').split('/');
        file.splice(-1, 1);
        file = file.join('/')?.toLowerCase();
        file = file?.split('/components/')?.[0];
        return file;
      });

      const outputs = manualAxeReport ? outputHtml : outputHtml.filter((item) => {
        let testPath = item?.testPath?.toLowerCase?.()?.split(isWindows ? '\\app\\src\\' : '/app/src/')?.[1];
        testPath = testPath.split(isWindows ? '\\tests\\' : '/tests/')?.[0];
        if (testPath && stagedFilesList.includes(testPath)) {
          return item;
        }
        return false;
      });
      if (outputs?.length > 0) {
        outputHtml.forEach((result) => {
          const { testPath, html, currentTestName } = result;
          test(`Accessibility Testing on test case "${currentTestName}"`, async () => {
            try {
              const render = () => html;
              const renderedHtml = render();
              const results = await axe(renderedHtml);
              generateReport(results, testPath);
              if (results?.violations?.length > 0) {
                if (overAllResults?.violations?.length > 0) {
                  results.violations.forEach((vio) => overAllResults.violations.some((allvio) => allvio.nodes[0].html !== vio.nodes[0].html) && overAllResults.violations.push({ ...vio, testPath }));
                  localStorage.setItem('violations', JSON.stringify(overAllResults.violations));
                } else {
                  overAllResults = results;
                  localStorage.setItem('violations', JSON.stringify(overAllResults.violations));
                }
              }
            } catch (e) {
              console.log(e);
            }
          });
        });
      } else {
        TestEmptyComponent();
      }
    });
  };
  TestAxeComponent();
} else {
  TestEmptyComponent();
}
