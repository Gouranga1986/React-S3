import React from 'react';
import { Route } from 'react-router-dom';

export const CustomRoute = ({
  component: Component, guardComponent, reduxStore, ...rest
}) => (
  <Route
    {...rest}
    render={(props) => (
      guardComponent
        ? (guardComponent.canActivate(reduxStore)
          ? <Component {...props} />
          : guardComponent.fallbackRoute(reduxStore, props.location)
        ) : <Component {...props} />
    )}
  />
);
