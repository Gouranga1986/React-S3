import React from 'react';
  

export const onTabChange = (value,setIsSettingsTabSelected,setIsRecentsTabsSelected) => {  
    if (value === 'settings') {
      setIsSettingsTabSelected(true);
      setIsRecentsTabsSelected(false);
    } else {
      setIsSettingsTabSelected(false);
      setIsRecentsTabsSelected(true);
    }
  };





