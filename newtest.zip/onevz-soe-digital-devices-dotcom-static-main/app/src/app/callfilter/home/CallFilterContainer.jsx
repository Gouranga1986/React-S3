import React, { useState, useEffect } from "react";
import styled from "styled-components";

import { Tab, Tabs } from "@vds/tabs";
import { useDispatch, useSelector } from "react-redux";
import apiUrl from "../../../shared/utilities/apiUrl";
import CallFilterSettings from "./components/callFilterSettings/CallFIlterSettings";
import CallFilterNotEligible from "./components/callFilterNotEligible/callFilterNotEligible";
import CallFilterRecents from "./components/callFilterRecents/callFilterRecents";

import { fetchCallTreatment } from "./components/actions";
import common from "../../../shared/utilities/util";
import BaseComponent from "../../../shared/components/BaseComponent";
import NewLoader from "../../../shared/components/Loader/NewLoader";
import { getAnyApiResponseError } from "../../../shared/utilities/apiActions";

import { onTabChange } from "./TabChange";

const CallFilterContainer = (props) => {
  // const [isSettingsTabSelected, setIsSettingsTabSelected] = useState(false);
  // const [isRecentsTabsSelected, setIsRecentsTabsSelected] = useState(true);
  const id =
    location.search.split("&")[0] &&
    location.search.split("&")[0].split("?id=")[1];

  const dispatch = useDispatch();

  useEffect(() => {
    if (id) {
      if (apiUrl().callFilterSettingsApiUrl.indexOf("id=") === -1) {
        // reactGlobals.encryptedMdn = id;
        apiUrl().callFilterSettingsApiUrl =
          apiUrl().callFilterSettingsApiUrl + "?id=" + id;
      }
    }
    fetchCallTreatment(dispatch);
  }, []);

  const { callTreatment: callFilterConatinerResponse } = useSelector(
    (state) => state || {}
  );

  //const { isFetching } = callFilterConatinerResponse;
  const errorData =
    callFilterConatinerResponse.response &&
    getAnyApiResponseError(callFilterConatinerResponse.response);
  console.log("errorData", callFilterConatinerResponse);

  const pageContent =
    callFilterConatinerResponse.response &&
    callFilterConatinerResponse.response.body &&
    callFilterConatinerResponse.response.body.sections &&
    common.getContentFromSection(
      callFilterConatinerResponse.response.body.sections[0],
      "devicesCFSettingSection"
    );

  const sectionData = pageContent && pageContent.data;

  // const onTabChange = (value) => {
  //   if (value === 'settings') {
  //     setIsSettingsTabSelected(true);
  //     setIsRecentsTabsSelected(false);
  //   } else {
  //     setIsSettingsTabSelected(false);
  //     setIsRecentsTabsSelected(true);
  //   }
  // };
  const isCallFilterOff =
    sectionData && sectionData.isCallFilterTurnOn === false;

  const renderComponent = () =>
    sectionData && sectionData.eligibleMtnInd != "N" ? (
      <div data-testid="callfilterContainer">
        {sectionData && !isCallFilterOff && (
          <TabGroup>
            <Tabs linePosition="bottom" indicatorPosition="bottom">
              <Tab
                label="Recents"
                id="recents"
                data-testid="recents"
                data-track='{ "type": "tab", "name": "call filter recents tab", "selector": "#call-filter-recents__tab" }'
                // onClick={() => {
                //   onTabChange(
                //     "recents",
                //     setIsSettingsTabSelected,
                //     setIsRecentsTabsSelected
                //   );
                // }}
              >
                <CallFilterRecents history={[]} />
              </Tab>
              <Tab
                label="Settings"
                id="settings"
                data-testid="settings"
                data-track='{ "type": "tab", "name": "call filter settings tab", "selector": "#call-filter-settings__tab" }'
                // onClick={() => {
                //   onTabChange(
                //     "settings",
                //     setIsSettingsTabSelected,
                //     setIsRecentsTabsSelected
                //   );
                // }}
              >
               <CallFilterSettings />
              </Tab>
            </Tabs>
          </TabGroup>
        )}
        {sectionData && isCallFilterOff && (
          <TabGroup>
            <Tabs linePosition="bottom" indicatorPosition="bottom">
              <Tab
                label="Settings"
                id="settings"
                data-testid="settings"
                data-track='{ "type": "tab", "name": "call filter settings tab", "selector": "#call-filter-settings__tab" }'
                // onClick={() => {
                //   onTabChange("settings");
                // }}
              >
                <CallFilterSettings />
              </Tab>
              <Tab label="" />
            </Tabs>
          </TabGroup>
        )}
      </div>
    ) : (
      <div id="not-eligible" data-testid="callfilterContainer">
        {callFilterConatinerResponse && <CallFilterNotEligible />}
      </div>
    );

  return (
    <>
      {errorData && (
        <BaseComponent
          errorData={errorData}
          sectionContentMetaData={sectionData}
          pageType="Landing"
          data={callFilterConatinerResponse}
          pageEvent="event117"
        >
          {sectionData ? renderComponent() : <NewLoader />}
        </BaseComponent>
      )}
    </>
  );
};

const TabGroup = styled.div`
  padding-right: 1.25rem;
  padding-left: 1.25rem;
   @media (max-width: 678px) {
    padding-right:0.75rem;
    padding-left:0.75rem;
  } 

  & p {
    //font-family: NHaasGroteskDSStd-55Rg;
    font-size: 16px;
  }
  & li button {
    font-size: 16px;
    height: 16px;
    color: black;
  }
  & ul {
  }
  @media (max-width: 480px) {
    li button {
      font-size: 12px;
      height: 54px;
    }
    ul {
      width: 100%;
    }
  }
`;

export default CallFilterContainer;
