import React, { useState, useEffect,useRef } from 'react';
import {  useHistory } from 'react-router-dom';
import styled from 'styled-components';
import { useDispatch, useSelector } from 'react-redux';
import { Input } from '@vds/inputs';
import { Button } from '@vds/buttons';
import { DropdownSelect } from '@vds/selects';
import { getDeviceType } from '../../../../utils/VendorScripts/DeviceType';
import CallFilterHeader from '../callFilterHeader/CallFilterHeader';
import HorizontalBar from '../horizontalBar/HorizontalBar';
import { LinkContainer } from '../styledComps';
import { POTENTIAL_SPAM_TYPE, BLOCKED_CALL_TYPE } from '../constants';
import '../callFilterSettings/style.css';
import BaseComponent from '../../../../../shared/components/BaseComponent';
import { fetchReportCallFilter, saveReport } from '../actions';
import common from '../../../../../shared/utilities/util';
import Icon from '@vds/icons';
import './CallFilterReportNumber.css';
import { getAnyApiResponseError } from '../../../../../shared/utilities/apiActions';

const CallFilterReportNumber = (props) =>{

const callTypeOptions = [
  { "label": "Scammer", "value": "scam-fraud" },
                { "label": "Debt Collection", "value": "debtcollector" },
                { "label": "Telemarketer", "value": "telemarketer-sales" },
                { "label": "Survey", "value": "survey" },
                { "label": "Donations", "value": "fundraiser-charity" },
                { "label": "Caller hung up", "value": "hangup-deadair" },
                { "label": "Not spam", "value": "not-spam" },
                { "label": "Other", "value": "other" }
 ]
const dispatch = useDispatch();
const history = useHistory();
const aceEditorRef = useRef();
const [requestPayload, setrequestPayload] = useState({param1:"",callingTn:"",spamCategory:"",comment:""});
const [isDisabledReportBtn, setIsDisabledReportBtn] = useState(true);
const [selectedCategoryType, setSelectedCategoryType] = useState('');
const [selectedPhoneNumber, setSelectedPhoneNumber] = useState('');
const [isShowMdnError, setIsShowMdnError] = useState('');

useEffect(() => {
 
  fetchReportCallFilter(dispatch);
},[]);

const { callTreatment: callTreatmentReportResponse } = useSelector(
  (state) => state || {}
);



const pageReportContent = callTreatmentReportResponse.reportResponse && common.getContentFromSection(
  callTreatmentReportResponse?.reportResponse?.body?.sections[0],
  'deviceCFReportSection'
);


const sectionData = pageReportContent && pageReportContent.data;
 
const mainSectionItems = pageReportContent && pageReportContent.contents && pageReportContent.contents.length > 0 && pageReportContent.contents[0].items;

const title = common.getItem(mainSectionItems, 'title');
const mdnHeading = common.getItem(mainSectionItems, 'mdnHeading');
const spamHeading = common.getItem(mainSectionItems, 'spamHeading');
const description = common.getItem(mainSectionItems, 'description');
const commentHeading = common.getItem(mainSectionItems, 'commentHeading');
const comment = common.getItem(mainSectionItems, 'comment');
const comment_desc = common.getItem(mainSectionItems, 'comment_desc');
const subHeading = common.getItem(mainSectionItems, 'subHeading');
const backBtn = common.getItem(mainSectionItems, 'backBtn');


 const isFetching = callTreatmentReportResponse.isFetching;
 

 const errorData =
 callTreatmentReportResponse.reportResponse &&
 getAnyApiResponseError(callTreatmentReportResponse.reportResponse);



const errorMessage = 'Please enter a valid Mdn';
if (window.vzdl && window.vzdl.page) {
  window.vzdl.page.name = 'landing';
}

const onSaveReport = () => {
  setrequestPayload({...requestPayload,param1:window.encryptedMdn});
  console.log(requestPayload,"requestPayload")
  let callingTnVal = requestPayload.callingTn;
  if (props.location.state && props.location.state.data) {
    callingTnVal = props.location.state.data.formattedMTN.replace(/[^0-9]/g, '');
    setrequestPayload({...requestPayload,callingTn:props.location.state.data.formattedMTN.replace(/[^0-9]/g, '')});
  }
  const requestPayloadObj = {
    callingTn:callingTnVal,
    spamCategory:requestPayload.spamCategory,
    param1: window.encryptedMdn
  }
    console.log(requestPayloadObj,"requestPayloadObj")
    saveReport(dispatch, requestPayloadObj);
  
}


const onResetChanges = () => {
   setrequestPayload({param1:"",callingTn:"",spamCategory:"",comment:""})
  setIsDisabledReportBtn(true);
  

  document.getElementById("comments").value = "";
  // document.getElementsByName("phoneNumber")[0].value="";
  document.getElementsByClassName("jozAsx").value="";
  // requestPayload['callingTn'] = '';
  setSelectedPhoneNumber('');
  setSelectedCategoryType('');
  const el = document.querySelector("select[name='Call type']");
  el.selectedIndex = null;
 
   
}


const handleChangeSelect = (e) => {
  setrequestPayload({...requestPayload,spamCategory:e.target.value});
  if (e.target.value && selectedPhoneNumber) {
    setIsDisabledReportBtn(false)
  } else if (props.location.state) {
    setIsDisabledReportBtn(false)
  } else {
    setIsDisabledReportBtn(true)
  }
  console.log(selectedPhoneNumber, 'selectedPhoneNumber')
  console.log(requestPayload, 'requestPayload')
  setSelectedCategoryType(e.target.value)
  
}


const onChangeCallingMdn = (e) => {
  const regExp = /^\(?([0-9]{3})\)?[.]?([0-9]{3})[.]?([0-9]{4})$/;
  const { value } = e.target;
  let callingTnVal = '';
  if (!regExp.test(value)) {
    setIsShowMdnError(true);
    setrequestPayload({...requestPayload,callingTn:''});
  } else {
    setIsShowMdnError(false);
    setrequestPayload({...requestPayload,callingTn:value.replace(/[^0-9]/g, '')});
    callingTnVal = value.replace(/[^0-9]/g, '');
  }

  if (value.replace(/[^a-zA-Z!@#\$%\^\&*\)\(=_]/g, '').length === 0 && value.replace(/[^0-9]/g, '').length >= 10 && value.replace(/[^0-9]/g, '').length <= 15) {
    setIsShowMdnError(false);
    setrequestPayload({...requestPayload,callingTn:value.replace(/[^0-9]/g, '')});
    callingTnVal = value.replace(/[^0-9]/g, '');
  }
  setSelectedPhoneNumber(value)
  console.log(requestPayload,"requestPayload")
  if (callingTnVal && (requestPayload.spamCategory || selectedCategoryType)) {
    setIsDisabledReportBtn(false)
  } else {
    setIsDisabledReportBtn(true)
  }
}


const changeComment = (e) => {
  setrequestPayload({...requestPayload,comment:e.target.value});
}

useEffect(() => {
  //window.scrollTo(0, 0);
  if (window.vztag && vztag.api) {
    vztag.api.dispatch('pageView', {
      name: 'call filter report',
    });
  }
});

useEffect(() => {
  if (callTreatmentReportResponse.isRedirectToConfiramtionPage) {
    console.log(callTreatmentReportResponse,"callTreatmentReportResponse")
    history.push('/confirmation');
  }
},[callTreatmentReportResponse]);


const  goBacktoLandingPage = () => {
  history.push('/');
}

const {  reportErrorMessage } = props;


const data = props.location && props.location.state && props.location.state.data;



const renderComponent = () => (

  <div id="call-filter-report-number__tab" data-testid="callfilterReportNumber"  className="text-container">
         
        <LinkContainer>
          <ChevronRight
            onClick={() => { props.history.push('/'); }}
            role="link"
            tabindex="0"
            aria-label="go back"
            data-track={'{"type": "link", "name": "go back to recents"}'}
          />
          <a href="javascript:void(0)" style={{ textDecoration: 'underline' }} onClick={() => { goBacktoLandingPage(); }}>
          {pageReportContent && backBtn.itemValue} 
          </a>            
        </LinkContainer>
        <HeadingBar>
          <HorizontalBar color="#d8dada" marginTop="1.5rem" width="1px" />
        </HeadingBar>
        <Container>
          {reportErrorMessage && reportErrorMessage !== ''
            && (
            <BannerContainer>
              <span aria-live="polite" tabIndex="0" role="alert" style={{ height: '0px', marginLeft: '-10000px' }}>{reportErrorMessage}</span>
              {/* <Banner> */}
              {reportErrorMessage.toString()}
              {/* </Banner> */}
            </BannerContainer>
            )}
          {!data
            ? (
              <div>
                <CallFilterHeader header={pageReportContent && title.itemValue} />
                <HeadingBar>
                  <HorizontalBar margin="1.5rem 0" width="4px" />
                </HeadingBar>
                <Left>
                  <SubHeader>
                    {pageReportContent && description.itemValue}
                  </SubHeader>
                </Left>
                <Group>
                <Input
                type="text"
                size={18}
                role="input"
                id="phoneNumber"
                name="phoneNumber"
                value={selectedPhoneNumber}
                className="input"
                label={pageReportContent && mdnHeading.itemValue}
                analyticstrack="phone_number_input"
                ariaLabel="Enter a number"
                width="100%"
                required={true}
                error={isShowMdnError}
                errorText={errorMessage}
                onChange={onChangeCallingMdn}
                data-track
              />
                </Group>
              </div>
            ) : (
              <div>
                <Header style={{ marginTop: '1.5rem' }}>
                  {data.type}
                </Header>
                <div>                 
                  {POTENTIAL_SPAM_TYPE.indexOf(data?.type?.toLowerCase()) !== -1 && 
                   <span style={{position: 'relative',bottom: '25px',right: '5px'}}>
                    <Icon 
                       name="error" 
                       size="XLarge" 
                       color="#000000"
                   /></span>
                  }
                  {BLOCKED_CALL_TYPE.indexOf(data?.type?.toLowerCase()) !== -1 && 
                    <span style={{position: 'relative',bottom: '25px',right: '5px'}}>
                      <Icon 
                       name="call-disconnected" 
                       size="XLarge" 
                       color="#000000"
                      />
                    </span> }                  
                  {!data.type &&  <span style={{position: 'relative',bottom: '25px',right: '5px'}}>
                    <Icon 
                        name="my-account" 
                        size="XLarge" 
                        color="#000000"
                   /> 
                   </span>}
                  <SpamCard>
                    <SpamMDN>
                      {data.date}

                    </SpamMDN>
                    <SpamDetails>{data.time}</SpamDetails>
                  </SpamCard>
                </div>
                <HeadingBar>
                  <HorizontalBar marginTop="1.5rem " width="4px" />
                </HeadingBar>
                <ReportDetails>
                  <Phone>Phone</Phone>
                  <PhoneMDN>{data.formattedMTN}</PhoneMDN>
                </ReportDetails>
                <HeadingBar>
                  <HorizontalBar margin="1.5rem 0" width="1px" />
                </HeadingBar>
                <Phone style={{ marginBottom: '25px' }}>Report caller</Phone>
              </div>
            )}
          
          <SelectWrapper id="spamCategoryList">
          {pageReportContent &&
            <DropdownSelect
            data-testid="selectedSpamCategory"
            id="selectedSpamCategory"
            errorText="Select a category"
            required={true}
            placeholder="Select a category"
            label={pageReportContent && spamHeading.itemValue}
            name={pageReportContent && spamHeading.itemValue}
            onChange={(e) => handleChangeSelect(e)}
            value={selectedCategoryType}
            data-track={`{"type":"menu","cat":"Search","head":"Call type","name": "${selectedCategoryType}"}`}
          >
              <option value="" disabled selected>Select a category</option>
              {callTypeOptions.map((item, index) => <option key={index} value={item.value}>{item.label}</option>)}
              {/* {pageReportContent?.data?.spamCategoryList?.map((item, index) => <option key={index} value={item.value}>{item.label}</option>)} */}
            </DropdownSelect>
            }
          </SelectWrapper>
          <PIntro style={{ marginBottom: '1.5rem', fontWeight: 700 }}>
          {pageReportContent && commentHeading?.itemValue}
          </PIntro>
          <PIntro style={{ marginBottom: '0.9rem', fontWeight: 700 }}>
            {pageReportContent && comment.itemValue}
          </PIntro>
          <SubHeader style={{ marginBottom: '0.9rem' }}>
            {pageReportContent && comment_desc?.itemValue}
          </SubHeader>
          <PIntro style={{ marginBottom: '0.4rem', fontSize: '0.9rem', color: '#747676' }}>
            Comment
          </PIntro>
          <TextArea
            name="comments"
            rows={getDeviceType() === 'mobile' ? '8' : '10'}
            cols={getDeviceType() === 'mobile' ? '35' : '50'}
            maxLength={200}
            id="comments"
            ref={aceEditorRef}
            autoFocus={false}
            value={requestPayload.comment}
            onChange={changeComment}
            data-track
            />  
         
          {data && <SubHeader>{pageReportContent &&  subHeading.itemValue}</SubHeader>}
          <FooterBar>
            <HorizontalBar margin="1.5rem 0" width="2px" />
          </FooterBar>

          <Footer>
            <ButtonWrapper>


              <Button className="mobile-button-width" disabled={isDisabledReportBtn || isShowMdnError} analyticstrack="call_filter_report__button" id="mdl_new_access_list_sav" use="primary" onClick={onSaveReport} data-track='{"type":"link","name":"Call Filter Report Button"}'>Report</Button>

            </ButtonWrapper>
            <ButtonWrapper>
              <Button className="mobile-button-width" onClick={onResetChanges} analyticstrack="new_access_list_cancel_button" id="mdl_new_access_list_cancel" use="secondary" data-track='{"type":"link","name":"Call Filter Report Cancel Button"}'>Cancel</Button>

            </ButtonWrapper>
          </Footer>
        </Container>
      </div>
);
return (
  <>
    {errorData && (
  <BaseComponent
    errorData={errorData}
    isFetching={isFetching}
    sectionContentMetaData={sectionData}
    pageType="Report a  Number"
    data={callTreatmentReportResponse}
    pageEvent="event117"
  >
    {renderComponent()}
  </BaseComponent>
  )}
  </>
);
}

export default CallFilterReportNumber; 

const BannerContainer = styled.div`
  height: 5rem;
`;

const Container = styled.div`
  margin-bottom: 6rem;
  margin-left: 0.75rem;
`;

const HeadingBar = styled.div`
  width: 70%;
  @media(max-width: 480px) { 
    width: 100%;
  }
`;

const FooterBar = styled.div`
  width: 70%;
  @media(max-width: 480px) { 
    width: 100%;
  }
`;

const ButtonWrapper = styled.div`
  margin-right: 1rem;
  margin-bottom: 3rem;
  @media(max-width: 480px) { 
    width: 150px;
    margin-bottom: 1rem;
  }
`;

const Left = styled.div`
font-weight: normal;
//font-family: NHaasGroteskDSStd-55Rg;
font-size: 14px;
color: #000;
width: 60%;
@media(max-width: 480px) {   
font-weight: normal;
width: 90%;
  }
`;

const SubHeader = styled.div`
  margin-bottom: 1.6rem;
  font-family: "BrandFont-Text", Arial, Helvetica, sans-serif;
  font-size: 1rem;
  line-height: 1rem;
  @media(max-width: 480px) { 
    margin-bottom: 0.75rem;
    font-size: 12px;
    width: 90%;
    }
`;

const Group = styled.div`
  margin-top: 1rem!important;
  margin-bottom: 2.5rem!important;
  width: 500px;
  @media(max-width: 480px) { 
    margin-left: 0;
    width: 300px;
  }
`;

const SelectWrapper = styled.section`
  width: 500px;
  margin-bottom: 2.5rem;
  @media(max-width: 480px) {    
    width: 300px;     
    }
`;

const TextArea = styled.textarea`
  width: 500px;
  margin-bottom: 2.5rem;
  resize: none;
  @media(max-width: 480px) {    
    width: 300px;     
    }
`;

const PIntro = styled.div`
font-family: "BrandFont-Text", Arial, Helvetica, sans-serif;
  font-size: 1rem;
  line-height: 1rem;
  font-weight: normal;
  font-style: normal;
  font-stretch: normal;
  letter-spacing: normal;
  display: ${(props) => (props.hide ? 'none' : 'block')};
  @media(max-width: 480px) { 
    font-size: 12px;     
  } 
`;

const Footer = styled.div`
  display:flex;
  justify-content: flex-start;
  height: 3rem;
  margin-top: 3.5rem;
`;

const Header = styled.h1`   
  font-size: 28px;
  //font-family: NHaasGroteskDSStd-75Bd;
  line-height: 0.95;
  color: #000000;
  font-weight: normal;
  font-style: normal;
  font-stretch: normal;
  -webkit-letter-spacing: normal;
  -moz-letter-spacing: normal;
  -ms-letter-spacing: normal;
  letter-spacing: normal;
  color: #000000;
  display: block;
  @media(max-width: 480px) { 
    height: auto;
    font-size: 20px;
    width: 100%;
  }
`;

const SpamCard = styled.div`
text-align:left;
width:45%;
font-weight: normal;
margin-top: 25px;
display: inline-block;
@media(max-width: 480px) { 
width: 82%;
display: inline-block;
}
`;

const SpamMDN = styled.div`
font-size: 20px;
color: #000000;
font-weight: bold;
font-style: normal;
font-stretch: normal;
font-family: Neue Haas Grotesk Display Std;
margin-bottom: 6px;
`;

const SpamDetails = styled.div`
font-family: "BrandFont-Text", Arial, Helvetica, sans-serif;
  font-size: 1rem;
  line-height: 1rem;
  font-weight: normal;
  font-style: normal;
  font-stretch: normal;
  letter-spacing: normal;
  margin-bottom: 10px;
  margin-top: 13px;
  display:flex;
  @media(max-width: 480px) { 
  font-size: 12px;     
} 
  
`;

const ReportDetails = styled.div`
margin-top : -22px;
`;


const Phone = styled.div`
font-size: 15px;
color: #000000;
font-weight: bold;
font-style: normal;
font-stretch: normal;
font-family: Neue Haas Grotesk Display Std;
margin-bottom: 6px;
margin-top : -22px;
`;

const PhoneMDN = styled.div`
font-family: "BrandFont-Text", Arial, Helvetica, sans-serif;
  font-size: 0.9rem;
  line-height: 1rem;
  font-weight: normal;
  font-style: normal;
  font-stretch: normal;
  letter-spacing: normal;
  margin-top: -6px;
  display:flex;
  @media(max-width: 480px) { 
    font-size: 12px;     
  }
`;

const ChevronRight = styled.div`
  padding-right: 1rem;
  cursor: pointer;
  position: absolute;
  left: 1rem;
  &::before {
    border-style: solid;
    border-width: 0.15em 0.15em 0 0;
    content: '';
    display: inline-block;
    height: 0.5em;
    left: 0;
    position: relative;
    top: 0.2em;
    transform: rotate(215deg);
    vertical-align: top;
    width: 0.5em;
  }
  &:focus {
    outline: 1px dashed #333;
    outline-offset: 5px;
  }
`;
