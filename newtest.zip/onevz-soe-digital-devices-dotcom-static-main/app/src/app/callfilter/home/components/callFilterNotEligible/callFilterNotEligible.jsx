import React, {  useState } from "react";
import styled from "styled-components";
import { Button } from "@vds/buttons";
import BaseComponent from "../../../../../shared/components/BaseComponent";
import { useSelector } from "react-redux";
import common from "../../../../../shared/utilities/util";
import { handleClick } from "../../../../../shared/utilities/click";
import { getAnyApiResponseError } from "../../../../../shared/utilities/apiActions";

const CallFilterNotEligible = (props) => {


  const [hideBanner, setHideBanner] = useState(false);

  if (window.vzdl && window.vzdl.page) {
    window.vzdl.page.name = "not-eligible";
  }

  const { callTreatment: callFilterSettingResponse } = useSelector((state) => state || {} );

  const settingContent = common.getContentFromSection(
    callFilterSettingResponse ?. response ?. body ?. sections[0],
    'devicesCFSettingSection'
  );
  
  const errorData = getAnyApiResponseError(callFilterSettingResponse.response);
  const sectionData = settingContent && settingContent.data;

  const actionsData = settingContent && settingContent.contents && settingContent.contents.length > 0 && settingContent.actions;
  const isFetching = callFilterSettingResponse.isFetching;
  
  const mainSectionItems =
  settingContent &&
  settingContent.contents &&
  settingContent.contents.length > 0 &&
  settingContent.contents[0].items;

  const errorBanner = common.getItem(mainSectionItems, "notEligible_errorBanner");
  const description = common.getItem(mainSectionItems, "notEligible_description");
  const backBtn = common.getItem(mainSectionItems, "backBtn");
  const addOnBtn = common.getItem(mainSectionItems, "addOnBtn");


  const closeBanner = () => {
    setHideBanner(true);
  };


  const renderComponent = () => (
    <Banner>
      <div id="call-filter-not-eligible" data-testid="notEligible">
        {!hideBanner && (
          <BannerContainer>
            <BannerMsg>
              <MessageContainer>
                <Message>{settingContent && errorBanner.itemValue}</Message>
                <CloseButton
                  aria-label="close"
                  analyticstrack="close_button"
                  data-track="close button"
                  id="closeButton"
                  onClick={() => closeBanner()}
                >
                  <ImgSpan>&#x2573;</ImgSpan>
                </CloseButton>
              </MessageContainer>
            </BannerMsg>
          </BannerContainer>
        )}
        <ContentContainer>
          {settingContent && description.itemValue}
        </ContentContainer>
        <ButtonWrapper>
          <Button
            analyticstrack="visit_addons_button"
            className="visit_addons_button"
            use="primary"
            onClick={(event) => {event.preventDefault(); handleClick(addOnBtn.actionKey, actionsData, addOnBtn)}}
            data-track='{ "type": "link", "name": "visit addons button" }'
          >
            {settingContent && addOnBtn.itemValue}
          </Button>
          <Button
            analyticstrack="goback_button"
            className="goback_button"
            use="secondary"
            onClick={(event) => {event.preventDefault(); handleClick(backBtn.actionKey, actionsData, backBtn)}}
            data-track='{ "type": "link", "name": "go back button" }'
          >
            {settingContent && backBtn.itemValue}
          </Button>
        </ButtonWrapper>
      </div>
    </Banner>
  );

  return (
    <BaseComponent
      errorData={errorData}
      isFetching={isFetching}
      sectionContentMetaData={sectionData}
      pageType="Not Eligible"
      data={callFilterSettingResponse}
      pageEvent="event117"
    >
      {renderComponent()}
    </BaseComponent>
  );
};

export default CallFilterNotEligible;

const BannerContainer = styled.div`
  height: 3rem;
`;
const BannerMsg = styled.div`
  background-color: #ed7000;
  min-height: 3.5rem;
  color: #ffffff;
  //font-family: NHaasGroteskDSStd-75Bd;
  font-size: 1rem;
  font-weight: normal;
  font-style: normal;
  font-stretch: normal;
  display: flex;
`;

const MessageContainer = styled.div`
  width: 98%;
`;

const Message = styled.div`
  margin-top: 1rem;
  display: flex;
  flex-direction: column;
  justify-content: space-around;
  padding-left: 0.6rem;
`;

const CloseButton = styled.div`
  margin-top: -1.3rem;
  float: right;
  cursor: pointer;
`;

const ImgSpan = styled.span`
  margin-top: 1px;
`;

const ContentContainer = styled.div`
margin-bottom: 6rem;
        margin-top: 3rem;
        width: 45%;
        font-size: 20px;
        @media(max-width: 480px) { 
        width:90%;
`;

const ButtonWrapper = styled.div`
margin-bottom: 3rem;
display:flex;
  .visit_addons_button {
    margin-right:20px;
          margin-right: 1rem
          @media(max-width: 480px) { 
          width:100% !important;
      }
  .goback_button {   
    @media (max-width: 480px) {
      margin-top: 1rem;
      width: 100% !important;
    }
  }
`;

const Banner = styled.div``;
