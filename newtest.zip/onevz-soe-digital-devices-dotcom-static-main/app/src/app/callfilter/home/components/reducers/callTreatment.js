import {
  FETCH_CALL_TREATMENT_BEGIN,
  FETCH_CALL_TREATMENT_SUCCESS,
  FETCH_CALL_TREATMENT_FAIL,
  FETCH_SPAM_CALL_FILTER_BEGIN,
  FETCH_SPAM_CALL_FILTER_SUCCESS,
  FETCH_SPAM_CALL_FILTER_FAIL,
  SAVE_CALL_TREATMENT_BEGIN,
  SAVE_CALL_TREATMENT_SUCCESS,
  SAVE_CALL_TREATMENT_ERROR,
  SAVE_REPORT_BEGIN,
  SAVE_REPORT_SUCCESS,
  SAVE_REPORT_ERROR,
  FETCH_REPORT_CALL_FILTER_SUCCESS,
  FETCH_REPORT_CALL_FILTER_FAIL,
  FETCH_CONFIRMATION_CALL_FILTER_SUCCESS,
  FETCH_CONFIRMATION_CALL_FILTER_FAIL,
} from '../actions';

import { updateObject } from '../../../../utils/reducer';

const initialstate = {
  callTreatment: [],
  spamCallFilter: [],
  isFetching: false,
  successMessage: '',
  errorMessage: '',
  reportErrorMessage: '',
  isSuccess: false,
};

const fetchCallTreatmentBegin = (state, action) => {
  return updateObject(state, {
    isFetching: true,
    errorMessage: '',
    successMessage: action.isShowSuccessMessage ? state.successMessage : '',
    reportErrorMessage: '',
    isSuccess: false,
    isRedirectToConfiramtionPage: false,
  });
};

const fetchSpamCallFilterBegin = (state, action) => updateObject(state, {
  isFetching: true,
  errorMessage: '',
  successMessage: action.isShowSuccessMessage ? state.successMessage : '',
  reportErrorMessage: '',
  isSuccess: false,
  isRedirectToConfiramtionPage: false,
});

const saveCallTreatmentBegin = (state, action) => updateObject(state, {
  isFetching: true,
  errorMessage: '',
  successMessage: '',
  reportErrorMessage: '',
});

const saveCallTreatmentSuccess = (state, action) => {
  console.log(action,"saveAction")
  let successText = !action.selectedToggleOption ? "You've updated your Call Filter settings." : action.selectedToggleOption.value ? "You've turned call filter on." : "You've turned call filter off.";
 if (vztag && vztag.api) {
    vztag.api.dispatch('notify', {
      name: 'call filter settings success',
      message: successText,
    });
  }

  return updateObject(state, {
    isFetching: false,
    errorMessage: '',
    successMessage: successText,    
    reportErrorMessage: '',
    isSuccess: true,
    response: action.response
  });
};
const saveCallTreatmentError = (state, action) => updateObject(state, {
  isFetching: false,
  errorMessage: action.error,
  successMessage: '',
  reportErrorMessage: '',
  isSuccess: false,
});

const saveReportBegin = (state, action) => updateObject(state, {
  isFetching: true,
  errorMessage: '',
  successMessage: '',
  reportErrorMessage: '',
  isRedirectToConfiramtionPage: false,
});

const saveReportSuccess = (state, action) => updateObject(state, {
  isFetching: false,
  reportErrorMessage: '',
  successMessage: '',
  errorMessage: '',
  isRedirectToConfiramtionPage: true,
  confirmationResponse: action.response,
});

const saveReportError = (state, action) => updateObject(state, {
  isFetching: false,
  reportErrorMessage: action.error,
  successMessage: '',
  errorMessage: '',
  confirmationResponse: action.error,
});

const fetchReportCallFilterBegin = (state, action) => updateObject(state, {
  isFetching: true,
  errorMessage: '',
  successMessage: action.isShowSuccessMessage ? state.successMessage : '',
  reportErrorMessage: '',
  isSuccess: false,
  isRedirectToConfiramtionPage: false,
});

const callTreatmentReducer = (state = initialstate, action) => {
  const { type } = action;
  switch (type) {
    case FETCH_CALL_TREATMENT_BEGIN:
      return fetchCallTreatmentBegin(state, action);
    case FETCH_CALL_TREATMENT_SUCCESS:
    {
      return {
        ...state,
        isFetching: false,
        response: action.response,
        eligibleMtnInd: action.eligibleMtnInd,
      };
    }
    case FETCH_CALL_TREATMENT_FAIL:
    {
      return {
        ...state,
        isFetching: false,
        errorMessage: reactGlobals.errorMessage,
        response: action.error,
        eligibleMtnInd: action.eligibleMtnInd,
      };
    }

    case FETCH_SPAM_CALL_FILTER_BEGIN:
      return fetchSpamCallFilterBegin(state, action);
    case FETCH_SPAM_CALL_FILTER_SUCCESS: {
      {
        return {
          ...state,
          isFetching: false,
          spamResponse: action.response,
          errorMessage: '',
        };
      }
    }
    case FETCH_SPAM_CALL_FILTER_FAIL:
    {
      return {
        ...state,
        isFetching: false,
        errorMessage: reactGlobals.errorMessage,
      };
    }
    case FETCH_REPORT_CALL_FILTER_SUCCESS: {
      {
        return {
          ...state,
          isFetching: false,
          reportResponse: action.response,
          errorMessage: '',
        };
      }
    }
    case FETCH_REPORT_CALL_FILTER_FAIL:
    {
      return {
        ...state,
        isFetching: false,
        reportResponse: action.error,
        errorMessage: reactGlobals.errorMessage,
      };
    }
    case FETCH_CONFIRMATION_CALL_FILTER_SUCCESS: {
      {
        return {
          ...state,
          isFetching: false,
          confirmationResponse: action.response,
          errorMessage: '',
        };
      }
    }
    case FETCH_CONFIRMATION_CALL_FILTER_FAIL:
    {
      return {
        ...state,
        isFetching: false,
        confirmationResponse: action.error,
        errorMessage: reactGlobals.errorMessage,
      };
    }
    case SAVE_CALL_TREATMENT_BEGIN:
      return saveCallTreatmentBegin(state, action);
    case SAVE_CALL_TREATMENT_SUCCESS:
      return saveCallTreatmentSuccess(state, action);
    case SAVE_CALL_TREATMENT_ERROR:
      return saveCallTreatmentError(state, action);
    case SAVE_REPORT_BEGIN:{
      return {
        ...state,
        isFetching: true,
        errorMessage: '',
        successMessage: '',
        reportErrorMessage: '',
        isRedirectToConfiramtionPage: false,
      }
    }
    case SAVE_REPORT_SUCCESS:{
      return {
         ...state,
         isFetching: false,
          reportErrorMessage: '',
          successMessage: '',
          errorMessage: '',
          isRedirectToConfiramtionPage: true,
          confirmationResponse: action.response,
      }
    }
    case SAVE_REPORT_ERROR:{
      return {
        ...state,
        isFetching: false,
        reportErrorMessage: action.error,
        successMessage: '',
        errorMessage: '',
        confirmationResponse: action.error,
      }
    }
    default:
      return state;
  }
};
export default callTreatmentReducer;
