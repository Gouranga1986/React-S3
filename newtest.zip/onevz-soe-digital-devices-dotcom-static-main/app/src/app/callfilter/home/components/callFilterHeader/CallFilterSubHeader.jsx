import React from 'react';
import styled from 'styled-components';

const CallFilterSubHeader = (props)=>{
  return (
    <Container>
      {props.hideH2Tag
        ? (
          <Div>
            {props.header}
          </Div>
        )
        : (
          <Header>
            {props.header}
          </Header>
        )
     }
    </Container>
  );
}
const Container = styled.div`
  max-width: 79.5rem;
  margin: 0;
  //margin-top: 2rem;
  padding: 0;
  //margin-bottom: 2rem; 
  @media(max-width: 480px) { 
  margin-top: 1rem;
  margin-bottom: 1rem;   
}
 
`;

const Header = styled.h2`   
  font-size: 24px;
  //font-family: NHaasGroteskDSStd-75Bd;
  line-height: 0.95;
  color: #000000;
  font-weight: bold;
  font-style: normal;
  font-stretch: normal;
  -webkit-letter-spacing: normal;
  -moz-letter-spacing: normal;
  -ms-letter-spacing: normal;
  letter-spacing: normal;
  color: #000000;
  display: block;
  @media(max-width: 480px) { 
  height: auto;
  font-size: 16px;
  width: 75%;
}
`;

const Div = styled.div`   
  font-size: 24px;
  //font-family: NHaasGroteskDSStd-75Bd;
  line-height: 0.95;
  color: #000000;
  font-weight: bold;
  font-style: normal;
  font-stretch: normal;
  -webkit-letter-spacing: normal;
  -moz-letter-spacing: normal;
  -ms-letter-spacing: normal;
  letter-spacing: normal;
  color: #000000;
  display: block;
  @media(max-width: 480px) { 
    height: auto;
    font-size: 16px;
    width: 75%;
  }
 
`;

export default CallFilterSubHeader;
