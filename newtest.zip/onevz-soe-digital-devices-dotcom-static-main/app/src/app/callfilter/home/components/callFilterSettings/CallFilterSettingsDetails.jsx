import React from 'react';
import styled from 'styled-components';

import { RadioButtonGroup, RadioButton } from '@vds/radio-buttons';
import HorizontalBar from '../horizontalBar/HorizontalBar';
import CallFilterSubHeader from '../callFilterHeader/CallFilterSubHeader';

import { Body } from '@vds/typography';
import { useSelector } from 'react-redux';

const ContainerForRadioStyles = styled.div`
[role="radiogroup"]{
padding-left:0px !important;
}
 label{
 margin-left:20px !important;
 }
label div:first-child {
left:4px !important;
 }
`;
const CallFilterSettingsDetails = (props)=>{

  const hyperLinkRequired = useSelector((state) =>
     state.callTreatment?.response?.body?.sections?.[0]?.sections?.[0]?.data?.notification?.hyperLinkRequired  );
   const label = useSelector((state) =>
    state.callTreatment?.response?.body?.sections?.[0]?.sections?.[0]?.data?.notification?.label  );  

   const LinkURL =useSelector((state) =>
    state.callTreatment?.response?.body?.sections?.[0]?.sections?.[0]?.data?.notification?.linkUrl  );

     

  const changeCriteriaList = (e) => {
    props.handleSaveChanges({ 
      name: 'criteria',
      value: e.target.value,
    });
  }

  const changeActionList = (e) => {
    props.handleSaveChanges({
      name: 'action',
      value: e.target.value,
    });
  }


  return (
    <Container>
      <HorizontalBar margin="1.5rem 0" width="4px" />
      <CallFilterSubHeader header="Choose the calls to auto-block" />
      <HorizontalBar margin="1.5rem 0" width="2px" color="rgb(217,217,217)" />
      <ContainerForRadioStyles>
      <RadioButtonGroup
        defaultValue={props.defaultCriteriaValue}
        onChange={changeCriteriaList}
        data={props.criteriaList?.map((cList, index) => (
          {
            name: 'group1',
            label: cList.header,
            children: cList.label,
            value: cList.criteria,
            ariaLabel: cList.header,
            disabled: false
          }
        ))}
      >
        {/* {props.criteriaList?.map((cList, index) => (
          <>
            <RadioButton
            name={cList.header}
            className="horizontal-bar"
            value={cList.criteria}
            ariaLabel={cList.header}
            key={index}
            analyticstrack={cList.header}
            data-track={cList.header}
          >
            <CallFilterSubHeader header={cList.header} hideH2Tag="true" />
            <Span>{cList.label}</Span>
          </RadioButton>
          <HorizontalBar margin="0" width="1px" color="rgb(217,217,217)" />
          </>
        ))} */}
      </RadioButtonGroup>
      <Span>&nbsp;</Span>
      </ContainerForRadioStyles>
      <CallFilterSubHeader header="Send blocked calls to:" />
      <HorizontalBar margin="1.5rem 0" width="2px" color="rgb(217,217,217)" />
      <ContainerForRadioStyles>
      <RadioButtonGroup
        defaultValue={props.defaultActionValue}
        onChange={changeActionList}
        data={props.actionList?.map((aList, index) => (
          {
            name: 'group2',
            label: aList.header,
            children: aList.label,
            value: aList.action,
            ariaLabel: aList.header,
            disabled: false
          }
        ))}
      >
        {/* {props.actionList?.map((aList, index) => (
          <>
          <RadioButton
            name={aList.header}
            className="horizontal-bar"
            value={aList.action}
            ariaLabel={aList.header}
            key={index}
            analyticstrack={aList.header}
            data-track={aList.header}
          >
            <CallFilterSubHeader header={aList.header} hideH2Tag="true" />
            <Span>{aList.label}</Span>
          </RadioButton>
          <HorizontalBar margin="0" width="1px" color="rgb(217,217,217)" />
          </>
        ))} */}
      </RadioButtonGroup>
      </ContainerForRadioStyles>
      {((!props.nonAppCapableInd || props.nonAppCapableInd === 'N') && props.notification) ? (
        <>
        <Span>&nbsp;</Span>
          <CallFilterSubHeader header={props.notification?.header} />
          <HorizontalBar margin="1.5rem 0" width="2px" color="rgb(217,217,217)" />
           <Body>
    {label}
    {hyperLinkRequired ?
    
   <ALink analyticstrack="call_filter_terms_condition_link" href={LinkURL} data-track='{"type": "link", "name": "call filter notification url"}'>
       {" Call Filter app."}
     </ALink> :
    <span>{" Call Filter app. Compatible device required."}</span>}
    </Body> 
          <HorizontalBar margin="1.5rem 0" width="2px" color="rgb(217,217,217)" />
        </>
      ) : null }
    </Container>
  );

}
export default CallFilterSettingsDetails;

const Container = styled.div`
  width: 65%;
  @media(max-width: 768px) {       
    width: 75%;
  }
  @media(max-width: 480px) {      
    font-size: 10px;
    width: 100%;
  }
    .radioWrapper {
    padding-bottom: 16px;
    border-bottom: 3px solid rgb(217,217,217);
    width: 90%;
  }
 `;

const Span = styled.div`
  max-height: 150px;
  font-size: 16px;
  font-weight: normal;
  font-style: normal;
  font-stretch: normal;
  margin-top: 0.7rem !important;
  margin-bottom: 1.5rem !important;
  line-height: 1.2;
  letter-spacing: normal;
  color: ${(props) => (props.color ? props.color : '#000000')};
  @media(max-width: 480px) {      
    font-size: 12px;
    width: 100%;
}
 `;

const ALink = styled.a.attrs({
  analyticstrack: (props) => props.analyticstrack,
})`
  height: 16.8px;
  //font-family: NHaasGroteskDSStd-55Rg;
  font-size: 20px;
  font-weight: normal;
  font-style: normal;
  font-stretch: normal;
  line-height: 1.2;
  letter-spacing: normal;
  color: #000000;
  padding-left: 5px;
  text-decoration: underline;
  @media(max-width: 480px) { 
  font-size: 14px;
}
`;
