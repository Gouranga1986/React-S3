import React from 'react';
import styled from 'styled-components';

const CallFilterHeader =(props)=>{
  return (
    <Container>
      <Header>
        {props.header}
      </Header>
    </Container>
  );
}

const Container = styled.div`
  max-width: 79.5rem;
  margin: 0;
  margin-top: 2rem;
  padding: 0;
  margin-bottom: 2rem; 
  @media(max-width: 480px) { 
  margin-top: 1rem;
  margin-bottom: 1rem;   
}
 
`;

const Header = styled.h1`   
  font-size: 24px;
  //font-family: NHaasGroteskDSStd-75Bd;
  line-height: 0.95;
  color: #000000;
  // font-weight: normal;
  font-style: normal;
  font-stretch: normal;
  -webkit-letter-spacing: normal;
  -moz-letter-spacing: normal;
  -ms-letter-spacing: normal;
  letter-spacing: normal;
  color: #000000;
  display: block;
  @media(max-width: 480px) { 
    height: auto;
    font-size: 16px;
    width: 75%;
  }
 
`;

export default CallFilterHeader;
