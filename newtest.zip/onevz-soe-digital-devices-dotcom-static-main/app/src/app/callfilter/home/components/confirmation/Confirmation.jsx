import React, {useEffect } from 'react';
import styled from 'styled-components';
import { Button } from '@vds/buttons';
import { Body,Title } from '@vds/typography';
import BaseComponent from '../../../../../shared/components/BaseComponent';
import { useDispatch, useSelector } from 'react-redux';
import { useHistory } from 'react-router-dom';
// import { fetchConfirmationCallFilter } from '../actions/reportCallFilter';
import common from '../../../../../shared/utilities/util';
import { getAnyApiResponseError } from '../../../../../shared/utilities/apiActions';

const Confirmation =(props) =>{
  console.log("renderd initailaly");
  const dispatch = useDispatch();
  const history = useHistory();

  // useEffect(() => {
  //   //window.scrollTo(0, 0);    
  //   // fetchConfirmationCallFilter(dispatch);
  // },[]);


  const { callTreatment: callTreatmentReportResponse } = useSelector(
    (state) => state || {}
  );
  
  
  const pageRCContent = callTreatmentReportResponse.confirmationResponse && common.getContentFromSection(
    callTreatmentReportResponse?.confirmationResponse?.body?.sections[0],
    'deviceCFReportConfirmationSection'
  );

  const isFetching = callTreatmentReportResponse.isFetching;
  //const errorData = getAnyApiResponseError(callTreatmentConfirmationResponse);

   const errorData =
   callTreatmentReportResponse.confirmationResponse &&
   getAnyApiResponseError(callTreatmentReportResponse.confirmationResponse);
  console.log("data prest",errorData);

  const sectionData = pageRCContent && pageRCContent.data;
   
  const mainSectionItems = pageRCContent && pageRCContent.contents && pageRCContent.contents.length > 0 && pageRCContent.contents[0].items;

  const title = common.getItem(mainSectionItems, 'title');
  const description = common.getItem(mainSectionItems, 'description');
  const backBtn = common.getItem(mainSectionItems, 'backBtn');

  const  goBacktoLandingPage = () => {
    history.push('/');
  }
  
  const renderComponent = () => {
   console.log("check the render component")
   return(
    <Container data-testid="Confirmation">
      <Title size="large" bold={true} color="#000000">{pageRCContent && title.itemValue} </Title>
      <div style={{marginTop:"15px"}}>
        <Body size="large">          
        {pageRCContent && description.itemValue} 
        </Body>
      </div>
        <ButtonWrapper>
          <Button use="primary" onClick={goBacktoLandingPage} data-track='{ "type": "link", "name": "back_call_filter__button" }'>{pageRCContent && backBtn.itemValue} </Button>
        </ButtonWrapper>
      </Container>
     
  )
  }

  return (
    <>
      {errorData && (
    <BaseComponent
      errorData={errorData}
      isFetching={isFetching}
      sectionContentMetaData=''
      pageType="Report Confirmation"
      data={sectionData}
      pageEvent="event117"
    >
      {renderComponent()}
    </BaseComponent>
    )}
    </>
  );
}
export default Confirmation;


const Container = styled.div`
  width: 54%;
  margin-top: 2rem;
  margin-bottom: 5rem;
  margin-left: 1.5rem;
`;

/*/const Body = styled.div`
  margin-top: 1.5rem;
`;*/

const ButtonWrapper = styled.div`
  margin-right: 1rem;
  // margin-bottom: 3rem;
  margin-top: 5rem;
  @media(max-width: 480px) {  
    width: 100%;
    // margin-bottom: 1rem;
  }
`;

const ALink = styled.a.attrs({
  analyticstrack: (props) => props.analyticstrack,
})`
  width: 100%;
  font-weight: normal;
  font-style: normal;
  font-stretch: normal; 
  letter-spacing: normal;
  color: #000000;
  //font-family: NHaasGroteskDSStd-55Rg;
  text-decoration: underline
  font-size: 20px;
  cursor: pointer;
  text-align: left;
  margin-bottom: 1rem;
  margin-top: 1rem;
  float: left;
  @media(max-width: 480px) {  
    display:inline-block;
    font-size: 16px;
    margin-top: 0;
    margin-bottom: 1rem;
    width: auto;
    text-align: left;
  }
`;
