import { getHttpClientRequest } from '@vz/react-util';
import apiUrl from '../../../../../shared/utilities/apiUrl';

export const FETCH_CALL_TREATMENT_BEGIN = 'callTreatment/FETCH_CALL_TREATMENT_BEGIN';
export const FETCH_CALL_TREATMENT_SUCCESS = 'callTreatment/FETCH_CALL_TREATMENT_SUCCESS';
export const FETCH_CALL_TREATMENT_FAIL = 'callTreatment/FETCH_CALL_TREATMENT_FAIL';

export const fetchCallTreatment = (dispatch, isShowSuccessMessage) => {
  const onError = (error) => {
    dispatch(fetchCallTreatmentError(error));
  };
   dispatch(fetchCallTreatmentBegin(isShowSuccessMessage))
  getHttpClientRequest(apiUrl().callFilterSettingsApiUrl).then((response) => {
    if (response.data && response.data.responseInfo.responseCode == '00') {
      dispatch(fetchCallTreatmentSuccess(response));
    } else {
      dispatch(fetchCallTreatmentError(response));
    }
  })
    .catch(onError);
};

export const fetchCallTreatmentBegin = (isShowSuccessMessage) => ({
  type: FETCH_CALL_TREATMENT_BEGIN,
  isShowSuccessMessage,
});
export const fetchCallTreatmentSuccess = (response) => ({
  type: FETCH_CALL_TREATMENT_SUCCESS,
  //response: response.data.body.sections[0],
  response: response.data,
  eligibleMtnInd: response.data.body.sections[0].sections[0].data.eligibleMtnInd,
});
export const fetchCallTreatmentError = (response) => ({
  type: FETCH_CALL_TREATMENT_FAIL,
  // error: response.data.body.sections[0],
  // eligibleMtnInd: response.data.body.sections[0].sections[0].data.eligibleMtnInd,
  error: response.data,
  eligibleMtnInd: response.data,
});
