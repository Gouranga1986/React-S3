import { getHttpClientRequest, postHttpClientRequest } from '@vz/react-util';

import apiUrl from '../../../../../shared/utilities/apiUrl';
export const FETCH_SPAM_CALL_FILTER_BEGIN = 'callTreatment/FETCH_SPAM_CALL_FILTER_BEGIN';
export const FETCH_SPAM_CALL_FILTER_SUCCESS = 'callTreatment/FETCH_SPAM_CALL_FILTER_SUCCESS';
export const FETCH_SPAM_CALL_FILTER_FAIL = 'callTreatment/FETCH_SPAM_CALL_FILTER_FAIL';


export const FETCH_REPORT_CALL_FILTER_SUCCESS = 'callTreatment/FETCH_REPORT_CALL_FILTER_SUCCESS';
export const FETCH_REPORT_CALL_FILTER_FAIL = 'callTreatment/FETCH_REPORT_CALL_FILTER_FAIL';

export const FETCH_CONFIRMATION_CALL_FILTER_SUCCESS = 'callTreatment/FETCH_CONFIRMATION_CALL_FILTER_SUCCESS';
export const FETCH_CONFIRMATION_CALL_FILTER_FAIL = 'callTreatment/FETCH_CONFIRMATION_CALL_FILTER_FAIL';

const onError = (error) => {
  dispatch(fetchSpamCallFilterError(error));
};

export const fetchSpamCallFilter = (payload) => async (dispatch) => {
  const httpMethod = window?.location?.hostname?.indexOf('localhost') > -1 ? 'get' : 'post';
  const callMS = () => {
    const axConfig = {
      headers: {
        pageName: 'Recents Spam',
        flowName: 'Recents Spam',
      },
    };
    if (httpMethod === 'get') {
      return getHttpClientRequest(
        apiUrl().callFilterLandingApiUrl,
        axConfig
      );
    }
    return postHttpClientRequest(
      apiUrl().callFilterLandingApiUrl,
      payload,
      axConfig
    );
  };

  callMS()
    .then((response) => {
      if (response.data && response.data.responseInfo.responseCode == '00') {
        /* response.data && response.data.body.sections[0].data && response.data.body.sections[0].data.detailsList.map((dList) => {
          if (dList.timeStamp) {
            const date = moment.utc(dList.timeStamp).local().format('M/D/YY hh:mm A');
            dList.localDate = date.split(' ')[0];
            dList.localTime = date.split(' ')[1] + ' ' + date.split(' ')[2];
            return dList;
          }
        }); */
        dispatch(fetchSpamCallFilterSuccess(response));
      } else {
        dispatch(fetchSpamCallFilterError(response));
      }
    }).catch(onError);
  /* catch((error) => {
      const data = {};
      data.errorMessage = reactGlobals.errorMessage;
      data.statusCode = 1;
      dispatch(fetchSpamCallFilterError(data));
    }); */
};


export const fetchReportCallFilter = (dispatch) => {
  // dispatch(fetchCallTreatmentBegin(true))
  getHttpClientRequest(apiUrl().callFilterReportApiUrl).then((response) => {
    if (response.data && response.data.responseInfo.responseCode == '00') {
      dispatch(fetchReportallFilterSuccess(response));
    } else {
      dispatch(fetchReportCallFilterError(response));
    }
  })
    .catch(onError);
};

export const fetchConfirmationCallFilter = (dispatch) => {
  // dispatch(fetchCallTreatmentBegin(true))
  getHttpClientRequest(apiUrl().callFilterReportConfirmationApiUrl).then((response) => {
    if (response.data && response.data.responseInfo.responseCode == '00') {
      dispatch(fetchConfirmationallFilterSuccess(response));
    } else {
      dispatch(fetchConfirmationCallFilterError(response));
    }
  })
    .catch(onError);
};


export const fetchSpamCallBegin = (isShowSuccessMessage) => ({
  type: FETCH_SPAM_CALL_FILTER_BEGIN,
  isShowSuccessMessage,
});
export const fetchSpamCallFilterSuccess = (response) => ({
  type: FETCH_SPAM_CALL_FILTER_SUCCESS,
  response: response.data.body.sections[0],
});
export const fetchSpamCallFilterError = (response) => ({
  type: FETCH_SPAM_CALL_FILTER_FAIL,
  error: response.data,
});

export const fetchReportallFilterSuccess = (response) => ({
  type: FETCH_REPORT_CALL_FILTER_SUCCESS,
  //response: response.data.body.sections[0],
  response: response.data,
});
export const fetchReportCallFilterError = (response) => ({
  type: FETCH_REPORT_CALL_FILTER_FAIL,
  error: response.data,
});

export const fetchConfirmationallFilterSuccess = (response) => ({
  type: FETCH_CONFIRMATION_CALL_FILTER_SUCCESS,
  //response: response.data.body.sections[0],
  response: response.data,
});
export const fetchConfirmationCallFilterError = (response) => ({
  type: FETCH_CONFIRMATION_CALL_FILTER_FAIL,
  error: response.data,
});
