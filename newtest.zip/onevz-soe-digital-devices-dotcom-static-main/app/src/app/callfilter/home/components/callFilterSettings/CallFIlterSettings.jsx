import React, { useState, useEffect } from 'react';
import styled from 'styled-components';
import { useDispatch, useSelector } from 'react-redux';

import { Notification } from '@vds/notifications';
import { Button } from '@vds/buttons';
import CallFilterHeader from '../callFilterHeader/CallFilterHeader';
import HorizontalBar from '../horizontalBar/HorizontalBar';
import HeaderDetails from '../callFilterHeader/HeaderDetails';
import CallFilterSettingsDetails from './CallFilterSettingsDetails';

import { fetchCallTreatment, saveCallTreatment } from '../actions';
import common from '../../../../../shared/utilities/util';
import { handleClick } from '../../../../../shared/utilities/click';
import NewLoader from '../../../../../shared/components/Loader/NewLoader';

const CallFilterSettings = (props) => {
  const dispatch = useDispatch();

  const { callTreatment: callFilterSettingResponse} = useSelector((state) => state || {});
 const successMessage = useSelector((state)=> state.callTreatment.successMessage)

 //console.log("successMessage", successMessage)
 console.log("callfiltersettingsresponse", callFilterSettingResponse.successMessage)


 console.log(callFilterSettingResponse,"callfiltersettingsresponse", successMessage)
  const settingContent = common.getContentFromSection(
    callFilterSettingResponse ?. response ?. body ?. sections[0],
    'devicesCFSettingSection'
  );
  //const sectionData = settingContent && settingContent.data;
  const [requestPayload, setIsRequestPayload] = useState({action:"",criteria:""});
  const id = location?.search?.split('&')[0] && location?.search?.split('&')[0].split('?id=')[1];
  const [isSuccessNotification, setIsSuccessNotification] = useState(false);
  const [isErrorNotification, setIsErrorNotification] = useState(false);

  if (window.vzdl && window.vzdl.page) {
    window.vzdl.page.name = 'landing';
  }

  const handleToggle = (isToggle) => {
    const callTreatment = {
      action: 'none',
      criteria: 'low',
    };
    let requestPayload = {};
    const selectedToggleOps = {
      value: isToggle,
    };
    if (isToggle) {
      callTreatment.criteria = 'high';
      callTreatment.action = 'voicemail';
    }

    requestPayload = {
      callTreatment,
      param1: id || '',
    };
    const selectedSaveOpt = {
      type: 'toggle',
      value: isToggle,
      
    }
    saveCallTreatment(dispatch, requestPayload, selectedToggleOps);
  };


  const handleSaveChanges = (callFilterObj) => {
    if(callFilterObj.name==="action"){
      setIsRequestPayload({...requestPayload,action:callFilterObj.value});
    }
    else if(callFilterObj.name==="criteria"){
      setIsRequestPayload({...requestPayload,criteria:callFilterObj.value});
    }
  };

  const saveChanges = () => {
    console.log("save changes trigerred")
    const payload = {
      callTreatment: requestPayload,
      param1: id || '',
    };

    if (!payload?.callTreatment?.criteria) {
      payload.callTreatment.criteria = settingContent.data?.callTreatment?.criteria;
    }

    if (!payload?.callTreatment?.action) {
      payload.callTreatment.action = settingContent.data?.callTreatment?.action;
    }
    // define save operation flag
    const selectedSaveOpt = {
      type: 'save',
      
    }

    saveCallTreatment(dispatch, payload);
  };

  useEffect(() => {
    // window.scrollTo(0, 0);
    if (id) {
      if (reactGlobals.callFilterSettingsApiUrl.indexOf('id=') === -1) {
        reactGlobals.encryptedMdn = id;
        reactGlobals.callFilterSettingsApiUrl = reactGlobals.callFilterSettingsApiUrl + '?id=' + id;
      }
    }
    console.log(callFilterSettingResponse,"callfiltersettingResponse123")
    if(callFilterSettingResponse?.successMessage && callFilterSettingResponse?.successMessage !== ''){
      fetchCallTreatment(dispatch,true);
    }
    else{
      fetchCallTreatment(dispatch);
    }
    
  }, []);

  useEffect(() => {
    if (props.isSuccess) {

      fetchCallTreatment(dispatch, true);
    }
  }, []);

  useEffect(() => {
  
    console.log(callFilterSettingResponse,"callFilterSettingResponse")
      if(callFilterSettingResponse.successMessage && callFilterSettingResponse.successMessage !== ''){
        setIsSuccessNotification(true);
        setIsErrorNotification(false);
      }
      else{
        setIsSuccessNotification(false); 
      }
      if(callFilterSettingResponse.errorMessage && callFilterSettingResponse.errorMessage !== ''){
        setIsErrorNotification(true);
        setIsSuccessNotification(false);
      }
      else{
        setIsErrorNotification(false); 
      }
    },[callFilterSettingResponse] );
 
 

  const { isFetching  } = props;


  const mainSectionItems = settingContent && settingContent.contents && settingContent.contents.length > 0 && settingContent.contents[0].items;

  const actionsData = settingContent && settingContent.contents && settingContent.contents.length > 0 && settingContent.actions;

  const header = common.getItem(mainSectionItems, 'header');
  const description = common.getItem(mainSectionItems, 'description');
  const linkDescription = common.getItem(mainSectionItems, 'linkDescription');
  const termsUrl = common.getItem(mainSectionItems, 'termsUrl');
  const privacyUrl = common.getItem(mainSectionItems, 'privacyUrl');
  const bannermsg_success = common.getItem(mainSectionItems, 'bannermsg_success');
  const bannermsg_failure = common.getItem(mainSectionItems, 'bannermsg_failure');
  
  
  console.log("message callfilter", callFilterSettingResponse.successMessage)
  return (
    <div id="call-filter-settings__tab" data-testid="callFilterSettings">
       {isSuccessNotification
         && <Notification type="success" title={ successMessage} fullBleed="true" />
        }
      {isErrorNotification
         && <Notification type="error" title={bannermsg_failure?.itemValue} fullBleed="true" />
          }

      {!isFetching && settingContent
          && (
          <Container>

            <CallFilterHeader header={settingContent && header.itemValue} />
            <HeadingBar>
              <HorizontalBar margin="1.5rem 0" width="4px" />
            </HeadingBar>
            <HeaderDetails
              isCallFilterTurnOn={settingContent.data.isCallFilterTurnOn}
              subHeader={description.itemValue.split('#')}
              linkDescription={linkDescription.itemValue}
              linkPrivacyUrl={settingContent.data.linkPrivacyUrl}
              linkTermsUrl={settingContent.data.linkTermsUrl}
              handleToggle={handleToggle}
            />

            <Termsdesc>
              {settingContent && linkDescription.itemValue}
              {' '}
              <TermsdescLink data-testid="termsURL"
                data-track={JSON.stringify({ type: 'link', name: termsUrl && termsUrl.itemValue })}
                onClick={(event) => { event.preventDefault(); handleClick(termsUrl.actionKey, actionsData, termsUrl); }}
              >
                {termsUrl && termsUrl.itemValue}
              </TermsdescLink>
              {' '}
              and
              {' '}
              <TermsdescLink data-testid="privacyURL"
                data-track={JSON.stringify({ type: 'link', name: privacyUrl && privacyUrl.itemValue })}
                onClick={(event) => { event.preventDefault(); handleClick(privacyUrl.actionKey, actionsData, privacyUrl); }}
              >
                {privacyUrl && privacyUrl.itemValue}
              </TermsdescLink>
            </Termsdesc>


            { settingContent.data.isCallFilterTurnOn
                && (
                <div>
                  <CallFilterSettingsDetails
                    defaultCriteriaValue={settingContent.data?.callTreatment?.criteria}
                    defaultActionValue={settingContent.data?.callTreatment?.action}
                    criteriaList={settingContent.data.criteriaList}
                    actionList={settingContent.data.actionList}
                    notification={settingContent.data.notification}
                    nonAppCapableInd={settingContent.data.nonAppCapableInd}
                    handleSaveChanges={handleSaveChanges}
                  />

                  <ButtonWrapper>
                    <Button
                      disabled={(!requestPayload.criteria && !requestPayload.action)||
                        (requestPayload.criteria === settingContent.data?.callTreatment?.criteria
            && requestPayload.action === settingContent.data?.callTreatment?.action)}
                      analyticstrack="save_call_filter__button"
                      data-testid="save_call_filter_button"
                      id="save_call_filter__button"
                      use="primary"
                      onClick={saveChanges}
                      width="auto"
                      data-track={`save call filter button criteria: ' ${requestPayload.criteria ? requestPayload.criteria : settingContent.data?.callTreatment?.criteria} action: ${requestPayload.action ? requestPayload.action : settingContent.data?.callTreatment?.action}`}
                      >
                        {settingContent.data?.callTreatment?.successMessage}
                      Save
                    </Button>
                  </ButtonWrapper>
                </div>
                )}
          </Container>
          )
        }
    </div>
  );
};
export default CallFilterSettings;

const Container = styled.div`
  margin-bottom: 6rem;
`;

const HeadingBar = styled.div`
  width: 65%;
  @media(max-width: 768px) { 
    width: 75%;
  }
  @media(max-width: 480px) { 
    display: none;
  }
`;

const ButtonWrapper = styled.div`
  margin-right: 1rem;
  margin-bottom: 3rem;
  margin-top:3rem;
  @media(max-width: 480px) { 
    width: 100%;
    margin-bottom: 1rem;
  }
`;

const Termsdesc = styled.div`
font-size:12px
`;
const TermsdescLink = styled.span`
font-size:12px;
text-decoration:underline;
cursor:pointer;
`;
