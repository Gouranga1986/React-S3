import styled from 'styled-components';

export const Header = styled.h1`   
  font-size: 20px;
  //font-family: NHaasGroteskDSStd-75Bd;
  line-height: 0.95;
  color: #000000;
  // font-weight: normal;
  font-style: normal;
  font-stretch: normal;
  -webkit-letter-spacing: normal;
  -moz-letter-spacing: normal;
  -ms-letter-spacing: normal;
  letter-spacing: normal;
  color: #000000;
  display: block;
  
`;


export const DropdownWrapper = styled.div`
width: 30%;
border-bottom: 1px solid #d8dada;
 
  @media (min-width: 679px) and (max-width: 1024px) {
    width: 50%;
  }
  @media (max-width: 678px) {
    width: 100%;
  }  
`;


export const SpamCard = styled.div`
    text-align:left;
    width:45%;
    font-weight: normal;
    //border-bottom: 0.0625rem solid #d8dada;
    padding-bottom: 25px;
    margin-top: 25px;
    display: inline-block;
     a{
      color: #000000;
    }
        
`;


export const SpamMDN = styled.div`
font-size: 20px;
color: #000000;
font-weight: bold;
font-style: normal;
font-stretch: normal;
font-family: Neue Haas Grotesk Display Std;
margin-bottom: 6px;
`;


export const HeadingBar = styled.div`
  width: 50%;
  @media (max-width: 678px) {
   width: 100%;
  }  
 
`;

export const SpamDetails = styled.div`
font-family: "BrandFont-Text", Arial, Helvetica, sans-serif;
  font-size: 1rem;
  // font-family: NHaasGroteskDSStd-55Rg;
  line-height: 1rem;
  // color: #747676;
  font-weight: normal;
  font-style: normal;
  font-stretch: normal;
  letter-spacing: normal;
  margin-bottom: 10px;
  margin-top: 13px;
  display:flex;
  
 
  
  >label {
    padding-right: 30px;
  }
`;

export const PIntro = styled.div`
font-family: "BrandFont-Text", Arial, Helvetica, sans-serif;
  font-size: 0.9rem;
  // font-family: NHaasGroteskDSStd-55Rg;
  line-height: 1rem;
  // color: #747676;
  font-weight: normal;
  font-style: normal;
  font-stretch: normal;
  letter-spacing: normal;
  margin-bottom: 10px;
  margin-top: 20px;
  width: 30%;
  display: flex;
  
  @media (min-width: 679px) and (max-width: 1024px) {
    width: 50%;
  }
  @media (max-width: 678px) {
    width: 100%;
  }   
`;

export const FooterBar = styled.div`
  width: 50%;
  
`;

export const BannerContainer = styled.div`
height: 5rem;
`;

export const LinkContainer = styled.div`
font-weight: normal;
//font-family: NHaasGroteskDSStd-55Rg;
font-size: 0.9rem;
color: #000;
width: 45%;
line-height: 1.25;
  
`;

export const IconContainer = styled.div`
border-bottom: 0.0625rem solid #d8dada; 
 span{
  position: relative;
  bottom: 50px;
  right: 5px
}
 @media (max-width:768px) {
 span{
    bottom: 62px;
    
 }
 
 }
`;