import { getHttpClientRequest, postHttpClientRequest } from '@vz/react-util';
import apiUrl from '../../../../../shared/utilities/apiUrl';

export const API_SAVE_REPORT_URL = apiUrl().callFilterReportConfirmationApiUrl;

export const SAVE_REPORT_BEGIN = 'callFilter/SAVE_REPORT_BEGIN';

export const saveReportBegin = (payload) => ({
  type: SAVE_REPORT_BEGIN,
  payload,
});

export const SAVE_REPORT_SUCCESS = 'callFilter/SAVE_REPORT_SUCCESS';

export const saveReportSuccess = (response) => ({
  type: SAVE_REPORT_SUCCESS,
  response,
});

export const SAVE_REPORT_ERROR = 'callFilter/SAVE_REPORT_ERROR';

export const saveReportError = (error) => ({
  type: SAVE_REPORT_ERROR,
  error,
});

export const saveReport = (dispatch, payload, isRedirectToConfirmationPage) => {
  console.log(payload,"payload123")
  dispatch(saveReportBegin(payload));
  const error = 'Your changes cannot be saved due to system error. Please try again later.';
  const onSuccess = (response) => {
    if (response.data.responseInfo.responseCode == '00') {
      dispatch(saveReportSuccess(response.data));
    } else {
      if (vztag && vztag.api) {
        vztag.api.dispatch('notify', {
          name: 'call filter report error',
          message: error, // The same error text presented to the user
          id: '503', // (optional if there is an associated error code)
          error: true, // a flag to tell us there was an error
        });
      }
      dispatch(saveReportError(error));
    }
  };

  const onError = () => {
    if (vztag && vztag.api) {
      vztag.api.dispatch('notify', {
        name: 'call filter report error',
        message: error, // The same error text presented to the user
        id: '503', // (optional if there is an associated error code)
        error: true, // a flag to tell us there was an error
      });
    }
    dispatch(saveReportError(error));
  };

  if (window?.location?.hostname?.indexOf('localhost') > -1) {
    getHttpClientRequest(API_SAVE_REPORT_URL).then(onSuccess).catch(onError);
  } else {
    postHttpClientRequest(API_SAVE_REPORT_URL, payload).then(onSuccess).catch(onError);
  }

};
