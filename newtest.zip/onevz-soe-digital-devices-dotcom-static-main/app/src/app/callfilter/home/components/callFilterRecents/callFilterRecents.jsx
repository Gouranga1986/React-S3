import React, { useEffect, useState } from 'react';
import { useHistory } from 'react-router-dom';
import {  useDispatch, useSelector } from 'react-redux';
import { DropdownSelect } from '@vds/selects';
import { Pagination } from '@vds/pagination';
import { Notification } from '@vds/notifications';
import alertsvg from "../../../../assets/images/alert-sign.svg"
import usersvg from "../../../../assets/images/user.svg"
import trafficsvg from "../../../../assets/images/traffic-signal.svg"
import NewLoader from '../../../../../shared/components/Loader/NewLoader';
import Icon from '@vds/icons';

import HorizontalBar from '../horizontalBar/HorizontalBar';
import {
  Header,
  DropdownWrapper,
  SpamCard,
  SpamMDN,
  HeadingBar,
  SpamDetails,
  PIntro,
  FooterBar,
  BannerContainer,
  LinkContainer,
  IconContainer,
} from '../styledComps';
import { POTENTIAL_SPAM_TYPE, BLOCKED_CALL_TYPE } from '../constants';


import { getDeviceType } from '../../../../utils/VendorScripts/DeviceType';
import util from '../../../../utils/utility'

import { fetchSpamCallFilter } from '../actions';
import { TextLink } from '@vds/buttons';
import { handleClick } from "../../../../../shared/utilities/click";
import common from '../../../../../shared/utilities/util';
import { relative } from 'path';


const CallFilterRecents = (props) => {
  const dispatch = useDispatch();
  const history = useHistory();

  const id = location?.search?.split('&')[0]
    && location?.search?.split('&')[0].split('?id=')[1];

  useEffect(() => {
    reactGlobals.isShowNoRecents = true;
    const payload = {
      param1: id ? id : '',
      pageNumber: 1,
      callType: 'ALL_CALLS',
    };
    fetchSpamCallFilter(dispatch, payload);
  }, []);

  const { callTreatment: callTreatmentResponse } = useSelector(
    (state) => state || {}
  );

  const spamCallFilter = (callTreatmentResponse?.spamResponse)
    ? (callTreatmentResponse?.spamResponse?.sections[0])
    : '';
  const [selectedCallType, setSelectedCallType] = useState('ALL_CALLS');



  const fetchCurrentPageRecords = (pageNumber) => {  // get corresponding pageNumber
       const payload = {
      param1: id || '',
      pageNumber,
      callType: selectedCallType || 'ALL_CALLS',
    };
    fetchSpamCallFilter(dispatch, payload);
  };

  const handleChangeSelect = (e, pageNumber) => {
    const payload = {
      param1: id || '',
      pageNumber: 1,
      callType: e.target.value,
    };

    fetchSpamCallFilter(dispatch, payload);

    if (e.target.value == 'ALL_CALLS') {
      reactGlobals.isShowNoRecents = true;
    } else {
      reactGlobals.isShowNoRecents = false;
    }
    setSelectedCallType(e.target.value);
  };

   const spamFilterComponent = (detailsList) => detailsList.map((item, key) => (
    <IconContainer>
    <div className='callfiltericons' key={key}>
      {item?.type && POTENTIAL_SPAM_TYPE.indexOf(item?.type?.toLowerCase()) !== -1 && (
      <span>
        <Icon 
      name="error" 
      size="XLarge" 
      color="#000000"
    /></span>
      )}
      {item?.type && BLOCKED_CALL_TYPE.indexOf(item?.type?.toLowerCase()) !== -1 && (
       <span >
      <Icon 
	      name="call-disconnected" 
	      size="XLarge" 
	      color="#000000"
      /></span>
      )}
      {!item.type && (
      <span >
      <Icon 
      name="my-account" 
      size="XLarge" 
      color="#000000"
    /> </span>
      )}
      <SpamCard>
        {getDeviceType() === 'mobile' ? (
          <a href={`tel:${item.formattedMTN}`}>
            <SpamMDN>{item.formattedMTN}</SpamMDN>
          </a>
        ) : (
          <SpamMDN>{item.formattedMTN}</SpamMDN>
        )}
        <SpamDetails>
          {item.type && <label>{item.type}</label>}
          <label>{item.date}</label>
          {' '}
          <label>{item.time}</label>
        </SpamDetails>

        <LinkContainer>
          <a
            href="javascript:void(0)"
            style={{ textDecoration: 'underline' }}
            onClick={() => {
              navigateToReportPage(item);
            }}
            data-track={`{"type": "link", "name": "report ${item.formattedMTN}"`}
          >
            {item.linkHeader}
          </a>
        </LinkContainer>
      </SpamCard>
    </div>
    </IconContainer>
  ));

  const navigateToReportPage = (data) => {
    if (data) {
      history.push({
        pathname: '/report',
        state: {
          data,
        },
      });
    }
  };


  const mainSectionItems = spamCallFilter
    && spamCallFilter.contents
    && spamCallFilter.contents.length > 0
    && spamCallFilter.contents[0].items;

  const calllogs = util.getItem(mainSectionItems, 'calllogs');
  const norecent = util.getItem(mainSectionItems, 'norecent');
  const nocalllogs = util.getItem(mainSectionItems, 'nocalllogs');
  const headerText =spamCallFilter?.data?.header;
  const reportanumberLink = common.getItem(mainSectionItems, "reportanumber");

  const actionsData = spamCallFilter && spamCallFilter.actions;

  return (
    <div id="call-filter-recents__tab" data-testid="callfilterRecentList">
      {callTreatmentResponse.errorMessage ? (
        callTreatmentResponse.errorMessage && (
          <BannerContainer aria-live="assertive">
            <span
              aria-live="polite"
              tabIndex="0"
              role="alert"
              style={{ height: '0px', marginLeft: '-10000px' }}
            >
              {callTreatmentResponse.errorMessage}
            </span>
            <Notification
              type="error"
              title={callTreatmentResponse.errorMessage.toString()}
              fullBleed="true"
            />
          </BannerContainer>
        )
      ) : (
        <React.Fragment>
          
          <Header style={{ marginTop: '2rem', marginBottom: '2rem' }}>
            {headerText}
          </Header>
          {spamCallFilter
            && spamCallFilter.data.incomingCallList.length > 0 && (
              <DropdownWrapper>
                <DropdownSelect
                  data-testid="incomingCallList"
                  id="incomingCallList"
                  label="Incoming calls"
                  onChange={(e) => handleChangeSelect(e, spamCallFilter.data.pageNumber)
                  }
                  data-track={`{"type":"menu","cat":"Search","head":"Incoming calls","name": "${selectedCallType}"}`}
                >
                  {spamCallFilter
                    && spamCallFilter.data.incomingCallList.map((item, index) => (
                      <option key={index} value={item.id}>
                        {item.label}
                        {' '}
                        (
                        {item.count}
                        )
                      </option>
                    ))}
                </DropdownSelect>
              </DropdownWrapper>
          )}
              { callTreatmentResponse.isFetching && <NewLoader /> }
          {spamCallFilter
            && spamCallFilter.data.incomingCallList.length > 0 && (
              <PIntro>{calllogs && calllogs.itemValue}</PIntro>
          )}

        
           <TextLink  type="standAlone" size="large"
                            data-track={JSON.stringify({type: "link", name: reportanumberLink && reportanumberLink.itemValue})}
                            onClick={(event) => {event.preventDefault(); handleClick(reportanumberLink.actionKey, actionsData, reportanumberLink)}}>{reportanumberLink && reportanumberLink.itemValue}</TextLink>


          {spamCallFilter && spamCallFilter.data.detailsList.length > 0 && (
            <HeadingBar>
              <HorizontalBar margin="1.5rem 0" width="4px" />
            </HeadingBar>
          )}

          {spamCallFilter
            && spamCallFilter.data.detailsList.length > 0
            && spamFilterComponent(spamCallFilter.data.detailsList)}

          <HeadingBar>
            <HorizontalBar margin="1.5rem 0" width="4px" />
          </HeadingBar>

          {spamCallFilter
            && spamCallFilter.data.detailsList.length == 0
            && reactGlobals.isShowNoRecents && (
              <Header style={{ marginTop: '2rem', marginBottom: '2rem' }}>
                {norecent && norecent.itemValue}
              </Header>
          )}

          {spamCallFilter
            && spamCallFilter.data.detailsList.length == 0
            && !reactGlobals.isShowNoRecents && (
              <PIntro
                style={{
                  marginTop: '2rem',
                  marginBottom: '2rem',
                  fontSize: '1.075rem',
                }}
              >
                {nocalllogs && nocalllogs.itemValue}
              </PIntro>
          )}

          <HeadingBar>
            {spamCallFilter && spamCallFilter.data.detailsList.length > 0 && (
              <Pagination
                selectPage={(ev) => {
                  fetchCurrentPageRecords(ev);
                }}
                selectedPage={spamCallFilter.data.pageNumber}
                // range={10}
                total={Math.ceil(spamCallFilter.data.total/spamCallFilter.data.recordsPerPage)}                
                showArrow
              />
            )}
          </HeadingBar>
        </React.Fragment>
      )}
    </div>
  );
};

export default CallFilterRecents;
