import { getHttpClientRequest, postHttpClientRequest } from '@vz/react-util';
import apiUrl from '../../../../../shared/utilities/apiUrl';
import { fetchCallTreatment } from './fetchCallTreatment';
export const API_SAVE_CALL_TREATMENT_URL = apiUrl().callFilterSaveSettingsOptionApiUrl;

export const SAVE_CALL_TREATMENT_BEGIN = 'callFilter/SAVE_CALL_TREATMENT_BEGIN';

export const saveCallTreatmentBegin = (payload) => ({
  type: SAVE_CALL_TREATMENT_BEGIN,
  payload,
});

export const SAVE_CALL_TREATMENT_SUCCESS = 'callFilter/SAVE_CALL_TREATMENT_SUCCESS';

export const saveCallTreatmentSuccess = (response, selectedToggleOption) => ({
  type: SAVE_CALL_TREATMENT_SUCCESS,
  response,  
  selectedToggleOption,
});

export const SAVE_CALL_TREATMENT_ERROR = 'callFilter/SAVE_CALL_TREATMENT_ERROR';

export const saveCallTreatmentError = (error) => ({
  type: SAVE_CALL_TREATMENT_ERROR,
  error,
});

export const saveCallTreatment = (dispatch, payload, selectedToggleOption) => {
  console.log(selectedToggleOption,"selectedToggleOption")
  dispatch(saveCallTreatmentBegin(payload));
  const error = 'Your changes cannot be saved due to system error. Please try again later.';
  const onSuccess = (response) => {
    if (response.data.responseInfo.responseCode == '00') {
      dispatch(saveCallTreatmentSuccess(response.data, selectedToggleOption));
      fetchCallTreatment(dispatch, true);
    } else {
      if (vztag && vztag.api) {
        vztag.api.dispatch('notify', {
          name: 'call filter settings error',
          message: error, // The same error text presented to the user
          id: '503', // (optional if there is an associated error code)
          error: true, // a flag to tell us there was an error
        });
      }
      dispatch(saveCallTreatmentError(error));
    }
  };
  const onError = () => {
    if (vztag && vztag.api) {
      vztag.api.dispatch('notify', {
        name: 'call filter settings error',
        message: 'Your changes cannot be saved due to system error. Please try again later.', // The same error text presented to the user
        id: '503', // (optional if there is an associated error code)
        error: true, // a flag to tell us there was an error
      });
    }
    dispatch(saveCallTreatmentError(error));
  };
 

  //  axios({
  //         method: 'post',
  //         url: API_SAVE_CALL_TREATMENT_URL,
  //         data: payload
  //       })

  //   .then(onSuccess)
  //   .catch(onError);

  if (window?.location?.hostname?.indexOf('localhost') > -1) {
    getHttpClientRequest(API_SAVE_CALL_TREATMENT_URL).then(onSuccess).catch(onError);
  } else {
    postHttpClientRequest(API_SAVE_CALL_TREATMENT_URL, payload).then(onSuccess).catch(onError);
  }
};
