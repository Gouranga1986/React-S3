export const POTENTIAL_SPAM_TYPE = ['potential spam', 'robo caller', 'potential fraud'];

export const BLOCKED_CALL_TYPE = ['blocked call'];
