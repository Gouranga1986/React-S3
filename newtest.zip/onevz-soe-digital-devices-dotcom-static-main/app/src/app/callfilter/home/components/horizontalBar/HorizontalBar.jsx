import React from 'react';
import styled from 'styled-components';
import PropTypes from 'prop-types';

const HorizontalBar = (props)=>{
  return (
    <Bar
      hide={props.hide}
      color={props.color}
      margin={props.margin}
      width={props.width}
    />
  );
}

const Bar = styled.div`
  max-width: 79.5rem;
  width: 90%;
  height: ${(props) => (props.width ? props.width : '1px')};
  margin: ${(props) => props.margin};
  border-style: solid;
  border-color: ${(props) => props.color}!important;
  background-color: ${(props) => props.color}!important;
  border-top: thin solid ${(props) => props.color}!important;
  display: ${(props) => (props.hide ? 'none' : 'block')};
  display: ${(props) => (props.hideOn === 'desktop' ? 'none' : 'block')};
  @media(max-width: 768px) {  
    display: ${(props) => (props.hideOn === 'mobile' ? 'none' : 'block')};
    width: 100%;
  }
`;


HorizontalBar.propTypes = {
  hide: PropTypes.bool,
  color: PropTypes.string,
  margin: PropTypes.string,
  width: PropTypes.string,
  hideOn: PropTypes.bool,
};

HorizontalBar.defaultProps = {
  hide: false,
  color: 'RGB(0,0,0)',
  margin: '0.25rem 0 1.5rem 0',
  width: '1px 0 0 0',
};

export default HorizontalBar;
