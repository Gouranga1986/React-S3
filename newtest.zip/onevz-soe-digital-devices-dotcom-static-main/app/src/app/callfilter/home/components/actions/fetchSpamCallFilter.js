import { getHttpClientRequest, postHttpClientRequest } from '@vz/react-util';
import apiUrl from '../../../../../shared/utilities/apiUrl';

export const FETCH_SPAM_CALL_FILTER_BEGIN = 'callTreatment/FETCH_SPAM_CALL_FILTER_BEGIN';
export const FETCH_SPAM_CALL_FILTER_SUCCESS = 'callTreatment/FETCH_SPAM_CALL_FILTER_SUCCESS';
export const FETCH_SPAM_CALL_FILTER_FAIL = 'callTreatment/FETCH_SPAM_CALL_FILTER_FAIL';

export const fetchSpamCallFilter = (dispatch, payload) => {
   
   let axConfig = {
    headers: { pageName: 'Spam Call Filtert', flowName: 'CallFilter' },
  };

  const onError = (error) => {
    dispatch(fetchSpamCallFilterError(error));
  };

  dispatch(fetchSpamCallBegin(payload));
  
  const httpMethod = window?.location?.hostname?.indexOf('localhost') > -1 ? 'get' : 'post';


  const callMS = () => {
    const axConfig = {
      headers: {
        pageName: 'Recents Spam',
        flowName: 'Recents Spam',
      },
    };
    if (httpMethod === 'get') {
      return getHttpClientRequest(
        apiUrl().callFilterLandingApiUrl,
        axConfig
      );
    }
    return postHttpClientRequest(
      apiUrl().callFilterLandingApiUrl,
      payload,
      axConfig
    );
  };

  callMS()
    .then((response) => {
      if (response.data && response.data.responseInfo.responseCode == '00') {
        response.data.body.sections[0].sections[0].data.pageNumber = payload.pageNumber;
        dispatch(fetchSpamCallFilterSuccess(response));
      } else {
        dispatch(fetchSpamCallFilterError(response));
      }
    }).catch(onError);
};

export const fetchSpamCallBegin = (isShowSuccessMessage) => ({
  type: FETCH_SPAM_CALL_FILTER_BEGIN,
  isShowSuccessMessage,
});
export const fetchSpamCallFilterSuccess = (response) => ({
  type: FETCH_SPAM_CALL_FILTER_SUCCESS,
  response: response?.data?.body?.sections[0],
});
export const fetchSpamCallFilterError = (response) => ({
  type: FETCH_SPAM_CALL_FILTER_FAIL,
  error: response.data,
});
