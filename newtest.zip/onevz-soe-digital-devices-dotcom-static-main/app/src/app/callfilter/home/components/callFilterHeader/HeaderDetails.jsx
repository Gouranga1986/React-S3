import React, { useState } from 'react';
import styled from 'styled-components';
// import { Input } from '@vds/inputs';
import { Toggle } from '@vds/toggles';

const HeaderDetails =(props)=> {
 
    const[isToggle, setIsToggle] = useState(props.isCallFilterTurnOn);

    const handleToggle = () => {
      props.handleToggle(!isToggle);
      setIsToggle(!isToggle);
    }


    return (
      <Container>
        {props.subHeader && props.subHeader.map((value, index) => (
          <div style={{ display: 'flex' }} key={value}>
            <Left>
              <SubHeader key={index}>
                <div style={{ fontSize: index===0 ?'18px':'16px'}}>
                  {value}
                </div>
              </SubHeader>
            </Left>
            {index === 0
                && (
                <Right>
                  <ToogleWrapper analyticstrack="callFilterToggleBtn" data-testid="callfilter-toggle">
                    {/* <Input
                      id="callfilter-toggle"
                      type="toggle"
                      value="default"
                      on={isToggle}
                      data-track={`{"type": "toggle","name": "auto block", "state": ${isToggle ? 'on' : 'off'}}`}
                      onChange={handleToggle}
                    /> */}
                    <Toggle
                    value="default"
                    surface="light"
                    surfaceType="colorFill"
                    showText={true}
                    textWeight="regular"
                    textSize="small"
                    textPosition="left"
                    on={isToggle}
                    statusText={(e)=> e ? 'On' : 'Off'}
                    data-track={`{"type": "toggle","name": "auto block", "state": ${isToggle ? 'on' : 'off'}}`}
                    onChange={handleToggle}
                  />
                  </ToogleWrapper>
                </Right>
                )}
          </div>
        ))}
        
      </Container>
    );
   
}

export default HeaderDetails;

const Container = styled.div`
  max-width: 79.5rem;
  margin: 0;
  padding: 0;
  @media(max-width: 480px) { 
    height: auto;  
  }
  
 
`;

const SubHeader = styled.div`
  margin-bottom:18px;
  @media(max-width: 480px) { 
    margin-bottom: 0.75rem;
    }
`;

const Left = styled.div`
font-weight: normal;
//font-family: NHaasGroteskDSStd-55Rg;
font-size: 14px;
color: #000;
width: 41%;
@media(max-width: 768px) {   
  width: 55%;
    }
    @media(max-width: 480px) {   
  font-weight: normal;
  font-size: 10px;
  width: 85%;
    }

`;

const Link = styled.div`
font-weight: normal;
//font-family: NHaasGroteskDSStd-55Rg;
font-size: 12px;
color: #000;
width: 45%;
 
`;

const ALink = styled.a.attrs({
  analyticstrack: (props) => props.analyticstrack,
})`
  height: 16.8px;
 // font-family: NHaasGroteskDSStd-55Rg;
  font-size: 12px;
  font-weight: normal;
  font-style: normal;
  font-stretch: normal;
  line-height: 1.2;
  letter-spacing: normal;
  color: #000000;
  text-decoration: underline;
  
`;

const Right = styled.div`
padding-left: 2rem;
font-weight: normal;
font-style: normal;
width: 17%;
@media (max-width: 678px) {
    width: 25%;
  }  
 
`;

const ToogleWrapper = styled.div.attrs({
  analyticstrack: (props) => props.analyticstrack,
})`
  display:block;
  float: right;
 
`;

