export const callfilterReportPageMockResponse = {
	"responseInfo": {
	  "timeStamp": "11-08-2023 07:48:23",
	  "correlationId": "",
	  "responseCode": "00",
	  "responseMessage": "SUCCESS",
	  "sectionErrors": []
	},
	"body": {
	  "pageId": "callFilterReport",
	  "pageAttributes": [
		{
		  "itemKey": "pageTitle",
		  "itemValue": "Call filter"
		},
		{
		  "itemKey": "hashedAccountNumber",
		  "itemValue": "f3c5c52290c3950bf248f23f173bcaf34cfcdb01cebee86350a5e0a9aa407016",
		  "itemType": "text"
		},
		{
		  "itemKey": "hashedMdn",
		  "itemValue": "d5c6b665a7c87ca9b7e5ee4f43e557b70480f516b68167f926e448a1b8e6885b",
		  "itemType": "text"
		}
	  ],
	  "sections": [
		{
		  "sectionIndex": "0",
		  "sectionId": "devicesCallFilterMainSection",
		  "sectionType": "devicesCallFilterMainSection",
		  "sectionComponentId": "",
		  "sections": [
			{
			  "sectionIndex": "2",
			  "sectionId": "devicesCFReportPageSection",
			  "sectionType": "deviceCFReportSection",
			  "actions": [
				{
				  "actionKey": "reportAction",
				  "actionValue": "/confirmation",
				  "actionType": "route",
				  "clickstream": "report-btn"
				},
				{
				  "actionKey": "cancelAction",
				  "actionValue": "",
				  "actionType": "route",
				  "clickstream": "cancel-btn"
				}
			  ],
			  "contents": [
				{
				  "contentIndex": "0",
				  "contentType": "callFilterReportPageContent",
				  "items": [
					{
						"itemKey": "title",
						"itemType": "text",
						"itemValue": "Report this number?",
						"itemAttributes": {}
					  },
					  {
						"itemKey": "description",
						"itemType": "text",
						"itemValue": "We use the information you report, including comments and tags, to improve the accuracy of our service.",
						"itemAttributes": {}
					  },{
						"itemKey": "commentHeading",
						"itemType": "text",
						"itemValue": "Leave a comment (optional)",
						"itemAttributes": {}
					  },
					  {
						"itemKey": "comment",
						"itemType": "text",
						"itemValue": "Comment",
						"itemAttributes": {}
					  },
					  {
						"itemKey": "comment_desc",
						"itemType": "text",
						"itemValue": "Why are you reporting this number? Use # to tag keywords like #scam or #phishing.",
						"itemAttributes": {}
					  },
					  {
						"itemKey": "bannermsg_failure",
						"itemType": "text",
						"itemValue": "Your changes cannot be saved due to system error. Please try again later.",
						"itemAttributes": {}
					  },
					  {
						"itemKey": "mdnHeading",
						"itemType": "text",
						"itemValue": "Enter a number",
						"itemAttributes": {}
					  },
					  {
						"itemKey": "spamHeading",
						"itemType": "text",
						"itemValue": "Call type",
						"itemAttributes": {}
					  }, {
						"itemKey": "subHeading",
						"itemType": "text",
						"itemValue": "We use this information you share to improve spam filter accuracy.",
						"itemAttributes": {}
					  },
					  
					  {
						"itemKey": "reportBtn",
						"itemType": "button",
						"itemValue": "Report",
						"actionKey": "reportAction"
					  },
					  {
						"itemKey": "cancelBtn",
						"itemType": "button",
						"itemValue": "Cancel",
						"actionKey": "cancelAction"
					  },
					  {
						"itemKey": "backBtn",
						"itemType": "Link",
						"itemValue": "Back",
						"actionKey": "BackAction"
					  }
				  ]
				}
			  ]
			}
		  ]
		}
	  ]
	}
  }