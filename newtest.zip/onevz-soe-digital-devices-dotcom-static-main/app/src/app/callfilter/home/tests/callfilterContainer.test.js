import React from "react";
import "../../../../../config/jest/test-setup";
import "./test-setup";
import { act, render, screen, cleanup, getByText, fireEvent } from "@testing-library/react";
import "@testing-library/jest-dom/extend-expect";
import userEvent from "@testing-library/user-event";
import { Provider } from "react-redux";
import { getHttpClientRequest } from "@vz/react-util";
import configureStore, { history } from "../../../../shared/store/configureStore";
import rootReducer from "../../reducers";
import { persistStore } from 'redux-persist';
import { PersistGate } from 'redux-persist/integration/react';
////import * as deviceActions from "../actions"

import CallFilterRecents from "../components/callFilterRecents/callFilterRecents"
import { callfilterLandingPageMockResponse,callfilterSettingsPageMockResponse ,callfilterSettingsPageMockResponse1} from "./callfilterLandingPageMock";
import CallFilterContainer from "../CallFilterContainer"
import { fetchCallTreatment } from "../components/actions";
import { onTabChange } from "../TabChange";
//import * as pageActions  from '../actions/pageActions';


const store = configureStore(rootReducer);
const persistor = persistStore(store);

jest.mock("@vz/react-util", () => ({
    ...jest.requireActual("@vz/react-util"),
    getHttpClientRequest: jest.fn()
  }));

jest.mock("../../../../shared/services/httpClient", () => ({
    ...jest.requireActual("../../../../shared/services/httpClient"),
    // getHttpClientRequest: jest.fn()
}));

//jest.mock('fetchCallTreatment', () =>jest.fn());

describe("<CallFilterContainer />", () => {
    beforeEach(async () => {
        getHttpClientRequest.mockImplementation((url) => {
            return Promise.resolve({ status: 200, data: {...callfilterSettingsPageMockResponse} });
        })
        
        await act(async () => render(
            <Provider store={store}>
                <PersistGate loading={null} persistor={persistor}>
                    <CallFilterContainer 
                        // pageLabels={pageLabels}
                        // deviceDetails={deviceDetails}
                        // deviceFilterDropdown = {[
                        //     "Show All",
                        //     "Eligible",
                        //     "Non-eligible"
                        // ]}
                        // disconnectClicked={jest.fn()}
                    />
                </PersistGate>
            </Provider>
        ));

    })

    test("it should mount", () => {
        const doc = screen.getByTestId("callfilterContainer");
        expect(doc).toBeInTheDocument();
    });
    test("should receive the response from  API", () => {
        expect(screen.getByTestId("callfilterContainer")).toBeInTheDocument();
    });
    test("it should use the value returned from API", () => {
        expect(screen.getByTestId("callfilterContainer")).toContainHTML("callfilterContainer");
   });

//    it('should test onChange behavior', () => {
//     //render(<Dropdown />)

    
//     const select = screen.getByTestId("settings");
//     //const testingLibrary = screen.getByTestId('incomingCallList', { name: 'React Testing Library' })
//     //const jest = screen.getByTestId('incomingCallList', { name: 'Jest' })

//     fireEvent.change(select, { target: { value: 'settings' } })

//     expect(select.value).toBe('settings')
//     //expect(testingLibrary.selected).toBe(true)

//     //fireEvent.change(select, { target: { value: '🎴' } })

//     //expect(select.value).toBe('🎴')
//     //expect(jest.selected).toBe(true)
// })


    it('should update react global and fetchCallTreatment when id is defined',()=>{
const id=123;
const reactGlobals={
    callFilterSettingsApiUrl:'settings?id=123',
    encryptedMdn:123
}
const dispatch = jest.fn();

//updateReactGlobals(reactGlobals,id);
expect(reactGlobals.encryptedMdn).toBe(id);
expect(reactGlobals.callFilterSettingsApiUrl).toContain(`?id=${id}`);

//expect(fetchCallTreatment).toHaveBeenCalledWith(dispatch);


// render(<Provider store={store}>
//     <PersistGate loading={null} persistor={persistor}>
//         <CallFilterContainer id={null} reactGlobals={reactGlobals} dispatch={dispatch}/>
//         </PersistGate>
//     </Provider>);


//expect(reactGlobals.encryptedMdn).toBe(id);
//expect(reactGlobals.callFilterSettingsApiUrl).not.toContain('id='+id);

//expect(fetchCallTreatment).toHaveBeenCalledTimes(1);

    })



// it("check onTab Change event",()=>{
// const closeRightSectionSpy = jest.fn();

// beforeEach(async () => {
//   const { getByTestId } = await render(<Provider store={store}>
//     <PersistGate loading={null} persistor={persistor}>
//     <CallFilterContainer onTabChange={closeRightSectionSpy} /></PersistGate></Provider>
//   );

//   fireEvent.click(screen.findByRole('tab', {label: 'Recents', hidden: true }));

//   expect(closeRightSectionSpy).toHaveBeenCalled();
// })
// })

// it('should trigger onTabChange with "recents" when clicking the Recents tab', () => {
//     const mockOnTabChange = jest.fn(); // Mock your onTabChange function

//     // Render your component
//     const { getByTestId } = render(<Provider store={store}>
//         <PersistGate loading={null} persistor={persistor}>
//         <CallFilterContainer onTabChange={mockOnTabChange} isRecentsTabsSelected={false} /></PersistGate></Provider>
//     );

//     // Find the tab element and simulate a click
//     const recentsTab = screen.getByText("Recents").closest("button");
//     fireEvent.click(recentsTab);

//     // Expect onTabChange to be called with 'recents'
// // Expect onTabChange to be called with 'recents' when the tab is clicked
//     expect(mockOnTabChange).toHaveBeenCalledWith('recents');
//   });

  // Add more test cases for other tabs or conditions as needed

  it('should cover recent tab true',()=>{
    
    const value = 'settings';
    const setIsSettingsTabSelected = jest.fn();
    const setIsRecentsTabsSelected = jest.fn();

     onTabChange(value,setIsSettingsTabSelected,setIsRecentsTabsSelected)
   
   })

   it('should cover recent tab true',()=>{
    
    const value = 'recents';
    const setIsSettingsTabSelected = jest.fn();
    const setIsRecentsTabsSelected = jest.fn();


    onTabChange(value,setIsSettingsTabSelected,setIsRecentsTabsSelected)
    
   })

    test("render Settings tab",()=>{
       const tab = screen.getByRole("tab", { name:"Settings"});
       expect(tab).toBeInTheDocument();
       fireEvent.click(tab);
   })

    test("render Recents tab", () => {
        const tab = screen.getByRole("tab", { name: "Recents" });
        expect(tab).toBeInTheDocument();
        fireEvent.click(tab);
    })
   

})

describe("<CallFilterContainer />", () => {
    beforeEach(async () => {
        getHttpClientRequest.mockImplementation((url) => {
            return Promise.resolve({ status: 200, data: { ...callfilterSettingsPageMockResponse1 } });
        })

        await act(async () => render(
            <Provider store={store}>
                <PersistGate loading={null} persistor={persistor}>
                    <CallFilterContainer
                    />
                </PersistGate>
            </Provider>
        ));

    })

    test("it should mount", () => {
        const doc = screen.getByTestId("callfilterContainer");
        expect(doc).toBeInTheDocument();
    });
    
})


