export const callfilterLandingPageMockResponse = {
	"responseInfo": {
		"timeStamp": "11-08-2023 07:48:23",
		"correlationId": "",
		"responseCode": "00",
		"responseMessage": "SUCCESS",
		"sectionErrors": []
	},
	"body": {
		"pageId": "callFilter",
		"pageAttributes": [
			{
				"itemKey": "pageTitle",
				"itemValue": "Call filter"
			},
			{
				"itemKey": "hashedAccountNumber",
				"itemValue": "f3c5c52290c3950bf248f23f173bcaf34cfcdb01cebee86350a5e0a9aa407016",
				"itemType": "text"
			},
			{
				"itemKey": "hashedMdn",
				"itemValue": "d5c6b665a7c87ca9b7e5ee4f43e557b70480f516b68167f926e448a1b8e6885b",
				"itemType": "text"
			}
		],
		"sections": [
			{
				"sectionIndex": "0",
				"sectionId": "devicesCallFilterMainSection",
				"sectionType": "devicesCallFilterMainSection",
				"sectionComponentId": "",
				"sections": [
					{
						"sectionIndex": "1",
						"sectionId": "devicesCallFilterLandingPageSection",
						"sectionType": "callFilterLandingSection",
						"actions": [],
						"contents": [
							{
								"contentIndex": "0",
								"contentType": "recentSpamFilterPageContent",
								"items": [
									{
										"itemKey": "calllogs",
										"itemType": "text",
										"itemValue": "Call log includes calls from the past 30 days and may not exactly match your device call log.",
										"itemAttributes": {}
									},
									{
										"itemKey": "reportanumber",
										"itemType": "text",
										"itemValue": "Need to report a number that isn't listed?",
										"itemAttributes": {}
									},
									{
										"itemKey": "norecent",
										"itemType": "text",
										"itemValue": "No recents",
										"itemAttributes": {}
									},
									{
										"itemKey": "nocalllogs",
										"itemType": "text",
										"itemValue": "There are no calls to show for the selected filter.",
										"itemAttributes": {}
									},
									{
										"itemKey": "description",
										"itemType": "text",
										"itemValue": "317 spam calls have been blocked in the last 30 days",
										"itemAttributes": {}
									}
								]
							}
						],
						"data": {
							"incomingCallList": [
								{
									"label": "All calls",
									"id": "ALL_CALLS",
									"count": 1001
								},
								{
									"label": "Blocked calls",
									"id": "BLOCKED_CALLS",
									"count": 317
								},
								{
									"label": "Identified spam",
									"id": "IDENTIFIED_SPAM",
									"count": 482
								}
							],
							"detailsList": [
								{
									"formattedMTN": "732.947.1214",
									"encryptedMTN": "KT2tfIdqc7smdCLyD0FFXA%3D%3D",
									"date": "11/23/20",
									"time": "06:20 PM",
									"linkHeader": "Report",
									"linkUrl": "",
									"type": "",
									"timeStamp": "2020-11-23T18:20:22"
								},
								{
									"formattedMTN": "866.583.8119",
									"encryptedMTN": "2Cf1zodl5kpc7Ny26AGV4w%3D%3D",
									"date": "11/23/20",
									"time": "05:20 PM",
									"linkHeader": "Report",
									"linkUrl": "",
									"type": "Robo Caller",
									"timeStamp": "2020-11-23T17:20:09"
								},
								{
									"formattedMTN": "732.754.1190",
									"encryptedMTN": "MNC36PYvWLTZHwSjhbr6kw%3D%3D",
									"date": "11/23/20",
									"time": "03:32 PM",
									"linkHeader": "Report",
									"linkUrl": "",
									"type": "",
									"timeStamp": "2020-11-23T15:32:37"
								},
								{
									"formattedMTN": "732.754.1190",
									"encryptedMTN": "MNC36PYvWLTZHwSjhbr6kw%3D%3D",
									"date": "11/23/20",
									"time": "03:28 PM",
									"linkHeader": "Report",
									"linkUrl": "",
									"type": "",
									"timeStamp": "2020-11-23T15:28:06"
								},
								{
									"formattedMTN": "480.706.2333",
									"encryptedMTN": "21DbjohXinXJAJWpTFX0IQ%3D%3D",
									"date": "11/9/20",
									"time": "06:30 PM",
									"linkHeader": "Report",
									"linkUrl": "",
									"type": "Potential spam",
									"timeStamp": "2020-11-09T18:30:45"
								},
								{
									"formattedMTN": "640.883.8164",
									"encryptedMTN": "k0%2BBkuT6VM1k4RQaZu6xHA%3D%3D",
									"date": "11/9/20",
									"time": "06:30 PM",
									"linkHeader": "Report",
									"linkUrl": "",
									"type": "Blocked call",
									"timeStamp": "2020-11-09T18:30:45"
								},
								{
									"formattedMTN": "680.577.6001",
									"encryptedMTN": "UEYXc4reb86whkdEbwi60A%3D%3D",
									"date": "11/9/20",
									"time": "06:30 PM",
									"linkHeader": "Report",
									"linkUrl": "",
									"type": "Robo Caller",
									"timeStamp": "2020-11-09T18:30:45"
								},
								{
									"formattedMTN": "885.428.4838",
									"encryptedMTN": "wmqDnvRQS9DbVvlB6tHUcA%3D%3D",
									"date": "11/9/20",
									"time": "06:30 PM",
									"linkHeader": "Report",
									"linkUrl": "",
									"type": "Potential spam",
									"timeStamp": "2020-11-09T18:30:45"
								},
								{
									"formattedMTN": "714.941.8571",
									"encryptedMTN": "ea7QOTPcPhNGTzE4uz3zCQ%3D%3D",
									"date": "11/9/20",
									"time": "06:30 PM",
									"linkHeader": "Report",
									"linkUrl": "",
									"type": "Blocked call",
									"timeStamp": "2020-11-09T18:30:45"
								},
								{
									"formattedMTN": "389.580.2767",
									"encryptedMTN": "i4crpFS8tdqaNWQdldONkA%3D%3D",
									"date": "11/9/20",
									"time": "06:30 PM",
									"linkHeader": "Report",
									"linkUrl": "",
									"type": "Blocked call",
									"timeStamp": "2020-11-09T18:30:45"
								},
								{
									"formattedMTN": "601.599.7285",
									"encryptedMTN": "stm7iRnIEXR3JjYyfbHDPg%3D%3D",
									"date": "11/9/20",
									"time": "06:30 PM",
									"linkHeader": "Report",
									"linkUrl": "",
									"type": "Blocked call",
									"timeStamp": "2020-11-09T18:30:44"
								},
								{
									"formattedMTN": "820.942.2842",
									"encryptedMTN": "k3mIkqQoi5eYObha%2FB6DnA%3D%3D",
									"date": "11/9/20",
									"time": "06:30 PM",
									"linkHeader": "Report",
									"linkUrl": "",
									"type": "Blocked call",
									"timeStamp": "2020-11-09T18:30:44"
								},
								{
									"formattedMTN": "842.640.3574",
									"encryptedMTN": "7O%2F1cEhsNo1Mz%2BDYJM0WQg%3D%3D",
									"date": "11/9/20",
									"time": "06:30 PM",
									"linkHeader": "Report",
									"linkUrl": "",
									"type": "",
									"timeStamp": "2020-11-09T18:30:44"
								},
								{
									"formattedMTN": "615.381.1524",
									"encryptedMTN": "LG4wW0C5Z%2Bv5XrmcLScnQQ%3D%3D",
									"date": "11/9/20",
									"time": "06:30 PM",
									"linkHeader": "Report",
									"linkUrl": "",
									"type": "",
									"timeStamp": "2020-11-09T18:30:44"
								},
								{
									"formattedMTN": "223.648.9254",
									"encryptedMTN": "AsA1dF4LHtWR8pRqOdo37Q%3D%3D",
									"date": "11/9/20",
									"time": "06:30 PM",
									"linkHeader": "Report",
									"linkUrl": "",
									"type": "Potential spam",
									"timeStamp": "2020-11-09T18:30:44"
								},
								{
									"formattedMTN": "530.425.3270",
									"encryptedMTN": "1aseYq6mqN8p1K5SxN0ILg%3D%3D",
									"date": "11/9/20",
									"time": "06:30 PM",
									"linkHeader": "Report",
									"linkUrl": "",
									"type": "Potential spam",
									"timeStamp": "2020-11-09T18:30:44"
								},
								{
									"formattedMTN": "287.463.8201",
									"encryptedMTN": "oDC4ea%2FiPZqwhkdEbwi60A%3D%3D",
									"date": "11/9/20",
									"time": "06:30 PM",
									"linkHeader": "Report",
									"linkUrl": "",
									"type": "Blocked call",
									"timeStamp": "2020-11-09T18:30:44"
								},
								{
									"formattedMTN": "484.640.8712",
									"encryptedMTN": "ssDbAtxxQSkZZezVhattoQ%3D%3D",
									"date": "11/9/20",
									"time": "06:30 PM",
									"linkHeader": "Report",
									"linkUrl": "",
									"type": "",
									"timeStamp": "2020-11-09T18:30:44"
								},
								{
									"formattedMTN": "192.562.4910",
									"encryptedMTN": "8zD6ttbIS9SvXiy3IGKQAw%3D%3D",
									"date": "11/9/20",
									"time": "06:30 PM",
									"linkHeader": "Report",
									"linkUrl": "",
									"type": "Blocked call",
									"timeStamp": "2020-11-09T18:30:44"
								},
								{
									"formattedMTN": "658.844.7829",
									"encryptedMTN": "sg9pPJ11KpFyxx%2Fj9s1NlQ%3D%3D",
									"date": "11/9/20",
									"time": "06:30 PM",
									"linkHeader": "Report",
									"linkUrl": "",
									"type": "",
									"timeStamp": "2020-11-09T18:30:44"
								}
							],
							"pageNumber": 1,
							"total": 1001,
							"recordsPerPage": 20,
							"lastPageNumber": 0,
						}
					}
				]
			}
		]
	}
}

export const callfilterSettingsPageMockResponse = {
	"responseInfo": {
		"timeStamp": "21-12-2023 11:22:42",
		"correlationId": "",
		"responseCode": "00",
		"responseMessage": "SUCCESS",
		"sectionErrors": []
	},
	"body": {
		"pageAttributes": [
			{
				"itemKey": "pageTitle",
				"itemValue": "Call filter",
				"itemAttributes": {}
			},
			{
				"itemKey": "hashedAccountNumber",
				"itemValue": "##HASHED_ACCTNO##",
				"itemType": "text",
				"itemAttributes": {}
			},
			{
				"itemKey": "hashedMdn",
				"itemValue": "##HASHED_MDN##",
				"itemType": "text",
				"itemAttributes": {}
			}
		],
		"sections": [
			{
				"sectionIndex": "0",
				"sectionId": "devicesCallFilterMainSection",
				"sectionType": "devicesCallFilterMainSection",
				"sectionComponentId": "GenericComponent",
				"sections": [
					{
						"sectionIndex": "1",
						"sectionId": "devicesCFSettingsPageSection",
						"sectionType": "devicesCFSettingSection",
						"actions": [
							{
								"actionType": "http",
								"actionValue": "##HOST_NAME##/support/call-filter-legal/",
								"actionKey": "termsLinkAction",
								"clickStream": "terms_link"
							},
							{
								"actionType": "http",
								"actionValue": "##HOST_NAME##/about/privacy/full-privacy-policy",
								"actionKey": "privacyLinkAction",
								"clickStream": "privacy_link"
							},
							{
								"actionType": "http",
								"actionValue": "##HOST_NAME##//ui/hub/secure/overview?flow=1D#/",
								"actionKey": "backAction",
								"clickStream": "back_btn"
							},
							{
								"actionType": "http",
								"actionValue": "##HOST_NAME##//ui/hub/secure/overview?flow=1D#/",
								"actionKey": "backAction",
								"clickStream": "back_btn"
							},
							{
								"actionType": "http",
								"actionValue": "##HOST_NAME##/ui/acct/secure/productApps/",
								"actionKey": "addOnAction",
								"clickStream": "add_on_btn"
							}
						],
						"contents": [
							{
								"contentIndex": "0",
								"contentComponentId": "recentSpamFilterPageContent",
								"items": [
									{
										"itemKey": "header",
										"itemType": "text",
										"itemValue": "Screen incoming calls and block spam for free",
										"itemAttributes": {}
									},
									{
										"itemKey": "description",
										"itemType": "text",
										"itemValue": "Auto-block spam calls by risk level.#Suspected spam calls that aren't auto-blocked will be labeled on your incoming call screen to help you decide if you want to answer.#Please note calls you want to receive may be auto-blocked by Call Filter, causing you to missing them.",
										"itemAttributes": {}
									},
									{
										"itemKey": "linkDescription",
										"itemType": "text",
										"itemValue": "By turning on Call Filter, you agree to our",
										"itemAttributes": {}
									},
									{
										"itemKey": "bannermsg_success",
										"itemType": "text",
										"itemValue": "You've updated your call settings",
										"itemAttributes": {}
									},
									{
										"itemKey": "bannermsg_failure",
										"itemType": "text",
										"itemValue": "Your changes cannot be saved due to system error. Please try again later.",
										"itemAttributes": {}
									},
									{
										"itemKey": "termsUrl",
										"itemType": "link",
										"itemValue": "Terms and Conditions",
										"itemAttributes": {},
										"actionKey": "termsLinkAction"
									},
									{
										"itemKey": "privacyUrl",
										"itemType": "link",
										"itemValue": "Privacy Policy",
										"itemAttributes": {},
										"actionKey": "privacyLinkAction"
									},
									{
										"itemKey": "notEligible_description",
										"itemType": "text",
										"itemValue": "You can learn more about managing your Call Filter subscription in Add-ons & Apps.",
										"itemAttributes": {}
									},
									{
										"itemKey": "notEligible_errorBanner",
										"itemType": "text",
										"itemValue": "We can't complete your request right now.",
										"itemAttributes": {}
									},
									{
										"itemKey": "backBtn",
										"itemType": "button",
										"itemValue": "Back to Call Filter",
										"itemAttributes": {},
										"actionKey": "backAction"
									},
									{
										"itemKey": "addOnBtn",
										"itemType": "button",
										"itemValue": "Visit add-ons",
										"itemAttributes": {},
										"actionKey": "addOnAction"
									}
								]
							}
						],
						"data": {
							"header": "Screen incoming calls and block spam for free",
							"description": "Auto-block spam calls by risk level.#Suspected spam calls that aren't auto-blocked will be labeled on your incoming call screen to help you decide if you want to answer.#Please note calls you want to receive may be auto-blocked by Call Filter, causing you to missing them.",
							"linkTermsUrl": "https://www.verizonwireless.com/support/call-filter-legal/",
							"linkPrivacyUrl": "https://www.verizon.com/about/privacy/full-privacy-policy",
							"linkDescription": "By turning on Call Filter, you agree to our",
							"encryptedMdn": "2183307889",
							"callTreatment": {
								"criteria": "low",
								"action": "none"
							},
							"criteriaList": [
								{
									"header": "High-risk only",
									"label": "Potential fraud. Number is usually disguised as private or anonymous.",
									"criteria": "high",
									"value": "High-risk only"
								},
								{
									"header": "Medium and high-risk",
									"label": "Potential spam and fraud. Number may be disguised.",
									"criteria": "medium"
								},
								{
									"header": "All spam calls",
									"label": "Any number that is identified as spam.",
									"criteria": "low"
								}
							],
							"actionList": [
								{
									"header": "No ring and no voicemail",
									"action": "block",
									"label": "Call is blocked and sent directly to voice mail."
								},
								{
									"header": "Allow voicemail",
									"action": "voicemail",
									"label": "Call is blocked and not sent to voice mail."
								}
							],
							"notification": {
								"header": "Call Filter notifications",
								"label": "Get notifications of auto-blocked calls using the",
								"linkName": "Call Filter App",
								"linkUrl": "https://play.google.com/store/apps/details?id=com.vzw.ecid&hl=en_US",
								"hyperLinkRequired": true
							},
							"nonAppCapableInd": "N",
							"loggedInMdnOsType": "Android",
							"currentManageCFMdnOsType": "Android",
							"eligibleMtnInd": "Y",
							"isCallFilterTurnOn": true
						}
					}
				]
			}
		]
	}
}

export const callfilterSettingsPageMockResponse1 = {
	"responseInfo": {
		"timeStamp": "21-12-2023 11:22:42",
		"correlationId": "",
		"responseCode": "00",
		"responseMessage": "SUCCESS",
		"sectionErrors": []
	},
	"body": {
		"pageAttributes": [
			{
				"itemKey": "pageTitle",
				"itemValue": "Call filter",
				"itemAttributes": {}
			},
			{
				"itemKey": "hashedAccountNumber",
				"itemValue": "##HASHED_ACCTNO##",
				"itemType": "text",
				"itemAttributes": {}
			},
			{
				"itemKey": "hashedMdn",
				"itemValue": "##HASHED_MDN##",
				"itemType": "text",
				"itemAttributes": {}
			}
		],
		"sections": [
			{
				"sectionIndex": "0",
				"sectionId": "devicesCallFilterMainSection",
				"sectionType": "devicesCallFilterMainSection",
				"sectionComponentId": "GenericComponent",
				"sections": [
					{
						"sectionIndex": "1",
						"sectionId": "devicesCFSettingsPageSection",
						"sectionType": "devicesCFSettingSection",
						"actions": [
							{
								"actionType": "http",
								"actionValue": "##HOST_NAME##/support/call-filter-legal/",
								"actionKey": "termsLinkAction",
								"clickStream": "terms_link"
							},
							{
								"actionType": "http",
								"actionValue": "##HOST_NAME##/about/privacy/full-privacy-policy",
								"actionKey": "privacyLinkAction",
								"clickStream": "privacy_link"
							},
							{
								"actionType": "http",
								"actionValue": "##HOST_NAME##//ui/hub/secure/overview?flow=1D#/",
								"actionKey": "backAction",
								"clickStream": "back_btn"
							},
							{
								"actionType": "http",
								"actionValue": "##HOST_NAME##//ui/hub/secure/overview?flow=1D#/",
								"actionKey": "backAction",
								"clickStream": "back_btn"
							},
							{
								"actionType": "http",
								"actionValue": "##HOST_NAME##/ui/acct/secure/productApps/",
								"actionKey": "addOnAction",
								"clickStream": "add_on_btn"
							}
						],
						"contents": [
							{
								"contentIndex": "0",
								"contentComponentId": "recentSpamFilterPageContent",
								"items": [
									{
										"itemKey": "header",
										"itemType": "text",
										"itemValue": "Screen incoming calls and block spam for free",
										"itemAttributes": {}
									},
									{
										"itemKey": "description",
										"itemType": "text",
										"itemValue": "Auto-block spam calls by risk level.#Suspected spam calls that aren't auto-blocked will be labeled on your incoming call screen to help you decide if you want to answer.#Please note calls you want to receive may be auto-blocked by Call Filter, causing you to missing them.",
										"itemAttributes": {}
									},
									{
										"itemKey": "linkDescription",
										"itemType": "text",
										"itemValue": "By turning on Call Filter, you agree to our",
										"itemAttributes": {}
									},
									{
										"itemKey": "bannermsg_success",
										"itemType": "text",
										"itemValue": "You've updated your call settings",
										"itemAttributes": {}
									},
									{
										"itemKey": "bannermsg_failure",
										"itemType": "text",
										"itemValue": "Your changes cannot be saved due to system error. Please try again later.",
										"itemAttributes": {}
									},
									{
										"itemKey": "termsUrl",
										"itemType": "link",
										"itemValue": "Terms and Conditions",
										"itemAttributes": {},
										"actionKey": "termsLinkAction"
									},
									{
										"itemKey": "privacyUrl",
										"itemType": "link",
										"itemValue": "Privacy Policy",
										"itemAttributes": {},
										"actionKey": "privacyLinkAction"
									},
									{
										"itemKey": "notEligible_description",
										"itemType": "text",
										"itemValue": "You can learn more about managing your Call Filter subscription in Add-ons & Apps.",
										"itemAttributes": {}
									},
									{
										"itemKey": "notEligible_errorBanner",
										"itemType": "text",
										"itemValue": "We can't complete your request right now.",
										"itemAttributes": {}
									},
									{
										"itemKey": "backBtn",
										"itemType": "button",
										"itemValue": "Back to Call Filter",
										"itemAttributes": {},
										"actionKey": "backAction"
									},
									{
										"itemKey": "addOnBtn",
										"itemType": "button",
										"itemValue": "Visit add-ons",
										"itemAttributes": {},
										"actionKey": "addOnAction"
									}
								]
							}
						],
						"data": {
							"header": "Screen incoming calls and block spam for free",
							"description": "Auto-block spam calls by risk level.#Suspected spam calls that aren't auto-blocked will be labeled on your incoming call screen to help you decide if you want to answer.#Please note calls you want to receive may be auto-blocked by Call Filter, causing you to missing them.",
							"linkTermsUrl": "https://www.verizonwireless.com/support/call-filter-legal/",
							"linkPrivacyUrl": "https://www.verizon.com/about/privacy/full-privacy-policy",
							"linkDescription": "By turning on Call Filter, you agree to our",
							"encryptedMdn": "2183307889",
							"callTreatment": {
								"criteria": "low",
								"action": "none"
							},
							"criteriaList": [
								{
									"header": "High-risk only",
									"label": "Potential fraud. Number is usually disguised as private or anonymous.",
									"criteria": "high",
									"value": "High-risk only"
								},
								{
									"header": "Medium and high-risk",
									"label": "Potential spam and fraud. Number may be disguised.",
									"criteria": "medium"
								},
								{
									"header": "All spam calls",
									"label": "Any number that is identified as spam.",
									"criteria": "low"
								}
							],
							"actionList": [
								{
									"header": "No ring and no voicemail",
									"action": "block",
									"label": "Call is blocked and sent directly to voice mail."
								},
								{
									"header": "Allow voicemail",
									"action": "voicemail",
									"label": "Call is blocked and not sent to voice mail."
								}
							],
							"notification": {
								"header": "Call Filter notifications",
								"label": "Get notifications of auto-blocked calls using the",
								"linkName": "Call Filter App",
								"linkUrl": "https://play.google.com/store/apps/details?id=com.vzw.ecid&hl=en_US",
								"hyperLinkRequired": true
							},
							"nonAppCapableInd": "N",
							"loggedInMdnOsType": "Android",
							"currentManageCFMdnOsType": "Android",
							"eligibleMtnInd": "N",
							"isCallFilterTurnOn": false
						}
					}
				]
			}
		]
	}
}