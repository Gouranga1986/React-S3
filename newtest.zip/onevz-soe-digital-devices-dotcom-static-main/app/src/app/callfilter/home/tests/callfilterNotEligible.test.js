import React from "react";
import "../../../../../config/jest/test-setup";
import "./test-setup";
import { act, render, screen, cleanup, fireEvent, shallow } from "@testing-library/react";
import "@testing-library/jest-dom/extend-expect";
import userEvent from "@testing-library/user-event";
import { Provider } from "react-redux";
import { getHttpClientRequest } from "@vz/react-util";
import configureStore, { history } from "../../../../shared/store/configureStore";
import rootReducer from "../../reducers";
import { persistStore } from 'redux-persist';
import { PersistGate } from 'redux-persist/integration/react';
import CallFilterNotEligible from "../components/callFilterNotEligible/callFilterNotEligible";
import { callfilterSettingsPageMockResponse } from "./callfilterSettingsPageMock";

const store = configureStore(rootReducer);
const persistor = persistStore(store);
const  window = {
    "vzdl":{
        "page":{
            "name" : "not-eligible"
        }
    }
}

jest.mock("@vz/react-util", () => ({
    ...jest.requireActual("@vz/react-util"),
    getHttpClientRequest: jest.fn()
  }));

jest.mock("../../../../shared/services/httpClient", () => ({
    ...jest.requireActual("../../../../shared/services/httpClient"),
    // getHttpClientRequest: jest.fn()
}));


describe("<CallFilterNotEligible />", () => {
    beforeEach(async () => {
        getHttpClientRequest.mockImplementation((url) => {
            return Promise.resolve({ status: 200, data: {...callfilterSettingsPageMockResponse} });
        })
        
        await act(async () => render(
            <Provider store={store}>
                <PersistGate loading={null} persistor={persistor}>
                    <CallFilterNotEligible />
                </PersistGate>
            </Provider>
        ));

    })

    test("it should mount", () => {
        const doc = screen.getByTestId("notEligible");
        expect(doc).toBeInTheDocument();
    });
    test("should receive the response from  API", () => {
        expect(screen.getByTestId("notEligible")).toBeInTheDocument();
    });
    test("it should use the value returned from API", () => {
        expect(screen.getByTestId("notEligible")).toContainHTML("notEligible");
   });


})


