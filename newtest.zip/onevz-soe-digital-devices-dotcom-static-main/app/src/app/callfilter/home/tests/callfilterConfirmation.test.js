import React from "react";
import "../../../../../config/jest/test-setup";
import "./test-setup";
import { act, render, screen, cleanup, fireEvent, shallow } from "@testing-library/react";
import { waitFor } from '@testing-library/dom';
import "@testing-library/jest-dom/extend-expect";
import userEvent from "@testing-library/user-event";
import { Provider } from "react-redux";
import { getHttpClientRequest } from "@vz/react-util";
import configureStore, { history } from "../../../../shared/store/configureStore";
import rootReducer from "../../reducers";
import { persistStore } from 'redux-persist';
import { PersistGate } from 'redux-persist/integration/react';
////import * as deviceActions from "../actions"
import Confirmation from "../components/confirmation/Confirmation";
import { callfilterLandingPageMockResponse } from "./callfilterLandingPageMock";
import CallFilterContainer from "../CallFilterContainer"
//import * as pageActions  from '../actions/pageActions';

const store = configureStore(rootReducer);
const persistor = persistStore(store);

jest.mock("@vz/react-util", () => ({
    ...jest.requireActual("@vz/react-util"),
    getHttpClientRequest: jest.fn()
  }));

jest.mock("../../../../shared/services/httpClient", () => ({
    ...jest.requireActual("../../../../shared/services/httpClient"),
   // getHttpClientRequest: jest.fn()
}));


describe("<Confirmation />", () => {
    beforeEach(async () => {
        getHttpClientRequest.mockImplementation((url) => {
            return Promise.resolve({ status: 200, data: {...callfilterLandingPageMockResponse} });
        })
        
        await act(async () => render(
            <Provider store={store}>
                <PersistGate loading={null} persistor={persistor}>
                    <Confirmation />

                </PersistGate>
            </Provider>
        ));

    })
    test("it should mount", async() => {
        await waitFor(() => {
            const doc = screen.getByTestId("Confirmation");
        expect(doc).toBeInTheDocument();

         },4000);
        
    });
    test("should receive the response from  API", () => {
        expect(screen.getByTestId("Confirmation")).toBeInTheDocument();
    });
    test("it should use the value returned from API", () => {
        expect(screen.getByTestId("Confirmation")).toContainHTML("Confirmation");
   });

})


