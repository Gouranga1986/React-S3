import React from 'react';
import { render, screen, fireEvent } from '@testing-library/react';
import { Provider } from 'react-redux';
import configureStore from 'redux-mock-store';
import CallFilterRecents from '../components/callFilterRecents/callFilterRecents';
import "@testing-library/jest-dom";
import { fetchSpamCallFilter } from '../components/actions/fetchSpamCallFilter';
//import { FETCH_SPAM_CALL_FILTER_BEGIN, FETCH_SPAM_CALL_FILTER_SUCCESS, FETCH_SPAM_CALL_FILTER_FAIL,fetchSpamCallFilter   } from "../components/actions";
import { fetchSpamCallFilterError,fetchSpamCallBegin, fetchSpamCallFilterSuccess } from "../components/actions/fetchSpamCallFilter";
import { useHistory } from 'react-router-dom';
import { object } from 'prop-types';
import { handleClick } from '../../../../../src/shared/utilities/click';
jest.mock("../components/actions/fetchSpamCallFilter", () => ({
  fetchSpamCallFilter: jest.fn()
}));
jest.mock("react-router-dom", () => ({
    useHistory: jest.fn()
}))
jest.mock('../../../../../src/shared/utilities/click', () => ({
  handleClick: jest.fn()
}));
beforeAll(() => {
    global.window.matchMedia = jest.fn().mockImplementation(query => ({
      matches: false,
      media: query,
      onchange: null,
      addListener: jest.fn(),
      removeListener: jest.fn(),
      addEventListener: jest.fn(),
      removeEventListener: jest.fn(),
      dispatchEvent: jest.fn(),
    }));
  });
  describe('CallFilterRecents Component', () => {
    const mockStore = configureStore([]);
    let store;
    const mockPush = jest.fn();
    beforeEach(() => {
        global.window.matchMedia = jest.fn().mockImplementation(query => ({
            matches: false,
            media: query,
            onchange: null,
            addListener: jest.fn(),
            removeListener: jest.fn(),
            addEventListener: jest.fn(),
            removeEventListener: jest.fn(),
            dispatchEvent: jest.fn(),
          }));
          useHistory.mockReturnValue({push : mockPush});
      store = mockStore({
        callTreatment: {
          spamResponse: {
            sections: [
              {
                data: {
                  incomingCallList: [
                    { label: 'All calls', id: 'ALL_CALLS', count: 100 },
                  ],
                  detailsList: [
                    { formattedMTN: '123-456-7890', type: 'Potential spam', date: '01/20/25', time: '10:00 AM', linkHeader: 'Report' },
                  ],
                  pageNumber: 1,
                },
              },
            ],
          },
          errorMessage: null,
        },
      });
      delete window.location;
      window.location = { search: '?id=12345' };
    });
    test('renders component and triggers API call', () => {
      render(
  <Provider store={store}>
  <CallFilterRecents />
  </Provider>
      );
       expect(fetchSpamCallFilter).toHaveBeenCalled();
       expect(screen.getByTestId('callfilterRecentList')).toBeInTheDocument();
    });
    test('renders call details when data is available', () => {
      render(
  <Provider store={store}>
  <CallFilterRecents />
  </Provider>
      );
      expect(screen.getByText('123-456-7890')).toBeInTheDocument();
      expect(screen.getByText('Potential spam')).toBeInTheDocument();
    });
    test('handles dropdown change event', () => {
      render(
  <Provider store={store}>
  <CallFilterRecents />
  </Provider>
      );
      const dropdown = screen.getByTestId('incomingCallList');
      fireEvent.change(dropdown, { target: { value: 'ALL_CALLS' } });
      expect(fetchSpamCallFilter).toHaveBeenCalledWith(expect.any(Function), {
        param1: '12345',
        pageNumber: 1,
        callType: 'ALL_CALLS',
      });
    });
    test('displays error message when available', () => {
      store = mockStore({ callTreatment: { errorMessage: 'Error fetching data' } });
      render(
  <Provider store={store}>
  <CallFilterRecents />
  </Provider>
      );
      expect(screen.getAllByText('Error fetching data').length).toBeGreaterThan(0);
    });
    test('fetches current page records correctly', () => {
        render(
    <Provider store={store}>
    <CallFilterRecents lastPageNumber={5} />
    </Provider>
        );
        const pagination = screen.getByText('123-456-7890');
        fireEvent.click(pagination);
        expect(fetchSpamCallFilter).toHaveBeenCalledWith(expect.any(Function), {
          param1: '12345',
          pageNumber: 1,
          callType: 'ALL_CALLS',
        });
      });
    test('calls navigateToReportPage function on report link click', () => {
        render(
    <Provider store={store}>
    <CallFilterRecents />
    </Provider>
        );
        const reportLink = screen.getByText('Report');
        fireEvent.click(reportLink);
        expect(mockPush).toHaveBeenCalledWith({ pathname: '/report', state: { data: {
          formattedMTN: '123-456-7890',
          type: 'Potential spam',
          date: '01/20/25',
          time: '10:00 AM',
          linkHeader: 'Report',
        } } });
      });
      //spamcallfilter
      test('renders spam filter component when detailsList has items', () => {
        render(
    <Provider store={store}>
    <CallFilterRecents />
    </Provider>
        );
        expect(screen.getByText('123-456-7890')).toBeInTheDocument();
      });
    //   test("calls handleclick", () => {
    //   //  store= mockStore({
    //   //   callTreatment:{
    //   //     spamResponse:{
    //   //       sections: [
    //   //         {
    //   //           data: {
    //   //             incomingCallList:[],
    //   //             detailsList:[],
    //   //             reportanumber:{itemValue: "Report a number", actionKey: "reportNumberAction"},
    //   //           },
    //   //         },
    //   //       ],
    //   //     },
    //   //   },
    //   //  });
    //    render(
    //     <Provider store={store}>
    //     <CallFilterRecents />
    //     </Provider>
    //         );
    //      const reportLink = screen.getByText(/report a number/i);
    //      // const reportLink = await screen.findByText("Report a number")
    //         fireEvent.click(reportLink);
    //         expect(handleClick).toHaveBeenCalledWith(
    //           'reportNumberAction',
    //           expect.anything(),
    //           expect.objectContaining({ itemValue: "Report a number"})
    //         );
    //   })
  });