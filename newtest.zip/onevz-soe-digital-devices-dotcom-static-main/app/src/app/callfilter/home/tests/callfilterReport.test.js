import React from "react";
import "../../../../../config/jest/test-setup";
import "./test-setup";
import { act, render, screen, cleanup, fireEvent, shallow } from "@testing-library/react";
import "@testing-library/jest-dom/extend-expect";
import userEvent from "@testing-library/user-event";
import { Provider } from "react-redux";
import httpClient from "../../../../shared/services/httpClient";
import { getHttpClientRequest } from "@vz/react-util";
import configureStore, { history } from "../../../../shared/store/configureStore";
import rootReducer from "../../reducers";
import { persistStore } from 'redux-persist';
import { PersistGate } from 'redux-persist/integration/react';
import { Button } from '@vds/buttons';
////import * as deviceActions from "../actions"
import { fetchSpamCallFilter, fetchSpamCallFilterError, fetchReportCallFilterError,fetchConfirmationCallFilterError, fetchSpamCallBegin, fetchConfirmationCallFilter } from "../components/actions/reportCallFilter";
import { saveReport } from "../components/actions/saveReport";
import { saveReportBegin, saveReportSuccess, saveReportError } from "../components/actions/saveReport";

import { SAVE_CALL_TREATMENT_BEGIN } from "../components/reducers/callTreatment";
import { saveCallTreatmentBegin, saveCallTreatmentSuccess } from "../components/actions/saveCallTreatment";



import CallFilterReportNumber from "../components/callFilterReportNumber/CallFilterReportNumber";

import { callfilterReportPageMockResponse } from "./callfilterReportPageMock";


const store = configureStore(rootReducer);
const persistor = persistStore(store);


jest.mock("@vz/react-util", () => ({
    ...jest.requireActual("@vz/react-util"),
    getHttpClientRequest: jest.fn()
  }));

jest.mock("../../../../shared/services/httpClient", () => ({
    ...jest.requireActual("../../../../shared/services/httpClient"),
     getHttpClientRequest: jest.fn()
}));
const mockHistoryPush = jest.fn();

jest.mock('react-router-dom', () => ({
    ...jest.requireActual('react-router-dom'),
    useHistory: () => ({
        push: mockHistoryPush
    }),
}));

describe("<CallFilterReportNumber />", () => {
    beforeEach(async () => {
        global.history.push= jest.fn();
        await getHttpClientRequest.mockImplementation((url) => {            
            return Promise.resolve({ status: 200, data: {...callfilterReportPageMockResponse} });
        })
        
        await act(async () => render(
            <Provider store={store}>
                <PersistGate loading={null} persistor={persistor}>
                    <CallFilterReportNumber isFetching={false}/>
                </PersistGate>
            </Provider>
        ));

    })

    test("it should mount", () => {
        const doc = screen.getByTestId("callfilterReportNumber");
        expect(doc).toBeInTheDocument();
   });
    test("should receive the response from  API", () => {
        expect(screen.getByTestId("callfilterReportNumber")).toBeInTheDocument();
    });
    test("it should use the value returned from API", () => {
        expect(screen.getByTestId("callfilterReportNumber")).toContainHTML("callfilterReportNumber");
   });


    it('should test onChange behavior on Textarea', () => {
        
        const input = screen.getByRole('textbox', {id : 'comments'}); // this is sample one , you need to add the role and name value based on what you have.

        fireEvent.change(input, {target: {value: 'a'}})

        
//     const select = screen.getByTestId("selectedSpamCategory");
//     const testingLibrary = screen.getByTestId('selectedSpamCategory', { name: 'Report Number' })
//     const jest = screen.getByTestId('selectedSpamCategory', { name: 'reportnumber' })

//     fireEvent.change(select, { target: { value: 'debtcollector' } })

//     expect(select.value).toBe('debtcollector')
    
 })

 it('should test onChange behavior on Input', () => {
        
    const input = screen.getByRole('input', {id : 'phoneNumber'}); // this is sample one , you need to add the role and name value based on what you have.

    fireEvent.change(input, {target: {value: 'a'}})


})


it('should test on Click of Report button', () => {
        
   // const input = screen.getByRole('button', {name : 'Report'}); 


   // fireEvent.click(input, {target: {value: 'a'}})


//     const onClick = jest.fn();
//   const {getByTestId} = render(
    
//   );
  const toggle = screen.getByRole('button', {name : 'Report'});

  fireEvent.click(toggle);
//   expect(onClick).toHaveBeenCalled();

    //const handleOnClick = jest.fn();

    //const { getByTestId } = render(<Button onClick={onSaveReport} />);
    //const element = screen.getByRole('button', {name : 'Report'});

    //fireEvent.click(element);

    //expect(handleOnClick).toBeCalled();


    // const handleOnClick = jest.fn();

     //const { getByTestId } = render(<Button onClick={handleOnClick} />);
     //const element = getByTestId("button");

     //fireEvent.click(element);

     //expect(handleOnClick).toBeCalled();
    
     //expect(element).toHaveClass("animate-wiggle");


})

it('should test on Click of Cancel button', () => {
        
    const input = screen.getByRole('button', {name : 'Cancel'}); 

    
    
    fireEvent.click(input, {target: {value:'a'}})


})

// it('should test return true when localhost', async() => {
      
//     global.window = Object.create(window);
//     Object.defineProperty(window, 'localhost', {
//         value:{
//             hostname: 'localhost',
//         }

//     });

//     const result=await store.dispatch(fetchSpamCallFilter())
//     expect(result).toEqual({type:'Localhost'});
//    // expect(result).toBe("error");
// })


describe('saveReport True Condition', ()=>{
    it('should dispatch success', ()=>{
        const mockDispatch = jest.fn();
        const payload = "";
        const response = {
            data:{
                responseInfo:{
                    responseCode:'00',
                },
            },
        };

        saveReport(mockDispatch, payload, true, response);

       // expect(mockDispatch).toHaveBeenCalled(saveReportBegin(payload));
        expect(mockDispatch).toHaveBeenCalled();

        // Expected has value: {"response": {"responseInfo": {"responseCode": "00"}}, "type": "callFilter/SAVE_REPORT_SUCCESS"}
    })
    
})

describe('saveReport False Condition', ()=>{
    const callfilterReportPageMockResponse1 = {
        "responseInfo": {
          "timeStamp": "11-08-2023 07:48:23",
          "correlationId": "",
          "responseCode": "99",
          "responseMessage": "SUCCESS",
          "sectionErrors": []
        }
    }
    beforeEach(async () => {
        await getHttpClientRequest.mockImplementation((url) => {            
            return Promise.resolve({ status: 200, data: {...callfilterReportPageMockResponse1} });
        })
        
        await act(async () => render(
            <Provider store={store}>
                <PersistGate loading={null} persistor={persistor}>
                    <CallFilterReportNumber />
                </PersistGate>
            </Provider>
        ));

    })
    it('should not dispatch success', ()=>{
        const mockDispatch = jest.fn();
        const payload = "";
        const response = {
            data:{
                responseInfo:{
                    responseCode:'00',
                },
            },
        };

        httpClient.getHttpClientRequest.mockImplementation((url) => {
            return Promise.reject({ data: 'error' });
        })
        store.dispatch(fetchSpamCallFilterError('fetchSpamCallFilter'));

        saveReport(mockDispatch, payload, true, response);

       // expect(mockDispatch).toHaveBeenCalled(saveReportBegin(payload));
        expect(mockDispatch).toHaveBeenCalled();

        // Expected has value: {"response": {"responseInfo": {"responseCode": "00"}}, "type": "callFilter/SAVE_REPORT_SUCCESS"}
    })

    it('fetchConfirmationCallFilterError with false condition', () => {

        const mockDispatch = jest.fn();      
        const response = {
            data:{
                responseInfo:{
                    responseCode:'99',
                },
            },
        };

        httpClient.getHttpClientRequest.mockImplementation((url) => {
            return Promise.reject({ data: 'error' });
        })
        store.dispatch(fetchConfirmationCallFilterError('fetchConfirmationCallFilterError '));

        fetchConfirmationCallFilter(mockDispatch);

        //expect(mockDispatch).toHaveBeenCalled();
    })
    
})

test('fetchSpamCallFilterError', () => {
    httpClient.getHttpClientRequest.mockImplementation((url) => {
        return Promise.reject({ data: 'error' });
    })
    store.dispatch(fetchSpamCallFilterError('fetchSpamCallFilter'));
})

test('fetchReportCallFilterError', () => {
    httpClient.getHttpClientRequest.mockImplementation((url) => {
        return Promise.reject({ data: 'error' });
    })
    store.dispatch(fetchReportCallFilterError('fetchReportCallFilterError'));
})

test('fetchConfirmationCallFilterError', () => {
    httpClient.getHttpClientRequest.mockImplementation((url) => {
        return Promise.reject({ data: 'error' });
    })
    store.dispatch(fetchConfirmationCallFilterError('fetchConfirmationCallFilterError '));
})
test('saveReportError', () => {
    httpClient.getHttpClientRequest.mockImplementation((url) => {
        return Promise.reject({ data: 'error' });
    })
    store.dispatch(saveReportError('saveReportError'));
})

test('fetchSpamCallBegin', () => {
    httpClient.getHttpClientRequest.mockImplementation((url) => {
        return Promise.resolve({ data: true });
    })
    store.dispatch(fetchSpamCallBegin('fetchSpamCallBegin '));
  })
 
  test('should call  saveCallTreatmentBegin', async () => {
    httpClient.getHttpClientRequest.mockImplementation((url) => {
        return Promise.reject({ data: 'true' });
    })
    store.dispatch(saveCallTreatmentBegin('saveCallTreatmentBegin'));
  });

  test('should call  saveCallTreatmentSuccess', async () => {
    httpClient.getHttpClientRequest.mockImplementation((url) => {
        return Promise.reject({ data: 'true' });
    })
    store.dispatch(saveCallTreatmentSuccess('saveCallTreatmentSuccess'));
  });

  test('should call  saveReportBegin', async () => {
    httpClient.getHttpClientRequest.mockImplementation((url) => {
        return Promise.reject({ data: 'true' });
    })
    store.dispatch(saveReportBegin('saveReportBegin'));
  });

  test('should call  saveReportSuccess', async () => {
    httpClient.getHttpClientRequest.mockImplementation((url) => {
        return Promise.reject({ data: 'true' });
    })
    store.dispatch(saveReportSuccess('saveReportSuccess'));
  });
})
