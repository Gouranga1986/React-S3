export const callfilterSettingsPageMockResponse = {
	"responseInfo": {
		"timeStamp": "21-12-2023 11:22:42",
		"correlationId": "",
		"responseCode": "00",
		"responseMessage": "SUCCESS",
		"sectionErrors": []
	},
	"body": {
		"pageAttributes": [
			{
				"itemKey": "pageTitle",
				"itemValue": "Call filter",
				"itemAttributes": {}
			},
			{
				"itemKey": "hashedAccountNumber",
				"itemValue": "##HASHED_ACCTNO##",
				"itemType": "text",
				"itemAttributes": {}
			},
			{
				"itemKey": "hashedMdn",
				"itemValue": "##HASHED_MDN##",
				"itemType": "text",
				"itemAttributes": {}
			}
		],
		"sections": [
			{
				"sectionIndex": "0",
				"sectionId": "devicesCallFilterMainSection",
				"sectionType": "devicesCallFilterMainSection",
				"sectionComponentId": "GenericComponent",
				"sections": [
					{
						"sectionIndex": "1",
						"sectionId": "devicesCFSettingsPageSection",
						"sectionType": "devicesCFSettingSection",
						"actions": [
							{
								"actionType": "http",
								"actionValue": "##HOST_NAME##/support/call-filter-legal/",
								"actionKey": "termsLinkAction",
								"clickStream": "terms_link"
							},
							{
								"actionType": "http",
								"actionValue": "##HOST_NAME##/about/privacy/full-privacy-policy",
								"actionKey": "privacyLinkAction",
								"clickStream": "privacy_link"
							},
							{
								"actionType": "http",
								"actionValue": "##HOST_NAME##//ui/hub/secure/overview?flow=1D#/",
								"actionKey": "backAction",
								"clickStream": "back_btn"
							},
							{
								"actionType": "http",
								"actionValue": "##HOST_NAME##//ui/hub/secure/overview?flow=1D#/",
								"actionKey": "backAction",
								"clickStream": "back_btn"
							},
							{
								"actionType": "http",
								"actionValue": "##HOST_NAME##/ui/acct/secure/productApps/",
								"actionKey": "addOnAction",
								"clickStream": "add_on_btn"
							}
						],
						"contents": [
							{
								"contentIndex": "0",
								"contentComponentId": "recentSpamFilterPageContent",
								"items": [
									{
										"itemKey": "header",
										"itemType": "text",
										"itemValue": "Screen incoming calls and block spam for free",
										"itemAttributes": {}
									},
									{
										"itemKey": "description",
										"itemType": "text",
										"itemValue": "Auto-block spam calls by risk level.#Suspected spam calls that aren't auto-blocked will be labeled on your incoming call screen to help you decide if you want to answer.#Please note calls you want to receive may be auto-blocked by Call Filter, causing you to missing them.",
										"itemAttributes": {}
									},
									{
										"itemKey": "linkDescription",
										"itemType": "text",
										"itemValue": "By turning on Call Filter, you agree to our",
										"itemAttributes": {}
									},
									{
										"itemKey": "bannermsg_success",
										"itemType": "text",
										"itemValue": "You've updated your call settings",
										"itemAttributes": {}
									},
									{
										"itemKey": "bannermsg_failure",
										"itemType": "text",
										"itemValue": "Your changes cannot be saved due to system error. Please try again later.",
										"itemAttributes": {}
									},
									{
										"itemKey": "termsUrl",
										"itemType": "link",
										"itemValue": "Terms and Conditions",
										"itemAttributes": {},
										"actionKey": "termsLinkAction"
									},
									{
										"itemKey": "privacyUrl",
										"itemType": "link",
										"itemValue": "Privacy Policy",
										"itemAttributes": {},
										"actionKey": "privacyLinkAction"
									},
									{
										"itemKey": "notEligible_description",
										"itemType": "text",
										"itemValue": "You can learn more about managing your Call Filter subscription in Add-ons & Apps.",
										"itemAttributes": {}
									},
									{
										"itemKey": "notEligible_errorBanner",
										"itemType": "text",
										"itemValue": "We can't complete your request right now.",
										"itemAttributes": {}
									},
									{
										"itemKey": "backBtn",
										"itemType": "button",
										"itemValue": "Back to Call Filter",
										"itemAttributes": {},
										"actionKey": "backAction"
									},
									{
										"itemKey": "addOnBtn",
										"itemType": "button",
										"itemValue": "Visit add-ons",
										"itemAttributes": {},
										"actionKey": "addOnAction"
									}
								]
							}
						],
						"data": {
							"header": "Screen incoming calls and block spam for free",
							"description": "Auto-block spam calls by risk level.#Suspected spam calls that aren't auto-blocked will be labeled on your incoming call screen to help you decide if you want to answer.#Please note calls you want to receive may be auto-blocked by Call Filter, causing you to missing them.",
							"linkTermsUrl": "https://www.verizonwireless.com/support/call-filter-legal/",
							"linkPrivacyUrl": "https://www.verizon.com/about/privacy/full-privacy-policy",
							"linkDescription": "By turning on Call Filter, you agree to our",
							"encryptedMdn": "2183307889",
							"callTreatment": {
								"criteria": "low",
								"action": "none"
							},
							"criteriaList": [
								{
									"header": "High-risk only",
									"label": "Potential fraud. Number is usually disguised as private or anonymous.",
									"criteria": "high",
									"value": "High-risk only"
								},
								{
									"header": "Medium and high-risk",
									"label": "Potential spam and fraud. Number may be disguised.",
									"criteria": "medium"
								},
								{
									"header": "All spam calls",
									"label": "Any number that is identified as spam.",
									"criteria": "low"
								}
							],
							"actionList": [
								{
									"header": "No ring and no voicemail",
									"action": "block",
									"label": "Call is blocked and sent directly to voice mail."
								},
								{
									"header": "Allow voicemail",
									"action": "voicemail",
									"label": "Call is blocked and not sent to voice mail."
								}
							],
							"notification": {
								"header": "Call Filter notifications",
								"label": "Get notifications of auto-blocked calls using the",
								"linkName": "Call Filter App",
								"linkUrl": "https://play.google.com/store/apps/details?id=com.vzw.ecid&hl=en_US",
								"hyperLinkRequired": true
							},
							"nonAppCapableInd": "N",
							"loggedInMdnOsType": "Android",
							"currentManageCFMdnOsType": "Android",
							"eligibleMtnInd": "Y",
							"isCallFilterTurnOn": true
						}
					}
				]
			}
		]
	}
  }