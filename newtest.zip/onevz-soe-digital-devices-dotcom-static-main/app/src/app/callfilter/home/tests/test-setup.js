
window.matchMedia = window.matchMedia || function () {
    return {
        matches: false,
        addListener: function () { },
        removeListener: function () { }
    };
};
global.mobileConfig = {
    reactStaticFilePath: "/",
    interstitialApiUrl:"/interstitial", 
    landingApiUrl: "/landing",
    confirmEnrollmentApiUrl: "/confirmEnroll",
    eligibleOffersApiUrl: "/enrollment",
    manageEnrollmentApiUrl: "/manageEnrollment",
    cancelEnrollmentApiUrl: "/cancelEnrollment",
    switchOfferApiUrl: "/switchOffer",
    fiosLoginApiUrl: "/fiosLogin",
    uiLogging: "/soe/digital/uilogging",
    clickStreamLogging: "/soe/digital/clickstream",
    clickstream: "/digital/nsa/nos/gw/mhdiscount/clickstream",
    secureLogging: "/digital/nsa/secure/gw/mhdiscount/clickstream"
}
global.reactGlobals = {};
global.staticFilePath ="";
global.__webpack_public_path__= "";
global.reactGlobals.routeLog = { confirmationShown: true };
global.reactGlobals.envConfig = reactGlobals.envConfig || {};
global.reactGlobals.envConfig.staticUrl = "/";
global.reactGlobals.transitionFallback = true;
global.reactGlobals.session = {
    warningTimer: 0,
    logoutTimer: 1,
    renewSessionURL: '"\/digital\/nsa\/secure\/ui\/oneapp\/status"',
    sessionTimeoutEnabled: false
};
global.reactGlobals.callFilterSettingsApiUrl = 'id=123';
reactGlobals.callFilterSettingsApiUrl = 'id=123';
global.callFilterSettingsApiUrl = 'id=123';
global._dg_channelId = "VZW-DOTCOM-MOB";
global._dg_eReqId = "7aa32279-7ec4-4f09-adfd-de30e2078dd6";
global.pageName = ""; global.flowName = "";
global._currentPageUrl = "/";
global.newrelic = { setCustomAttribute: jest.fn(), noticeError: jest.fn() };
global._vzwTagUrl = "//tags.tiqcdn.com/utag/vzw/main/dev/utag.js"
global.VZTAG_IS_READY = true;
global.vztag = { api: { dispatch: jest.fn() } };
global.vzwDL = JSON.parse("{\"page\":{\"area\":\"\",\"authStatus\":\"authenticated\",\"channel\":\"\/my verizon\",\"condition\":\"\",\"flowName\":\"calling plan change\",\"flowType\":\"\",\"globalId\":\"94a9a1b9d048493abd5754966b9f6e83\",\"hier1\":\"\/my verizon\/postpay\/cpc\/landing\",\"language\":\"english\",\"lineOfBusiness\":\"postpay\",\"platform\":\"desktop\",\"state\":\"\",\"typeIndicator\":\"customer\",\"zipCode\":\"\",\"mlsExp\":\"desktop:northstar\",\"pageName\":\"\/desktop\/my verizon\/postpay\/cpc\/landing\",\"pageType\":\"my verizon\",\"section2\":\"\/my verizon\/postpay\",\"section3\":\"\/my verizon\/postpay\/cpc\",\"dataCenter\":\"\",\"deviceId\":\"\",\"deviceManufacturer\":\"\",\"deviceModel\":\"\",\"deviceType\":\"\",\"deviceValue\":\"\",\"clientId\":\"\",\"categoryName\":\"\",\"appointmentId\":\"\",\"filter\":\"\",\"flowInteraction\":\"\",\"microInteraction\":\"\",\"microType\":\"\",\"mlsContent\":\"\",\"contentGroup\":\"\",\"conversionType\":\"\",\"creditAppNumber\":\"\",\"creditResponse\":\"\",\"deviceFilter\":\"\",\"email\":\"\",\"paymentType\":\"\",\"perContentImpression\":\"\",\"perEngineName\":\"\",\"registrationType\":\"\",\"returnType\":\"\",\"rylToken\":\"\",\"selfServiceType\":\"desktop:cpc:landing\",\"shopPath\":\"\",\"sort\":\"\",\"storeNumber\":\"\",\"subFlowType\":\"\",\"testVersion\":\"\",\"sessionId\":\"\",\"errorMsg\":\"\",\"errorCode\":\"\",\"customerType\":\"\",\"submissionId\":\"\",\"numberofTradeInLines\":\"\",\"jaxEnabled\":\"\",\"softResponse\":\"\",\"hardResponse\":\"\",\"planId\":\"\",\"planName\":\"\",\"vzSelects\":\"\",\"numberShare\":\"\",\"globalSessionId\":\"\",\"accountNumberOfLines\":\"\",\"numberOfLinesChanged\":\"\",\"currentUserPlanId\":\"\",\"paymentMethod\":\"\",\"cpcFlag\":false,\"accBundleFlag\":false,\"events\":\"\",\"promosApplied\":\"\",\"shippingStateZip\":\"\",\"sddFlag\":false,\"deviceDollarsApplied\":\"\",\"accDiscountApplied\":\"\",\"cpcCaseId\":\"\",\"itpUnauthFlow\":false,\"vzCloudBackup\":\"\"},\"authentication\":{\"collectionsInd\":\"N\",\"accountNumber\":\"0271539682-00001\",\"greetingName\":\"PRODMVO\",\"ecpdId\":\"\",\"impId\":\"\",\"impType\":\"\",\"userRole\":\"accountHolder\",\"mdn\":\"9495141535\",\"vzw_survey\":\"0\",\"custType\":\"B2C\",\"vct\":\"\",\"mHash\":\"8B9AA44FFC6115362D3C292DBE730061\",\"eHash\":\"E9C199E693A9F3A763905694EFD859C2\",\"mHash2\":\"f89dc1d7ef173b62dc79d4cda6d7edd8e9cf3a2c79e39cf1fd3cbf8baaae15c1\",\"eHash2\":\"a1c4be7b6b4459719d79bdf5120f30ced8131200fd5944c959c4028f2eb4ffe7\",\"prepayInd\":\"\",\"visHashedAccountNumber\":\"\",\"visHashedMdn\":\"\"}}");	
global.vzdl = JSON.parse("{\"cmp\":{\"all\":\"\"},\"env\":{\"businessUnit\":\"wireless\"},\"error\":{\"code\":\"\"},\"event\":{\"value\":\"\"},\"page\":{\"channel\":\"Account Management\",\"channelSession\":\"94a9a1b9d048493abd5754966b9f6e83\",\"detail\":\"\",\"displayChannel\":\"VZW\",\"flow\":\"calling plan change\",\"name\":\"LANDING_PMD\",\"sourceChannel\":\"VZW\",\"subFlow\":\"\",\"throttle\":\"desktop:northstar\",\"contentFragments\":\"\",\"link\":\"\",\"LQZip\":\"\"},\"platform\":{\"call\":\"\"},\"search\":{\"term\":\"\",\"type\":\"\",\"results\":\"\"},\"support\":{\"issueNumber\":\"\",\"tsaIssueName\":\"\",\"tsaStepName\":\"\"},\"target\":{\"assetsRequested\":\"\",\"assetAttributes\":\"\",\"assetsLeveraged\":\"\",\"abTest\":\"\",\"campaign\":\"\",\"experience\":\"\",\"message\":\"\",\"offer\":\"\",\"cloud\":\"\",\"mktgId\":\"\",\"sandBox\":\"\",\"engagement\":{\"intent\":\"Account Management\",\"id\":\"\",\"offered\":\"\"}},\"txn\":{\"agent\":\"\",\"autoPay\":\"\",\"id\":\"\",\"offer\":\"\",\"discountId\":\"\",\"orderType\":\"\",\"status\":\"\",\"cartId\":\"\",\"outletId\":\"\",\"quoteId\":\"\",\"paymentType\":\"\",\"shippingZip\":\"\",\"shippingTotal\":\"\",\"tradeInQty\":\"\",\"tradeInAmt\":\"\",\"total\":\"\",\"taxAmt\":\"\",\"recurringCharges\":\"\",\"nonRecurringCharges\":\"\",\"futurePayment\":\"\",\"installOptions\":\"\",\"discount\":\"\",\"paymentAmt\":\"\",\"reasonCode\":\"\",\"reviewOption\":\"\",\"accBundleFlag\":\"\",\"cpcFlag\":\"\",\"wishListFlag\":\"\",\"product\":{\"owns\":[],\"current\":[]}},\"user\":{\"existingServices\":\"\",\"account\":\"\",\"accountType\":\"postpay\",\"customerRole\":\"accountHolder\",\"customerType\":\"B2C\",\"numberOfLines\":\"\",\"planType\":\"\",\"authStatus\":\"Logged In\",\"id\":\"\",\"tenure\":\"\",\"prospect\":\"\",\"session\":\"94a9a1b9d048493abd5754966b9f6e83\",\"chatId\":\"\",\"childId\":\"\",\"creditAppNum\":\"\",\"deviceDollars\":\"\",\"zip\":\"\",\"emcAccountId\":\"\",\"emcEmailId\":\"\",\"emcMdn\":\"\",\"productsQualified\":\"\",\"acctId_unhashed\":\"0271539682-00001\",\"custId_unhashed\":\"9495141535\",\"visionAcctID_unhashed\":\"\",\"visionCustID_unhashed\":\"\"},\"utils\":{\"StrategyApiKey\":\"\",\"appApiKey\":\"\",\"pegaCaseId\":\"\",\"athenaSession\":\"\",\"outcome\":\"\",\"pegaOffer\":\"\"}}");
global.vzwAnalytics = { events: { track: jest.fn() } };
global.lob = "vzt";
jest.spyOn(console, 'warn');
console.warn.mockImplementation(() => {});
window.verticalMargin = 0;
window.horizontalMargin=0;

const jsdom = require('jsdom');
const { JSDOM } = jsdom;
const virtualConsole = new jsdom.VirtualConsole();
virtualConsole.on("error", () => {
  // No-op to skip console errors.
});
const dom = new JSDOM(``, { virtualConsole });