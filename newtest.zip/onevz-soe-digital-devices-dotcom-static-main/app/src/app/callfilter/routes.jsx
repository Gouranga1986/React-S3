import React, { Fragment } from 'react';
import { CustomRoute } from './routing/CustomRoute';
//import { GlobalGuard } from './routing/GlobalGuard';
import CallFilterContainer from './home/CallFilterContainer';
import Confirmation from './home/components/confirmation/Confirmation';
import CallFilterReportNumber from './home/components/callFilterReportNumber/CallFilterReportNumber';


const Routes = ({ reduxStore }) => {
  const routeConfig = (
    <div>
      <CustomRoute exact path="/" component={CallFilterContainer} />
      <CustomRoute exact path="/confirmation" component={Confirmation} />
      <CustomRoute exact path="/report" component={CallFilterReportNumber} />
    </div>
  );
  return (<Fragment>{routeConfig}</Fragment>);
};

export default Routes;
