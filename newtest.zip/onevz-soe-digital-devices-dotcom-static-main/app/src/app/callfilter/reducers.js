import { combineReducers } from 'redux';
import callTreatmentReducer from './home/components/reducers/callTreatment';

const rootReducer = combineReducers({
  callTreatment: callTreatmentReducer,
});

export default rootReducer;
