__webpack_public_path__ = staticFilePath || dotcomConfig.reactStaticFilePath || '//ecache.verizonwireless.com/imageFiles/cpc/dotcom/east/';
