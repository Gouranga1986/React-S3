import 'url-search-params-polyfill';
import React, { Suspense, useState, useEffect } from 'react';
//import { bindActionCreators } from 'redux';
import { HashRouter } from 'react-router-dom';
import { createBrowserHistory } from 'history';
import { CookiesProvider } from 'react-cookie';
import Routes from '@pwd/routes';
import Loader from '@shared/components/Loader/Loader';
import { ErrorBoundary, library, SessionTimeoutModal } from '@vz/react-util';
//import { connect } from 'react-redux';
//import * as homeActions from '@pwd/home/components/actions';
//import common from '@shared/utilities/util';
import apiUrl from '@shared/utilities/apiUrl';
export const history = createBrowserHistory();

const App =(props)=>{
  const loadingImg = (<Loader />);

  const[isAuthenticated, setIsAuthenticated] = useState(true);

  useEffect(() => {

    //componentWillMount
    try {
      library.init({ appName: 'Devices', pageName: 'CallFilter', flowName: 'CallFilter' });
    } catch (ex) { }
    
    //componentDidMount
    let path = '';
    const pathArray = window.location.hash.split('/');
    path = pathArray.length > 1 ? pathArray[1].toLowerCase() : '';
    if (path && path === 'confirmation' && !props.isConfirmationFetching) {
      props.homeActions.purgeStore();
      window.location.href = apiUrl().disconnectLanding ? apiUrl().disconnectLanding : '/';
    }

    if (typeof reactGlobals === 'undefined' || reactGlobals === null || !reactGlobals) {
      window.reactGlobals = {};
    }
    reactGlobals.routeLog = reactGlobals.routeLog || {};
    reactGlobals.routeLog = {
      showConfirmation: false,
      confirmationShown: false,
    };

    document.addEventListener('vztagLoaded', handleOmniLoad);

    //componentWillUnmount
    window.removeEventListener('vztagLoaded', handleOmniLoad);

  });

  const removeUrlParams = () => {
    try {
      let finalPath = '';
      const pathArray1 = window.location.href.split('?');
      const pathArray2 = window.location.href.split('#');
      if (pathArray2 && pathArray2.length > 1 && pathArray2[1].length > 1) {
        finalPath += '#' + pathArray2[1];
      }
      if (pathArray1.length > 1) {
        history.replace(finalPath);
      }
    } catch (e) { console.log('App removeUrlParams ERROR---', e); }
  }

  const handleOmniLoad = (e) => {
    try {
      if (vztag?.api?.dispatch) {
        vztag.api.dispatch();
      }
    } catch (ex) { console.log('ex:' + ex); }
  }
  
  //componentDidCatch(error, info) {
 //   console.log('CDC', error);
  //}

  if (isAuthenticated) {
    return (
      <div data-testid="appTestId">
        <Suspense fallback={loadingImg}>
          <HashRouter history={history}>
            <CookiesProvider>
              <div className="main grid">
                <section>
                  <ErrorBoundary init>
                    <Routes reduxStore={props.reduxStore} />
                    {reactGlobals && reactGlobals.session && reactGlobals.session.sessionTimeoutEnabled
                      && (
                        <SessionTimeoutModal />
                      )
                    }
                  </ErrorBoundary>
                </section>
              </div>
            </CookiesProvider>
          </HashRouter>
        </Suspense>
      </div>
    );
  }
  return <div data-testid="appTestId">{loadingImg}</div>;

}


/*class App extends Component {
  constructor(props) {
    super(props);
    this.state = {
      isAuthenticated: true,
    };
  }

  componentWillMount() {
    try {
      library.init({ appName: 'Devices', pageName: 'CallFilter', flowName: 'CallFilter' });
    } catch (ex) { }
  }

  componentDidMount() {
    let path = '';
    const pathArray = window.location.hash.split('/');
    path = pathArray.length > 1 ? pathArray[1].toLowerCase() : '';
    if (path && path === 'confirmation' && !this.props.isConfirmationFetching) {
      this.props.homeActions.purgeStore();
      window.location.href = apiUrl().disconnectLanding ? apiUrl().disconnectLanding : '/';
    }

    if (typeof reactGlobals === 'undefined' || reactGlobals === null || !reactGlobals) {
      window.reactGlobals = {};
    }
    reactGlobals.routeLog = reactGlobals.routeLog || {};
    reactGlobals.routeLog = {
      showConfirmation: false,
      confirmationShown: false,
    };

    document.addEventListener('vztagLoaded', this.handleOmniLoad);
  }

  componentWillUnmount() {
    window.removeEventListener('vztagLoaded', this.handleOmniLoad);
  }

  removeUrlParams() {
    try {
      let finalPath = '';
      const pathArray1 = window.location.href.split('?');
      const pathArray2 = window.location.href.split('#');
      if (pathArray2 && pathArray2.length > 1 && pathArray2[1].length > 1) {
        finalPath += '#' + pathArray2[1];
      }
      if (pathArray1.length > 1) {
        history.replace(finalPath);
      }
    } catch (e) { console.log('App removeUrlParams ERROR---', e); }
  }

  handleOmniLoad = (e) => {
    try {
      if (vztag?.api?.dispatch) {
        vztag.api.dispatch();
      }
    } catch (ex) { console.log('ex:' + ex); }
  }

  componentDidCatch(error, info) {
    console.log('CDC', error);
  }

  render() {
    if (this.state.isAuthenticated) {
      return (
        <div data-testid="appTestId">
          <Suspense fallback={loadingImg}>
            <HashRouter history={history}>
              <CookiesProvider>
                <div className="main grid">
                  <section>
                    <ErrorBoundary init>
                      <Routes reduxStore={this.props.reduxStore} />
                      {reactGlobals && reactGlobals.session && reactGlobals.session.sessionTimeoutEnabled
                        && (
                          <SessionTimeoutModal />
                        )
                      }
                    </ErrorBoundary>
                  </section>
                </div>
              </CookiesProvider>
            </HashRouter>
          </Suspense>
        </div>
      );
    }
    return <div data-testid="appTestId">{loadingImg}</div>;
  }
}
*/

export default App;
