import React, { Suspense } from 'react'
import { Loader } from '@vds/loaders'
import { QueryClient, QueryClientProvider } from 'react-query' // tanstack query has webpack dependency issue
import { ErrorBoundary } from 'react-error-boundary'
import Routes from './routes'
import ErrrorPage from './components/ErrorPage'
import { BrowserRouter } from 'react-router-dom'
import { VDSManager } from '@vds-core/utilities'
import { ReactQueryDevtools } from 'react-query/devtools'
import { nativeSetTitleOnly } from '@shared/utilities/native'
import { isMVA } from './helpers/getChannel'

// set vzdl flow name
window.vzdl.page.flow = "Device Repair"

if(isMVA) {
  nativeSetTitleOnly('Schedule Device Repair')
  window.vzdl.page.inApp = 'MVA'
}

// set jenkins build info
window.buildInfo = {
  buildDate: process?.env?.buildDate,
  buildNumber: process?.env?.buildNumber,
  branch: process?.env?.branch,
}

const PROD_URL = '/digital/nsa/secure/ui/devices/clnr/schedule-device-repair'
const basename = process?.env?.isDev === 'true' ? '/' : PROD_URL
console.log('basename', basename, 'env', process?.env?.isDev)

export const queryClient = new QueryClient({
  defaultOptions: {
    queries: {
      staleTime: 300000,
      refetchOnWindowFocus: false,
      refetchOnMount: false,
    },
  },
})

const App = () => {
  
  return (
    <QueryClientProvider client={queryClient}>
      <VDSManager />
      <BrowserRouter basename={basename}>
        <ErrorBoundary fallbackRender={ErrrorPage}>
          <Suspense fallback={<Loader />}>
            <Routes />
          </Suspense>
        </ErrorBoundary>
      </BrowserRouter>
      <ReactQueryDevtools initialIsOpen={false} />
    </QueryClientProvider>
  )
}

export default App
