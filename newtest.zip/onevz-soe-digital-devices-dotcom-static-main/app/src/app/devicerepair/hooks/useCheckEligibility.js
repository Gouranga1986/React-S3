import { useMutation } from 'react-query'
import { checkEligibility } from '@devicerepair/services/issueDetails'
import useStore from '@devicerepair/stores/useStore'
import { useCLNRContext } from './useInitiateClnr'

const useCheckEligibility = () => {
  const { store } = useStore()
  const clnrContext = useCLNRContext()

  const { selectedMTN, primaryReason, secondaryReason } = store

  return useMutation({
    mutationFn: () => {
      const { cartId } = clnrContext?.cartInfo || {}

      const data = {
        cartId,
        mtn: selectedMTN,
        primaryReasonCode: primaryReason?.code,
        secondaryReasonCode: secondaryReason?.code,
      }

      return checkEligibility(data)
    },
  })
}

export default useCheckEligibility
