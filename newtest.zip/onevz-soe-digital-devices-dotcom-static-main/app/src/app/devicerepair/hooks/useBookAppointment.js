import { useMutation } from 'react-query'
import { bookAppointment, validateCartAndCheckout } from '@devicerepair/services/bookAppointment'
import { useCLNRContext } from './useInitiateClnr'
import useNotifications from '@devicerepair/stores/useNotifications'
import commonConfig from '@devicerepair/config/common.json'

const useBookAppointment = () => {
  const clnrContext = useCLNRContext()
  const addNotification = useNotifications((store) => store?.addNotification)

  return useMutation({
    mutationFn: async (data) => {
      const { cartId } = clnrContext?.cartInfo || {}
      const { cartCreator, processingMTN, accountNumber } = clnrContext?.customerInfo || {}
      const { caseId } = clnrContext || {}
      const correlationId = clnrContext?.correlationId

      const cartInfo = {
        processingMTN,
        cartCreator,
        cartId,
        caseId,
      }

      const validateCartAndCheckoutResponse = await validateCartAndCheckout(cartInfo)

      if (validateCartAndCheckoutResponse?.data?.body?.errors) {
        if (validateCartAndCheckoutResponse?.data?.body?.errors?.length) {
          const message = validateCartAndCheckoutResponse?.data?.body?.errors?.[0]?.message || ''
          addNotification({
            type: 'error',
            title: 'Failed to validate cart.',
            subtitle: message,
          })
          throw new Error(message)
        }
      }

      const orderDetails = validateCartAndCheckoutResponse?.data?.body?.serviceBody?.serviceResponse?.context?.validateOrder?.orderDetails
   
      if (!orderDetails) {
        const message =  "Missing order details"
          addNotification({
            type: 'error',
            title: 'Failed to validate cart.',
            subtitle: message
          })
          throw new Error(message)
      }

      const payload = {
        accountNumber,
        correlationId,
        caseId,
        cartCreator,
        processingMTN,
        locationCode : commonConfig?.locationCode,
        email: data?.email,
        cartId,
      }

      const response = await bookAppointment(payload)
      return response?.data?.body?.serviceBody?.serviceResponse
    },
  })
}

export default useBookAppointment
