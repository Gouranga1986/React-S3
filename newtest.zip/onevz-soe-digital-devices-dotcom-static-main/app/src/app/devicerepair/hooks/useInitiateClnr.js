import { useQuery } from 'react-query'
import { initiateClnr } from '@devicerepair/services/initiateClnr'
import useStore from '@devicerepair/stores/useStore'

const enableCLNRFlow = window?.enableCLNRFlow

const useInitiateClnr = () => {
  const { store } = useStore()
  const { selectedMTN } = store

  return useQuery({
    queryKey: ['initiateCnlr', selectedMTN],
    queryFn: () => initiateClnr(selectedMTN),
    select: (response) => response?.data,
    useErrorBoundary: true,
    enabled: !!selectedMTN && enableCLNRFlow
  })
}

export const useCLNRContext = () => {
  const { data: initiateCnlr } = useInitiateClnr()

  const context = initiateCnlr?.serviceBody?.serviceResponse?.context
  const correlationId = initiateCnlr?.serviceHeader?.correlationId
  return {
    ...context,
    correlationId,
  }
}

export default useInitiateClnr
