import { useMutation } from 'react-query'
import { validateAddress } from '@devicerepair/services/storeRepair'

export const useValidateAddress = () => {
  return useMutation({
    mutationFn: async (data) => {
      const response = await validateAddress(data)
      return response?.data?.data?.validateAddress
    }
  })
}
