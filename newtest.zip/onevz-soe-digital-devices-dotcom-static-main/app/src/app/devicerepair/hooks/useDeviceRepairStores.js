import { useQuery } from 'react-query'
import { getDeviceRepairStores } from '@devicerepair/services/storeRepair'
import useStore from '@devicerepair/stores/useStore'
import { useCLNRContext } from './useInitiateClnr'
import useRetrieveCLNRInfo from './useRetrieveCLNRInfo'
import dayjs from 'dayjs'
import commonConfig from '@devicerepair/config/common.json'


export const useDeviceRepairStores = (validAddress = false, variables) => {
  const { setStore } = useStore()
  const clnrContext = useCLNRContext()
  const { data: CLNRInfo } = useRetrieveCLNRInfo()
  const shipping = CLNRInfo?.cart?.lineDetails?.lineInfo?.[0]?.itemsInfo?.[0]?.shipping

  const onSuccess = (response) => {
    const repaireStores = response?.appointmentList?.store
    const selectedStore = repaireStores?.[0]
    const selectedAppointmentDate = selectedStore?.appointmentWindow?.[0]
    const selectedAppointmentTime = selectedAppointmentDate?.appointmentTime?.[0]

    setStore({ selectedStore, selectedAppointmentDate, selectedAppointmentTime })
  }

  return useQuery({
    queryKey: ['repair-stores', variables],
    queryFn: () => {
      const { cartId, lines } = clnrContext?.cartInfo || {}

      const data = {
        deviceSymptom: 1,
        windowRangeStart: dayjs().format('YYYY-MM-DD'), 
        locationCode : commonConfig?.locationCode,
        appleEligibleInd: lines?.[0]?.appleEligibleInd,
        cartId,
      }

      if (!variables?.zipCode) {
        data.address = {
          addressLine1: shipping?.address?.addressLine1,
          addressLine2: shipping?.address?.addressLine2,
          city: shipping?.address?.city,
          state: shipping?.address?.state,
          zipCode: shipping?.address?.zipCode,
          zipCodePlus4: shipping?.address?.zipCode4,
        }
      } else {
        data.address = {
          addressLine1: '',
          addressLine2: '',
          city: '',
          state: '',
          zipCode: variables?.zipCode,
          zipCodePlus4: '',
        }
      }

      return getDeviceRepairStores(data)
    },
    select: (response) => response?.data?.data,
    enabled: validAddress && !!shipping?.address,
    onSuccess,
    useErrorBoundary: true,
  })
}
