import { useHistory } from 'react-router-dom'

export const usePageName = () => {
  const history = useHistory()

  // split pathname by '/' and filter out empty strings
  return history?.location?.pathname?.split('/')?.filter(p => !!p)?.[0] || 'unknown'
}
