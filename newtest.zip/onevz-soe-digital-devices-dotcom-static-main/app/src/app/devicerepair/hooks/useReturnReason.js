import { useMutation, useQuery } from 'react-query'
import { getReasonCodes, getCLNREligibilityAndWarranty } from '@devicerepair/services/issueDetails'
import { useCLNRContext } from './useInitiateClnr'
import useStore from '@devicerepair/stores/useStore'
import useNotifications from '@devicerepair/stores/useNotifications'

export const useCLNREligibilityandWarranty = () => {
  const clnrContext = useCLNRContext()

  const addNotification = useNotifications((store) => store?.addNotification)
  const reset = useNotifications((store) => store?.reset)

  return useMutation({
    mutationKey: ['chcekCLNREligibility'],
    mutationFn: async (deviceId) => {
      reset()
      const response = await getCLNREligibilityAndWarranty({ clnrContext, deviceId })

      if (response?.data?.errors?.length) {
        const message = response?.data?.errors?.[0]?.message || 'Failed to update clrn info.'
        addNotification({
          type: 'error',
          title: 'Failed to validate eligibility.',
          subtitle: message,
        })
        throw new Error(message)
      }

      const { context } = response?.data?.serviceBody?.serviceResponse || {}
      const { clnrEligibility } = context?.cartInfo?.lines?.[0] || {}
      const isEligible = clnrEligibility === 'Y'

      return {
        ...response?.data,
        isEligible,
      }
    },
  })
}

export const useReturnReason = () => {
  const clnrContext = useCLNRContext()
  const { store } = useStore()
  const { selectedMTN } = store

  return useQuery({
    queryKey: ['get-reason-code', selectedMTN],
    queryFn: getReasonCodes,
    select: (response) => response?.data?.data,
  })
}

export const usePrimaryReason = () => {
  const { data } = useReturnReason()
  const returnReason = data?.returnType?.[0]?.returnReason
  const [otherReturnType] = returnReason?.filter(
    (returnReason) => returnReason?.returnReasonType === 'Others'
  )
  return otherReturnType?.primaryReasons?.map((primaryReason) => ({
    ...primaryReason,
    id: `Others-${primaryReason?.code}`,
    returnReasonType: returnReason?.returnReasonType,
  }))
}

export default useReturnReason
