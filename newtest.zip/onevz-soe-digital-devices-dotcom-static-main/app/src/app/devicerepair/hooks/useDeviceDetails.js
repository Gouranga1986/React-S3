import { useQuery } from 'react-query'
import { useCLNRContext } from './useInitiateClnr'
import { getDeviceDetails } from '@devicerepair/services/eligible'

const useDeviceDetails = () => {
  const clnrContext = useCLNRContext()
  const { cartId } = clnrContext?.cartInfo || {}

  return useQuery({
    queryKey: ['getDeviceDetails', cartId],
    queryFn: () => {
      const data = { cartId }
      return getDeviceDetails(data)
    },
    select: (response) => response?.data,
    enabled: !!cartId,
  })
}

export default useDeviceDetails
