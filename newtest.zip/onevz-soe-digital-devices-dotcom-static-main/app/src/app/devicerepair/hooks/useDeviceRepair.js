import { useQuery } from 'react-query'
import { getMTNs } from '@devicerepair/services/landing'
import useInitiateClnr from './useInitiateClnr'

const useDeviceRepair = () => {
  const { data: initiateClnr } = useInitiateClnr()

  return useQuery({
    queryKey: ['get-device-repair'],
    queryFn: () => {
      if (initiateClnr?.errors?.length) throw new Error(initiateClnr?.errors?.[0]?.message)

      return getMTNs()
    },
    select: (response) => response?.data?.body,
    enabled: !!initiateClnr,
    useErrorBoundary: true,
  })
}

export const useDeviceRepairContent = () => {
  const { data: deviceRepair } = useDeviceRepair()

  return deviceRepair?.content?.steps
}

export const useMTNs = () => {
  const { data: deviceRepair } = useDeviceRepair()
  const { mtns = [] } = deviceRepair?.data?.customerProfile?.billAccounts?.[0] || {}
  return mtns
}

export default useDeviceRepair
