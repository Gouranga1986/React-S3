import { useMutation } from 'react-query'
import { updateAddress } from '@devicerepair/services/shippingAddress'
import { useCLNRContext } from './useInitiateClnr'
import useRetrieveCLNRInfo from '@devicerepair/hooks/useRetrieveCLNRInfo'
import useNotifications from '@devicerepair/stores/useNotifications'

export const useUpdateAddress = () => {
  const clnrContext = useCLNRContext()
  const { data: CLNRInfo } = useRetrieveCLNRInfo()
  const addNotification = useNotifications((store) => store?.addNotification)
  const resetNotifications = useNotifications((store) => store?.reset)

  return useMutation({
    mutationFn: async (data) => {
      const { cartId } = clnrContext?.cartInfo || {}
      const { cartCreator, processingMTN, accountNumber } = clnrContext?.customerInfo || {}
      const { caseId } = clnrContext || {}
      const userInfo = CLNRInfo?.cart?.lineDetails?.lineInfo?.[0]?.serviceInfo?.primaryUserInfo
      const phoneNumber = CLNRInfo?.cart?.lineDetails?.lineInfo?.[0]?.mtnDetails?.mobileNumber

      const payload = {
        accountNumber,
        caseId,
        cartCreator,
        processingMTN,
        cartId,
        isFwaServiceAddress: false,
        address: {
          ...data,
          streetName: data?.street,
          addressLine1: data?.street,
          firstName: userInfo?.firstName,
          lastName: userInfo?.lastName,
          emailId: userInfo?.emailId,
          phoneNumber,
          apartmentNo: '',
          streetNumber: '',
          addressType: 'R',
          addressLine2: '',
          poBoxNo: '',
          ruralDelNo: '',
          zipCode4: '',
          countryCode: '',
          fipsCode: '',
          firmName: '',
        },
      }

      resetNotifications()
      const response = await updateAddress(payload)

      const { data: responseData, errors = [] } = response?.data?.body || {}

      if (errors?.length > 0) {
        const error = errors?.[0]
        addNotification({
          type: 'error',
          title: 'Failed to update address',
          subtitle: error?.message,
        })
        throw new Error(error?.message)
      }


      return responseData
    },
  })
}
