import { useMutation } from 'react-query'
import { useCLNRContext } from './useInitiateClnr'
import { updateClnrInfoDetails } from '@devicerepair/services/storeRepair'
import useStore from '@devicerepair/stores/useStore'
import dayjs from 'dayjs'
import useNotifications from '@devicerepair/stores/useNotifications'

export const useUpdateClnrInfoDetails = () => {
  const clnrContext = useCLNRContext()
  const { store } = useStore()
  const addNotification = useNotifications((store) => store?.addNotification)
  const reset = useNotifications((store) => store?.reset)

  return useMutation({
    mutationKey: 'update-clnr-info-details',
    mutationFn: async () => {
      reset()

      const {
        primaryReason,
        secondaryReason,
        selectedStore,
        selectedAppointmentDate,
        selectedAppointmentTime,
        additionalInfo,
      } = store
      const { cartId } = clnrContext?.cartInfo || {}
      const { cartCreator, accountNumber } = clnrContext?.customerInfo || {}
      const { caseId } = clnrContext || {}

      const payload = {
        caseId,
        accountNumber,
        cartCreator,
        processStep: 'ReturnReason',
        processAction: 'updateReturnReason',
        cartInfo: {
          itemType: 'CLNR-REASON-INFO',
          cartId,
          action: 'UPDATE',
          intendType: 'CLNR',
          triggerPricingValidation: false,
          lines: [
            {
              mtn: cartCreator,
              depletionType: 'L',
              clnrInfo: {
                symptom: additionalInfo,
                isEWServiceFeeCharged: false,
                isDeviceRepaireEligible: true,
                primaryReasonInfo: {
                  reasonCode: primaryReason?.code,
                  reasonDescription: primaryReason?.description,
                },
                secondaryReasonInfo: {
                  reasonCode: secondaryReason?.code,
                  reasonDescription: secondaryReason?.description,
                },
                appointmentInfo: {
                  appointmentId: selectedStore?.storeId,
                  appointmentTimeFrame: `${selectedAppointmentTime?.startTime}-${selectedAppointmentTime?.endTime}`,
                  appointmentDate: dayjs(selectedAppointmentDate?.appointmentDate).format(
                    'YYYY-MM-DD'
                  ),
                  appointmentDescription: 'instoreType',
                },
              },

              storeInfo: {
                businessName: selectedStore?.businessName,
                vendor: selectedStore?.vendorName,
                storeName: selectedStore?.storeName,
                address: `${selectedStore?.address1}, ${selectedStore?.address2}, ${selectedStore?.city}, ${selectedStore?.state} ${selectedStore?.postalCode}`,
                storeId: selectedStore?.storeId,
                storePhoneNumber: selectedStore?.phone,
                timeZone: selectedStore?.timeZone,
                drivingDistance: selectedStore?.distance,
                streetName: selectedStore?.address1,
                addressLine2: selectedStore?.address2,
                city: selectedStore?.city,
                state: selectedStore?.state,
                zipCode: selectedStore?.postalCode,
                streetSuite: selectedStore?.address2,
              },
            },
          ],
        },
      }

      const response = await updateClnrInfoDetails(payload)

      if (response?.data?.errors?.length) {
        // const message = response?.data?.errors?.[0]?.message || 'Failed to update clnr info.'
        const message = 'Failed to update clnr info.'
        addNotification({
          type: 'error',
          title: 'Update failed',
          subtitle: message,
        })
        throw new Error(message)
      }

      return response?.data
    },
  })
}
