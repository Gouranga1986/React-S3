// useOnRouteChange.js
import { useEffect } from 'react'
import { useHistory } from 'react-router-dom'

const useOnRouteChange = (callback) => {
  const history = useHistory()

  useEffect(() => {
    const unlisten = history.listen((location, action) => {
      callback?.(location, action) // Invoke the callback on route change
    })

    return () => {
      unlisten() // Clean up the listener when component unmounts
    }
  }, [history, callback])
}

export default useOnRouteChange
