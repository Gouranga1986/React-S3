import { useQuery } from 'react-query'
import { getDevices } from '@devicerepair/services/landing'
import { useMTNs } from './useDeviceRepair'

const useDevicesByMTN = (mtn) => {
  const  mtns = useMTNs()

  return useQuery({
    queryKey: ['devices', mtn],
    queryFn: async () => {
      const { data } = await getDevices(mtn)
      const { mtns } = data?.data?.customerProfile?.billAccounts?.[0] || {}
      const deviceInfo = mtns?.[0]?.equipmentInfos?.[0]?.deviceInfo
      return (mtns?.[0]?.deviceHistory || []).map((mtn) => ({
        ...mtn,
        status: deviceInfo?.deviceId === mtn?.deviceId ? 'Active' : 'Inactive',
      }))
    },
    enabled: !!mtns && !!mtn,
    useErrorBoundary: true,
  })
}

export default useDevicesByMTN
