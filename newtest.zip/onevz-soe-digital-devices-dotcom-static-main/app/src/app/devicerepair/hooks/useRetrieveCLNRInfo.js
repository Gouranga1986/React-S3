import { useQuery } from 'react-query'
import { retrieveCLNRInfo } from '@devicerepair/services/initiateClnr'
import { useCLNRContext } from './useInitiateClnr'

const useRetrieveCLNRInfo = () => {
  const clnrContext = useCLNRContext()
  const { cartId } = clnrContext?.cartInfo || {}

  return useQuery({
    queryKey: ['retrieveCLNRInfo', cartId],
    queryFn: () => {
      const data = { cartId }
      return retrieveCLNRInfo(data)
    },
    select: (response) => response?.data?.data,
    enabled: !!cartId,
  })
}

export default useRetrieveCLNRInfo
