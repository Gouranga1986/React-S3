import { queryClient } from '@devicerepair/app'
import { QueryClientProvider } from 'react-query'

export const QueryProvider = ({ children }) => (
  <QueryClientProvider client={queryClient}>{children}</QueryClientProvider>
)
