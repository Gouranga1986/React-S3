import { getHttpClientRequest, postHttpClientRequest } from '@vz/react-util';
import { channelId } from "./getChannel"

const axiosConfig = {
  withCredentials: true,
  headers: {
    'Content-Type': 'application/json',
    channelId,
  },
}

const post = (url, payload, config) =>
  postHttpClientRequest(url, payload, {
    ...axiosConfig,
    ...config,
  })

const get = (url, payload, config) =>
  getHttpClientRequest(url, {
    ...axiosConfig,
    ...config,
  })

export default {
  post,
  get,
}