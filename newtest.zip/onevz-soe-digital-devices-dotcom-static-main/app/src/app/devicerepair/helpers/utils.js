export const scrollToTop = () => {
  window.scrollTo({
    top: 0,
    behavior: 'smooth',
  })
}

export const isActionSuccess = (statusCode) => {
  const SUCCESS_CODE = '00'
  return statusCode !== SUCCESS_CODE
}

export const parseTemplate = (template, variables) => {
  return template.replace(/##(.*?)##/g, (_, key) => {
      return variables[key] || '';
  });
}