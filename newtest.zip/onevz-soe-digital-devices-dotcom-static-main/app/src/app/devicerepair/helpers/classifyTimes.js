import dayjs from 'dayjs'
import customParseFormat from 'dayjs/plugin/customParseFormat'

dayjs.extend(customParseFormat)


export const classifyTimes = (timeWindows) => {
  const result = { morning: [], afternoon: [], evening: [] }

  timeWindows?.forEach((item) => {
    const dateTime = `${dayjs().format('YYYY-MM-DD')} ${item?.startTime}`
    const hour = dayjs(dateTime, 'YYYY-MM-DD hh:mmA')?.hour()

    if (hour < 12) {
      result.morning.push(item)
    } else if (hour < 17) {
      result.afternoon.push(item)
    } else {
      result.evening.push(item)
    }
  })

  return result
}
