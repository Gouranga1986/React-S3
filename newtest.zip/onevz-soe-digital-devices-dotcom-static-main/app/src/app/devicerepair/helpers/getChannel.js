const DOTCOM = 'VZW-DOTCOM'
const MDOT = 'VZW-DOTCOM-MOB'
const MVA = 'VZW-MFA'

const getChannel = () => {
  const channelId = window?._dg_channelId 
  let isMVO = false
  let isMDOT = false
  let isMVA = false

  switch (channelId) {
    case DOTCOM:
      isMVO = true
      break
    case MDOT:
      isMDOT = true
      break
    case MVA:
      isMVA = true
      break
    default:
      return {}
  }

  return {
    channelId,
    isMDOT,
    isMVA,
    isMVO,
  }
}

export const { channelId, isMDOT, isMVA, isMVO } = getChannel()

export default getChannel
