import '@testing-library/jest-dom/extend-expect'
import { render } from '@testing-library/react'
import React from 'react'
import CarouselWithDeviceSelector, {
  DevicesLoading,
  DeviceCarousel,
} from '../CarouselWithDeviceSelector'
import useDevicesByMTN from '@devicerepair/hooks/useDevicesByMTN'
import { QueryClientProvider } from 'react-query'
import { queryClient } from '@devicerepair/app'

jest.mock('@devicerepair/hooks/useDevicesByMTN')

describe('<DevicesLoading />', () => {
  test('render component', async () => {
    const { getByLabelText } = render(<DevicesLoading />)

    const loader = getByLabelText('loader overlay')
    expect(loader).toBeInTheDocument()
  })
})

describe('<DeviceCarousel />', () => {
  beforeEach(() => {
    useDevicesByMTN.mockImplementation(() => ({
      data: [{}, {}, {}],
      isLoading: false,
    }))
  })

  test('render component', async () => {
    const { getByRole } = render(
      <QueryClientProvider client={queryClient}>
        <DeviceCarousel />
      </QueryClientProvider>
    )
    const carousel = getByRole('group')
    expect(carousel).toBeInTheDocument()
  })

  test('render 3 tiles', async () => {
    const { getAllByRole } = render(
      <QueryClientProvider client={queryClient}>
        <DeviceCarousel />
      </QueryClientProvider>
    )
    const tiles = getAllByRole('button')
    expect(tiles).toHaveLength(3)
  })
})

describe('<CarouselWithDeviceSelector />', () => {
  const title = 'Select which device you want to repair:'

  beforeEach(() => {
    useDevicesByMTN.mockImplementation(() => ({
      data: [{}, {}, {}],
      isLoading: false,
    }))
  })

  test('render component', async () => {
    const { getByText } = render(
      <QueryClientProvider client={queryClient}>
        <CarouselWithDeviceSelector />
      </QueryClientProvider>
    )
    const titleEl = getByText(title)
    expect(titleEl).toBeInTheDocument()
  })
})

describe('<CarouselWithDeviceSelector />', () => {
  beforeEach(() => {
    useDevicesByMTN.mockImplementation(() => ({
      data: [{}, {}, {}],
      isLoading: true,
    }))
  })

  test('loading devices', async () => {
    const { getByLabelText } = render(
      <QueryClientProvider client={queryClient}>
        <CarouselWithDeviceSelector />
      </QueryClientProvider>
    )

    const loader = getByLabelText('loader overlay')
    expect(loader).toBeInTheDocument()
  })
})
