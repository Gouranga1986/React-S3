export { default } from "./Landing";
