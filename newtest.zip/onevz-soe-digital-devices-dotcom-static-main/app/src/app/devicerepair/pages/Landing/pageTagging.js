export const getPageTagging = () => {
  return {
    page: {
      name: 'device selection',
    },
    event: {
      value: "event117"
    }
  }
}
