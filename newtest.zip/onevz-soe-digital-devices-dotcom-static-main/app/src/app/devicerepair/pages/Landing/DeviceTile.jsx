import React from 'react'
import { HStack, Image, Stack } from '@devicerepair/components/Flexify'
import useStore from '@devicerepair/stores/useStore'
import { TileContainer } from '@vds/tiles'
import { Body } from '@vds/typography'
import { useHistory } from 'react-router-dom'
import useSteps from '@devicerepair/stores/useSteps'
import { useCLNREligibilityandWarranty } from '@devicerepair/hooks/useReturnReason'
import phoneImage from "@devicerepair/assets/phone.png"

export const DeviceInfo = ({ device }) => {
  return (
    <Stack gap="16px">
      <Body bold>{device?.productName}</Body>

      <HStack gap="2px">
        <Body bold>Status:</Body>
        <Body>{device?.status}</Body>
      </HStack>

      <HStack gap="2px">
        <Body bold>IMEI:</Body>
        <Body>{device?.deviceId}</Body>
      </HStack>
    </Stack>
  )
}

export const DeviceImage = ({ deviceImage =  phoneImage}) => {
  return (
    <HStack justifyContent="center" width="100%">
      <Image src={deviceImage}  width="auto" height="180px" objectFit="contain" style={{ mixBlendMode: 'multiply' }} />
    </HStack>
  )
}

export const DeviceTile = (props) => {
  const { store, setStore,reset } = useStore()
  const history = useHistory()
  const completeStep = useSteps((state) => state.completeStep)
  const { mutateAsync: checkCLNREligibility } = useCLNREligibilityandWarranty()

  const onTileClick = async (device) => {
    const response = await checkCLNREligibility(device?.deviceId)

    completeStep('landing')
    reset()
    setStore({
      selectedDevice: props?.device,
    })

    if (!response?.isEligible) history.push('/ineligible')
    else history.push('/issue-details')
  }

  return (
    <TileContainer
      {...props}
      padding="16px"
      height="371px"
      width="100%"
      onClick={() => onTileClick(props?.device)}
      data-track={`{"type": "link", "name": "tile-${props?.device?.productName}"}`}
      data-analyticstrack={`tile-${props?.device?.productName}`}
      data-clickstream={`tile-${props?.device?.productName}`}
    >
      <Stack
        gap="32px"
        justifyContent="space-between"
        width="100%"
        marginTop="32px"
        marginBottom="10px"
      >
        <DeviceImage deviceImage={props?.device?.imageSet} />
        <DeviceInfo device={props?.device} />
      </Stack>
    </TileContainer>
  )
}
