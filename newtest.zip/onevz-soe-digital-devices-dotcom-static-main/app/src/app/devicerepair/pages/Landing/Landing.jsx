import React from 'react'
import Page from '@devicerepair/components/Page'
import CarouselWithDeviceSelector from './CarouselWithDeviceSelector'
import Header from '@devicerepair/components/Header'
import useContent from '@devicerepair/stores/useContent'
import { dispatchNotify, sendData, useSetPage } from '@devicerepair/services/tagging'
import { getPageTagging } from './pageTagging'
import { Button } from '@vds/buttons'
import useNotifications from '@devicerepair/stores/useNotifications'
import useStore from '@devicerepair/stores/useStore'
import useDevicesByMTN from '@devicerepair/hooks/useDevicesByMTN'

const Landing = () => {
  const { title, description } = useContent((store) => store?.content?.deviceSelection || {})

  useSetPage(getPageTagging(), { enabled: true })

  return (
    <Page>
      <Header title={title} description={description} />
      <CarouselWithDeviceSelector />
    </Page>
  )
}

export default Landing
