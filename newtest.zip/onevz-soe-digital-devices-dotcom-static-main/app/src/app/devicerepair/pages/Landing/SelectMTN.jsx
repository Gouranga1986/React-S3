import React from 'react'
import { useMTNs } from '@devicerepair/hooks/useDeviceRepair'
import { DropdownSelect } from '@vds/selects'
import useStore from '@devicerepair/stores/useStore'
import { useIsMutating } from 'react-query'
import { formatPhoneNumber } from '@devicerepair/helpers/formater'

const content = {
  dropdownLabel: 'Mobile Device Number (MDN)',
}

const SelectMTN = () => {
  const mtns = useMTNs()
  const { store, setStore, reset } = useStore()
  const isCheckingCLNREligibility = useIsMutating(['chcekCLNREligibility'])

  const onMTNChange = (e) => {
    const selectedMTN = e?.target?.value
    reset();
    setStore({ selectedMTN, selectedDevice: null })
  }

  return (
    <DropdownSelect
      label={content?.dropdownLabel}
      errorText="Select a MDN"
      error={false}
      disabled={!mtns?.length || !!isCheckingCLNREligibility}
      readOnly={false}
      inlineLabel={false}
      width="328px"
      onChange={onMTNChange}
      defaultValue={store?.selectedMTN}
    >
      {mtns?.map(({ mtn }) => (
        <option key={mtn} value={mtn}>
          {formatPhoneNumber(mtn)}
        </option>
      ))}
    </DropdownSelect>
  )
}

export default SelectMTN
