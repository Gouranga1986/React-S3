import { useMTNs } from '@devicerepair/hooks/useDeviceRepair'
import useStore from '@devicerepair/stores/useStore'
import '@testing-library/jest-dom/extend-expect'
import { fireEvent, render } from '@testing-library/react'
import React from 'react'
import SelectMTN from '../SelectMTN'
import { QueryClientProvider } from 'react-query'
import { queryClient } from '@devicerepair/app'

jest.mock('@devicerepair/stores/useStore', () => jest.fn())

jest.mock('@devicerepair/hooks/useDeviceRepair', () => ({
  ...jest.requireActual('@devicerepair/hooks/useDeviceRepair'),
  useMTNs: jest.fn(),
}))

const mtns = [
  {
    mtn: '5703960160',
  },
  {
    mtn: '5703960161',
  },
  {
    mtn: '5703960162',
  },
]

describe('<SelectMTN />', () => {
  let setStore = jest.fn()

  beforeEach(() => {
    useStore.mockImplementation(() => ({
      store: {},
      setStore,
    }))

    useMTNs.mockImplementation(() => mtns)
  })

  test('render component', async () => {
    const { getByRole, getAllByRole } = render(
      <QueryClientProvider client={queryClient}>
        <SelectMTN />
      </QueryClientProvider>
    )

    const selectMTN = getByRole('combobox')
    expect(selectMTN).toBeInTheDocument()

    const options = getAllByRole('option')
    expect(options).toHaveLength(3)
  })

  test('selecting option', async () => {
    const { getByRole } = render(
      <QueryClientProvider client={queryClient}>
        <SelectMTN />
      </QueryClientProvider>
    )
    const selectMTN = getByRole('combobox')
    const selectedOption = mtns?.[1]?.mtn

    fireEvent.change(selectMTN, { target: { value: selectedOption } })

    expect(setStore).toHaveBeenCalledWith({ selectedDevice: null, selectedMTN: selectedOption })
  })
})
