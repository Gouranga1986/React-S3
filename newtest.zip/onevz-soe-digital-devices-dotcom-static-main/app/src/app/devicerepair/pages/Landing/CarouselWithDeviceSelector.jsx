import { Box, Stack } from '@devicerepair/components/Flexify'
import useDevicesByMTN from '@devicerepair/hooks/useDevicesByMTN'
import { Carousel } from '@vds/carousels'
import { Title } from '@vds/typography'
import React, { useMemo } from 'react'
import { DeviceTile } from './DeviceTile'
import SelectMTN from './SelectMTN'
import { Loader } from '@vds/loaders'
import useStore from '@devicerepair/stores/useStore'
import { useResponsiveValue } from '@devicerepair/components/Flexify'
import { useIsMutating } from 'react-query'

const content = {
  title: 'Select which device you want to repair:',
}

export const DevicesLoading = () => {
  return (
    <Box position="relative" width="100%" height="400px">
      <Loader fullscreen={false} active={true} />
    </Box>
  )
}

export const DeviceCarousel = () => {
  const { store } = useStore()
  const layout = useResponsiveValue(['1UP', '3UP', '4UP'])
  const { data: devices, isLoading, dataUpdatedAt } = useDevicesByMTN(store?.selectedMTN)
  devices?.sort((firstdevice,nextdevice)=>{
    if(firstdevice.status==="Active"&& nextdevice.status!=="Active")return -1;
    if(firstdevice.status!=="Active"&& nextdevice.status==="Active")return 1;
    return 0;
  })
  const carouselData = devices?.map((device) => ({ device }))
  const isCheckingCLNREligibility = useIsMutating(['chcekCLNREligibility'])

  if (isLoading) return <DevicesLoading />

  return (
    <Box overflow="hidden" position="relative">
      {!!isCheckingCLNREligibility && <Loader active fullScreen={false} />}

      <Carousel
        key={dataUpdatedAt}
        layout={layout}
        gutter="24px"
        paginationInset="12px"
        paginationDisplay="onHover"
        data={carouselData}
        renderItem={(props) => <DeviceTile {...props} />}
      />
    </Box>
  )
}

const CarouselWithDeviceSelector = () => {
  return (
    <Stack gap="16px">
      <Title size="medium" bold>
        {content?.title}
      </Title>

      <SelectMTN />

      <DeviceCarousel />
    </Stack>
  )
}

export default CarouselWithDeviceSelector
