import '@testing-library/jest-dom/extend-expect'
import { render } from '@testing-library/react'
import React from 'react'
import Landing from '../Landing'
import { QueryClientProvider } from 'react-query'
import { queryClient } from '@devicerepair/app'

describe('<Landing />', () => {

  test('render component', async () => {
    const { getByLabelText } = render(
      <QueryClientProvider client={queryClient}>
        <Landing />
      </QueryClientProvider>
    )

    const loader = getByLabelText('loader overlay')
    expect(loader).toBeInTheDocument()
  })
})
