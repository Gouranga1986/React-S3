import '@testing-library/jest-dom/extend-expect'
import { fireEvent, render, waitFor } from '@testing-library/react'
import React from 'react'
import { DeviceInfo, DeviceImage, DeviceTile } from '../DeviceTile'
import useStore from '@devicerepair/stores/useStore'
import { QueryClientProvider } from 'react-query'
import { queryClient } from '@devicerepair/app'
import { useCLNREligibilityandWarranty } from '@devicerepair/hooks/useReturnReason'

const mockHistoryPush = jest.fn()

jest.mock('@devicerepair/hooks/useReturnReason', () => ({
  ...jest.requireActual('@devicerepair/hooks/useReturnReason'),
  useCLNREligibilityandWarranty: jest.fn(),
}))
jest.mock('@devicerepair/stores/useStore', () => jest.fn())
jest.mock('react-router-dom', () => ({
  ...jest.requireActual('react-router-dom'),
  useHistory: () => ({
    push: mockHistoryPush,
  }),
}))

const deviceInfo = {
  productName: 'iPhone',
  deviceId: '98098098098',
}

describe('<DeviceInfo />', () => {
  test('render component', async () => {
    const { getByText } = render(<DeviceInfo device={deviceInfo} />)

    const deviceName = getByText(deviceInfo.productName)
    expect(deviceName).toBeInTheDocument()

    const deviceId = getByText(deviceInfo.deviceId)
    expect(deviceId).toBeInTheDocument()
  })
})

describe('<DeviceImage />', () => {
  test('render component', async () => {
    const deviceImage =
      'https://ss7.vzw.com/is/image/VerizonWireless/apple-iphone-15-pro-max-256gb-natural-titanium-mu683ll-a-a?hei=262&fmt=webp'
    const { getByRole } = render(<DeviceImage deviceImage={deviceImage} />)

    const deviceImageEl = getByRole('img')
    expect(deviceImageEl).toHaveAttribute('src', deviceImage)
  })
})

const props = {
  device: {
    deviceId: '354003081340362',
    productName: 'Samsung Galaxy S8 Plus Black',
    mtnEffectiveDate: '09/16/2018',
    orderNumber: '20180916171249',
    orderLocation: 'ASURION',
    orderSku: 'SMG955UZKV',
  },
  ariaLabel: ' ',
  aspectRatio: '2:3',
  viewport: 'desktop',
  tabIndex: -1,
  inView: false,
  grouped: true,
  surface: 'light',
}

describe('<DeviceTile />', () => {
  let setStore = jest.fn()
  let checkCLNREligibility

  beforeEach(() => {
    useStore.mockImplementation(() => ({
      store: {},
      setStore,
    }))

    checkCLNREligibility = jest.fn().mockResolvedValue({
      isEligible: true,
    })

    useCLNREligibilityandWarranty.mockReturnValue({
      mutateAsync: checkCLNREligibility,
      isLoading: false,
    })
  })

  test('render component', async () => {
    const { getByRole } = render(
      <QueryClientProvider client={queryClient}>
        <DeviceTile {...props} />
      </QueryClientProvider>
    )

    const tile = getByRole('button')
    expect(tile).toBeInTheDocument()
  })

  test('select device', async () => {
    const { getByRole } = render(
      <QueryClientProvider client={queryClient}>
        <DeviceTile {...props} />
      </QueryClientProvider>
    )
    const tile = getByRole('button')

    fireEvent.click(tile)

    expect(checkCLNREligibility).toHaveBeenCalled()

    await waitFor(() => {
      expect(setStore).toHaveBeenCalled()
      expect(mockHistoryPush).toHaveBeenCalledWith('/issue-details')
    })
  })

  test('not eligible', async () => {
    checkCLNREligibility = jest.fn().mockResolvedValue({
      isEligible: false,
    })

    useCLNREligibilityandWarranty.mockReturnValue({
      mutateAsync: checkCLNREligibility,
      isLoading: false,
    })

    const { getByRole } = render(
      <QueryClientProvider client={queryClient}>
        <DeviceTile {...props} />
      </QueryClientProvider>
    )
    const tile = getByRole('button')

    fireEvent.click(tile)

    expect(checkCLNREligibility).toHaveBeenCalled()

    waitFor(() => {
      expect(mockHistoryPush).toHaveBeenCalled()
      expect(mockHistoryPush).toHaveBeenCalledWith('/ineligible')
    })
  })
})
