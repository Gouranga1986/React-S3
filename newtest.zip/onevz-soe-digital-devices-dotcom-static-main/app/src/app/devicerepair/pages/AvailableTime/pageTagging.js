export const getPageTagging = () => {
  return {
    page: {
      name: 'time selector',
    }
  }
}
