import React from 'react'
import { Button } from '@vds/buttons'
import ActionNav from '@devicerepair/components/ActionNav'
import { useHistory } from 'react-router-dom'
import useSteps from '@devicerepair/stores/useSteps'
import { useResponsiveValue } from '@devicerepair/components/Flexify'
import { useUpdateClnrInfoDetails } from '@devicerepair/hooks/useUpdateClnrInfoDetails'
import { usePageName } from '@devicerepair/hooks/usePageName'
import { scrollToTop } from '@devicerepair/helpers/utils'

const Actions = () => {
  const history = useHistory()
  const completeStep = useSteps((state) => state.completeStep)
  const { mutateAsync: updateClnrInfoDetails } = useUpdateClnrInfoDetails()
  const width = useResponsiveValue(['100%', '226px'])
  const pageName = usePageName()

  const onContinue = async () => {
    completeStep('available-time')
    await updateClnrInfoDetails()
    scrollToTop()
    history.push('/shipping-address')
  }

  return (
    <ActionNav>
      <Button
        width={width}
        onClick={onContinue}
        data-track={`{"type":"link","name": "${pageName}-continue-button"}`}
        data-analyticstrack={`${pageName}-continue-button`}
        data-clickstream={`${pageName}-continue-button`}
      >
        Continue
      </Button>
    </ActionNav>
  )
}
export default Actions
