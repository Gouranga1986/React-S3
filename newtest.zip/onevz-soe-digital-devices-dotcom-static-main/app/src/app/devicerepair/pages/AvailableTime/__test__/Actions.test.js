import '@testing-library/jest-dom/extend-expect'
import { fireEvent, render } from '@testing-library/react'
import React from 'react'
import useStore from '@devicerepair/stores/useStore'
import Actions from '../Actions'
import { useMediaQuery } from '@devicerepair/components/Flexify'

jest.mock('@devicerepair/stores/useStore', () => jest.fn())

jest.mock('@devicerepair/components/Flexify', () => ({
  ...jest.requireActual('@devicerepair/components/Flexify'),
  useMediaQuery: jest.fn(),
}))

const mockHistoryPush = jest.fn()

jest.mock('react-router-dom', () => ({
  ...jest.requireActual('react-router-dom'),
  useHistory: () => ({
    push: mockHistoryPush,
  }),
}))

describe('<Actions />', () => {
  beforeEach(() => {
    useStore.mockImplementation(() => ({
      store: {},
    }))

    useMediaQuery.mockImplementation(() => ({
      isMobile: false,
      isDesktop: true,
    }))
  })

  test('render component ', async () => {
    const { getByRole } = render(<Actions />)
    const continueButton = getByRole('button', { name: 'Continue' })

    expect(continueButton).toBeInTheDocument()
  })

  test('should navigate on continue', async () => {
    const { getByRole } = render(<Actions />)
    const continueButton = getByRole('button', { name: 'Continue' })

    fireEvent.click(continueButton)

    expect(mockHistoryPush).toHaveBeenCalledWith("/shipping-address")
  })
})
