import { Stack } from '@devicerepair/components/Flexify'
import Page from '@devicerepair/components/Page'
import React from 'react'
import Actions from './Actions'
import TimeRange from '../StoreLocator/TimeRange'
import Header from '@devicerepair/components/Header'
import { getPageTagging } from './pageTagging'
import { useSetPage } from '@devicerepair/services/tagging'

const title = 'Choose an available time for this store.'

const AvailableTime = () => {
  useSetPage(getPageTagging(), { enabled: true })
  return (
    <Page>
      <Header title={title} />

      <Stack position="relative" gap={['24px', '16px']}>
        <TimeRange />
        <Actions />
      </Stack>
    </Page>
  )
}

export default AvailableTime
