import AvailableTime from '../AvailableTime'
import useStore from '@devicerepair/stores/useStore'
import '@testing-library/jest-dom/extend-expect'
import { render, fireEvent, waitFor, screen } from '@testing-library/react'
import React from 'react'
import { useMediaQuery } from '@devicerepair/components/Flexify'
import { useDeviceRepairStores } from '@devicerepair/hooks/useDeviceRepairStores'
import { useValidateAddress } from '@devicerepair/hooks/useValidateAddress'
import { QueryClientProvider } from 'react-query'
import { queryClient } from '@devicerepair/app'

jest.mock('@devicerepair/stores/useStore')
jest.mock('@devicerepair/hooks/useDeviceRepairStores')
jest.mock('@devicerepair/hooks/useValidateAddress')

jest.mock('@devicerepair/components/Flexify', () => ({
  ...jest.requireActual('@devicerepair/components/Flexify'),
  useMediaQuery: jest.fn(),
}))

const selectedAppointmentDate = {
  appointmentDate: '07/23/2024',
  appointmentDay: 'FRI',
  appointmentTime: [
    {
      startTime: '10:00AM',
      endTime: '10:30AM',
    },
    {
      startTime: '10:30AM',
      endTime: '11:00AM',
    },
  ],
}

const selectedStore = {
  vendorName: 'UBREAK',
  businessName: 'Asurion Tech Repair & Solutions',
  storeId: '463',
  storeName: 'Surprise',
  distance: '3.7',
  timeZone: 'America/Phoenix',
  city: 'Surprise',
  state: 'AZ',
  phone: '6232257347',
  email: '6232257347',
  drivingDistance: '5.291',
  earliestAppDate: '2024-02-22',
  address2: '111',
  address1: '14155 W. Bell Rd.',
  postalCode: '85374',
  countryCode: 'US',
}

const repairStores = [
  {
    vendorName: 'UBREAK',
    businessName: 'Asurion Tech Repair & Solutions',
    storeId: '463',
    storeName: 'Surprise',
    distance: '3.7',
    timeZone: 'America/Phoenix',
    city: 'Surprise',
    state: 'AZ',
    phone: '6232257347',
    email: '6232257347',
    drivingDistance: '5.291',
    earliestAppDate: '2024-02-22',
    address2: '111',
    address1: '14155 W. Bell Rd.',
    postalCode: '85374',
    countryCode: 'US',
    appointmentWindow: [
      {
        appointmentDate: '07/23/2024',
        appointmentDay: 'FRI',
        appointmentTime: [
          {
            startTime: '10:00AM',
            endTime: '10:30AM',
          },
        ],
      },
      {
        appointmentDate: '07/24/2024',
        appointmentDay: 'SAT',
        appointmentTime: [
          {
            startTime: '10:00AM',
            endTime: '10:30AM',
          },
        ],
      },
    ],
  },
]

describe('<AvailableTime />', () => {
  let setStore = jest.fn()
  let validateAddress = jest.fn()

  beforeEach(() => {
    useStore.mockImplementation(() => ({
      store: {
        selectedAppointmentDate,
        selectedStore,
      },
      setStore,
    }))

    useMediaQuery.mockImplementation(() => ({
      isMobile: false,
      isDesktop: true,
    }))

    useDeviceRepairStores.mockReturnValue({
      data: {
        appointmentList: {
          store: repairStores,
        },
      },
      isLoading: false,
    })

    useValidateAddress.mockReturnValue({
      mutateAsync: validateAddress,
      isLoading: false,
      error: false,
    })
  })

  test('render component', async () => {
    const { getByLabelText } = render(
      <QueryClientProvider client={queryClient}>
        <AvailableTime />
      </QueryClientProvider>
    )

    const loader = getByLabelText('loader overlay')
    expect(loader).toBeInTheDocument()
  })
})
