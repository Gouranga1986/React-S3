import { DropdownSelect } from '@vds/selects'
import React from 'react'
import { Controller } from 'react-hook-form'
import states from '@devicerepair/helpers/states.json'
import { Input } from '@vds4/inputs'
import { Box } from '@devicerepair/components/Flexify'

export const StateField = ({ control, isDisabled }) => {
  return (
    <Box gridArea="state">
      <Controller
        name="state"
        control={control}
        rules={{ required: 'Select a state' }}
        render={({ field, formState: { errors } }) => (
          <DropdownSelect
            label="State"
            error={!!errors?.state}
            errorText={errors?.state?.message}
            disabled={isDisabled}
            width="100%"
            {...field}
          >
            {states?.map((state) => (
              <option key={state}>{state}</option>
            ))}
          </DropdownSelect>
        )}
      />
    </Box>
  )
}

export const StreetField = ({ control, isDisabled }) => {
  return (
    <Controller
      name="street"
      control={control}
      rules={{ required: 'This field is required' }}
      render={({ field, formState: { errors } }) => (
        <Input
          label="Street address"
          error={!!errors?.street}
          errorText={errors?.street?.message}
          disabled={isDisabled}
          {...field}
        />
      )}
    />
  )
}

export const CityField = ({ control, isDisabled }) => {
  return (
    <Box gridArea="city">
      <Controller
        name="city"
        control={control}
        rules={{ required: 'This field is required' }}
        render={({ field, formState: { errors } }) => (
          <Input
            label="City"
            error={!!errors?.city}
            errorText={errors?.city?.message}
            disabled={isDisabled}
            {...field}
          />
        )}
      />
    </Box>
  )
}
export const ZipCodeField = ({ control, isDisabled }) => {
  return (
    <Box gridArea="zipCode">
      <Controller
        name="zipCode"
        control={control}
        rules={{
          required: 'This field is required',
          minLength: {
            message: 'Minimum length of 5',
            value: 5,
          },
          maxLength: {
            message: 'Maximum length of 8',
            value: 8,
          },
        }}
        render={({ field, formState: { errors } }) => (
          <Input
            type="number"
            label="Zip code"
            error={!!errors?.zipCode}
            errorText={errors?.zipCode?.message}
            width="100%"
            disabled={isDisabled}
            {...field}
          />
        )}
      />
    </Box>
  )
}
