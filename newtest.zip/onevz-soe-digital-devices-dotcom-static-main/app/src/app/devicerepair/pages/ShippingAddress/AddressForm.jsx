import { Stack } from '@devicerepair/components/Flexify'
import { Box, Grid, HStack } from '@devicerepair/components/Flexify/Flexify'
import { useUpdateAddress } from '@devicerepair/hooks/useUpdateAddress'
import useSteps from '@devicerepair/stores/useSteps'
import useStore from '@devicerepair/stores/useStore'
import { Loader } from '@vds/loaders'
import { Notification } from '@vds/notifications'
import React, { useEffect } from 'react'
import { useForm } from 'react-hook-form'
import { useHistory } from 'react-router-dom'
import Actions from './Actions'
import { CityField, StateField, StreetField, ZipCodeField } from './FormFields'
import { EditButton, SaveButton } from './SaveAndEdit'
import { dispatchNotify } from '@devicerepair/services/tagging'

const AddressForm = ({ address, isEditing, setIsEditing }) => {
  const { store, setStore } = useStore()
  const history = useHistory()
  const completeStep = useSteps((state) => state.completeStep)
  const { mutateAsync: updateAddress, isLoading } = useUpdateAddress()

  const {
    control,
    handleSubmit,
    formState: { isValid },
    getValues,
    trigger,
  } = useForm({
    defaultValues: address,
    mode: 'onBlur',
  })

  const onSubmit = (shippingAddress) => {
    setStore({ shippingAddress })

    completeStep('shipping-address')
    history.push('/review-appointment')
  }

  const onSave = async () => {
    const isValidated = await trigger()
    if (!isValidated) return

    const shippingAddress = getValues()
    await updateAddress(shippingAddress)
    setStore({ shippingAddress })
    setIsEditing(false)
  }

  const onEditCancel = () => {
    setIsEditing(false)
  }

  return (
    <Stack as="form" role="form" onSubmit={handleSubmit(onSubmit)} gap="32px" position="relative">
      {isLoading && <Loader active fullScreen={false} />}
      
      <Stack maxWidth="384px" gap="12px">
        <StreetField control={control} isDisabled={!isEditing} />
        <Grid
          gap="12px"
          gridTemplateColumns={['1fr 1fr', '1fr 85px 1fr']}
          gridTemplateAreas={[
            `
            "city city" 
            "state zipCode"
            `,
            `"city state zipCode"`,
          ]}
        >
          <CityField control={control} isDisabled={!isEditing} />
          <StateField control={control} isDisabled={!isEditing} />
          <ZipCodeField control={control} isDisabled={!isEditing} />
        </Grid>
      </Stack>

      {isEditing ? (
        <SaveButton onSave={onSave} onCancel={onEditCancel} />
      ) : (
        <EditButton onEdit={setIsEditing} />
      )}

      <Actions isDisabled={isEditing || !isValid} />
    </Stack>
  )
}

export default AddressForm
