import { Box, HStack } from '@devicerepair/components/Flexify'
import { usePageName } from '@devicerepair/hooks/usePageName'
import { TextLink } from '@vds/buttons'
import { Body } from '@vds/typography'
import React from 'react'

export const SaveButton = ({ onSave, isDisabled, onCancel }) => {
  const pageName = usePageName()

  return (
    <HStack gap="16px">
      <Body size="medium"> 
      <TextLink
        data-track={`{"type":"link","name": "${pageName}-save-address-button"}`}
        data-analyticstrack={`${pageName}-save-address-button`}
        data-clickstream={`${pageName}-save-address-button`}
        onClick={onSave}
        disabled={isDisabled}
      >
        Save address
      </TextLink>
      </Body>
      <Body size="medium">
      <TextLink
        data-track={`{"type":"link","name": "${pageName}-cancel-edit-button"}`}
        data-analyticstrack={`${pageName}-cancel-edit-button`}
        data-clickstream={`${pageName}-cancel-edit-button`}
        onClick={onCancel}
        disabled={isDisabled}
      >
         Cancel 
      </TextLink>
      </Body>
    </HStack>
  )
}
export const EditButton = ({ onEdit }) => {
  const pageName = usePageName()

  return (
    <Box>
       <Body size="medium">
      <TextLink
        data-track={`{"type":"link","name": "${pageName}-edit-address-button"}`}
        data-analyticstrack={`${pageName}-edit-address-button`}
        data-clickstream={`${pageName}-edit-address-button`}
        onClick={() => onEdit(true)}
        size="medium"
      >
          Edit address
        
      </TextLink>{' '}
      </Body>
    </Box>
  )
}
