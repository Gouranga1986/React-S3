import ActionNav from '@devicerepair/components/ActionNav'
import { useResponsiveValue } from '@devicerepair/components/Flexify'
import { usePageName } from '@devicerepair/hooks/usePageName'
import { Button } from '@vds/buttons'
import React from 'react'

const Actions = ({ isDisabled }) => {
  const width = useResponsiveValue(['100%', '226px'])
  const pageName = usePageName()

  return (
    <ActionNav>
      <Button
        type="submit"
        width={width}
        disabled={isDisabled}
        data-track={`{"type":"link","name": "${pageName}-continue-button"}`}
        data-analyticstrack={`${pageName}-continue-button`}
        data-clickstream={`${pageName}-continue-button`}
      >
        Continue
      </Button>
    </ActionNav>
  )
}

export default Actions
