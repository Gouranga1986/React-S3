import { Box, HStack, Image, Stack } from '@devicerepair/components/Flexify'
import useStore from '@devicerepair/stores/useStore'
import { Input, TextArea } from '@vds4/inputs'
import React from 'react'
import styled from 'styled-components'
import { ColorTokens } from '@vds-tokens/color'
import useDeviceDetails from '@devicerepair/hooks/useDeviceDetails'
import { formatPhoneNumber } from '@devicerepair/helpers/formater'

const CustomInput = styled(Input)`
  color: ${ColorTokens.palette.gray85.value};
`
export const CustomTextArea = styled(TextArea)`
  color: ${ColorTokens.palette.gray85.value};
  -webkit-text-fill-color: ${ColorTokens.palette.gray85.value};
`

export const ReadOnlyForm = () => {
  const { store } = useStore()
  return (
    <Box width={['100%', '464px']}>
      <Stack gap={['24px', '16px']} width={['100%', '328px']}>
        <CustomInput label="Mobile number" readOnly value={formatPhoneNumber(store?.selectedMTN)} />
        <CustomInput
          label="Device ID / IMEI"
          readOnly
          value={store?.selectedDevice?.deviceId}
          tooltip={{
            children: 'todo: tooltip message',
          }}
        />
        <CustomInput label="Device" readOnly value={store?.selectedDevice?.productName} />
        <CustomInput label="Issue type" readOnly value={store?.primaryReason?.description} />
        <CustomInput
          label="Issue description"
          readOnly
          value={store?.secondaryReason?.description}
        />

        <CustomTextArea
          readOnly
          required={false}
          label="Additional information about your issue:"
          maxLength={200}
          value={store?.additionalInfo}
        />
      </Stack>
    </Box>
  )
}

export const DeviceImage = () => {
  const { data } = useDeviceDetails()

  return (
    <Box width="200px">
      <Image src={data?.imageUrl} width="219px" height="auto" loading="lazy" />
    </Box>
  )
}

export const Details = () => (
  <HStack gap="18px" flexDirection={['column-reverse', 'row']} alignItems={['center', 'left']}>
    <ReadOnlyForm />
    <DeviceImage />
  </HStack>
)

export default Details
