export { default } from "./EligibleDevice";
