import '@testing-library/jest-dom/extend-expect'
import { fireEvent, render } from '@testing-library/react'
import React from 'react'
import useStore from '@devicerepair/stores/useStore'
import Actions from '../Actions'
import { useMediaQuery } from '@devicerepair/components/Flexify'
import useSteps from '@devicerepair/stores/useSteps'

jest.mock('@devicerepair/stores/useStore', () => jest.fn())
jest.mock('@devicerepair/stores/useSteps', () => jest.fn())

jest.mock('@devicerepair/components/Flexify', () => ({
  ...jest.requireActual('@devicerepair/components/Flexify'),
  useMediaQuery: jest.fn(),
}))

const mockHistoryGoBack = jest.fn()
const mockHistoryGoForward = jest.fn()

jest.mock('react-router-dom', () => ({
  ...jest.requireActual('react-router-dom'),
  useHistory: () => ({
    goBack: mockHistoryGoBack,
    goForward: mockHistoryGoForward,
  }),
}))

describe('<Actions />', () => {
  beforeEach(() => {
    useStore.mockImplementation(() => ({
      store: {},
    }))

    useMediaQuery.mockImplementation(() => ({
      isMobile: false,
      isDesktop: true,
    }))

    const completedSteps = ['landing', 'issue-details', 'eligible-device']
    useSteps.mockImplementation(() => completedSteps)
  })

  test('render component ', async () => {
    const { getByRole } = render(<Actions />)
    const continueButton = getByRole('button', { name: 'Continue' })

    expect(continueButton).toBeInTheDocument()
  })

  test('should go back', async () => {
    const { getByRole } = render(<Actions />)
    
    const backButton = getByRole('button', { name: 'Back' })

    fireEvent.click(backButton)

    expect(mockHistoryGoBack).toHaveBeenCalled()
  })

})
