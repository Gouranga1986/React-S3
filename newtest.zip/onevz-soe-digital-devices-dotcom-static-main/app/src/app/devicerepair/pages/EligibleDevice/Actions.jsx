import ActionNav from '@devicerepair/components/ActionNav'
import { useResponsiveValue } from '@devicerepair/components/Flexify'
import { usePageName } from '@devicerepair/hooks/usePageName'
import { Button } from '@vds/buttons'
import React from 'react'

const Actions = ({ onContinue }) => {
  const width = useResponsiveValue(['100%', '226px'])
  const pageName = usePageName()

  return (
    <ActionNav>
      <Button
        data-track={`{"type":"link","name": "${pageName}-continue-button"}`}
        data-analyticstrack={`${pageName}-continue-button`}
        data-clickstream={`${pageName}-continue-button`}
        width={width}
        onClick={onContinue}
      >
        Continue
      </Button>
    </ActionNav>
  )
}

export default Actions
