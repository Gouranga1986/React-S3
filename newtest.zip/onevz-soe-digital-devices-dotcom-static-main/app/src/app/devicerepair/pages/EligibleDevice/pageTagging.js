export const getPageTagging = () => {
  return {
    page: {
      name: 'device elgible confirmation',
    }
  }
}
