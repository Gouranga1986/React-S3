import { useMediaQuery } from '@devicerepair/components/Flexify'
import { QueryProvider } from '@devicerepair/helpers/testing'
import useDeviceRepair from '@devicerepair/hooks/useDeviceRepair'
import { useDeviceRepairStores } from '@devicerepair/hooks/useDeviceRepairStores'
import useRetrieveCLNRInfo from '@devicerepair/hooks/useRetrieveCLNRInfo'
import useStore from '@devicerepair/stores/useStore'
import '@testing-library/jest-dom/extend-expect'
import { fireEvent, render } from '@testing-library/react'
import React from 'react'
import EligibleDevice from '../EligibleDevice'

jest.mock('@devicerepair/hooks/useDeviceRepair')
jest.mock('@devicerepair/hooks/useRetrieveCLNRInfo')
jest.mock('@devicerepair/hooks/useDeviceRepairStores')
jest.mock('@devicerepair/stores/useStore')
jest.mock('@devicerepair/components/Flexify', () => ({
  ...jest.requireActual('@devicerepair/components/Flexify'),
  useMediaQuery: jest.fn(),
}))

const mockHistoryPush = jest.fn()

jest.mock('react-router-dom', () => ({
  ...jest.requireActual('react-router-dom'),
  useHistory: () => ({
    push: mockHistoryPush,
  }),
}))

describe('<EligibleDevice />', () => {
  let refetch = jest.fn()

  const selectedDevice = {
    deviceId: '351906514335853',
    productName: 'IPHONE 14 PLUS 256 STARLIGHT',
    mtnEffectiveDate: '02/10/2024',
    status: 'active',
  }

  const primaryReason = {
    description: 'Power',
  }
  const secondaryReason = {
    description: 'Does Not Power On at all',
  }
  const additionalInfo = 'some comments'

  beforeEach(() => {
    useStore.mockImplementation(() => ({
      store: {
        selectedDevice,
        primaryReason,
        secondaryReason,
        additionalInfo,
      },
    }))

    useMediaQuery.mockImplementation(() => ({
      isMobile: false,
      isDesktop: true,
    }))

    useRetrieveCLNRInfo.mockImplementation(() => ({
      isLoading: false,
    }))

    useDeviceRepairStores.mockImplementation(() => ({
      data: undefined,
      refetch,
      isLoading: false,
    }))

    useDeviceRepair.mockImplementation(() => ({
      data: {},
      isLoading: false,
    }))
  })

  test('render component', async () => {
    const { getByRole } = render(
      <QueryProvider>
        <EligibleDevice />
      </QueryProvider>
    )

    const mobileNumberInput = getByRole('textbox', { name: 'Mobile number Optional Input Field' })
    expect(mobileNumberInput).toBeInTheDocument()
  })

  test('should refetch when store data is not available', async () => {
    const { getByRole } = render(
      <QueryProvider>
        <EligibleDevice />
      </QueryProvider>
    )

    const continueButton = getByRole('button', { name: 'Continue' })

    fireEvent.click(continueButton)

    expect(refetch).toHaveBeenCalled()
  })
})
