import '@testing-library/jest-dom/extend-expect'
import { render } from '@testing-library/react'
import React from 'react'
import Details from '../Details'
import useStore from '@devicerepair/stores/useStore'
import { QueryProvider } from '@devicerepair/helpers/testing'
import { formatPhoneNumber } from '@devicerepair/helpers/formater'

jest.mock('@devicerepair/stores/useStore')

describe('<Details />', () => {
  const selectedMTN = "1233457890"

  const selectedDevice = {
    deviceId: '351906514335853',
    productName: 'IPHONE 14 PLUS 256 STARLIGHT',
    mtnEffectiveDate: '02/10/2024',
    status: 'active',
  }

  const primaryReason = {
    description: 'Power',
  }
  const secondaryReason = {
    description: 'Does Not Power On at all',
  }
  const additionalInfo = 'some comments'

  beforeEach(() => {
    useStore.mockImplementation(() => ({
      store: {
        selectedMTN,
        selectedDevice,
        primaryReason,
        secondaryReason,
        additionalInfo,
      },
    }))
  })

  test('render component', async () => {
    const { getByRole } = render(
      <QueryProvider>
        <Details />
      </QueryProvider>
    )

    const mobileNumberInput = getByRole('textbox', { name: 'Mobile number Optional Input Field' })
    expect(mobileNumberInput.value).toBe(formatPhoneNumber(selectedMTN))
  })
})
