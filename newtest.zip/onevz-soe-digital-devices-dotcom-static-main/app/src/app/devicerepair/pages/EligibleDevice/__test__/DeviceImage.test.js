import { QueryProvider } from '@devicerepair/helpers/testing'
import useDeviceDetails from '@devicerepair/hooks/useDeviceDetails'
import '@testing-library/jest-dom/extend-expect'
import { render } from '@testing-library/react'
import React from 'react'
import { DeviceImage } from '../Details'

jest.mock('@devicerepair/hooks/useDeviceDetails')

const imageUrl =
  'https://ss7.vzw.com/is/image/VerizonWireless/apple-iphone-15-pro-max-256gb-natural-titanium-mu683ll-a-a?hei=262&fmt=webp'

describe('<DeviceImage />', () => {
  beforeEach(() => {
    useDeviceDetails.mockImplementation(() => ({
      data: { imageUrl },
    }))
  })

  test('render component', async () => {
    const { getByRole } = render(
      <QueryProvider>
        <DeviceImage />
      </QueryProvider>
    )

    const deviceImage = getByRole('img')
    expect(deviceImage).toBeInTheDocument()

    expect(deviceImage.src).toBe(imageUrl)
  })
})
