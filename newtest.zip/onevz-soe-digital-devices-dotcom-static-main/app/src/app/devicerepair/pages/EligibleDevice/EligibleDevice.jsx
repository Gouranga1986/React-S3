import { Stack } from '@devicerepair/components/Flexify'
import Page from '@devicerepair/components/Page'
import useRetrieveCLNRInfo from '@devicerepair/hooks/useRetrieveCLNRInfo'
import useSteps from '@devicerepair/stores/useSteps'
import { Loader } from '@vds/loaders'
import React from 'react'
import { useHistory } from 'react-router-dom'
import Actions from './Actions'
import Details from './Details'
import Header from '@devicerepair/components/Header'
import useContent from '@devicerepair/stores/useContent'
import { useSetPage } from '@devicerepair/services/tagging'
import { getPageTagging } from './pageTagging'

const EligibleDevice = () => {
  useSetPage(getPageTagging(), { enabled: true })
  const { title, description } = useContent((store) => store?.content?.eligible || {})

  const history = useHistory()
  const completeStep = useSteps((state) => state.completeStep)
  const { isLoading } = useRetrieveCLNRInfo()

  const onContinue = async () => {
    completeStep('eligible-device')
    history.push('/store-locator')
  }

  return (
    <Page>
      <Header title={title} description={description} />

      <Stack position="relative" gap={['24px', '32px']}>
        {(isLoading ) && <Loader fullscreen={false} active={true} />}
        <Details />
        <Actions onContinue={onContinue} />
      </Stack>
    </Page>
  )
}

export default EligibleDevice
