import React from 'react'
import Page from '@devicerepair/components/Page'
import YourAppointment from './YourAppointment'
import { Stack } from '@devicerepair/components/Flexify'
import PriorToYourVisit from './PriorToYourVisit'
import Actions from './Actions'
import useContent from '@devicerepair/stores/useContent'
import Header from '@devicerepair/components/Header'
import { getPageTagging } from './pageTagging'
import { useSetPage } from '@devicerepair/services/tagging'

const ConfirmedAppointment = () => {
  useSetPage(getPageTagging(), { enabled: true })
  const { title, description } = useContent((store) => store?.content?.confirmation || {})

  return (
    <Page>
      <Header title={title} description={description} />
      <Stack flexDirection={['column', 'row']} gap={['24px', '106px']}>
        <YourAppointment />
        <PriorToYourVisit />
      </Stack>
      <Actions />
    </Page>
  )
}

export default ConfirmedAppointment
