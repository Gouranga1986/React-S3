export { default } from "./ConfirmedAppointment";
