import useStore from '@devicerepair/stores/useStore'
import '@testing-library/jest-dom/extend-expect'
import { render } from '@testing-library/react'
import React from 'react'
import { useParams } from 'react-router-dom'
import YourAppointment from '../YourAppointment'

const mockHistoryPush = jest.fn()

jest.mock('@devicerepair/stores/useStore')

jest.mock('react-router-dom', () => ({
  ...jest.requireActual('react-router-dom'),
  useHistory: () => ({
    push: mockHistoryPush,
  }),
  useParams: jest.fn(),
}))

describe('<YourAppointment />', () => {
  const primaryReason = {
    description: 'Power',
  }
  const secondaryReason = {
    description: 'Does Not Power On at all',
  }

  const shippingAddress = {
    street: '23 COTTONWOOD DR',
    city: 'JACKSON',
    state: 'NJ',
    zipCode: '08527',
  }

  const selectedAppointmentTime = {
    startTime: '10:30AM',
    endTime: '11:00AM',
  }

  const selectedAppointmentDate = {
    appointmentDate: '07/23/2024',
    appointmentDay: 'FRI',
  }

  const selectedStore = {
    vendorName: 'UBREAK',
    businessName: 'Asurion Tech Repair & Solutions',
    storeId: '48',
    storeName: 'Goodyear',
    distance: '9.4',
    timeZone: 'America/Phoenix',
    city: 'Goodyear',
    state: 'AZ',
    phone: '6235364880',
    email: '6235364880',
  }

  beforeEach(() => {
    useStore.mockImplementation(() => ({
      store: {
        primaryReason,
        secondaryReason,
        selectedStore,
        selectedAppointmentDate,
        selectedAppointmentTime,
        shippingAddress,
      },
    }))

    useParams.mockReturnValue({
      confirmationId: '43453453',
    })
  })

  test('should render compnenet with data', async () => {
    const { getByText } = render(<YourAppointment />)

    const primaryReasonEl = getByText(primaryReason.description)
    expect(primaryReasonEl).toBeInTheDocument()

    const secondaryReasonEl = getByText(secondaryReason.description)
    expect(secondaryReasonEl).toBeInTheDocument()
  })
})
