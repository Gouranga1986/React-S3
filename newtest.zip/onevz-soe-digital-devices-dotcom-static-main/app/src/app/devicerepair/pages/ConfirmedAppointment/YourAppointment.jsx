import React, { Fragment } from 'react'
import { Stack, Box, Grid } from '@devicerepair/components/Flexify'
import { Body } from '@vds/typography'
import { TextLink } from '@vds/buttons'
import useStore from '@devicerepair/stores/useStore'
import dayjs from 'dayjs'
import { useParams } from 'react-router-dom'

const Confirmation = ({ confirmationId }) => (
  <Fragment>
    <Body bold size="medium">
      Order number:
    </Body>
    <Body bold size="medium">
      {confirmationId}
    </Body>
  </Fragment>
)

const Reason = ({ reason }) => (
  <Fragment>
    <Body bold size="medium">
      Reason:
    </Body>
    <Body size="medium">{reason}</Body>
  </Fragment>
)

const RelatingTo = ({ reason }) => (
  <Fragment>
    <Body bold size="medium">
      Relating to:
    </Body>
    <Body size="medium">{reason}</Body>
  </Fragment>
)

const Location = ({ selectedStore }) => (
  <Fragment>
    <Body bold size="medium">
      Location:
    </Body>
    <Stack gap="2px">
      <Body size="medium">{selectedStore?.storeName}</Body>
      <Stack>
        <Body size="small">{selectedStore?.address1}</Body>
        <Body size="small">{selectedStore?.address2}</Body>
        <Body size="small">
          {selectedStore?.city}, {selectedStore?.state} {selectedStore?.postalCode}
        </Body>
      </Stack>
    </Stack>
  </Fragment>
)

const Date = ({ selectedAppointmentDate }) => (
  <Fragment>
    <Body bold size="medium">
      Date:
    </Body>
    <Body size="medium">
      {dayjs(selectedAppointmentDate?.appointmentDate).format('dddd MMMM DD, YYYY')}
    </Body>
  </Fragment>
)

const Time = ({ selectedAppointmentTime }) => (
  <Fragment>
    <Body bold size="medium">
      Time:
    </Body>
    <Body size="medium">{selectedAppointmentTime?.startTime} - {selectedAppointmentTime?.endTime}</Body>
  </Fragment>
)

const ReturnShippingAddress = ({ shippingAddress }) => (
  <Fragment>
    <Box maxWidth={["101px", "114px"]} >
      <Body bold size="medium">
        Return shipping address:
      </Body>
    </Box>
    <Stack gap="2px">
      <Body size="medium">{shippingAddress?.street}</Body>
      <Body size="medium">
        {shippingAddress?.city}, {shippingAddress?.state} {shippingAddress?.zipCode}
      </Body>
    </Stack>
  </Fragment>
)

const Comment = ({ additionalInfo }) => (
  <Fragment>
    <Body bold size="medium">
      Comment:
    </Body>
    <Body size="medium">{additionalInfo}</Body>
  </Fragment>
)

const YourAppointment = () => {
  const { store } = useStore()
  const { confirmationId } = useParams()
  const {
    primaryReason,
    secondaryReason,
    selectedStore,
    selectedAppointmentDate,
    selectedAppointmentTime,
    shippingAddress,
    additionalInfo,
  } = store


  return (
    <Grid gridTemplateColumns="repeat(2, 192px)" rowGap={['24px', '20px']}>
      <Confirmation confirmationId={confirmationId} />
      <Reason reason={primaryReason?.description} />
      <RelatingTo reason={secondaryReason?.description} />
      <Location selectedStore={selectedStore} />
      <Date selectedAppointmentDate={selectedAppointmentDate} />
      <Time selectedAppointmentTime={selectedAppointmentTime} />
      <ReturnShippingAddress shippingAddress={shippingAddress} />
      <Comment additionalInfo={additionalInfo} />
    </Grid>
  )
}

export default YourAppointment
