import { queryClient } from '@devicerepair/app'
import '@testing-library/jest-dom/extend-expect'
import { render } from '@testing-library/react'
import React from 'react'
import { QueryClientProvider } from 'react-query'
import ConfirmedAppointment from '../ConfirmedAppointment'

jest.mock('@devicerepair/hooks/useRetrieveCLNRInfo')

describe('<ConfirmedAppointment />', () => {

  test('render loader', async () => {
    const { getByLabelText } = render(
      <QueryClientProvider client={queryClient}>
        <ConfirmedAppointment />
      </QueryClientProvider>
    )

    const loader = getByLabelText('loader overlay')
    expect(loader).toBeInTheDocument()
  })
})
