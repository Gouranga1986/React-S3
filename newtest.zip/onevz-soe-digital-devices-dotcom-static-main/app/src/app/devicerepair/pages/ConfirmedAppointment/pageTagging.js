export const getPageTagging = () => {
  return {
    page: {
      name: 'appointement confirmation',
    },
    event: {
      value: "event116"
    }
  }
}
