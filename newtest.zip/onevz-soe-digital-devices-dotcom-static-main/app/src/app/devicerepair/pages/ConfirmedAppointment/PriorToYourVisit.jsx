import { Stack } from '@devicerepair/components/Flexify'
import { parseTemplate } from '@devicerepair/helpers/utils'
import useRetrieveCLNRInfo from '@devicerepair/hooks/useRetrieveCLNRInfo'
import useContent from '@devicerepair/stores/useContent'
import { ListItem, UnorderedList } from '@vds/lists'
import { TitleLockup } from '@vds/type-lockups'
import { Body } from '@vds/typography'
import React from 'react'
import { getUserDetails } from '../ReviewAppointment/AppointmentDetails'
import useStore from '@devicerepair/stores/useStore'


const Repairs = () => {
  const { conditions } = useContent((store) => store?.content?.confirmation || {})

  return (
    <Stack gap={['4px', '4px']}>
      <Body bold>Repairs: </Body>

      <UnorderedList>
        {conditions?.repairs?.map((item) => (
          <ListItem key={item} size="bodyMedium" spacing="compact">
            {item}
          </ListItem>
        ))}
      </UnorderedList>
    </Stack>
  )
}
const SoftwareBackup = () => {
  const { conditions } = useContent((store) => store?.content?.confirmation || {})

  return (
    <Stack>
      <Body bold>Backup of software and data: </Body>

      <UnorderedList>
        {conditions?.backup?.map((item) => (
          <ListItem key={item} size="bodyMedium" spacing="compact">
            {item}
          </ListItem>
        ))}
      </UnorderedList>
    </Stack>
  )
}

const Header = () => {
  const { conditions } = useContent((store) => store?.content?.confirmation || {})
  const store  = useStore(state => state?.store)
  const { data: CLNRInfo } = useRetrieveCLNRInfo()
  const userDetails = getUserDetails(CLNRInfo, store?.userDetails)

  const parseDescription = parseTemplate(conditions?.description, {
    emailId: userDetails?.email?.toLowerCase(),
    storename: store?.selectedStore?.storeName
  })

  return (
    <TitleLockup
      data={{
        title: {
          size: 'titleMedium',
          children: 'Prior to your visit',
        },
        subtitle: {
          size: 'bodyMedium',
          children: parseDescription
        },
      }}
    />
  )
}

const PriorToYourVisit = () => {
  return (
    <Stack gap={['24px', '24px']}>
      <Header />
      <Repairs />
      <SoftwareBackup />
    </Stack>
  )
}

export default PriorToYourVisit
