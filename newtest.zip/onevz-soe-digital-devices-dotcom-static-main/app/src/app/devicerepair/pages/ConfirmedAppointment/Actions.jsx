import React from 'react'
import { Button } from '@vds/buttons'
import { useResponsiveValue } from '@devicerepair/components/Flexify'
import { usePageName } from '@devicerepair/hooks/usePageName'

const UDB_URL = '/digital/nsa/secure/ui/udb/#/'

const Actions = () => {
  const width = useResponsiveValue(['100%', '100px'])
  const pageName = usePageName()

  const onDone = () => {
    window.location.href = UDB_URL
  }

  return (
    <Button
      width={width}
      data-track={`{"type":"link","name": "${pageName}-done-button"}`}
      data-analyticstrack={`${pageName}-done-button`}
      data-clickstream={`${pageName}-done-button`}
      onClick={onDone}
    >
      Done
    </Button>
  )
}
export default Actions
