import '@testing-library/jest-dom/extend-expect'
import { render } from '@testing-library/react'
import React from 'react'
import PriorToYourVisit from '../PriorToYourVisit'


describe('<PriorToYourVisit />', () => {

  test('render component', async () => {
    const { getByText } = render(<PriorToYourVisit />)

    const repairText = getByText('A repair may take up to 4 hours to complete.')
    expect(repairText).toBeInTheDocument()
  })
})
