import { queryClient } from '@devicerepair/app'
import { useMediaQuery } from '@devicerepair/components/Flexify'
import useCheckEligibility from '@devicerepair/hooks/useCheckEligibility'
import { usePrimaryReason, useReturnReason } from '@devicerepair/hooks/useReturnReason'
import useStore from '@devicerepair/stores/useStore'
import '@testing-library/jest-dom/extend-expect'
import { render } from '@testing-library/react'
import React from 'react'
import { QueryClientProvider } from 'react-query'
import IssueSelection from '../IssueSelection'

jest.mock('@devicerepair/components/Flexify', () => ({
  ...jest.requireActual('@devicerepair/components/Flexify'),
  useMediaQuery: jest.fn(),
}))

jest.mock('@devicerepair/hooks/useCheckEligibility')
jest.mock('@devicerepair/hooks/useReturnReason')
jest.mock('@devicerepair/stores/useStore')

const mockHistoryPush = jest.fn()

jest.mock('react-router-dom', () => ({
  ...jest.requireActual('react-router-dom'),
  useHistory: () => ({
    push: mockHistoryPush,
  }),
}))

describe('<IssueSelection />', () => {
  let setStore = jest.fn()
  let checkEligibility;

  beforeEach(() => {
    useReturnReason.mockImplementation(() => ({
      isLoading: true,
    }))

    usePrimaryReason.mockImplementation(() => [
      {
        code: '00',
        description: 'Power',
        id: 'Others-00',
        secondaryReasons: [
          {
            code: '01',
            description: 'Does Not Power On at all',
          },
          {
            code: '02',
            description: 'Intermittently Powers on',
          },
        ],
      },
      {
        code: '10',
        description: 'Audio/Alert',
        id: 'Others-10',
        secondaryReasons: [
          {
            code: '11',
            description: 'Earpiece Audio Absent',
          },
          {
            code: '12',
            description: 'Earpiece Audio Poor',
          },
        ],
      },
    ])

    checkEligibility = jest.fn().mockResolvedValue({
      data: {
        body: {
          data: {
            repairEligible: true, // change to false to test ineligible path
          },
        },
      },
    });

    useCheckEligibility.mockReturnValue({
      mutateAsync: checkEligibility,
      isLoading: false,
    });
    
    useMediaQuery.mockImplementation(() => ({
      isMobile: false,
      isDesktop: true,
    }))

    useStore.mockImplementation(() => ({
      store: {},
      setStore,
    }))
  })

  test('render loader', async () => {
    const { getByLabelText } = render(
      <QueryClientProvider client={queryClient}>
        <IssueSelection />
      </QueryClientProvider>
    )

    const loader = getByLabelText('loader overlay')
    expect(loader).toBeInTheDocument()
  })

  test('render IssueForm', async () => {
    useReturnReason.mockImplementation(() => ({
      isLoading: false,
    }))
    const { getByRole } = render(
      <QueryClientProvider client={queryClient}>
        <IssueSelection />
      </QueryClientProvider>
    )

    const form = getByRole('form')
    expect(form).toBeInTheDocument()
  })
})
