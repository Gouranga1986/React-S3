import useStore from '@devicerepair/stores/useStore'
import '@testing-library/jest-dom/extend-expect'
import { fireEvent, render } from '@testing-library/react'
import React from 'react'
import { IsPhysicalyDamanaged } from '../IssueForm'

jest.mock('@devicerepair/stores/useStore')

describe('<IsPhysicalyDamanaged />', () => {
  let setStore = jest.fn()

  const additionalInfo = 'some comments'

  beforeEach(() => {
    useStore.mockImplementation(() => ({
      store: {
        additionalInfo,
      },
      setStore,
    }))
  })

  test('render component ', async () => {
    const { getByRole } = render(<IsPhysicalyDamanaged />)
    const checkbox = getByRole('checkbox')
    expect(checkbox).toBeInTheDocument()
  })

  test('on comment change', async () => {
    const { getByRole } = render(<IsPhysicalyDamanaged />)
    const checkbox = getByRole('checkbox')
    fireEvent.click(checkbox, {
      selected: true,
    })
    expect(setStore).toHaveBeenCalledWith({
      isPhysicallyDamaged : true
    })
  })
})
