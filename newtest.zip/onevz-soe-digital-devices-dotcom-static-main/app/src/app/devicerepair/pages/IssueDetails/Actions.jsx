import ActionNav from '@devicerepair/components/ActionNav'
import { useResponsiveValue } from '@devicerepair/components/Flexify'
import useStore from '@devicerepair/stores/useStore'
import { Button } from '@vds/buttons'
import React from 'react'

const Actions = ({isDisabled}) => {
  const { store } = useStore()
  const width = useResponsiveValue(['100%', '226px'])

  return (
    <ActionNav>
      <Button
        type="submit"
        data-track='{"type":"link","name":"check-eligibility-button"}'
        data-analyticstrack="check-eligibility-button"
        data-clickstream="check-eligibility-button"
        width={width}
        disabled={store?.isPhysicallyDamaged || isDisabled}
      >
        Check eligibility
      </Button>
    </ActionNav>
  )
}

export default Actions
