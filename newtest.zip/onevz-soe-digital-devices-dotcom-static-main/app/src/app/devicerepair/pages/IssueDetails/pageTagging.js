export const getPageTagging = () => {
  return {
    page: {
      name: 'issue selection',
    },
    event: {
      value: ""
    }
  }
}
