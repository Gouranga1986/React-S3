import { usePrimaryReason } from '@devicerepair/hooks/useReturnReason'
import useStore from '@devicerepair/stores/useStore'
import '@testing-library/jest-dom/extend-expect'
import { render, fireEvent } from '@testing-library/react'
import React from 'react'
import { IssueType } from '../IssueForm'

jest.mock('@devicerepair/hooks/useReturnReason')
jest.mock('@devicerepair/stores/useStore')

const primaryReason = [
  {
    code: '00',
    description: 'Power',
    id: 'Others-00',
    secondaryReasons: [
      {
        code: '01',
        description: 'Does Not Power On at all',
      },
      {
        code: '02',
        description: 'Intermittently Powers on',
      },
    ],
  },
  {
    code: '10',
    description: 'Audio/Alert',
    id: 'Others-10',
    secondaryReasons: [
      {
        code: '11',
        description: 'Earpiece Audio Absent',
      },
      {
        code: '12',
        description: 'Earpiece Audio Poor',
      },
    ],
  },
]

describe('<IssueType />', () => {
  let setStore = jest.fn()

  beforeEach(() => {
    usePrimaryReason.mockImplementation(() => primaryReason)

    useStore.mockImplementation(() => ({
      store: {
        primaryReason: primaryReason.at(0),
      },
      setStore,
    }))
  })

  test('render component ', async () => {
    const { getByRole } = render(<IssueType />)
    const select = getByRole('combobox')
    expect(select).toBeInTheDocument()
    expect(select.children).toHaveLength(2)
  })

  test('on change issue type ', async () => {
    const { getByRole } = render(<IssueType />)
    const select = getByRole('combobox')
    fireEvent.change(select, {
      target: { value: 'Others-10' },
    })
    expect(setStore).toHaveBeenCalled()
  })
})
