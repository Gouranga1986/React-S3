import { queryClient } from '@devicerepair/app'
import { useMediaQuery } from '@devicerepair/components/Flexify'
import useCheckEligibility from '@devicerepair/hooks/useCheckEligibility'
import { usePrimaryReason } from '@devicerepair/hooks/useReturnReason'
import useStore from '@devicerepair/stores/useStore'
import '@testing-library/jest-dom/extend-expect'
import { render, fireEvent, waitFor } from '@testing-library/react'
import React from 'react'
import { QueryClientProvider } from 'react-query'
import IssueForm from '../IssueForm'

jest.mock('@devicerepair/components/Flexify', () => ({
  ...jest.requireActual('@devicerepair/components/Flexify'),
  useMediaQuery: jest.fn(),
}))

jest.mock('@devicerepair/hooks/useCheckEligibility')
jest.mock('@devicerepair/hooks/useReturnReason')
jest.mock('@devicerepair/stores/useStore')

const mockHistoryPush = jest.fn()

jest.mock('react-router-dom', () => ({
  ...jest.requireActual('react-router-dom'),
  useHistory: () => ({
    push: mockHistoryPush,
  }),
}))

describe('<IssueForm />', () => {
  let setStore = jest.fn()
  let checkEligibility

  beforeEach(() => {
    usePrimaryReason.mockImplementation(() => [
      {
        code: '00',
        description: 'Power',
        id: 'Others-00',
        secondaryReasons: [
          {
            code: '01',
            description: 'Does Not Power On at all',
          },
          {
            code: '02',
            description: 'Intermittently Powers on',
          },
        ],
      },
      {
        code: '10',
        description: 'Audio/Alert',
        id: 'Others-10',
        secondaryReasons: [
          {
            code: '11',
            description: 'Earpiece Audio Absent',
          },
          {
            code: '12',
            description: 'Earpiece Audio Poor',
          },
        ],
      },
    ])

    checkEligibility = jest.fn().mockResolvedValue({
      data: {
        data: {
          repairEligible: true, // change to false to test ineligible path
        },
      },
    })

    useCheckEligibility.mockReturnValue({
      mutateAsync: checkEligibility,
      isLoading: false,
    })

    useMediaQuery.mockImplementation(() => ({
      isMobile: false,
      isDesktop: true,
    }))

    useStore.mockImplementation(() => ({
      store: {},
      setStore,
    }))
  })

  test('render component', async () => {
    const { getByRole } = render(
      <QueryClientProvider client={queryClient}>
        <IssueForm />
      </QueryClientProvider>
    )

    const form = getByRole('form')
    expect(form).toBeInTheDocument()
  })

  test('on form submit', async () => {
    const { getByRole } = render(
      <QueryClientProvider client={queryClient}>
        <IssueForm />
      </QueryClientProvider>
    )

    const form = getByRole('form')

    fireEvent.submit(form)
    expect(checkEligibility).toHaveBeenCalled()
  })

  test('not eligible', async () => {
    checkEligibility = jest.fn().mockResolvedValue({
      data: {
        data: {
          repairEligible: false,
        },
      },
    })

    useCheckEligibility.mockReturnValue({
      mutateAsync: checkEligibility,
      isLoading: false,
    })

    const { getByRole } = render(
      <QueryClientProvider client={queryClient}>
        <IssueForm />
      </QueryClientProvider>
    )

    const form = getByRole('form')

    fireEvent.submit(form)
    expect(checkEligibility).toHaveBeenCalled()
    await waitFor(() => {
      expect(mockHistoryPush).toHaveBeenCalledWith('/ineligible')
    })
  })

  test('show loader', async () => {
    checkEligibility = jest.fn().mockResolvedValue({
      data: {
        data: {
          repairEligible: false,
        },
      },
    })

    useCheckEligibility.mockReturnValue({
      mutateAsync: checkEligibility,
      isLoading: true,
    })

    const { getByLabelText } = render(
      <QueryClientProvider client={queryClient}>
        <IssueForm />
      </QueryClientProvider>
    )

    const loader = getByLabelText('loader overlay')
    expect(loader).toBeInTheDocument()
  })
})
