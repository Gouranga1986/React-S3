import '@testing-library/jest-dom/extend-expect';
import { render } from '@testing-library/react';
import React from 'react';
import { QueryClientProvider } from 'react-query';
import { queryClient } from '@devicerepair/app';
import IssueDetails from '../IssueDetails';

describe('<IssueDetails />', () => {


  test('render component', async () => {
    const { getByLabelText } = render(
      <QueryClientProvider client={queryClient}>
        <IssueDetails />
      </QueryClientProvider>
    );

    const loader = getByLabelText('loader overlay')
    expect(loader).toBeInTheDocument()
  });
});
