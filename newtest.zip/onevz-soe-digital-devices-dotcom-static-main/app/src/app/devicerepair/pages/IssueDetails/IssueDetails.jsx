import React from 'react'
import Page from '@devicerepair/components/Page'
import IssueSelection from './IssueSelection'
import useContent from '@devicerepair/stores/useContent'
import Header from '@devicerepair/components/Header'
import { useSetPage } from '@devicerepair/services/tagging'
import { getPageTagging } from './pageTagging'

const tagging = getPageTagging()

const IssueDetails = () => {
  useSetPage(tagging, { enabled: true })
  const { title, description } = useContent((store) => store?.content?.issueSelection || {})

  return (
    <Page>
      <Header title={title} description={description} />
      <IssueSelection />
    </Page>
  )
}

export default IssueDetails
