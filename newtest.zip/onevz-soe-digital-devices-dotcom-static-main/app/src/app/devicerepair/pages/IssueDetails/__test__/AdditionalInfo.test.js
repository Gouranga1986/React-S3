import useStore from '@devicerepair/stores/useStore'
import '@testing-library/jest-dom/extend-expect'
import { fireEvent, render } from '@testing-library/react'
import React from 'react'
import { AdditionalInfo } from '../IssueForm'

jest.mock('@devicerepair/stores/useStore')

describe('<AdditionalInfo />', () => {
  let setStore = jest.fn()

  const additionalInfo = 'some comments'

  beforeEach(() => {
    useStore.mockImplementation(() => ({
      store: {
        additionalInfo,
      },
      setStore,
    }))
  })

  test('render component ', async () => {
    const { getByRole } = render(<AdditionalInfo />)
    const additionalInfoInput = getByRole('textbox')
    expect(additionalInfoInput).toBeInTheDocument()
  })

  test('on comment change', async () => {
    const newComment = "new comment"
    const { getByRole } = render(<AdditionalInfo />)
    const additionalInfoInput = getByRole('textbox')
    fireEvent.change(additionalInfoInput, {
      target: { value: newComment },
    })
    expect(setStore).toHaveBeenCalledWith({
      additionalInfo : newComment
    })
  })
})
