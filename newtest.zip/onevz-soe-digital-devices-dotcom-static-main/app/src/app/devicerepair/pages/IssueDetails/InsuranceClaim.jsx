import useStore from '@devicerepair/stores/useStore'
import { Modal, ModalTitle, ModalBody } from '@vds/modals'
import React, { useEffect } from 'react'
import { Notification } from '@vds/notifications'
import { useState } from 'react'
import { Box } from '@devicerepair/components/Flexify'
import { dispatchNotify, dispatchOverlay } from '@devicerepair/services/tagging'

const content = {
  title: 'CLNR eligible Asurion insurance claim',
  details:
    'This device has physical damage. The Insurance Claim is administered by Asurion . Please contact Asurion (1-888-881-2622). For more information, see OST: 203043',
}

const BannerInfo = () => {
  useEffect(() => {
    dispatchNotify({
      name: 'eligible-asurion-insurance-claim',
      message: content.details,
    })
  }, [])

  return (
    <Box maxWidth="808px">
      <Notification
        type="info"
        title={content?.title}
        subtitle={content?.details}
        fullBleed={false}
        inline={false}
        hideCloseButton={true}
        disableFocus={false}
      />
    </Box>
  )
}

const InsuranceClaim = () => {
  const { store } = useStore()
  const [isModalClosed, setIsModalClosed] = useState(false)

  const onModalClose = (isOpened) => {
    if (!isOpened) setIsModalClosed(true)
  }

  useEffect(() => {
    if (!store?.isPhysicallyDamaged) {
      setIsModalClosed(false)
    }
  }, [store?.isPhysicallyDamaged])

  useEffect(() => {
    if (store?.isPhysicallyDamaged) {
      dispatchOverlay({
        name: 'eligible-asurion-insurance-claim-modal',
        selector: '#eligible-assurance-claim-modal',
        data: {
          page : {
            details: 'CLNR eligible Asurion insurance claim',
          }
        }
      })
    }
  }, [store?.isPhysicallyDamaged])

  if (!store?.isPhysicallyDamaged) return null

  if (isModalClosed) return <BannerInfo />

  return (
    <Modal
      id="#eligible-assurance-claim-modal"
      disableOutsideClick={true}
      ariaLabel="asurion insurance claim modal"
      opened={store?.isPhysicallyDamaged}
      onOpenedChange={onModalClose}
    >
      <ModalTitle>{content?.title}</ModalTitle>
      <ModalBody>{content?.details}</ModalBody>
    </Modal>
  )
}

export default InsuranceClaim
