import React from 'react'
import { useReturnReason } from '@devicerepair/hooks/useReturnReason'
import { Loader } from '@vds/loaders'
import { Box } from '@devicerepair/components/Flexify'
import IssueForm from './IssueForm'

export const FormLoading = () => {
  return (
    <Box position="relative" width="100%" height="400px">
      <Loader fullscreen={false} active={true} />
    </Box>
  )
}

const IssueSelector = () => {
  const { isLoading } = useReturnReason()

  if (isLoading) return <FormLoading />

  return <IssueForm />
}

export default IssueSelector
