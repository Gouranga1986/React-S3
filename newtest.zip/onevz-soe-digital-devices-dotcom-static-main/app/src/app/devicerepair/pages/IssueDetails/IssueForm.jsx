import { Stack } from '@devicerepair/components/Flexify'
import { usePrimaryReason } from '@devicerepair/hooks/useReturnReason'
import useStore from '@devicerepair/stores/useStore'
import { Checkbox } from '@vds/checkboxes'
import { TextArea } from '@vds4/inputs'
import { DropdownSelect } from '@vds/selects'
import React, { useEffect } from 'react'
import useCheckEligibility from '@devicerepair/hooks/useCheckEligibility'
import { Loader } from '@vds/loaders'
import Actions from './Actions'
import useSteps from '@devicerepair/stores/useSteps'
import { useHistory } from 'react-router-dom'
import InsuranceClaim from './InsuranceClaim'
import { dispatchLink, dispatchNotify } from '@devicerepair/services/tagging'
import { Controller, FormProvider, useForm, useFormContext } from 'react-hook-form'

export const IssueType = () => {
  const primaryReasons = usePrimaryReason()
  const { store, setStore } = useStore()
  const { control } = useFormContext()

  const onIssueTypeChange = (onChange) => (e) => {
    const value = e?.target.value

    const primaryReason = primaryReasons?.find((p) => p.id === value)
    const secondaryReason = primaryReason?.secondaryReasons?.[0]
    setStore({
      primaryReason,
      secondaryReason,
    })
    dispatchLink({ name: `issue-description-dropdown: ${secondaryReason?.description}` })
    onChange?.(value)
  }

  return (
    <Controller
      name="issueType"
      control={control}
      defaultValue={store?.primaryReason?.id}
      render={({ field, formState: { errors } }) => (
        <DropdownSelect
          {...field}
          label="Issue type"
          onChange={onIssueTypeChange(field?.onChange)}
          value={store?.primaryReason?.id}
          error={!!errors?.issueType}
          errorText={errors?.issueType?.message}
          // data-track={`{"type": "link", "name": "issue-type-dropdown:${store?.primaryReason?.description}"}`}
          // data-analyticstrack="issue-type-dropdown"
          // data-clickstream="issue-type-dropdown"
        >
          {primaryReasons?.map((reason) => (
            <option key={reason?.id} value={reason?.id}>
              {reason?.description}
            </option>
          ))}
        </DropdownSelect>
      )}
    />
  )
}

export const IssueDescription = () => {
  const { store, setStore } = useStore()
  const { control } = useFormContext()

  const onIssueDescriptionChange = (onChange) => (e) => {
    const value = e?.target.value
    const secondaryReason = store?.primaryReason?.secondaryReasons?.find((p) => p.code === value)
    setStore({ secondaryReason })
    onChange(secondaryReason?.code)
  }

  return (
    <Controller
      name="issueDescription"
      control={control}
      defaultValue={store?.secondaryReason?.code}
      rules={{ required: 'Please select an issue description' }}
      render={({ field, formState: { errors } }) => (
        <DropdownSelect
          {...field}
          label="Issue description"
          onChange={onIssueDescriptionChange(field?.onChange)}
          value={store?.secondaryReason?.code}
          error={!!errors?.issueDescription}
          errorText={errors?.issueDescription?.message}
          // data-track={`{"type": "link", "name": "issue-description-dropdown:${store?.secondaryReason?.description}"}`}
          // data-analyticstrack="issue-description-dropdown"
          // data-clickstream="issue-description-dropdown"
        >
          {store?.primaryReason?.secondaryReasons?.map((reason) => (
            <option key={reason?.code} value={reason?.code}>
              {reason?.description}
            </option>
          ))}
        </DropdownSelect>
      )}
    />
  )
}

export const AdditionalInfo = () => {
  const { store, setStore } = useStore()
  const {
    control,
    clearErrors,
    formState: { errors },
  } = useFormContext()

  const onAdditionInfoChange = (onChange) => (e) => {
    const additionalInfo = e?.target.value
    if(errors?.additionalInfo) clearErrors('additionalInfo')
    setStore({ additionalInfo })
    onChange(additionalInfo)
  }

  return (
    <Controller
      name="additionalInfo"
      control={control}
      defaultValue={store?.additionalInfo}
      rules={{
        required: 'Please provide additional information',
      }}
      render={({ field, formState: { errors } }) => (
        <TextArea
          {...field}
          required={true}
          label="Additional information about your issue"
          maxLength={200}
          onChange={onAdditionInfoChange(field?.onChange)}
          error={!!errors?.additionalInfo}
          errorText={errors?.additionalInfo?.message}
          data-analyticstrack="IssueAdditionalInfo-textarea"
          data-track='{"type": "link", "name": "Additional information about your issue"}'
          data-analyticstrack="Additional information about your issue"
          data-clickstream="Additional information about your issue"
        />
      )}
    />
  )
}

export const IsPhysicalyDamanaged = () => {
  const { store, setStore } = useStore()

  const onChange = (e, { selected }) => {
    setStore({
      isPhysicallyDamaged: selected,
    })
  }

  return (
    <Checkbox
      data-track='{"type": "link", "name": "physical-damage-check-box"}'
      data-analyticstrack="physical-damage-check-box"
      data-clickstream="physical-damage-check-box"
      required={false}
      selected={store?.isPhysicallyDamaged}
      onChange={onChange}
    >
      Check this box if your device has any physical damage
    </Checkbox>
  )
}

const IssueForm = () => {
  const primaryReason = usePrimaryReason()
  const { store, setStore } = useStore()
  const { mutateAsync: checkEligibility, isLoading } = useCheckEligibility()
  const completeStep = useSteps((state) => state.completeStep)
  const history = useHistory()

  const formMethods = useForm({
    mode: 'onBlur',
  })

  // set initial values after data loads
  useEffect(() => {
    const defaultPrimaryReason = primaryReason?.[0]
    const defaultSecondyReason = defaultPrimaryReason?.secondaryReasons?.[0]
    if (!store?.primaryReason && defaultPrimaryReason) {
      setStore({
        primaryReason: defaultPrimaryReason,
        secondaryReason: defaultSecondyReason,
      })
    }
  }, [store?.primaryReason, primaryReason])

  const onSubmit = async (e) => {
    e?.preventDefault()

    const response = await checkEligibility?.()
    const repairEligible = response?.data?.data?.repairEligible
    setStore({ repairEligible })
    completeStep('issue-details')

    if (repairEligible) history.push('/eligible-device')
    else history.push('/ineligible')
  }

  if (!store?.primaryReason) return null

  return (
    <FormProvider {...formMethods}>
      <Stack
        as="form"
        role="form"
        gap={['24px', '32px']}
        onSubmit={onSubmit}
        novalidate
        position="relative"
      >
        {isLoading && <Loader active fullScreen={false} />}

        <Stack gap={['24px', '16px']}>
          <Stack maxWidth={['100%', '328px']} gap={['24px', '16px']}>
            <IssueType />
            <IssueDescription />
            <AdditionalInfo />
          </Stack>

          <IsPhysicalyDamanaged />

          <InsuranceClaim />
        </Stack>

        <Actions isDisabled={!formMethods.formState.isValid} />
      </Stack>
    </FormProvider>
  )
}

export default IssueForm
