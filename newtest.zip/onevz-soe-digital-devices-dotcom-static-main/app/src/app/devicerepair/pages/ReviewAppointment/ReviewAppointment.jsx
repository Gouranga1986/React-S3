import React from 'react'
import Page from '@devicerepair/components/Page'
import AppointmentDetails from './AppointmentDetails'
import Header from '@devicerepair/components/Header'
import useContent from '@devicerepair/stores/useContent'
import { getPageTagging } from './pageTagging'
import { useSetPage } from '@devicerepair/services/tagging'

const ReviewAppointment = () => {
  useSetPage(getPageTagging(), { enabled: true })
  const { title, description } = useContent((store) => store?.content?.review || {})

  return (
    <Page>
      <Header title={title} description={description} />
      <AppointmentDetails />
    </Page>
  )
}

export default ReviewAppointment
