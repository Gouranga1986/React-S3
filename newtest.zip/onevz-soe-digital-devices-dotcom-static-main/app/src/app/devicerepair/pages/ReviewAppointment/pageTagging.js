export const getPageTagging = () => {
  return {
    page: {
      name: 'review appointment details',
    }
  }
}
