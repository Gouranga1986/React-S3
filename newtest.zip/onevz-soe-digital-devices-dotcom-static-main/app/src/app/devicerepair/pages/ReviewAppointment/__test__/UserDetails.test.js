import '@testing-library/jest-dom/extend-expect'
import { render } from '@testing-library/react'
import React from 'react'
import { UserDetails } from '../UserDetails'
import { FormProvider, useForm } from 'react-hook-form'
import { QueryProvider } from '@devicerepair/helpers/testing'

const renderWithForm = (Component, props) => {
  const FormWrapper = () => {
    const methods = useForm()
    return (
      <FormProvider {...methods}>
        <QueryProvider>
          <Component {...props} />
        </QueryProvider>
      </FormProvider>
    )
  }

  return render(<FormWrapper />)
}

describe('<FormFields />', () => {
  test('should render form fields', async () => {
    const { getByRole } = renderWithForm(UserDetails)

    const firtName = getByRole('textbox', { name: 'First name Optional Input Field' })
    expect(firtName).toBeInTheDocument()

    const lastname = getByRole('textbox', { name: 'Last name Optional Input Field' })
    expect(lastname).toBeInTheDocument()

    const contactNumber = getByRole('combobox', { name: 'Best contact number Optional' })
    expect(contactNumber).toBeInTheDocument()

    const email = getByRole('textbox', { name: 'Email Optional Input Field' })
    expect(email).toBeInTheDocument()
  })
})
