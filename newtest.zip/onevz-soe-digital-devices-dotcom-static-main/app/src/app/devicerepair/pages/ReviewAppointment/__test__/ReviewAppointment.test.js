import { queryClient } from '@devicerepair/app'
import '@testing-library/jest-dom/extend-expect'
import { render } from '@testing-library/react'
import React from 'react'
import { QueryClientProvider } from 'react-query'
import ReviewAppointment from '../ReviewAppointment'

jest.mock('@devicerepair/hooks/useRetrieveCLNRInfo')

describe('<ReviewAppointment />', () => {

  test('render loader', async () => {
    const { getByLabelText } = render(
      <QueryClientProvider client={queryClient}>
        <ReviewAppointment />
      </QueryClientProvider>
    )

    const loader = getByLabelText('loader overlay')
    expect(loader).toBeInTheDocument()
  })
})
