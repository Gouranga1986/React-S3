import '@testing-library/jest-dom/extend-expect'
import { render, fireEvent, waitFor } from '@testing-library/react'
import React from 'react'
import YourAppointment, { RelatingTo, ReturnShippingAddress } from '../YourAppointment'
import useStore from '@devicerepair/stores/useStore'
import { FormProvider, useForm } from 'react-hook-form'
import { useHistory } from 'react-router-dom'

jest.mock('@devicerepair/stores/useStore')

jest.mock('react-router-dom', () => ({
  ...jest.requireActual('react-router-dom'),
  useHistory: jest.fn(),
}))

const renderWithForm = (Component, props = {}) => {
  const FormWrapper = () => {
    const methods = useForm()
    return (
      <FormProvider {...methods}>
        <Component {...props} />
      </FormProvider>
    )
  }

  return render(<FormWrapper />)
}

describe('<YourAppointment />', () => {
  const primaryReason = {
    description: 'Power',
  }
  const secondaryReason = {
    description: 'Does Not Power On at all',
  }

  const shippingAddress = {
    street: '23 COTTONWOOD DR',
    city: 'JACKSON',
    state: 'NJ',
    zipCode: '08527',
  }

  const selectedAppointmentTime = {
    startTime: '10:30AM',
    endTime: '11:00AM',
  }

  const selectedAppointmentDate = {
    appointmentDate: '07/23/2024',
    appointmentDay: 'FRI',
  }

  const selectedStore = {
    vendorName: 'UBREAK',
    businessName: 'Asurion Tech Repair & Solutions',
    storeId: '48',
    storeName: 'Goodyear',
    distance: '9.4',
    timeZone: 'America/Phoenix',
    city: 'Goodyear',
    state: 'AZ',
    phone: '6235364880',
    email: '6235364880',
  }

  const mockHistory = {
    push: jest.fn(),
  }

  let setStore = jest.fn()


  beforeEach(() => {
    useStore.mockImplementation(() => ({
      store: {
        primaryReason,
        secondaryReason,
        selectedStore,
        selectedAppointmentDate,
        selectedAppointmentTime,
        shippingAddress,
      },
      setStore,

    }))

    useHistory.mockImplementation(() => mockHistory)
  })

  test('should render compnenet with data', async () => {
    const { getByText } = renderWithForm(YourAppointment)

    const primaryReasonEl = getByText(primaryReason.description)
    expect(primaryReasonEl).toBeInTheDocument()

    const secondaryReasonEl = getByText(secondaryReason.description)
    expect(secondaryReasonEl).toBeInTheDocument()
  })

  test('should navigate to change device', async () => {
    const { getByRole } = renderWithForm(RelatingTo, { reason: 'some reason' })

    const changeDevice = getByRole('link', { name: 'Change device details' })

    fireEvent.click(changeDevice)

    expect(mockHistory.push).toHaveBeenCalledWith('/')
  })

  test('should navigate to shipping address', async () => {
    const { getByRole } = renderWithForm(ReturnShippingAddress)

    const changeShippingAddress = getByRole('link', { name: 'Change return address' })

    fireEvent.click(changeShippingAddress)

    expect(mockHistory.push).toHaveBeenCalledWith('/shipping-address')
    
  })
})
