import { Box, Grid, Stack } from '@devicerepair/components/Flexify'
import useStore from '@devicerepair/stores/useStore'
import { TextLink } from '@vds/buttons'
import { Body, Title } from '@vds/typography'
import dayjs from 'dayjs'
import React, { Fragment } from 'react'
import { useHistory } from 'react-router-dom'
import { useFormContext } from 'react-hook-form'
import { usePageName } from '@devicerepair/hooks/usePageName'

const getUserDetails = (formData) => {
  return {
    firstName: formData?.firstName,
    lastName: formData?.lastName,
    email: formData?.email,
    receiveTextAlert: formData?.receiveTextAlert,
  }
}

export const Reason = ({ reason }) => (
  <Fragment>
    <Body bold size="medium">
      Reason:
    </Body>
    <Body size="medium">{reason}</Body>
  </Fragment>
)

export const RelatingTo = ({ reason }) => {
  const history = useHistory()
  const { getValues } = useFormContext()
  const { setStore } = useStore()
  const pageName = usePageName()

  const onChangeDevice = () => {
    const formData = getValues()
    const userDetails = getUserDetails(formData)
    setStore({ userDetails })
    history.push('/')
  }

  return (
    <Fragment>
      <Body bold size="medium">
        Relating to:
      </Body>
      <Stack gap="20px">
        <Body size="medium">{reason}</Body>
        <Box>
        <Body size="medium">
          <TextLink
            data-track={`{"type":"link","name": "${pageName}-change-device-details-link"}`}
            data-analyticstrack={`${pageName}-change-device-details-link`}
            data-clickstream={`${pageName}-change-device-details-link`}
            onClick={onChangeDevice}
          >
           Change device details 
          </TextLink>
          </Body>
        </Box>
      </Stack>
    </Fragment>
  )
}

export const Location = ({ selectedStore }) => (
  <Fragment>
    <Body bold size="medium">
      Location:
    </Body>
    <Stack gap="2px">
      <Body size="medium">{selectedStore?.storeName}</Body>
      <Stack>
        <Body size="small">{selectedStore?.address1}</Body>
        <Body size="small">{selectedStore?.address2}</Body>
        <Body size="small">
          {selectedStore?.city}, {selectedStore?.state} {selectedStore?.postalCode}
        </Body>
      </Stack>
    </Stack>
  </Fragment>
)

export const Date = ({ selectedAppointmentDate }) => (
  <Fragment>
    <Body bold size="medium">
      Date:
    </Body>
    <Body size="medium">
      {dayjs(selectedAppointmentDate?.appointmentDate).format('dddd MMMM DD, YYYY')}
    </Body>
  </Fragment>
)

export const Time = ({ selectedAppointmentTime }) => {
  const history = useHistory()
  const { getValues } = useFormContext()
  const { setStore } = useStore()
  const pageName = usePageName()

  const onChangeTime = () => {
    const formData = getValues()
    const userDetails = getUserDetails(formData)
    setStore({ userDetails })
    history.push('/store-locator')
  }

  return (
    <Fragment>
      <Body bold size="medium">
        Time:
      </Body>
      <Stack>
        <Body size="medium">{selectedAppointmentTime?.startTime} - {selectedAppointmentTime?.endTime}</Body>
        <Box marginTop="20px">
        <Body size="medium">
          <TextLink
            data-track={`{"type":"link","name": "${pageName}-change-location-time-link"}`}
            data-analyticstrack={`${pageName}-change-location-time-link`}
            data-clickstream={`${pageName}-change-location-time-link`}
            onClick={onChangeTime}
          >
              Change location, date, and time 
          </TextLink>
          </Body>
        </Box>
      </Stack>
    </Fragment>
  )
}

export const ReturnShippingAddress = ({ shippingAddress }) => {
  const history = useHistory()
  const { getValues } = useFormContext()
  const { setStore } = useStore()
  const pageName = usePageName()

  const onChangeAddress = () => {
    const formData = getValues()
    const userDetails = getUserDetails(formData)
    setStore({ userDetails })
    history.push('/shipping-address')
  }

  return (
    <Fragment>
      <Box maxWidth="114px">
        <Body bold size="medium">
          Return shipping address:
        </Body>
      </Box>
      <Stack gap="2px">
        <Body size="medium">{shippingAddress?.street}</Body>
        <Body size="medium">
          {shippingAddress?.city}, {shippingAddress?.state} {shippingAddress?.zipCode}
        </Body>
        <Box marginTop="20px">
        <Body size="medium"> 
          <TextLink
            data-track={`{"type":"link","name": "${pageName}-change-return-address-link"}`}
            data-analyticstrack={`${pageName}-change-return-address-link`}
            data-clickstream={`${pageName}-change-return-address-link`}
            onClick={onChangeAddress}
          >
             Change return address 
          </TextLink>
          </Body>
        </Box>
      </Stack>
    </Fragment>
  )
}

export const AdditionalInfo = ({ additionalInfo }) => (
  <Fragment>
    <Body bold size="medium">
      Additional information:
    </Body>
    <Body size="medium">{additionalInfo}</Body>
  </Fragment>
)

const YourAppointment = () => {
  const { store } = useStore()
  const {
    primaryReason,
    secondaryReason,
    selectedStore,
    selectedAppointmentDate,
    selectedAppointmentTime,
    shippingAddress,
    additionalInfo
  } = store

  return (
    <Stack gap="20px" maxWidth="384px">
      <Title bold size="large">
        Your appointment
      </Title>

      <Grid gridTemplateColumns="repeat(2, 192px)" rowGap={['24px', '20px']}>
        <Reason reason={primaryReason?.description} />
        <RelatingTo reason={secondaryReason?.description} />
        <Location selectedStore={selectedStore} />
        <Date selectedAppointmentDate={selectedAppointmentDate} />
        <Time selectedAppointmentTime={selectedAppointmentTime} />
        <ReturnShippingAddress shippingAddress={shippingAddress} />
        <AdditionalInfo additionalInfo={additionalInfo} />
      </Grid>
    </Stack>
  )
}

export default YourAppointment
