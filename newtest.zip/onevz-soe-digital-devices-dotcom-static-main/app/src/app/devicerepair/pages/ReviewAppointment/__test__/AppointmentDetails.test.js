import { queryClient } from '@devicerepair/app'
import '@testing-library/jest-dom/extend-expect'
import { render, fireEvent, waitFor, screen } from '@testing-library/react'
import React from 'react'
import { QueryClientProvider } from 'react-query'
import AppointmentDetails, { AdditionalInfo } from '../AppointmentDetails'
import useStore from '@devicerepair/stores/useStore'
import useRetrieveCLNRInfo from '@devicerepair/hooks/useRetrieveCLNRInfo'
import useBookAppointment from '@devicerepair/hooks/useBookAppointment'
import { FormProvider, useForm } from 'react-hook-form'
import useCheckEligibility from '@devicerepair/hooks/useCheckEligibility'

const renderWithForm = (Component, props = {}) => {
  const FormWrapper = () => {
    const methods = useForm()
    return (
      <QueryClientProvider client={queryClient}>
        <FormProvider {...methods}>
          <Component {...props} />
        </FormProvider>
      </QueryClientProvider>
    )
  }

  return render(<FormWrapper />)
}

jest.mock('@devicerepair/stores/useStore')
jest.mock('@devicerepair/hooks/useRetrieveCLNRInfo')
jest.mock('@devicerepair/hooks/useBookAppointment')
jest.mock('@devicerepair/hooks/useCheckEligibility')

const mockHistoryPush = jest.fn()
const mockHistoryReplace = jest.fn()

jest.mock('react-router-dom', () => ({
  ...jest.requireActual('react-router-dom'),
  useHistory: () => ({
    push: mockHistoryPush,
    replace: mockHistoryReplace,
  }),
}))

const selectedMTN = "1233457890"

const primaryReason = {
  description: 'Power',
}
const secondaryReason = {
  description: 'Does Not Power On at all',
}

const shippingAddress = {
  street: '23 COTTONWOOD DR',
  city: 'JACKSON',
  state: 'NJ',
  zipCode: '08527',
}

const selectedAppointmentTime = {
  startTime: '10:30AM',
  endTime: '11:00AM',
}

const selectedAppointmentDate = {
  appointmentDate: '07/23/2024',
  appointmentDay: 'FRI',
}

const additionalInfo = 'some comments'

const selectedStore = {
  vendorName: 'UBREAK',
  businessName: 'Asurion Tech Repair & Solutions',
  storeId: '48',
  storeName: 'Goodyear',
  distance: '9.4',
  timeZone: 'America/Phoenix',
  city: 'Goodyear',
  state: 'AZ',
  phone: '6235364880',
  email: '6235364880',
  drivingDistance: '5.291',
  earliestAppDate: '2024-02-22',
  address2: '111',
  address1: '14155 W. Bell Rd.',
  postalCode: '85374',
  countryCode: 'US',
}

describe('<AppointmentDetails />', () => {
  let setStore = jest.fn()
  let bookAppointment = jest.fn()
  let checkEligibility


  beforeEach(() => {
    useStore.mockImplementation(() => ({
      store: {
        primaryReason,
        secondaryReason,
        selectedStore,
        selectedAppointmentDate,
        selectedAppointmentTime,
        shippingAddress,
        additionalInfo,
        selectedMTN
      },
      setStore,
    }))

    useRetrieveCLNRInfo.mockImplementation(() => ({
      data: {
        cart: {
          lineDetails: {
            lineInfo: [
              {
                itemsInfo: [
                  {
                    shipping: {
                      address: {
                        emailId: 'KARIANN2375@GMAIL.COM',
                        phoneNumber: '7322281339',
                      },
                      firstName: 'KARI',
                      lastName: 'MCNAIR',
                    },
                  },
                ],
              },
            ],
          },
        },
      },
      isLoading: false,
    }))

    bookAppointment = jest.fn().mockResolvedValue({
      confirmationId: '43434534534',
    })

    useBookAppointment.mockReturnValue({
      mutateAsync: bookAppointment,
      isLoading: false,
    })


    checkEligibility = jest.fn().mockResolvedValue({
      data: {
        data: {
          repairEligible: true, // change to false to test ineligible path
        },
      },
    })

    useCheckEligibility.mockReturnValue({
      mutateAsync: checkEligibility,
      isLoading: false,
    })

  })

  test('render loader', async () => {
    const { getByRole } = renderWithForm(AppointmentDetails)

    const form = getByRole('form')
    expect(form).toBeInTheDocument()
  })

  test('should update additional info', async () => {
    const newComment = 'new comment'
    const { getByRole } = renderWithForm(AdditionalInfo)

    const additionalInfoInput = getByRole('textbox', {
      name: 'Additional information about your issue: Optional Input Field 0 out of 200 characters entered',
    })
    fireEvent.change(additionalInfoInput, {
      target: { value: newComment },
    })
    expect(setStore).toHaveBeenCalledWith({
      additionalInfo: newComment,
    })
  })

  test('on form submit', async () => {

    const { getByRole } = renderWithForm(AppointmentDetails)

    const confirmButton = getByRole('button', { name: 'Confirm appointment' })
    // fireEvent.submit(confirmButton)

    expect(confirmButton).toBeEnabled()

    // await waitFor(() => {
    //   expect(checkEligibility).toHaveBeenCalled()
    // })
  })
})
