import { useMediaQuery } from '@devicerepair/components/Flexify'
import '@testing-library/jest-dom/extend-expect'
import { render } from '@testing-library/react'
import React from 'react'
import Actions from '../Actions'

jest.mock('@devicerepair/components/Flexify', () => ({
  ...jest.requireActual('@devicerepair/components/Flexify'),
  useMediaQuery: jest.fn(),
}))

// const mockHistoryPush = jest.fn()

// jest.mock('react-router-dom', () => ({
//   ...jest.requireActual('react-router-dom'),
//   useHistory: () => ({
//     push: mockHistoryPush,
//   }),
// }))

describe('<Actions />', () => {
  beforeEach(() => {
    useMediaQuery.mockImplementation(() => ({
      isMobile: false,
      isDesktop: true,
    }))
  })

  test('render component ', async () => {
    const { getByRole } = render(<Actions />)
    const continueButton = getByRole('button', { name: 'Confirm appointment' })

    expect(continueButton).toBeInTheDocument()
  })
})
