import { Box, Stack } from '@devicerepair/components/Flexify'
import useBookAppointment from '@devicerepair/hooks/useBookAppointment'
import useRetrieveCLNRInfo from '@devicerepair/hooks/useRetrieveCLNRInfo'
import useSteps from '@devicerepair/stores/useSteps'
import useStore from '@devicerepair/stores/useStore'
import { TextArea } from '@vds4/inputs'
import { Loader } from '@vds/loaders'
import React, { useEffect, useState } from 'react'
import { useForm, Controller, FormProvider, useFormContext } from 'react-hook-form'
import { useHistory } from 'react-router-dom'
import Actions from './Actions'
import { UserDetails } from './UserDetails'
import YourAppointment from './YourAppointment'
import useCheckEligibility from '@devicerepair/hooks/useCheckEligibility'
import { Notification } from '@vds/notifications'
import useNotifications from '@devicerepair/stores/useNotifications'
import { dispatchNotify } from '@devicerepair/services/tagging'
import { CustomTextArea } from '../EligibleDevice/Details'

export const AdditionalInfo = () => {
  const { control } = useFormContext()

  const { setStore } = useStore()

  const onChange = (e, onFieldChange) => {
    const additionalInfo = e?.target?.value
    setStore({ additionalInfo })
    onFieldChange?.(additionalInfo)
  }

  return (
    <Box maxWidth="424px">
      <Controller
        name="additionalInfo"
        control={control}
        render={({ field }) => (
          <CustomTextArea
            {...field}
            required={true}
            readOnly={true}
            label="Additional information about your issue:"
            maxLength={200}
            onChange={(e) => onChange(e, field?.onChange)}
            data-analyticstrack="IssueAdditionalInfo-textarea"
            data-track='{"type": "link", "name": "Additional information about your issue"}'
            data-analyticstrack="Additional information about your issue"
            data-clickstream="Additional information about your issue"
          />
        )}
      />
    </Box>
  )
}

export const getUserDetails = (CLNRInfo, userDetails) => {
  if (userDetails) return userDetails
  if (!CLNRInfo) return

  const shipping = CLNRInfo?.cart?.lineDetails?.lineInfo?.[0]?.itemsInfo?.[0]?.shipping

  return {
    firstName: shipping?.firstName,
    lastName: shipping?.lastName,
    email: shipping?.address?.emailId,
    phoneNumber: shipping?.address?.phoneNumber,
    receiveTextAlert: false,
  }
}

const NotEligible = () => {
  
  useEffect(() => {
    dispatchNotify({
      name: 'Not Eligible',
      message: `This device is no longer eligible for repair`,
      error: true,
    })
  }, [])

  return (
    <Box maxWidth="808px">
      <Notification
        type="error"
        title="Not Eligible"
        subtitle="This device is no longer eligible for repair"
        fullBleed={false}
        inline={false}
        disableFocus={true}
        hideCloseButton={true}
        disableAnimation={false}
      />
    </Box>
  )
}

const AppointmentDetails = () => {
  const { store } = useStore()
  const [notEligibleAnymore, setNoEligibleAnymore] = useState(false)

  const {
    primaryReason,
    secondaryReason,
    selectedStore,
    selectedAppointmentDate,
    selectedAppointmentTime,
    shippingAddress,
    additionalInfo,
    selectedMTN,
  } = store

  const addNotification = useNotifications((store) => store?.addNotification)
  const resetNotifications = useNotifications((store) => store?.reset)

  const { data: CLNRInfo } = useRetrieveCLNRInfo()
  const userDetails = getUserDetails(CLNRInfo, store?.userDetails)
  const history = useHistory()
  const { mutateAsync: bookAppointment, isLoading } = useBookAppointment()
  const resetSteps = useSteps((state) => state.reset)
  const { mutateAsync: checkEligibility, isLoading: checkingIsStillEligible } =
    useCheckEligibility()

  const formMethods = useForm({
    mode: 'onBlur',
    defaultValues: {
      primaryReason: primaryReason?.description,
      secondaryReason: secondaryReason?.description,
      retailStore: {
        storeName: selectedStore?.storeName,
        storeId: selectedStore?.storeId,
        address1: selectedStore?.address1,
        address2: selectedStore?.address2,
        city: selectedStore?.city,
        state: selectedStore?.state,
        postalCode: selectedStore?.postalCode,
      },
      appointmentDate: selectedAppointmentDate?.appointmentDate,
      appointmentTime: selectedAppointmentTime?.startTime,
      returnShippingAddress: shippingAddress,
      additionalInfo,
      firstName: userDetails?.firstName,
      lastName: userDetails?.lastName,
      contactNumber: selectedMTN,
      email: userDetails?.email,
      receiveTextAlert: userDetails?.receiveTextAlert,
    },
  })

  const onSubmit = async (formdata) => {
    resetNotifications()
    const stillEligible = await checkEligibility()
    const repairEligible = stillEligible?.data?.data?.repairEligible
    if (!repairEligible) {
      setNoEligibleAnymore(true)
      return
    }

    const response = await bookAppointment(formdata)
    const confirmationId = response?.context?.orderWrite?.orderDetails?.[0]?.orderNum

    if (!confirmationId) {
      addNotification({
        type: 'error',
        title: 'Failed to confirm appointment.',
        subtitle: 'Confirmation details missing',
      })
    }

    if (!confirmationId) return // verify if confirmationId available in response

    resetSteps()
    history.replace(`/confirmed-appointment/${confirmationId}`)
  }

  return (
    <FormProvider {...formMethods}>
      <Stack
        as="form"
        role="form"
        onSubmit={formMethods?.handleSubmit(onSubmit)}
        gap={['24px', '32px']}
        position="relative"
      >
        {(isLoading || checkingIsStillEligible) && <Loader active fullScreen={false} />}
        <Stack flexDirection={['column', 'row']} gap={['24px', '40px']}>
          <YourAppointment />
          {/* <UserDetails /> */}
        </Stack>

        {/* <AdditionalInfo /> */}
        {notEligibleAnymore && <NotEligible />}
        <Actions isDisabled={!formMethods?.formState?.isValid} />
      </Stack>
    </FormProvider>
  )
}

export default AppointmentDetails
