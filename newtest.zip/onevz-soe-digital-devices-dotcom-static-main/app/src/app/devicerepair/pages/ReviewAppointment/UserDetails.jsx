import React from 'react'
import { Stack, Box } from '@devicerepair/components/Flexify'
import { Input } from '@vds4/inputs'
import { DropdownSelect } from '@vds/selects'
import { Controller, useFormContext } from 'react-hook-form'
import { Checkbox } from '@vds/checkboxes'
import { useMTNs } from '@devicerepair/hooks/useDeviceRepair'
import useStore from '@devicerepair/stores/useStore'
import { formatPhoneNumber } from '@devicerepair/helpers/formater'

export const UserDetails = () => {
  const { control } = useFormContext()
  const mtns = useMTNs()
  const store = useStore((state) => state?.store)
  const phoneNumbers = mtns.map((m) => m.mtn)

  return (
    <Stack gap={['24px', '16px']} width={['100%', '328px']}>
      <Box>
        <Controller
          name="firstName"
          control={control}
          rules={{ required: 'This field is required' }}
          render={({ field, fieldState, formState: { errors } }) => (
            <Input
              label="First name"
              error={!!errors?.firstName}
              errorText={errors?.firstName?.message}
              width="100%"
              success={!fieldState?.invalid}
              {...field}
            />
          )}
        />
      </Box>
      <Box>
        <Controller
          name="lastName"
          control={control}
          rules={{ required: 'This field is required' }}
          render={({ field, fieldState, formState: { errors } }) => (
            <Input
              {...field}
              label="Last name"
              error={!!errors?.lastName}
              errorText={errors?.lastName?.message}
              width="100%"
              success={!errors?.lastName}
            />
          )}
        />
      </Box>
      <Box>
        <Controller
          name="contactNumber"
          control={control}
          rules={{ required: 'This field is required' }}
          render={({ field, fieldState, formState: { errors } }) => (
            <DropdownSelect
              {...field}
              label="Best contact number"
              defaultValue={store?.selectedMTN}
              data-track='{"type": "link", "name": "Best contact number"}'
              data-analyticstrack="Best contact number"
              data-clickstream="Best contact number"
              error={!!errors?.contactNumber}
              errorText={errors?.contactNumber?.message}
              success={!errors?.contactNumber}
            >
              {phoneNumbers?.map((phoneNumber) => (
                <option key={phoneNumber} value={phoneNumber}>
                  {formatPhoneNumber(phoneNumber)}
                </option>
              ))}
            </DropdownSelect>
          )}
        />
      </Box>
      <Box>
        <Controller
          name="email"
          control={control}
          rules={{ required: 'This field is required' }}
          render={({ field, fieldState, formState: { errors } }) => (
            <Input
              {...field}
              label="Email"
              error={!!errors?.email}
              errorText={errors?.email?.message}
              width="100%"
              success={!errors?.email}
            />
          )}
        />
      </Box>
      <Box>
        <Controller
          name="receiveTextAlert"
          control={control}
          render={({ field }) => (
            <Checkbox {...field} width="auto" selected={field?.value} required={false}>
              Receive text alerts about your visit
            </Checkbox>
          )}
        />
      </Box>
    </Stack>
  )
}
