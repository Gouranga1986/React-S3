import React from 'react'
import { Button } from '@vds/buttons'
import { useResponsiveValue } from '@devicerepair/components/Flexify'

const Actions = ({ isDisabled }) => {
  const width = useResponsiveValue(['100%', '220px'])

  return (
    <Button
      type="submit"
      width={width}
      disabled={isDisabled}
      data-track={`{"type":"link","name": "confirm-appointment-button"}`}
      data-analyticstrack="confirm-appointment-button"
      data-clickstream="confirm-appointment-button"
    >
      Confirm appointment
    </Button>
  )
}
export default Actions
