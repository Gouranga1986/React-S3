import React from 'react'
import { Tilelet } from '@vds/tiles'
import { Stack, useResponsiveValue } from '@devicerepair/components/Flexify'
import useContent from '@devicerepair/stores/useContent'

export const ActionTiles = () => {
  const width = useResponsiveValue(['100%', '360px'])
  const { options: tiles } = useContent((store) => store?.content?.ineligible || {})

  const redirectToCallUs = () => {
    const callUsNowUrl = '/digital/nsa/secure/ui/contactus/signinlanding/callus?breadcrumb=support/contactus/mobile/Troubleshoot/skipthisstep'
    window.location.href = callUsNowUrl
  }

  const openChat = () => {
    window?.EchannelVera?.init({ userText: 'Device repair support' })
  }

  const handleTileClick = (action) => {
    switch (action) {
      case 'redireciton':
        redirectToCallUs()
        break
      case 'openchat':
        openChat()
        break
      default:
        return
    }
  }

  return (
    <Stack gap="16px" flexDirection={['column', 'row']}>
      {tiles?.map((tile) => (
        <Tilelet
          key={tile?.text}
          title={{
            bold: true,
            size: 'titleSmall',
            children: tile?.text,
          }}
          subtitle={{
            size: 'bodyLarge',
            children: tile.subText,
            color: 'primary',
          }}
          directionalIcon={{
            name: 'right-arrow',
            size: 'medium',
          }}
          surface="light"
          width={width}
          height="150px"
          onClick={() => {
            handleTileClick(tile?.action)
          }}
          backgroundColor="gray"
          data-track={`{"type":"link","name": "tile-${tile?.text}"}`}
          data-analyticstrack={`tile-${tile?.text}`}
          data-clickstream={`tile-${tile?.text}`}
        />
      ))}
    </Stack>
  )
}
