import '@testing-library/jest-dom/extend-expect'
import { render, fireEvent } from '@testing-library/react'
import React from 'react'
import { ActionTiles } from '../ActionTiles'
import useContent from '@devicerepair/stores/useContent'

jest.mock('@devicerepair/stores/useContent')

const tiles = [
  {
    text: "Call us now or we'll call you",
    subText: 'Estimated wait time 12 minutes',
    action: 'redireciton',
  },
  {
    text: 'Chat with us',
    subText: 'Estimated wait time 5 minutes',
    action: 'openchat',
  },
]

describe('<ActionTiles />', () => {
  beforeEach(() => {
    useContent.mockReturnValue({
      options: tiles,
    })
  })

  test('render action tiles', async () => {
    const { getAllByRole } = render(<ActionTiles />)

    const tiles = getAllByRole('button')
    expect(tiles).toHaveLength(2)
  })

  test('should redirect to call us url', async () => {
    const href = '/digital/nsa/secure/ui/contactus/signinlanding/callus?breadcrumb=support/contactus/mobile/Troubleshoot/skipthisstep'
    const { getByRole } = render(<ActionTiles />)

    const callUsNow = getByRole('button', {
      name: "Call us now or we'll call you Estimated wait time 12 minutes",
    })

    delete window.location
    window.location = {
      href: jest.fn(),
    }

    fireEvent.click(callUsNow)

    expect(window.location.href).toBe(href)
  })

  test('should invoke chat', async () => {
    let init = jest.fn()
    const { getByRole } = render(<ActionTiles />)

    const chat = getByRole('button', {
      name: 'Chat with us Estimated wait time 5 minutes',
    })

    window.EchannelVera = {
      init,
    }

    fireEvent.click(chat)

    expect(init).toHaveBeenCalled()
  })

  test('should not take any action', async () => {
    useContent.mockReturnValue({
      options: [
        {
          text: 'Invalid tile',
          action: '',
        },
      ],
    })

    let action = jest.fn()
    const { getByRole } = render(<ActionTiles />)

    const invalidTile = getByRole('button', {
      name: 'Invalid tile',
    })

    fireEvent.click(invalidTile)

    expect(action).not.toHaveBeenCalled()
  })
})
