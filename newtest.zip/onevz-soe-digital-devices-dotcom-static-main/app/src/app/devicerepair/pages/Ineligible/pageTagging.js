export const getPageTagging = () => {
  return {
    page: {
      name: 'inelgible for repair',
    }
  }
}
