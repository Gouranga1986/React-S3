import '@testing-library/jest-dom/extend-expect'
import { render } from '@testing-library/react'
import React from 'react'
import Ineligible from '../Ineligible'
import { QueryClientProvider } from 'react-query'
import { queryClient } from '@devicerepair/app'

describe('<Ineligible />', () => {
  test('render component', async () => {
    const { getByLabelText } = render(
      <QueryClientProvider client={queryClient}>
        <Ineligible />
      </QueryClientProvider>
    )

    const loader = getByLabelText('loader overlay')
    expect(loader).toBeInTheDocument()
  })
})
