import React from 'react'
import Page from '@devicerepair/components/Page'
import { ActionTiles } from './ActionTiles'
import Header from '@devicerepair/components/Header'
import useContent from '@devicerepair/stores/useContent'
import { getPageTagging } from './pageTagging'
import { useSetPage } from '@devicerepair/services/tagging'

const Ineligible = () => {
  useSetPage(getPageTagging(), { enabled: true })
  const { title, description } = useContent((store) => store?.content?.ineligible || {})

  return (
    <Page>
      <Header title={title} description={description} />
      <ActionTiles />
    </Page>
  )
}

export default Ineligible
