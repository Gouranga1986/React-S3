import '@testing-library/jest-dom/extend-expect'
import { render } from '@testing-library/react'
import React from 'react'
import Header from './Header'

const content = {
  title: 'You’re eligible for a device repair.',
  description:
    'Device repairs are handled by our authorized repair vendors. Continue below to set up your appointment now through their store scheduler.',
}

describe('<Header />', () => {
  test('render component', async () => {
    const { getByText } = render(<Header title={content.title} description={content.description} />)

    const title = getByText(content.title)
    expect(title).toBeInTheDocument()

    const description = getByText(content.description)
    expect(description).toBeInTheDocument()
  })
})
