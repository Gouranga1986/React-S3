import { Stack, useResponsiveValue } from '@devicerepair/components/Flexify'
import { usePageName } from '@devicerepair/hooks/usePageName'
import { Button } from '@vds/buttons'
import React from 'react'
import { useHistory } from 'react-router-dom'

const ActionNav = ({ children }) => {
  const history = useHistory()
  const width = useResponsiveValue(['100%', '226px'])
  const pageName = usePageName()

  const onBack = () => {
    history.goBack()
  }

  return (
    <Stack flexDirection={['column', 'row']} alignItems={['center', 'flex-start']} gap="12px">
      {children}
      <Button
        type="button"
        data-track={`{"type":"link","name": "${pageName}-back-button"}`}
        data-analyticstrack={`${pageName}-back-button`}
        data-clickstream={`${pageName}-back-button`}
        width={width}
        use="secondary"
        onClick={onBack}
      >
        Back
      </Button>
    </Stack>
  )
}

export default ActionNav
