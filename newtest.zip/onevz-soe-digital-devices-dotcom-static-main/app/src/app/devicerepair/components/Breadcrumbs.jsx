import React from "react";
import {
  Breadcrumbs as VDSBreadcrumbs,
  BreadcrumbItem,
} from "@vds/breadcrumbs";

const Breadcrumbs = () => {
  return (
    <VDSBreadcrumbs surface="light">
      <BreadcrumbItem href="/digital/nsa/secure/ui/support/signinlanding">Support</BreadcrumbItem>
      <BreadcrumbItem>Schedule device repair appointment</BreadcrumbItem>
    </VDSBreadcrumbs>
  );
};

export default Breadcrumbs;
