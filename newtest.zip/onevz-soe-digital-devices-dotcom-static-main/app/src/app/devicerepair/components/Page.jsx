import React from 'react';
import Breadcrumbs from '@devicerepair/components/Breadcrumbs';
import useDeviceRepair from '@devicerepair/hooks/useDeviceRepair';
import PageLoader from '@devicerepair/components/PageLoader';
import { Stack } from './Flexify';
import GlobalNotifications from './GlobalNotifications';

const Page = ({ children, ...stackProps }) => {
  const { data: deviceRepair } = useDeviceRepair();

  if (!deviceRepair) return <PageLoader />;

  return (
    <Stack maxWidth="1272px" margin="auto" padding={['16px', '16px 16px 64px 16px']} gap={['24px', '32px']} {...stackProps}>
      <Breadcrumbs />
      <GlobalNotifications />

      {children}
    </Stack>
  );
};

export default Page;
