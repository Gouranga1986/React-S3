import React from 'react'
import { Box } from '@devicerepair/components/Flexify'
import { TitleLockup } from '@vds/type-lockups'

const Header = ({ title, description }) => {

  return (
    <Box maxWidth={['100%', '808px']}>
      <TitleLockup
        data={{
          title: {
            size: 'titleXLarge',
            children: title,
          },
          subtitle: {
            size: 'bodyLarge',
            children: description,
          },
        }}
      />
    </Box>
  )
}

export default Header
