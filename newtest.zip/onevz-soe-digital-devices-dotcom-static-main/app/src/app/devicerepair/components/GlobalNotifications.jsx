import useNotifications from '@devicerepair/stores/useNotifications'
import React, { useEffect } from 'react'
import { Stack } from './Flexify'
import { Notification } from '@vds/notifications'
import { useLocation } from 'react-router-dom'
import { dispatchNotify } from '@devicerepair/services/tagging'

const GlobalNotifications = () => {
  const { notifications, removeNotification, reset } = useNotifications()
  const location = useLocation()

  // // clear notifiation when route change
  useEffect(() => {
    if (notifications?.length) reset()
  }, [location?.pathname])

  useEffect(() => {
    notifications.forEach((notification) => {
      dispatchNotify({
        name: notification.title,
        message: notification.subtitle,
        error: notification.type === 'error',
      })
    })
  }, [notifications])

  if (!notifications.length) return null

  return (
    <Stack gap="16px">
      {notifications?.map((notification, index) => (
        <Notification
          key={notification?.title}
          {...notification}
          onCloseButtonClick={() => removeNotification(index)}
        />
      ))}
    </Stack>
  )
}

export default GlobalNotifications
