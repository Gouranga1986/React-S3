import { Loader } from '@vds/loaders'
import React from 'react'
import { Box } from '@devicerepair/components/Flexify'

const PageLoader = () => {
  return (
    <Box width="100%" height="80vh" position="relative">
      <Loader fullScreen={false} active />
    </Box>
  )
}

export default PageLoader
