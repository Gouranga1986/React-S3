import React from 'react'
import { Body, Title } from '@vds/typography'
import { ColorTokens } from '@vds-tokens/color'
import { Button } from '@vds/buttons'
import { Center } from './Flexify'

const deviceRepairHome = '/digital/nsa/secure/ui/devices/clnr/schedule-device-repair/'

const ErrrorPage = () => (
  <Center height="calc(100vh - 350px)" maring="20px">
    <Center
      backgroundColor={ColorTokens.feedback.error.background.onlight.value}
      width={['auto', '500px']}
      height="300px"
      borderRadius="0.25rem"
      gap="10px"
      padding="10px"
    >
      <Title>Error Occurred</Title>
      <Body>Apologies. Technical problem. Refresh and retry.</Body>
      <Button
        href={deviceRepairHome}
        use="primary"
        size="small"
        data-track={`{"type":"link","name": "error-page-return-home"}`}
        data-analyticstrack="error-page-return-home"
        data-clickstream="error-page-return-home"
      >
        return home
      </Button>
    </Center>
  </Center>
)

export default ErrrorPage
