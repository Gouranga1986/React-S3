import React from "react";
import { act, fireEvent, render, screen } from "@testing-library/react";
import { Provider } from 'react-redux';
import { configureStore } from 'redux-mock-store';
import "@testing-library/jest-dom";
import AdvanceControls from "./AdvanceControls";
import * as deviceLandingActions from '../actions';
import rootReducer from "../../reducers";
import { thunk } from 'redux-thunk';

const mockStoreConfig = configureStore([thunk]);
const mockDeviceList = {
  "pageAttributes": [
      {
          "itemKey": "pageTitle",
          "itemValue": "Devices blocks",
          "itemAttributes": {}
      },
      {
          "itemKey": "hashedAccountNumber",
          "itemValue": "##HASHED_ACCTNO##",
          "itemType": "text",
          "itemAttributes": {}
      },
      {
          "itemKey": "hashedMdn",
          "itemValue": "##HASHED_MDN##",
          "itemType": "text",
          "itemAttributes": {}
      }
  ],
  "sections": [
      {
          "sectionIndex": "0",
          "sectionId": "devicesBlocksMainSection",
          "sectionType": "devicesBlocksMainSection",
          "sectionComponentId": "GenericComponent",
          "sections": [
              {
                  "sectionIndex": "0",
                  "sectionId": "devicesBlocksPageSection",
                  "sectionType": "devicesSection",
                  "actions": [
                      {
                          "actionType": "http",
                          "actionValue": "https://vzwqa1.verizonwireless.com/devices/",
                          "actionKey": "shopADevicetAction",
                          "clickStream": "shop-a-device-cta"
                      },
                      {
                          "actionType": "http",
                          "actionValue": "https://vzwqa1.verizonwireless.com/digital/nsa/secure/ui/acct/pending-account",
                          "actionKey": "pendingOrderAction",
                          "clickStream": "pending-order-cta"
                      }
                  ],
                  "contents": [
                      {
                          "contentIndex": "0",
                          "items": [
                              {
                                  "itemKey": "headerText",
                                  "itemType": "text",
                                  "itemValue": "Blocks",
                                  "itemAttributes": {}
                              },
                              {
                                  "itemKey": "subHeaderText",
                                  "itemType": "text",
                                  "itemValue": "Temporarily block calls and messages, use of services, and certain types of purchases with this free My Verizon service.",
                                  "itemAttributes": {}
                              },
                              {
                                  "itemKey": "devicesHeader",
                                  "itemType": "text",
                                  "itemValue": "Devices",
                                  "itemAttributes": {}
                              },
                              {
                                  "itemKey": "selectDeviceText",
                                  "itemType": "text",
                                  "itemValue": "Please select a device.",
                                  "dataKey": "devices",
                                  "itemAttributes": {}
                              },
                              {
                                  "itemKey": "deviceDisabledText",
                                  "itemType": "text",
                                  "itemValue": "Devices disabled",
                                  "itemAttributes": {}
                              },
                              {
                                  "itemKey": "shopADevicetBtn",
                                  "itemType": "button",
                                  "itemValue": "Shop a device",
                                  "itemAttributes": {},
                                  "actionKey": "shopADevicetAction"
                              },
                              {
                                  "itemKey": "pendingOrderMsg",
                                  "itemType": "text",
                                  "itemValue": "You have one or more pending orders on your account. To block a service, your pending order(s) will need to be cancelled.",
                                  "itemAttributes": {}
                              },
                              {
                                  "itemKey": "pendingOrderBtn",
                                  "itemType": "button",
                                  "itemValue": "Go to pending orders",
                                  "itemAttributes": {},
                                  "actionKey": "pendingOrderAction"
                              },
                              {
                                  "itemKey": "fiveGRedirectUrl",
                                  "itemType": "text",
                                  "itemValue": "http://www.google.com",
                                  "itemAttributes": {}
                              }
                          ]
                      }
                  ],
                  "data": {
                      "accountType": "mobileSecure",
                      "devices": [
                          {
                              "spotDeviceMessage": "",
                              "mtn": "7049956931",
                              "encryptedMtn": "tlGLL3TP7KiWMbweWlF91g%3D%3D",
                              "deviceMake": "GGL",
                              "deviceModel": "Google Pixel 7 Pro 512GB in Obsidian",
                              "deviceNickname": "RAVI WRIGHT",
                              "displayMtn": "704.995.6931",
                              "role": "Member",
                              "basicPhoneFiveG": false,
                              "isFiveGDevice": false,
                              "isFiveGHomeVoiceDevice": false,
                              "isFiveGModDeviceMtn": false,
                              "isSpotDevice": false,
                              "images": {
                                  "defaultImage": "https://ss7.vzw.com/is/image/VerizonWireless/pixel-7-pro-obsidian-ga03414-us",
                                  "largeImage": "https://ss7.vzw.com/is/image/VerizonWireless/pixel-7-pro-obsidian-ga03414-us?$device-lg$",
                                  "mediumImage": "https://ss7.vzw.com/is/image/VerizonWireless/pixel-7-pro-obsidian-ga03414-us?$device-med$",
                                  "miniImage": "https://ss7.vzw.com/is/image/VerizonWireless/pixel-7-pro-obsidian-ga03414-us?$device-mini$",
                                  "thumbImage": "https://ss7.vzw.com/is/image/VerizonWireless/pixel-7-pro-obsidian-ga03414-us?$device-thumb$"
                              }
                          },
                          {
                              "spotDeviceMessage": "",
                              "mtn": "7045759998",
                              "encryptedMtn": "Q3PqtpzP006lxXhwY297Fg%3D%3D",
                              "deviceMake": "SAM",
                              "deviceModel": "Samsung Galaxy S24 Ultra 512GB in Titanium Black",
                              "deviceNickname": "RAVI WRIGHT",
                              "displayMtn": "704.575.9998",
                              "role": "Owner",
                              "basicPhoneFiveG": false,
                              "isFiveGDevice": false,
                              "isFiveGHomeVoiceDevice": false,
                              "isFiveGModDeviceMtn": false,
                              "isSpotDevice": false,
                              "images": {
                                  "defaultImage": "https://ss7.vzw.com/is/image/VerizonWireless/samsung-eureka-e3-titaniumblack",
                                  "largeImage": "https://ss7.vzw.com/is/image/VerizonWireless/samsung-eureka-e3-titaniumblack?$device-lg$",
                                  "mediumImage": "https://ss7.vzw.com/is/image/VerizonWireless/samsung-eureka-e3-titaniumblack?$device-med$",
                                  "miniImage": "https://ss7.vzw.com/is/image/VerizonWireless/samsung-eureka-e3-titaniumblack?$device-mini$",
                                  "thumbImage": "https://ss7.vzw.com/is/image/VerizonWireless/samsung-eureka-e3-titaniumblack?$device-thumb$"
                              }
                          },
                          {
                              "spotDeviceMessage": "",
                              "mtn": "7049931315",
                              "encryptedMtn": "40MSQEMFlc1v9hPsUwrpIQ%3D%3D",
                              "deviceMake": "APL",
                              "deviceModel": "IPHONE14 PRO GENERIC NVZW",
                              "deviceNickname": "RAVI WRIGHT",
                              "displayMtn": "704.993.1315",
                              "role": "Manager",
                              "basicPhoneFiveG": false,
                              "isFiveGDevice": false,
                              "isFiveGHomeVoiceDevice": false,
                              "isFiveGModDeviceMtn": false,
                              "isSpotDevice": false,
                              "images": {
                                  "defaultImage": "https://ss7.vzw.com/is/image/VerizonWireless/DU-fallback-smartphone-03152023",
                                  "largeImage": "https://ss7.vzw.com/is/image/VerizonWireless/DU-fallback-smartphone-03152023?$device-lg$",
                                  "mediumImage": "https://ss7.vzw.com/is/image/VerizonWireless/DU-fallback-smartphone-03152023?$device-med$",
                                  "miniImage": "https://ss7.vzw.com/is/image/VerizonWireless/DU-fallback-smartphone-03152023?$device-mini$",
                                  "thumbImage": "https://ss7.vzw.com/is/image/VerizonWireless/DU-fallback-smartphone-03152023?$device-thumb$"
                              }
                          },
                          {
                              "spotDeviceMessage": "",
                              "mtn": "7049952838",
                              "encryptedMtn": "JhzP2xgRyxPbVvlB6tHUcA%3D%3D",
                              "deviceMake": "APL",
                              "deviceModel": "Apple iPhone 11 (PRODUCT)RED 64GB (2019)",
                              "deviceNickname": "RAVI WRIGHT",
                              "displayMtn": "704.995.2838",
                              "role": "Non Registered",
                              "basicPhoneFiveG": false,
                              "isFiveGDevice": false,
                              "isFiveGHomeVoiceDevice": false,
                              "isFiveGModDeviceMtn": false,
                              "isSpotDevice": false,
                              "images": {
                                  "defaultImage": "https://ss7.vzw.com/is/image/VerizonWireless/Apple_iPhone_11_Red_09102019",
                                  "largeImage": "https://ss7.vzw.com/is/image/VerizonWireless/Apple_iPhone_11_Red_09102019?$device-lg$",
                                  "mediumImage": "https://ss7.vzw.com/is/image/VerizonWireless/Apple_iPhone_11_Red_09102019?$device-med$",
                                  "miniImage": "https://ss7.vzw.com/is/image/VerizonWireless/Apple_iPhone_11_Red_09102019?$device-mini$",
                                  "thumbImage": "https://ss7.vzw.com/is/image/VerizonWireless/Apple_iPhone_11_Red_09102019?$device-thumb$"
                              }
                          },
                          {
                              "spotDeviceMessage": "",
                              "mtn": "7049956420",
                              "encryptedMtn": "gjpI5g4MFVP%2BLko1YMeOKA%3D%3D",
                              "deviceMake": "APL",
                              "deviceModel": "Apple iPhone 12 128GB in White",
                              "deviceNickname": "RAVI WRIGHT",
                              "displayMtn": "704.995.6420",
                              "role": "Non Registered",
                              "basicPhoneFiveG": false,
                              "isFiveGDevice": false,
                              "isFiveGHomeVoiceDevice": false,
                              "isFiveGModDeviceMtn": false,
                              "isSpotDevice": false,
                              "images": {
                                  "defaultImage": "https://ss7.vzw.com/is/image/VerizonWireless/apple-iphone-12-white-10132020",
                                  "largeImage": "https://ss7.vzw.com/is/image/VerizonWireless/apple-iphone-12-white-10132020?$device-lg$",
                                  "mediumImage": "https://ss7.vzw.com/is/image/VerizonWireless/apple-iphone-12-white-10132020?$device-med$",
                                  "miniImage": "https://ss7.vzw.com/is/image/VerizonWireless/apple-iphone-12-white-10132020?$device-mini$",
                                  "thumbImage": "https://ss7.vzw.com/is/image/VerizonWireless/apple-iphone-12-white-10132020?$device-thumb$"
                              }
                          },
                          {
                              "spotDeviceMessage": "",
                              "mtn": "9124092690",
                              "encryptedMtn": "E5ClCRYrjXfZHwSjhbr6kw%3D%3D",
                              "deviceMake": "SAM",
                              "deviceModel": "Samsung Galaxy S23 128GB in Phantom Black",
                              "deviceNickname": "RAVI WRIGHT",
                              "displayMtn": "912.409.2690",
                              "role": "Non Registered",
                              "basicPhoneFiveG": false,
                              "isFiveGDevice": false,
                              "isFiveGHomeVoiceDevice": false,
                              "isFiveGModDeviceMtn": false,
                              "isSpotDevice": false,
                              "images": {
                                  "defaultImage": "https://ss7.vzw.com/is/image/VerizonWireless/samsung-diamond-1-black",
                                  "largeImage": "https://ss7.vzw.com/is/image/VerizonWireless/samsung-diamond-1-black?$device-lg$",
                                  "mediumImage": "https://ss7.vzw.com/is/image/VerizonWireless/samsung-diamond-1-black?$device-med$",
                                  "miniImage": "https://ss7.vzw.com/is/image/VerizonWireless/samsung-diamond-1-black?$device-mini$",
                                  "thumbImage": "https://ss7.vzw.com/is/image/VerizonWireless/samsung-diamond-1-black?$device-thumb$"
                              }
                          },
                          {
                              "spotDeviceMessage": "",
                              "mtn": "9804259206",
                              "encryptedMtn": "eo1KyXSxpoieF%2FpQqdI1mA%3D%3D",
                              "deviceMake": "ARC",
                              "deviceModel": "Verizon Internet Gateway ARC-XCI55AX",
                              "deviceNickname": "RAVI WRIGHT",
                              "displayMtn": "980.425.9206",
                              "role": "Non Registered",
                              "basicPhoneFiveG": false,
                              "isFiveGDevice": false,
                              "isFiveGHomeVoiceDevice": false,
                              "isFiveGModDeviceMtn": false,
                              "isSpotDevice": false,
                              "images": {
                                  "defaultImage": "https://ss7.vzw.com/is/image/VerizonWireless/vzw-internet-gateway-askey-titan-2-router-white-arc-xci55ax",
                                  "largeImage": "https://ss7.vzw.com/is/image/VerizonWireless/vzw-internet-gateway-askey-titan-2-router-white-arc-xci55ax?$device-lg$",
                                  "mediumImage": "https://ss7.vzw.com/is/image/VerizonWireless/vzw-internet-gateway-askey-titan-2-router-white-arc-xci55ax?$device-med$",
                                  "miniImage": "https://ss7.vzw.com/is/image/VerizonWireless/vzw-internet-gateway-askey-titan-2-router-white-arc-xci55ax?$device-mini$",
                                  "thumbImage": "https://ss7.vzw.com/is/image/VerizonWireless/vzw-internet-gateway-askey-titan-2-router-white-arc-xci55ax?$device-thumb$"
                              }
                          },
                          {
                              "spotDeviceMessage": "",
                              "mtn": "9805791273",
                              "encryptedMtn": "pHzF%2BzxOGkQqZXoHhch%2BkA%3D%3D",
                              "deviceMake": "SAM",
                              "deviceModel": "Samsung Galaxy S7 32GB in Gold Platinum",
                              "deviceNickname": "RAVI WRIGHT",
                              "displayMtn": "980.579.1273",
                              "role": "Non Registered",
                              "basicPhoneFiveG": false,
                              "isFiveGDevice": false,
                              "isFiveGHomeVoiceDevice": false,
                              "isFiveGModDeviceMtn": false,
                              "isSpotDevice": false,
                              "images": {
                                  "defaultImage": "https://ss7.vzw.com/is/image/VerizonWireless/Samsung_Hero_Gold",
                                  "largeImage": "https://ss7.vzw.com/is/image/VerizonWireless/Samsung_Hero_Gold?$device-lg$",
                                  "mediumImage": "https://ss7.vzw.com/is/image/VerizonWireless/Samsung_Hero_Gold?$device-med$",
                                  "miniImage": "https://ss7.vzw.com/is/image/VerizonWireless/Samsung_Hero_Gold?$device-mini$",
                                  "thumbImage": "https://ss7.vzw.com/is/image/VerizonWireless/Samsung_Hero_Gold?$device-thumb$"
                              }
                          }
                      ],
                      "showAdvanceControls": false,
                      "pendingOrder": false,
                      "isFiveGOnlyAccount": false,
                      "isSingleDevice": false,
                      "isFiveGRedirect": false,
                      "isFamilyBase": true
                  }
              },
              {
                  "sectionIndex": "2",
                  "sectionId": "devicesBlocksAdvCtrlsPageSection",
                  "sectionType": "advancedControlsSection",
                  "contents": [
                      {
                          "contentIndex": "0",
                          "items": [
                              {
                                  "itemKey": "controlsHeader",
                                  "itemType": "text",
                                  "itemValue": "Advanced Controls",
                                  "itemAttributes": {},
                                  "actionKey": "advanceControls"
                              }
                          ]
                      }
                  ],
                  "data": {
                      "advanceControls": [
                          {
                              "titleText": "Call Filter",
                              "headerText": "Put an end to mystery calls.",
                              "description": "Call Filter identifies unknown numbers by name or as spam and automatically blocks unwanted calls based on risk level.",
                              "url": "https://vzwqa1.verizonwireless.com/solutions-and-services/call-filter/",
                              "caretMsg": "Manage Call Filter",
                              "isFeatureAvailable": "N"
                          },
                          {
                              "titleText": "Smart Family",
                              "headerText": "Set smart boundaries or your kids.",
                              "description": "With Verizon Smart Family you can set content filters and contact lists for your child. So you can keep certain sites out of sight until they're ready, and make sure they're only contacting trusted contacts.",
                              "url": "https://vzwqa1.verizonwireless.com/solutions-and-services/verizon-smart-family/",
                              "caretMsg": "Manage Smart Family",
                              "isFeatureAvailable": "N"
                          },
                          {
                              "titleText": "Digital Secure",
                              "headerText": "Protect your private information from digital threats.",
                              "description": "Safeguard your internet connection and personal data with antivirus, anti-malware and identity theft protection so you can browse with peace of mind.",
                              "url": "https://vzwqa1.verizonwireless.com/myv/productsapps/#/manageProducts/",
                              "caretMsg": "Manage Digital Secure",
                              "isFeatureAvailable": "N"
                          }
                      ]
                  }
              }
          ]
      }
  ],
  "deceasedFlag": false
}
 

const store = mockStoreConfig({
  Home:{
    isFetching: true,
    deviceList: mockDeviceList,
    deviceListError: null,
    advanceControls: true,
    deviceListFlag: true,
  }
}
)
const initialProps={
    actions :{
      getBlocksDeviceList: jest.fn(()=> [])
    }
  }
describe("<AdvanceControls />", () => {
    beforeEach(async () => {
      await act(async () => render(
        <Provider store={store}>
             <AdvanceControls {...initialProps} />
        </Provider>
      ));
    })
    test("it should mount", () => {
      const advanceControl = screen.getByTestId("AdvanceControlsTestId");
      const special = screen.getByTestId("SpeicialId");
      expect(advanceControl).toBeInTheDocument();
      expect(special).toBeInTheDocument();
  });
  

  test("it should render all advance control tiles with correct data", () => {
    const tile0 = screen.getByTestId("TileletId-0");
    expect(tile0).toBeInTheDocument();
  });
  test("it should render all advance control tiles with correct data", () => {
    const tile1 = screen.getByTestId("TileletId-1");
    expect(tile1).toBeInTheDocument();
  });

  test("it should render all advance control tiles with correct data", () => {
    const tile2 = screen.getByTestId("TileletId-2");
    expect(tile2).toBeInTheDocument();
  });


  test("it should render all advance control tiles with correct data", () => {
    // Check individual tiles
    expect(screen.getByText("Call Filter")).toBeInTheDocument();
    expect(screen.getByText("Smart Family")).toBeInTheDocument();
    expect(screen.getByText("Digital Secure")).toBeInTheDocument();
    //expect(screen.getByText("Put an end to mystery calls")).toBeInTheDocument();
    expect(screen.getByTestId("TileletId-0")).toHaveTextContent("Call Filter identifies unknown numbers by name or as spam and automatically blocks unwanted calls based on risk level.");
    expect(screen.getByTestId("TileletId-1")).toHaveTextContent("With Verizon Smart Family you can set content filters and contact lists for your child.");
    expect(screen.getByTestId("TileletId-2")).toHaveTextContent("Safeguard your internet connection and personal data with antivirus, anti-malware and identity theft protection so you can browse with peace of mind.");
  });

  test("it should render valid advace control data", () => {
    const button0 =  screen.getByRole("button", {name: /Call Filter/i})
    fireEvent.click(button0);
    const button1 =  screen.getByRole("button", {name: /Smart Family/i})
    fireEvent.click(button1);
    const button2 =  screen.getByRole("button", {name: /Digital Secure/i})
    fireEvent.click(button2);
  });  
}) 