/**
 * Responsive Layout Components with Styled-Components
 *
 * This module defines a set of layout components  based on styled components for creating responsive
 * layouts. It includes support for various screen
 * breakpoint and responsive design.
 *
 * ex: You can pass any css property here.
 *     <Box width="100px" /> # sets width to 100px
 *     <Box width={["10px", "20px", "30px"]} # sets 10px on mobile, 20px on tablet and 30px on desktop
 *
 * @module ResponsiveLayout
 */

// const newDiv = document.createElement('div');

import styled from 'styled-components';
import divProps from './divProps.json';

/**
 * Configured breakpoint breakpoint for responsive design.
 *
 * @constant
 * @type {Object}
 */
export const breakpoint = {
  sm: '768px',
  md: '1024px',
  lg: '4096px',
};

/**
 * Generate responsive style objects based on provided props and element type.
 *
 * @param {Object} props - The props containing styles to be made responsive.
 * @param {string} elementType - The type of element to apply styles to.
 * @returns {Object} An object containing 'mobile', 'tablet', and 'desktop' properties with responsive styles.
 */
const responsiveObject = (props) => {
  const mobile = {};
  const tablet = {};
  const desktop = {};

  for (const [key, value] of Object.entries(props)) {
    if (divProps.includes(key)) {
      if (Array.isArray(value) && value.length === 3) {
        const [m, t, d] = value;
        mobile[key] = m;
        tablet[key] = t;
        desktop[key] = d;
      } else if (Array.isArray(value) && value.length === 2) {
        const [m, d] = value;
        mobile[key] = m;
        tablet[key] = d;
        desktop[key] = d;
      } else {
        mobile[key] = value;
        tablet[key] = value;
        desktop[key] = value;
      }
    }
  }
  return {
    mobile,
    tablet,
    desktop,
  };
};

/**
 * Styled component for creating a responsive 'Box' with configurable media queries.
 *
 */
export const Box = styled.div`
  ${(props) => {
    const { mobile, tablet, desktop } = responsiveObject(props);
    return {
      [`@media (min-width: ${breakpoint.md}) and (max-width: ${breakpoint.lg})`]: desktop,
      [`@media (min-width: ${breakpoint.sm}) and (max-width: ${breakpoint.md})`]: tablet,
      [`@media (max-width: ${breakpoint.sm})`]: mobile,
    };
  }}
`;

export const Image = styled.img`
  ${(props) => {
    const { mobile, tablet, desktop } = responsiveObject(props);
    return {
      [`@media (min-width: ${breakpoint.md}) and (max-width: ${breakpoint.lg})`]: desktop,
      [`@media (min-width: ${breakpoint.sm}) and (max-width: ${breakpoint.md})`]: tablet,
      [`@media (max-width: ${breakpoint.sm})`]: mobile,
    };
  }}
`;

export const IFrame = styled.iframe`
  ${(props) => {
    const { mobile, tablet, desktop } = responsiveObject(props);
    return {
      [`@media (min-width: ${breakpoint.md}) and (max-width: ${breakpoint.lg})`]: desktop,
      [`@media (min-width: ${breakpoint.sm}) and (max-width: ${breakpoint.md})`]: tablet,
      [`@media (max-width: ${breakpoint.sm})`]: mobile,
    };
  }}
`;

/**
 * Styled component for creating a responsive 'Stack' layout with flex properties.
 *
 */
export const Stack = styled(Box)`
  display: ${(props) => props?.display || 'flex'};
  flex-direction: ${(props) => props?.flexDirection || 'column'};
`;

/**
 * Styled component for creating a responsive Horizintal Stack 'HStack' layout with flex properties.
 *
 */
export const HStack = styled(Box)`
  display: ${(props) => props?.display || 'flex'};
  flex-direction: ${(props) => props?.flexDirection || 'row'};
`;

/**
 * Styled component for creating a responsive Vertical Stack 'VStack' layout with flex properties and center alignment.
 *
 */
export const VStack = styled(Box)`
  display: ${(props) => props?.display || 'flex'};
  flex-direction: ${(props) => props?.flexDirection || 'column'};
  align-items: ${(props) => props?.alignItems || 'center'};
`;
/**
 * Styled component for creating a responsive Vertical Stack 'VStack' layout with flex properties and center alignment.
 *
 */
export const Grid = styled(Box)`
  display: ${(props) => props?.display || 'grid'};
`;
/**
 * Styled component for creating a responsive Vertical Stack 'VStack' layout with flex properties and center alignment.
 *
 */
export const Center = styled(Box)`
  display: ${(props) => props?.display || 'flex'};
  flex-direction: ${(props) => props?.flexDirection || 'column'};
  align-items: ${(props) => props?.alignItems || 'center'};
  justify-content: ${(props) => props?.justifyContent || 'center'};
`;