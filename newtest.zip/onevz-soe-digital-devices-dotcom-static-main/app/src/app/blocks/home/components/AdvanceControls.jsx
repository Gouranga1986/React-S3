import React, { Component, Fragment } from 'react';
import { Tilelet, TileletGroup } from '@vds/tiles';
import { Line } from '@vds/lines';
import styled from "styled-components";
import { media } from '../../../utils/VendorScripts/style';

import '../../styles.css';
import { Title } from '@vds/typography';

class AdvanceControls extends Component {
  constructor(props) {
    super(props);
  }

  callfilter = (e, url) => {
    window.location.href = url;
  }

  smartFamily = (e, url) => {
    window.location.href = url;
  }

  designSecure = (e, url) => {
    window.location.href = url;
  }

  render() {
    // const { advanceControls } = this.props.deviceList?.sections?.[0]?.sections?.[1]?.data?.advanceControls?.[0]
    // if(!advanceControls)
    const { advanceControls } = this.props

    return (
      <Fragment>
        <div className="One">
          <div className=" row">
            <div className="col-lg-12">
              <Title size="large" bold="true">Advanced Controls</Title>
              <br/>
              </div>
          </div>
          <div className=" row">
            <div className="col-lg-12">
              <p>Need special controls for the services on your account? Consider trying out these.</p>
              <br />
            </div>
            {' '}

          </div>
          {/* <div>{this.props.advanceControls}</div> */}
            <div className='advanceControls'>
          <Container>
              <Tilelet
                viewport="mobile"
                title={{
                  size: 'titleLarge',
                  children: advanceControls?.advanceControls?.[0]?.headerText,
                  primitive: 'h1',
                }}
                subtitle={{
                  size: 'bodyLarge',
                  children:
                    <div>
                      <br />
                      <Line />
                      <br />
                      <div>{advanceControls?.advanceControls?.[0]?.description}</div>
                      <br />
                      <br />
                    </div>,
                  primitive: 'h1',
                }}
                directionalIcon={{
                  name: 'right-arrow',
                  size: 'medium',
                }}
                eyebrow={{
                  children: advanceControls?.advanceControls?.[0]?.titleText,
                  size: 'TitleLarge',
                }}
                surface='light'
                backgroundColor='white'
                height='350px'
                width='410px'
                onClick={(e) => { this.callfilter(e, advanceControls?.advanceControls?.[0]?.url); }}
                showBorder="true"
              />
              <Tilelet
                viewport="mobile"
                title={{
                  size: 'titleLarge',
                  children: advanceControls?.advanceControls?.[1]?.headerText,
                  primitive: 'h1',
                }}
                subtitle={{
                  size: 'bodyLarge',
                  children:
                    <div>
                      <br />
                      <Line />
                      <br />
                      <div>{advanceControls?.advanceControls?.[1]?.description}</div>
                      <br />
                      <br />
                    </div>,
                  primitive: 'h1',
                }}
                directionalIcon={{
                  name: 'right-arrow',
                  size: 'medium',
                }}
                eyebrow={{
                  children: advanceControls?.advanceControls?.[1]?.titleText,
                  size: 'TitleLarge',
                }}
                surface='light'
                backgroundColor='white'
                height='350px'
                width='410px'
                onClick={(e) => { this.smartFamily(e, advanceControls?.advanceControls?.[1]?.url); }}
                showBorder="true"
              />
              <Tilelet
                viewport="mobile"
                title={{
                  size: 'titleLarge',
                  children: advanceControls?.advanceControls?.[2]?.headerText,
                  primitive: 'h1',
                }}
                subtitle={{
                  size: 'bodyLarge',
                  children:
                    <div>
                      <br />
                      <Line />
                      <br />
                      <div>{advanceControls?.advanceControls?.[2]?.description}</div>
                      <br />
                      <br />
                    </div>,
                  primitive: 'h1',
                }}
                directionalIcon={{
                  name: 'right-arrow',
                  size: 'medium',
                }}
                eyebrow={{
                  children: advanceControls?.advanceControls?.[2]?.titleText,
                  size: 'TitleLarge',
                }}
                surface='light'
                backgroundColor='white'
                height='350px'
                width='410px'
                onClick={(e) => { this.designSecure(e, advanceControls?.advanceControls?.[2]?.url); }}
                showBorder="true"
              />
            </Container>
            </div>
            </div>
      </Fragment>
    );
  }
}


export default AdvanceControls;
const Container = styled.div`
  display: flex;
  
  ${media.mobile`
    display: block;
  `}
  
`;
const SubContainer = styled.div`
  flex: 1;
  padding-right: 35px;
  ${media.mobile`
    padding-right: 0;
  `}
`;