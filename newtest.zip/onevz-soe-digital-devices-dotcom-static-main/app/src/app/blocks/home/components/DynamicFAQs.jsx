import React, { Component } from "react";

import "./style.css";
import FAQs from "../../FAQs";
// import { getDeviceType } from '../../Tagging/DeviceType'
// import { setDataTrackAttr } from '../../utils/VendorScripts/VendorScripts';

class DynamicFAQs extends Component {

  componentDidMount(){
    const element = document.querySelectorAll('.faq-wrapper a')[0];
    element.parentNode.insertBefore(element, element.previousElementSibling);
    setTimeout(function() { 
      // setDataTrackAttr("#faq-container");
      /* updating dynamic tabindex to VDS component */
      // const setTabIndexEl1 = document.querySelectorAll(".faq-wrapper .gAOLMh")[0];
      // const setTabIndexEl2 = document.querySelectorAll('.secondary-Faqs .gAOLMh')[0];    
      // setTabIndexEl1.setAttribute("tabindex", "-1");
      // setTabIndexEl2.setAttribute("tabindex", "-1"); 
      /* End */
    }, 500);
  }
  render() {
    return (
        <div id="faq-container">
        <div className="faq-wrapper" style={{ flex: "5" }}>
        <FAQs
              faqDataSet={[
                {
                  tagName: "?tag=block&count=3",
                  
                  tabName: "Blocks FAQs",
                  tabUrl: "https://www.verizonwireless.com/support/spot/",
                  allFAQUrl: "https://www.verizonwireless.com/support/block-unblock-services-faqs/"
                }
              ]}
              // allSupportFaq={(val) => console.log("support",val)}
            />
        </div>
        <div id="secondary-Faqs" className="secondary-Faqs">
         <FAQs
         faqDataSet={[
           {
             tagName: "?tag=smart-family&count=1",
            
             tabUrl: "https://www.verizonwireless.com/support/spot/"
             
           }
         ]}
         // allSupportFaq={(val) => console.log("support",val)}
       />
   </div>
   </div>
      
    );
  }
}

export default DynamicFAQs;





