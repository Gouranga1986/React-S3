import { useMemo, useEffect, useState } from 'react';

export const useScreenSize = () => {
  //   const screenSize = useRef();
  const [screenWidth, setScreenWidth] = useState(window.innerWidth);

  useEffect(() => {
    const handleResize = () => {
      const newWidth = window.innerWidth;
      if (newWidth !== screenWidth) {
        setScreenWidth(newWidth);
      }
    };

    // subscribe to window resize
    window.addEventListener('resize', handleResize);

    // cleanup
    return () => {
      window.removeEventListener('resize', () => handleResize);
    };
  }, [screenWidth]);

  return screenWidth;
};

export const useResponsiveValue = (style = []) => {
  const screenWidth = useScreenSize();

  return useMemo(() => {
    const [mobile, tab, desktop] = style;

    if (screenWidth < 768) return mobile;
    if (screenWidth >= 768 && screenWidth <= 1024) return tab || desktop;
    return desktop || tab;
  }, [screenWidth, style]);
};
