import { useState, useEffect } from 'react'
import { breakpoint } from './Flexify'

export const getMatch = (screen) => {
  if (screen === "mobile")
    return window.matchMedia(`(max-width: ${breakpoint.sm})`)?.matches;
  else if (screen === "tablet")
    return window.matchMedia(
      `(min-width: ${breakpoint.sm}) and (max-width: ${breakpoint.md})`
    )?.matches;
  else if (screen === "desktop")
    return window.matchMedia(`(min-width: ${breakpoint.md})`)?.matches;
  return false;
};

export const useMediaQuery = () => {
  const [isMobile, setIsMobile] = useState(() => getMatch("mobile"));
  const [isTablet, setIsTablet] = useState(() => getMatch("tablet"));
  const [isDesktop, setIsDesktop] = useState(() => getMatch("desktop"));

  useEffect(() => {
    const updateMedia = () => {
      setIsMobile(getMatch("mobile"));
      setIsTablet(getMatch("tablet"));
      setIsDesktop(getMatch("desktop"));
    };

    updateMedia(); // Set the initial state
    window.addEventListener("resize", updateMedia);

    return () => {
      window.removeEventListener("resize", updateMedia);
    };
  }, []);

  return { isMobile, isTablet, isDesktop };
};
