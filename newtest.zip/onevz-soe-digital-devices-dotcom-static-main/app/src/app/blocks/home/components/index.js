import React, { Component } from 'react';
import { connect } from 'react-redux';
import { Redirect } from 'react-router-dom';
import { TileContainer } from '@vds/tiles';
import { Title, Body } from '@vds/typography';
import { Col, Grid, Row } from '@vds/grids';
import '../../styles.css';
import { bindActionCreators } from 'redux';
import styled from 'styled-components';
import Alert from '../../alert';
import DynamicFAQs from './DynamicFAQs';
import * as deviceLandingActions from '../actions';
import AdvancedControls from './AdvanceControls';
import { Tooltip } from '@vds/tooltips';
import { Line } from '@vds/lines';
import { Loader } from '@vds/loaders';
export const MDN_ROLE_MESSAGE = 'This line isn\'t registered for a My Verizon Account yet. You\'ll need this line to complete the online registration in order to access the features within My Verizon.';
export const MDN_ROLE_NONREG_MESSAGE = 'Non Registered';
class BlocksPage extends Component {
  constructor(props) {
    super(props);
    window.scrollTo({ top: 0, behavior: 'smooth' });
    this.state = {
      selectedDevice: null,
      pendingOderNotified: false,
    };
  }

  componentDidMount() {
    this.props.actions.getBlocksDeviceList();
    console.log(this.props, 'this.props');
    // vzwDL.page.flowType = this.props.deviceList.isFamilyBase ? 'family base' : 'non family base'
  }
  selectDevice = (event, device) => {
    event.preventDefault();
    if (this.props.deviceList && !this.props.deviceList?.sections[0]?.sections[0]?.data?.isPendingOrder) {
      this.setState({ selectedDevice: device });
    }
  }
  render() {
    const { deviceListError, isFetching } = this.props;
    if (
      this.props.deviceList
      && this.props.deviceList?.sections?.[0]?.sections[0]?.data?.pendingOrder
    ) {
      if (!this.state.pendingOderNotified) {
        this.setState({ pendingOderNotified: true });
      }
    }
    else {
      if (this.state.selectedDevice && this.props.deviceList?.sections?.[0]?.sections[0]?.data?.devices[0]?.encryptedMtn) {
        return (
          <Redirect
            push
            to={{
              pathname: `/devicedetails/${this.state.selectedDevice.encryptedMtn}`,
              state: {
                devices: this.props.deviceList?.sections[0]?.sections[0]?.data?.devices,
                isSingleDevice:
                  this.props.deviceList?.sections[0]?.sections[0]?.data?.isSingleDevice,
                selectedDevice: this.state.selectedDevice,
                advanceControls:
                  this.props.deviceList?.sections[0]?.sections[1]?.data,
                showAdvanceControls:
                  this.props.deviceList?.sections[0]?.sections[0]?.data?.showAdvanceControls,
              },
            }}
          />
        );
      }
      const tileGroupComp = this.props.deviceList?.sections?.[0]?.sections?.[0]?.data?.devices
        ?.filter((rec) => !rec.isFiveGDevice)
        .map((tile, index) => (
          <Col colSizes={{ mobile: 1, desktop: 3, tablet: 2 }} width="100px">
            <TileContainer
              key={`${index}`}
              id="tileContainer"
              backgroundImage="none"
              aspectRatio="5:1"
              height="220px"
              width="400px"
              showBorder
              onClick={(event) => this.selectDevice(event, tile)}
              onKeyPress={(event) => this.selectDevice(event, tile)}
              role={
                this.props.deviceList?.sections[0]?.sections[0]?.data?.pendingOrder ? '' : 'link'
              }
              aria-label={`${tile.deviceNickname}  ${this.props.deviceList?.sections[0]?.sections[0]?.data?.pendingOrder
                ? 'disabled'
                : ''
                }`}
              tabIndex={
                this.props.deviceList?.sections[0]?.sections[0]?.data?.pendingOrder ? '-1' : '0'
              }
              aria-disabled={this.props.deviceList?.sections[0]?.sections[0]?.data?.pendingOrder}
              data-track={tile.mtn}
            >
              <Col className="col col-title">
                <div>
                  <Body>{tile.role}</Body>
                  <Title size="medium" bold color="#000000">
                    {tile.deviceNickname}
                    <br />
                    {tile.displayMtn}
                    <br />
                  </Title>

                  <Body primitive="p">
                    {' '}
                    {tile.deviceMake}
                    {' '}
                    -
                    {' '}
                    {tile.deviceModel}
                  </Body>
                </div>
              </Col>
              <Col className="col-image">
                <div aria-hidden="true">
                  <img src={tile.images.mediumImage} alt="" />
                </div>
              </Col>
              {tile.role == MDN_ROLE_NONREG_MESSAGE ? <div >
                <Tooltip outlined={true} style={{ marginLeft: "0.5rem" }}>
                  {MDN_ROLE_MESSAGE}
                </Tooltip>
              </div> : ""
              }
            </TileContainer>
          </Col>
        ));

      return (
        <div className="oneD">
          <div>
            {' '}
            <Loader active={isFetching} fullscreen={false} />
          </div>
          {this.props.deviceCallFail && (
            <div className="mb-32">
              <br />
              {' '}
              <Alert
                Message={
                  this.props.deviceListError && deviceListError.errorMessage
                    ? deviceListError.errorMessage
                    : 'Something went wrong, Please try again later!'
                }
                Type={3}
                closeBanner={false}
              />
            </div>
          )}
          {/* {this.props.deviceCallSuccess && ( */}
          <React.Fragment>
            <h3>Blocks</h3>
            <Grid
              padding="0"
              >
              <Row>
                <Col colSizes={{ desktop: 5, mobile: 4 }} padding="0" id="blocktext"><Body size="medium" >Temporarily block calls and messages, use of services, and certain types of purchases with this free My Verizon service.</Body>
                </Col>
              </Row>
            </Grid>
            
            <div className=" row">
              <div className="col-lg-12">
                {this.props.deviceList?.sections?.[0]?.sections?.[0]?.data?.pendingOrder && (
                  <Alert
                    Message={this.props.deviceList?.pendingOrderMsg}
                    URL={this.props.deviceList?.goToPendingUrl}
                    Label={this.props.deviceList?.goToPendingOrder}
                    Type={3}
                    closeBanner={false}
                  />
                )}
                <h4>Devices</h4>
                <br />
                <p className="paragraph-content">Please select a device.</p>
                <br />
              </div>
            </div>
            <div
              className={
                this.props.deviceList?.sections?.[0]?.sections?.[0]?.data?.pendingOrder
                  ? 'radio-choose--disabled'
                  : ''
              }
              aria-disabled={this.props.deviceList?.sections?.[0]?.sections?.[0]?.data?.pendingOrder}
            >
              <Row Id="deviceListTiles">
                <AccessElement
                  id="enabled"
                  className="accessibility"
                  aria-hidden={
                    !this.props.deviceList?.sections?.[0]?.sections?.[0]?.data?.pendingOrder
                      ? 'true'
                      : 'false'
                  }
                >
                  Devices disabled
                </AccessElement>

                {tileGroupComp}
              </Row>
              <br />
            </div>
            <br />
            {this.props.advanceControls
              && (
                <div>
                  <Line />
                  <div className="One">
                    <br></br>
                    <AdvancedControls advanceControls={this.props.deviceList?.sections?.[0]?.sections?.[1]?.data} />
                    <br />
                    <DynamicFAQs />
                  </div>
                </div>
              )}
          </React.Fragment>
          
        </div>
      );
    }
  }
}

const mapStateToProps = (state) => ({
  isFetching: state.Home.isFetching,
  deviceList: state.Home.deviceList,
  deviceListError: state.Home.deviceListError,
  advanceControls: state.Home.advanceControls,
  deviceListFlag: state.Home.deviceListFlag,
});

const mapDispatchToProps = (dispatch) => ({
  actions: bindActionCreators({ ...deviceLandingActions }, dispatch),
});

const ToolTipPTP = styled.div`
  padding-left: 0.5rem;
`;
const ToolTipWrapper = styled.div`
  display: flex;
  top: 2% !important;
  position: absolute;
  left: 48%;
`;
const ToolTipText = styled.div`
  font-family: NHaasGroteskDSStd-55Rg;
  font-size: 0.7rem;
  display: inline-flex;
`;
const AccessElement = styled.span`
  position: absolute;
  top: -1000px;
  left: -1000px;
  visibilty: hidden;
`;

export default connect(mapStateToProps, mapDispatchToProps)(BlocksPage);
