export { getBlocksDeviceList } from './pageActions'
