import { getHttpClientRequest, postHttpClientRequest } from '../../../../shared/services/httpClient'
import apiUrl from '../../../../shared/utilities/apiUrl'
import axios from 'axios'

export const GET_BLOCKS_DEVICELIST_BEGIN = 'blocksDeviceList/GET_BLOCKS_DEVICELIST_BEGIN'
export const GET_BLOCKS_DEVICELIST_SUCCESS = 'blocksDeviceList/GET_BLOCKS_DEVICELIST_SUCCESS'
export const GET_BLOCKS_DEVICELIST_FAIL = 'blocksDeviceList/GET_BLOCKS_DEVICELIST_FAIL'

export const getBlocksDeviceList = () => async (dispatch) => {
  if (apiUrl().callDeviceLanding === 'false') {
    return
  }

  dispatch(getBlocksDeviceListBegin())

  const onSuccess = (networkRes) => {
    console.log(networkRes, 'networkRes')
    if (
      networkRes &&
      networkRes.data &&
      networkRes.data.responseInfo &&
      networkRes.data.responseInfo.responseCode == '00'
    ) {
      dispatch(getBlocksDeviceListSuccess(networkRes.data))
    }
  }

  const onError = (error) => {
    console.log(error, 'error')
    dispatch(getBlocksDeviceListError(error))
  }

  const callMS = () => {
    let axConfig = {
      headers: {
        flowName:'Blocks',
        contentType: 'application/json',
        
      },
    }
    return getHttpClientRequest(apiUrl().landing, axConfig)
  }

  callMS()
    .then((msResp) => {
      console.log(msResp, 'msResp')
      if (msResp && msResp.status == 200) {
        onSuccess(msResp)
      }
    })
    .catch(onError)
}

export const getBlocksDeviceListBegin = () => ({
  type: GET_BLOCKS_DEVICELIST_BEGIN,
})

export const getBlocksDeviceListSuccess = (response) => ({
  type: GET_BLOCKS_DEVICELIST_SUCCESS,
  response,
})
export const getBlocksDeviceListError = (err) => ({
  type: GET_BLOCKS_DEVICELIST_FAIL,
  err,
})
