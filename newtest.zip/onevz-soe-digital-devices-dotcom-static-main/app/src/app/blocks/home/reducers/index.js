import {
  GET_BLOCKS_DEVICELIST_SUCCESS,
  GET_BLOCKS_DEVICELIST_FAIL,
  GET_BLOCKS_DEVICELIST_BEGIN,
} from '../actions/pageActions'

import { updateObject } from '../../../../shared/utilities/reducer'
import common from '../../../../shared/utilities/util'

const initialState = {
  isFetching: true,
  statusCode: '',
  statusMessage: '',
  errorMessage: '',
  errorDesc: '',
  actionName: '',
  actionValue: '',
  actionType: '',
  errorObj: {},
  // sectionContentMetaData: {},
  // selectedDevice: {},
  // recommendation: {},
  // isRecommendationFetching: true,
  // recommendationStatusCode: '',
  // recommendationStatusMessage: '',
  // recommendationErrorMessage: '',
  // recommendationErrorDesc: '',
  // recommendationActionName: '',
  // recommendationActionValue: '',
  // recommendationActionType: '',
  // recommendationErrorObj: '',
  // isNetworkOutage: false,
  // networkOutageDetail: {},
  // isProactiveNotification: false,
  // proactiveNotificationDetail: {}
  deviceList: [],
  advanceControls: {},
  deviceListError: {},
  deviceListFlag: false,
}

export const getBlocks_DeviceListBegin = (state, action) => {
  return updateObject(state, {
    isFetching: true,
  })
}

export const getBlocks_DeviceListSuccess = (state, action) => {
  console.log(state, action, 'action')
  return updateObject(state, {
    deviceList: action.response.body,
    advanceControls: true,
    isFetching:false
  })
}

export const getBlocks_DeviceListFail = (state, action) => {
  return updateObject(state, {
    deviceListError: false,
    deviceListFlag: {},
  })
}

const deviceLandingReducer = (state = initialState, action) => {
  const { type } = action
  switch (type) {
    case GET_BLOCKS_DEVICELIST_SUCCESS:
      return getBlocks_DeviceListSuccess(state, action)
    case GET_BLOCKS_DEVICELIST_FAIL:
      return getBlocks_DeviceListFail(state, action)
    case GET_BLOCKS_DEVICELIST_BEGIN:
      return getBlocks_DeviceListBegin(state, action)
    default:
      return state
  }
}

export default deviceLandingReducer
