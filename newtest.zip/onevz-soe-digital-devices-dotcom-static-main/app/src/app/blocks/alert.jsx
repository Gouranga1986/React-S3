import { TextLink } from '@vds/buttons';
import { Notification } from '@vds/notifications';
import { Body } from '@vds/typography';
import React, { Component } from 'react';
class Alert extends Component {
    constructor(props) {
        super(props);
    }

    render() {
        console.log("Alert", this.props)
        let type = "";
        let alert="";
        let warning=false;
        if (this.props.Type == 1) {
            type = "#0088CE"
            alert="warning"
            warning= true;
        } else if (this.props.Type == 2) {
            type = '#00CE2D';
            alert="success"
        }
        else if (this.props.Type == 3) {
            type = '#ED7000';
            alert="error"
        }
        // console.log(type,"type")

        return (
            <div>   {this.props.Message  ? <div className="a-user-notice" style={{ padding: "2px" }}  >
                
                {warning?<div style={{ backgroundColor: type, color: 'white', padding: '10px' }}>
                    <span className="a-icon" aria-hidden="true" style={{ color: 'white' }}></span>
                    <div >
                        <div id="alertBlock" aria-live="polite" role="alert" ><p dangerouslySetInnerHTML={{ __html: this.props.Message }}></p></div>
                        {this.props.URL != undefined && this.props.Label != undefined}
                        {this.props.familyBaseFlag != undefined && this.props.familyBaseFlag ?
                            <Body color="white"><TextLink href={this.props.URL} dangerouslySetInnerHTML={{ __html: this.props.Label }} /></Body> : <Body color="white"> <TextLink href={this.props.URL} >{this.props.Label}</TextLink></Body>}
                    </div>
                </div>:<Notification
                    type={(alert==="success")?"success":"error"}
                    title={<p dangerouslySetInnerHTML={{ __html: this.props.Message }} />}
                    fullBleed={false}
                    inline={false}
                    disableFocus={true}
                />}
                
            </div> : null}
            </div>
        )
    }
}

export default Alert;
