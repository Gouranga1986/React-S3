import React from 'react';
import Cookies from "universal-cookie";
import apiUrl from "../../../shared/utilities/apiUrl";
// function canActivate(reduxStore) {
//     const confirmationPageShown = (!(typeof reactGlobals === 'undefined' || reactGlobals === null) 
//     && reactGlobals && reactGlobals.routeLog && reactGlobals.routeLog.confirmationShown);
//     if (confirmationPageShown) {
//       return false;
//     } else {
//       return true;
//     }
//   }
  
  function fallbackRoute(reduxStore, currentLocation) {
    const myVzPageUrl = apiUrl().myVzPage ? apiUrl().myVzPage : "";
    const confirmationPageShown = (!(typeof reactGlobals === 'undefined' || reactGlobals === null) 
    && reactGlobals && reactGlobals.routeLog && reactGlobals.routeLog.confirmationShown);
    
    if (confirmationPageShown && myVzPageUrl){
        setCookie();
        window.location.href = myVzPageUrl;
    } else {
         window.location.href = window.location.href.split('#')[0];
    }
  }

  function setCookie(){
    const cookies = new Cookies();
    cookies.set('clearSessionCookie', 'M', { path: '/' , secure :true });
  }
  
  // export const GlobalGuard = { canActivate, fallbackRoute };
  export const GlobalGuard = { fallbackRoute };