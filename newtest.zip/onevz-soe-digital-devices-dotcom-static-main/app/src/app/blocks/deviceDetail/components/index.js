
import React, { Component } from 'react';
import { connect } from 'react-redux';
import { Redirect } from 'react-router-dom';
import { Body } from '@vds/typography';
import { bindActionCreators } from 'redux';
import styled from 'styled-components';
import { Button, TextLink } from '@vds/buttons';
import { Line } from '@vds/lines';
import {
  Modal, ModalBody, ModalTitle,
} from '@vds/modals';
import { Toggle } from '@vds/toggles';
import { Loader } from '@vds/loaders';
import { DropdownSelect } from '@vds/selects';
import './blocksServices/style.css';
import { Tooltip } from '@vds/tooltips';
import BlockServices from './blocksServices/BlockServices';
import BlockCallsMessages from './blockCallsMessages';
import Alert from '../../alert';
import * as deviceDetailActions from '../actions';
import AdvancedControls from '../../home/components/AdvanceControls';
import { media } from '../../../utils/VendorScripts/style';
import { Col, Grid, Row } from '@vds/grids';
export const MDN_ROLE_MESSAGE = 'This line isn\'t registered for a My Verizon Account yet. You\'ll need this line to complete the online registration in order to access the features within My Verizon.';
export const MDN_ROLE_NONREG_MESSAGE = 'Non Registered';
class DeviceDetail extends Component {
  constructor(props) {
    super(props);
    console.log(props, 'props');
    window.scrollTo({
      top: 0,
      behavior: 'smooth',
    });
    if (props.location.state !== null && props.location.state !== undefined) {
      this.devices = props.location.state.devices;
      this.isSingleDevice = props.location.state.isSingleDevice;
      this.selectedDevice = props.location.state.selectedDevice;
      this.advanceControls = props.location.state.advanceControls;
      this.showAdvanceControls = props.location.state.showAdvanceControls;
    }
    this.state = {
      selectedDevice: this.selectedDevice,
      devices: this.devices,
      advanceControls: this.advanceControls,
      applePopUp: false,
      isSingleDevice: this.isSingleDevice,
    };
  }

  componentDidMount() {
    const selectedMdn = this.props.location?.state?.selectedDevice?.encryptedMtn || null ;
   if(selectedMdn )
    {
     this.props?.actions?.getDeviceDetail(selectedMdn);
    }
    
  }

  handleOnChangeDevice = (event) => {
    const newSelectedDevice = this.state.devices.filter((selected) => selected.mtn === event.target.value);
    if (newSelectedDevice.length > 0) {
      this.props?.actions?.getDeviceDetail(newSelectedDevice[0].encryptedMtn);
      this.setState({
        selectedDevice: newSelectedDevice[0],
        selectedAccordian: ""
      });
    }
  }

  selectAccordian = (name) => {
    if (this.state.selectedAccordian === name) name = '';
    this.setState({
      selectedAccordian: name,
    });
  }
  render() {
    // const { isFetching, deviceListError } = this.props

    const { deviceDetails, isFetching } = this.props;
    const { isSingleDevice } = this.state;
    console.log(this.state);
    let Message = '';
    let appleNotice = false;
    let showNotice = false;
    let Showmsg = '';
    if (this.state.devices === undefined || this.state.devices === null) {
      return (
        <Redirect
          push
          to={{
            pathname: '/',
          }}
        />
      );
    }
    const deviceOptions = this.state.devices.filter((rec) => !rec.isFiveGDevice).map((device) => (
      <option value={device.mtn}>
        {(device.deviceNickname)}
        {' '}
        {device.mtn}
      </option>
    ));
    let cons = '';
    let familybasemessage = '';
    let callsmessage = '';
    let familybaseurl = '';
    const msg = deviceDetails.contents?.[0]?.items.map((item) => {
      if (item.itemKey === 'appleDeviceMessage') {
        cons = item.itemValue;
        return (cons);
      }
      if (item.itemKey === 'familyBaseMessage') {
        familybasemessage = item.itemValue;
        familybaseurl = item.itemAttributes;
        return (familybasemessage);
      }
      if (item.itemKey === 'trackingDeviceMessage') {
        callsmessage = item.itemValue;
        return (callsmessage);
      }
      if (item.itemKey === 'dataOnlyMessage') {
        callsmessage = item.itemValue;
        return (callsmessage);
      }
    });

    if (deviceDetails && deviceDetails.data?.isAppleDevice && deviceDetails.data?.isAppleDevice === true) {
      appleNotice = true;
      Showmsg = deviceDetails.appleDeviceMessage;
    }
    if (this.props.deviceDetails) {
      if (deviceDetails?.data?.isDataOnlyPlan === true) {
        showNotice = true;
        Message = callsmessage;
      } else if (deviceDetails?.data?.isTrackingDevice === true) {
        showNotice = true;
        Message = callsmessage;
      }
    }
    return (
      <div className="oneD">
        <div>
          <Loader active={isFetching} />
        </div>
        <br />
        <br />
        <div className="row" tabIndex="-1">
          <div className="col-lg-12 visible-lg visible-md">
            <h1 style={{ paddingLeft: '10px' }}>
              Now, let's manage blocks
              <br />
              for this device.
            </h1>
          </div>
          {!isSingleDevice && (
            <div className="row">
              <div style={{ paddingLeft: '8px' }}>
                <Button use="secondary" surface="light" onClick={() => window.location.href = "/digital/nsa/secure/ui/devices/blocks/#/"} role="button" data-track="DeviceDetailsSeeAllDevices">See all devices</Button>
              </div>
            </div>
          )}
          <div style={{ padding: '5px' }} />
        </div>
        {!isSingleDevice && (

            <Grid
            >
              <Row>
                <Col colSizes={{ desktop: 4, mobile: 4 }}>
                <DropdownSelect
                  onChange={(event) => this.handleOnChangeDevice(event)}
                  defaultValue={this.state.selectedDevice.mtn}
                  
                >
                  {deviceOptions}
                </DropdownSelect>
                </Col>
              </Row>
            </Grid> 
        )}
        <br />
        <Line />
        <br />
        <Grid
          bleed="1272"
          rowGutter="10px"
        >
          <Row >
            <Col colSizes={{ desktop: 5 }}><div style={{ width: '100%' }} /><div className="col-lg-4 col-sm-12 col-md-4">
              <div className="row " style={{ paddingLeft: '10px' }}>
                <div className="col-lg-12 col-sm-8 col-xs-8 col-md-8">
                  <div style={{ display: 'flex' }}>
                    <p className="role">
                      {this.state.selectedDevice.role}
                    </p>
                    {this.state.selectedDevice.role === MDN_ROLE_NONREG_MESSAGE ? (
                      <div>
                        <Tooltip outlined style={{ marginLeft: '0.5rem' }}>
                          {MDN_ROLE_MESSAGE}
                        </Tooltip>
                      </div>
                    ) : ''
                    }
                  </div>
                  <h4>{this.state.selectedDevice.deviceNickname}</h4>
                  <h4>{(this.state.selectedDevice.displayMtn)}</h4>
                  {appleNotice && (
                    <div className="row visible-sm visible-xs">
                      {Showmsg}
                    </div>
                  )}
                </div>
                <div style={{ padding: 0 }}>
                  <img src={this.state.selectedDevice?.images?.mediumImage} alt="Device" />
                </div>
              </div>
              {appleNotice
                ? (
                  <div className="row visible-lg visible-md" style={{ width: '300px', paddingLeft: '10px' }}>
                    <Body>
                      {' '}
                      <span dangerouslySetInnerHTML={{ __html: cons }} />


                      <TextLink surface="light">
                        {' '}
                        <Modal
                          toggleButton={<TextLink surface="light"> Click here </TextLink>}
                          surface="light"
                          fullScreenDialog={false}
                          disableAnimation={false}
                          disableOutsideClick={false}
                          ariaLabel="Testing Modal"
                        >
                          <ModalTitle>
                            Apple® iPhone® - Turn iMessage on/off<br />
                            Before you start:
                          </ModalTitle>
                          <ModalBody>
                            <p>Note the steps below apply to the following models:</p>
                            <br />
                            <li>iPhone 16/16 pro/16 pro Max</li>
                            <li>iPhone 15/15 pro/15 pro Max</li>
                            <li>iPhone 14/14 pro/14 pro Max</li>
                            <li>iPhone 13/13 pro/13 pro Max</li>
                            <li>iPhone 12/12 pro/12 pro Max</li>
                            <li>iPhone 11/11 pro/11 pro Max</li>
                            <li>iPhone X/XS Max/XR</li>
                            <li>iPhone 8/8 Plus</li>
                            <li>iPhone 7/7 Plus</li>
                            <li>iPhone SE</li>
                            <li>iPhone 6/6 Plus/6S/6S Plus</li>
                            <li>iPhone 5/5C/5S</li>
                            <li>iPhone 4/4S</li>
                            <br />
                            <h5>Steps</h5>
                            <br />
                            <ol>
                              <li>From the Home screen, navigate: Settings Messages.</li>
                              <li>
                                <div style={{ display: 'flex' }}>
                                  Tap iMessage switch to turn<label style={{ textAlign: 'center', paddingLeft: '2px' }}>

                                    <Toggle
                                      disabled={false}
                                      showText
                                      on
                                    />

                                  </label>
                                  {' '}
                                  <span style={{ paddingLeft: '5px' }}>or</span>
                                  {' '}
                                  <label style={{ textAlign: 'center', paddingLeft: '2px' }}>
                                    <Toggle
                                      disabled={false}
                                      on={false}
                                      showText
                                    />
                                  </label>
                                </div>
                              </li>
                            </ol>
                          </ModalBody>
                        </Modal>
                        {' '}
                      </TextLink>
                      <br />
                    </Body>
                  </div>
                ) : null}
            </div></Col>
            <Col colSizes={{ desktop: 7, mobile: 4 }}><div style={{ width: '100%' }}><span style={{ fontSize: '13px' }}>Select a section below to get started. All changes are automatically saved.</span>
              <br />
              <br />
              {deviceDetails?.data?.isFamilyBase && <Alert Message={familybasemessage} URL={familybaseurl.baseUrl} Label={familybaseurl.baseUrlMsg} Type={1} familyBaseFlag={deviceDetails.isFamilyBase} closeBanner={false} />}
              {showNotice ? <Alert Message={Message} Type={1} closeBanner /> : null}
              <div className={!showNotice && !deviceDetails?.data?.isFamilyBase ? '' : 'disabled'} >
                <BlockCallsMessages selectAccordian={this.selectAccordian} selectedAccordian={this.state.selectedAccordian} selectedDevice={this.state.selectedDevice} disabled={true} />
              </div>
              <div className={showNotice ? 'radio-choose--disabled' : ''}>
                <BlockServices key={this.state.selectedDevice.mtn} selectAccordian={this.selectAccordian} selectedAccordian={this.state.selectedAccordian} selectedDevice={this.state.selectedDevice} />
              </div></div></Col>
          </Row>
        </Grid>
        <Line />
        {this.showAdvanceControls
          && (
            <div>
              <Line />
              <br></br>
              <AdvancedControls advanceControls={this.state.advanceControls} />
            </div>
          )
        }
      </div>
    );
  }
}
const mapStateToProps = (store) => {
  return {
    isFetching: store.Detail.Details.isFetching,
    deviceDetails: store.Detail.Details.deviceDetails,
  };
};
const mapDispatchToProps = (dispatch) => ({
  actions: bindActionCreators({ ...deviceDetailActions }, dispatch),
});

export default connect(mapStateToProps, mapDispatchToProps)(DeviceDetail);