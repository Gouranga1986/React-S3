import React, { Component, Fragment } from 'react'
import { connect } from 'react-redux'
import * as actions from '../../actions/fetchEmailsDomains'
import { bindActionCreators } from 'redux';
import "../../../../blocks/Accordion.css"
import '../../../../blocks/home/components/style.css';
import styled from "styled-components";
import Alert from '../../../alert';
import { Input } from '@vds/inputs';
import { Body, Title } from '@vds/typography';
import { Button } from '@vds/buttons';
import { Checkbox } from '@vds/checkboxes';
// import Loader from "../../../suspendReconnect/shared/Loader/Loader"

class BSEmailsDomains extends Component {


  constructor(props) {
    super(props)
    this.state = {
      blockedSites: [],
      memo: "",
      email: "",
      checkBox: false,
      blockMessagesFromWeb: "",
      blockMessagesFromEmail: "",
      blockMessagesFromWebEdit: false,
      blockMessagesFromEmailEdit: false,
      editEmail: false,
      editAllEmail: false,
      invalidEmail: null
    }
  }
  mobilecheck() {
    var check = false;
    (function (a) { if (/(android|bb\d+|meego).+mobile|avantgo|bada\/|blackberry|blazer|compal|elaine|fennec|hiptop|iemobile|ip(hone|od)|iris|kindle|lge |maemo|midp|mmp|mobile.+firefox|netfront|opera m(ob|in)i|palm( os)?|phone|p(ixi|re)\/|plucker|pocket|psp|series(4|6)0|symbian|treo|up\.(browser|link)|vodafone|wap|windows ce|xda|xiino/i.test(a) || /1207|6310|6590|3gso|4thp|50[1-6]i|770s|802s|a wa|abac|ac(er|oo|s\-)|ai(ko|rn)|al(av|ca|co)|amoi|an(ex|ny|yw)|aptu|ar(ch|go)|as(te|us)|attw|au(di|\-m|r |s )|avan|be(ck|ll|nq)|bi(lb|rd)|bl(ac|az)|br(e|v)w|bumb|bw\-(n|u)|c55\/|capi|ccwa|cdm\-|cell|chtm|cldc|cmd\-|co(mp|nd)|craw|da(it|ll|ng)|dbte|dc\-s|devi|dica|dmob|do(c|p)o|ds(12|\-d)|el(49|ai)|em(l2|ul)|er(ic|k0)|esl8|ez([4-7]0|os|wa|ze)|fetc|fly(\-|_)|g1 u|g560|gene|gf\-5|g\-mo|go(\.w|od)|gr(ad|un)|haie|hcit|hd\-(m|p|t)|hei\-|hi(pt|ta)|hp( i|ip)|hs\-c|ht(c(\-| |_|a|g|p|s|t)|tp)|hu(aw|tc)|i\-(20|go|ma)|i230|iac( |\-|\/)|ibro|idea|ig01|ikom|im1k|inno|ipaq|iris|ja(t|v)a|jbro|jemu|jigs|kddi|keji|kgt( |\/)|klon|kpt |kwc\-|kyo(c|k)|le(no|xi)|lg( g|\/(k|l|u)|50|54|\-[a-w])|libw|lynx|m1\-w|m3ga|m50\/|ma(te|ui|xo)|mc(01|21|ca)|m\-cr|me(rc|ri)|mi(o8|oa|ts)|mmef|mo(01|02|bi|de|do|t(\-| |o|v)|zz)|mt(50|p1|v )|mwbp|mywa|n10[0-2]|n20[2-3]|n30(0|2)|n50(0|2|5)|n7(0(0|1)|10)|ne((c|m)\-|on|tf|wf|wg|wt)|nok(6|i)|nzph|o2im|op(ti|wv)|oran|owg1|p800|pan(a|d|t)|pdxg|pg(13|\-([1-8]|c))|phil|pire|pl(ay|uc)|pn\-2|po(ck|rt|se)|prox|psio|pt\-g|qa\-a|qc(07|12|21|32|60|\-[2-7]|i\-)|qtek|r380|r600|raks|rim9|ro(ve|zo)|s55\/|sa(ge|ma|mm|ms|ny|va)|sc(01|h\-|oo|p\-)|sdk\/|se(c(\-|0|1)|47|mc|nd|ri)|sgh\-|shar|sie(\-|m)|sk\-0|sl(45|id)|sm(al|ar|b3|it|t5)|so(ft|ny)|sp(01|h\-|v\-|v )|sy(01|mb)|t2(18|50)|t6(00|10|18)|ta(gt|lk)|tcl\-|tdg\-|tel(i|m)|tim\-|t\-mo|to(pl|sh)|ts(70|m\-|m3|m5)|tx\-9|up(\.b|g1|si)|utst|v400|v750|veri|vi(rg|te)|vk(40|5[0-3]|\-v)|vm40|voda|vulc|vx(52|53|60|61|70|80|81|83|85|98)|w3c(\-| )|webc|whit|wi(g |nc|nw)|wmlb|wonu|x700|yas\-|your|zeto|zte\-/i.test(a.substr(0, 4))) check = true; })(navigator.userAgent || navigator.vendor || window.opera);
    return check;
  }
  handleEmailsDomains(encryptedMtn) {
    //e.preventDefault();
    //this.props.selectAccordian('ED');
    this.props.actions.getEmailsDomains(encryptedMtn).then(() => {
      let elmnt = document.getElementById("blockEmailsDomains");
     /*  if (this.mobilecheck()) {
        elmnt.scrollIntoView(top);
      } else {
        window.scrollTo(0, elmnt.parentElement.parentElement.offsetTop + ((elmnt.parentElement.parentElement.offsetTop * 20) / 100));
      } */

      if (this.props.emailDomains && parseInt(this.props.emailDomains.statusCode) == 0) {
        const blockedSites = this.props.blockedSites && this.props.blockedSites
        const blockMessagesFromWeb = this.props.emailDomains.blockMessagesFromWeb && this.props.emailDomains.blockMessagesFromWeb
        const blockMessagesFromEmail = this.props.emailDomains.blockMessagesFromEmail && this.props.emailDomains.blockMessagesFromEmail
        blockedSites.forEach(element => {
          element.blockedOldSiteName = element.blockedSiteName;
          element.blockedOldSiteMemo = element.blockedSiteMemo;
        });
        this.setState({
          blockedSites: blockedSites,
          bannerStatus: false,
          blockMessagesFromWeb: blockMessagesFromWeb,
          blockMessagesFromEmail: blockMessagesFromEmail,
          blockMessagesFromWebEdit: blockMessagesFromWeb,
          blockMessagesFromEmailEdit: blockMessagesFromEmail
        })
      }
      else {
        this.setState({
          blockedSites: [],
          bannerStatus: true
        });
      }
    })
  }


  handleChecked = () => {
    const { checkBox } = this.state
    this.setState({
      checkBox: !checkBox
    })

  }

  handleCheckPreference = (e, inputType) => {

    // console.log("Input type", inputType)
    const { blockMessagesFromWeb, blockMessagesFromEmail } = this.state
    if (inputType == "blockMessagesFromWeb") {
      this.setState({
        blockMessagesFromWeb: !blockMessagesFromWeb
      })
    }
    if (inputType == "blockMessagesFromEmail") {
      this.setState({
        blockMessagesFromEmail: !blockMessagesFromEmail
      })
    }
  }

  handlePreference() {
    const { selectedDevice, newEmailSuccess } = this.props
    const { blockMessagesFromWeb, blockMessagesFromEmail } = this.state
    const payload = {
      "mtn": selectedDevice.encryptedMtn,
      "blockMessagesFromWeb": blockMessagesFromWeb,
      "blockMessagesFromEmail": blockMessagesFromEmail,
      "isPreferences": true
    }
    this.props.actions.postNewEmail(payload, selectedDevice.encryptedMtn).then(() => {
      let elmnt = document.getElementById("scrollFix");
      if (elmnt != null)
        if (this.mobilecheck()) {
          elmnt.scrollIntoView(top);
        } else {
          window.scrollTo(0, elmnt.offsetTop);
        }
      // console.log("handlePreference", payload)
    });
  }

  SaveButton(e) {
    e.preventDefault();
    const { selectedDevice } = this.props
    const { blockedSites, checkBox, blockMessagesFromWeb, blockMessagesFromEmail } = this.state
    const payload = {
      // "id": blockedSites.length,
      "blockedSiteName": this.state.email,
      "blockedSiteMemo": this.state.memo,
      "blockedSiteAction": "ADD",
      "mtn": selectedDevice.encryptedMtn,
      "applyAll": checkBox,
      "blockMessagesFromWeb": blockMessagesFromWeb,
      "blockMessagesFromEmail": blockMessagesFromEmail,
      "isPreferences": false
    }
    console.log("Payload", payload)
    this.props.actions.postNewEmail(payload, selectedDevice.encryptedMtn).then(() => {
      let elmnt = document.getElementById("scrollFix");
      if (elmnt != null)
        if (this.mobilecheck()) {
          elmnt.scrollIntoView(top);
        } else {
          window.scrollTo(0, elmnt.offsetTop);
        }
      if (this.props.newEmails && parseInt(this.props.newEmails.statusCode) == 0) {
        this.setState({
          blockedSites: [...blockedSites, {
            // "id": this.props.blockedSites.length,
            "blockedSiteName": this.state.email,
            "blockedSiteMemo": this.state.memo
          }],
          email: "",
          memo: ""
        });
      }
      else {
        this.setState({
          blockedSites: [...blockedSites],
          email: "",
          memo: ""
        });
      }
    })
  }

  editSingleBlock(e, selectedSite) {
    const { blockedSites } = this.state;
    blockedSites.forEach(site => {
      if (site.blockedSiteName == selectedSite.blockedSiteName) {
        site.blockedSiteAction = true;
      }
      else {
        site.blockedSiteAction = false;
      }
    });
    // this.setState({
    //     selectedEmail: selectedSite.blockedSiteName,
    //     selectedMemo: selectedSite.blockedSiteMemo,
    //     oldEmail: selectedSite.blockedSiteName,
    //     oldMemo: selectedSite.blockedSiteMemo,
    //     emptyFields: true
    // });
  }

  deletedBlocks = (e, selectedSite) => {
    e.preventDefault();
    // console.log("POST DELETE")
    console.log("selecetedState", selectedSite)
    const { selectedDevice } = this.props
    const { blockedSites } = this.state
    if (reactGlobals.isCsr) {
            return;
          }
    const payload = {
      "blockedSiteName": selectedSite.blockedSiteName,
      "blockedSiteMemo": selectedSite.blockedSiteMemo,
      "blockedSiteAction": "DELETE",
      "mtn": selectedDevice.encryptedMtn
    }

    this.props.actions.postDeleteEmail(payload).then(() => {
      let elmnt = document.getElementById("scrollFix");
      if (elmnt != null)
        if (this.mobilecheck()) {
          elmnt.scrollIntoView(top);
        } else {
          window.scrollTo(0, elmnt.offsetTop);
        }
      if (this.props.deleteEmailSuccess && this.props.deleteEmailSuccess) {

        const updatedList = this.state.blockedSites.filter((site) => site.blockedSiteName !== selectedSite.blockedSiteName && site.blockedSiteMemo !== selectedSite.blockedSiteMemo)
        this.setState({
          blockedSites: updatedList
        })
      }
      else if(this.props.postDeployError){
        let blockedList = this.state.blockedSites;
        blockedList.forEach(element => {
          element.isEdit = false
        })
        this.setState({
          editEmail: false, editAllEmail: false
        })
      }
    })

  }
  handleEdit = (e, email) => {
    e.preventDefault();
    this.state.blockedSites.forEach(element => {
      element.editEmailValid = true;
      if (element.blockedSiteName == email.blockedSiteName) {
        element.isEdit = true;
      }
      else
        element.isEdit = false;
    });
    this.setState({
      editEmail: true,
      editAllEmail: false
    });
  }
  handleEditAll = (e) => {
    let Blocked = this.state.blockedSites;
    Blocked.forEach(element => {
      element.isEdit = true;
      element.editEmailValid = true;
    });
    this.setState({ Blocked, editAllEmail: true, editEmail: false })
    e.preventDefault();

  }
  handleEditSite = (e) => {
    debugger
    e.preventDefault();
    if (this.state.editEmail) {
      let editedRow = this.state.blockedSites.filter(q => q.isEdit);
      let payload = {
        blockedOldSiteName: editedRow[0].blockedOldSiteName,
        blockedSiteName: editedRow[0].blockedSiteName,
        blockedSiteMemo: editedRow[0].blockedSiteMemo,
        blockedOldSiteMemo: editedRow[0].blockedOldSiteMemo,
        "blockedSiteAction": "UPDATE",
        "mtn": this.props.selectedDevice.encryptedMtn
      }
      this.props.actions.postEditEmail(payload).then(() => {
        let blockedList = this.state.blockedSites;
        blockedList.forEach(element => {
          element.isEdit = false;
        });
        if(this.props.editEmailSuccess && this.props.editEmailSuccess)
        this.setState({ Blocked: blockedList, editEmail: false })
        else if(this.props.postDeployError){
          let blockedList = this.state.blockedSites;
          blockedList.forEach(element => {
            element.isEdit = false,
            element.blockedSiteName = element.blockedOldSiteName
            element.blockedSiteMemo = element.blockedOldSiteMemo
          })
          this.setState({
            editEmail: false, editAllEmail: false
          })
        }
      });
    }
    if (this.state.editAllEmail) {
      let editpayload = [];
      this.state.blockedSites.forEach(element => {
        editpayload.push({
          blockedOldSiteName: element.blockedOldSiteName,
          blockedSiteName: element.blockedSiteName,
          blockedSiteMemo: element.blockedSiteMemo,
          blockedOldSiteMemo: element.blockedOldSiteMemo
        })
      });
      let editAllPayload = {
        "mtn": this.props.selectedDevice.encryptedMtn,
        "blockedSites": editpayload
      }
      this.props.actions.postEditAll(editAllPayload).then(() => {
        let blockedList = this.state.blockedSites;
        blockedList.forEach(element => {
          element.isEdit = false;
        });
        if(this.props.editAllEmailSuccess && this.props.editAllEmailSuccess)
        this.setState({ Blocked: blockedList, editAllEmail: false })
        else if(this.props.postDeployError){
          let blockedList = this.state.blockedSites;
          blockedList.forEach(element => {
            element.isEdit = false,
            element.blockedSiteName = element.blockedOldSiteName
            element.blockedSiteMemo = element.blockedOldSiteMemo
          })
          this.setState({
            editEmail: false, editAllEmail: false
          })
        }
      });

    }
  }
  handleInput = (event, inputType, row) => {
    let inputValue = event.target.value;

    let invalidEmail = false;
    if (inputType == "email") {
      if (inputValue.indexOf("@") != -1) {
        let pattern = /^(([^<>()\[\]\\.,;:\s@"]+(\.[^<>()\[\]\\.,;:\s@"]+)*)|(".+"))@((\[[0-9]{1,3}\.[0-9]{1,3}\.[0-9]{1,3}\.[0-9]{1,3}\])|(([a-zA-Z\-0-9]+\.)+[a-zA-Z]{2,}))$/
        invalidEmail = pattern.test(inputValue);
      }
      else {
        let pattern = /^(([a-zA-Z]{1})|([a-zA-Z]{1}[a-zA-Z]{1})|([a-zA-Z]{1}[0-9]{1})|([0-9]{1}[a-zA-Z]{1})|([a-zA-Z0-9][a-zA-Z0-9-_]{1,61}[a-zA-Z0-9]))\.([a-zA-Z]{2,6}|[a-zA-Z0-9-]{2,30}\.[a-zA-Z]{2,3})$/
        invalidEmail = pattern.test(inputValue);
      }
      if (this.state.editEmail || this.state.editAllEmail) {
        let blockedList = this.state.blockedSites;
        blockedList.forEach(element => {
          if (element.blockedOldSiteName == row.blockedOldSiteName) {
            element.blockedSiteName = inputValue;
            element.editEmailValid = invalidEmail;
          }
        });
        this.setState({ Blocked: blockedList });
      }
      else
        this.setState({
          email: inputValue,
          invalidEmail: !invalidEmail
        })
    } else if (inputType == "memo") {
      if (this.checkAllowedPattern(inputValue)) {
        if (this.state.editEmail || this.state.editAllEmail) {
          let blockedList = this.state.blockedSites;
          blockedList.forEach(element => {
            if (element.blockedOldSiteName == row.blockedOldSiteName) {
              element.blockedSiteMemo = inputValue;
            }
          });
          this.setState({ Blocked: blockedList });
        }
        else
          this.setState({
            memo: event.target.value
          });
      } else
      return false;
    }
  }
  checkAllowedPattern = (addStr) => {
    let addPattern = /^[0-9a-zA-Z\s=,.:_-]+$/;
    let spacePattern = /^[\s=,.:_-]+$/;
    if ((addStr.length == 1) && addStr.match(spacePattern)) {
      return false;
    }
    else if (addStr.match(addPattern) || addStr == "") {
      return true;
    } else
      return false;
  }
  handleCancel = (e) => {
    event.preventDefault();
    let blockedList = this.state.blockedSites;
    blockedList.forEach(element => {
      element.isEdit = false;
      element.blockedSiteName = element.blockedOldSiteName
      element.blockedSiteMemo = element.blockedOldSiteMemo
    });
    this.setState({ Blocked: blockedList, editEmail: false, editAllEmail: false })
  }

  componentDidMount() {
    this.handleEmailsDomains(this.props.selectedDevice.encryptedMtn);
  }

  render() {
    // console.log("remainingCount",this.props.remainingCount)
    // console.log("this.state.blockMessagesFromEmail",this.state.blockMessagesFromEmail) 
    // console.log(" this.state.blockMessagesFromWeb", this.state.blockMessagesFromWeb)
    // console.log("BlockedList", this.props.newEmails)
    // console.log("this.props.postDeployError",this.props.postDeployError)
    // console.log("this.props.postDeployError",this.props.postErrorResponse)
    // console.log("emailDomains", this.props.emailDomains && this.props.emailDomains.remainingSpamCount && this.props.emailDomains.remainingSpamCount)
    const { blockedSites, editall, editAllEmail } = this.state
    const { isFetching, emailDomains, newEmailSuccess, deleteEmails, newEmails, postErrorResponse, remainingCount, emailEditAll, editEmails } = this.props
    let showNotice = false
    let showBanner = false
    let successMsg = ""
    let failMsg = ""
    let Type = ""
    let trackingId = ""
    let Message = ""
    const count = this.props.remainingCount && remainingCount
    if (this.props.newEmailSuccess == true) {
      if (this.props.newEmails && (newEmails.hasSuccessMsg || newEmails.hasFailureMsg)) {
        showBanner = true,
          showNotice = false,
          successMsg = this.props.newEmails && newEmails.successMsg && newEmails.successMsg,
          failMsg = this.props.newEmails && newEmails.failureMsg && newEmails.failureMsg
      }
      else if (this.props.newEmails && (newEmails.hasSuccessMsg == false && newEmails.hasFailureMsg == false)) {
        showBanner = false,
          showNotice = true,
          Message = this.props.newEmails && newEmails.successMsg && newEmails.successMsg,
          Type = 2,
          trackingId = "EmailDomainsSuccessNotification"
      }
    }
    else if (this.props.deleteEmailSuccess == true) {
      showNotice = true,
        Type = 2,
        Message = this.props.deleteEmails && deleteEmails.successMsg && deleteEmails.successMsg,
        trackingId = "EmailDomainsSuccessNotification"
    }
    else if (this.props.editEmailSuccess == true) {
      showNotice = true,
        Type = 2,
        Message = this.props.editEmails && editEmails.successMsg && editEmails.successMsg,
        trackingId = "EmailDomainsSuccessNotification"
    }
    else if (this.props.editAllEmailSuccess == true) {
      showNotice = true,
        Type = 2,
        Message = this.props.emailEditAll && emailEditAll.successMsg && emailEditAll.successMsg,
        trackingId = "EmailDomainsSuccessNotification"
    }
    else if (this.props.postDeployError == true) {
      showNotice = true,
        Type = 3,
        Message = this.props.postErrorResponse && postErrorResponse.errorMessage ? postErrorResponse.errorMessage : "Something went wrong, Please try again later!",
        trackingId = "EmailDomainsFailureNotification"
    }
    const Blocked = blockedSites.map(blockedSite => (
      <div className="row row-p-b" key={blockedSite.blockedSiteName}>
        {blockedSite.isEdit ?
          <Fragment>
            <div className="col-sm-8 col-xs-8 hidden-md hidden-lg"></div>
            <div className="col-sm-2 col-xs-2 hidden-md hidden-lg">
              <a href="javascript: void(0);" className="o-link radio-choose--disabled" data-track="CallsMessagesDesktopEdit">Edit</a>
            </div>
            <div className="col-sm-2 col-xs-2 hidden-md hidden-lg p-l-r-0">
              <a href="javascript: void(0);" className={reactGlobals.isCsr?"o-link radio-choose--disabled":"o-link" } onClick={(e) => this.deletedBlocks(e, blockedSite)} data-track="CallsMessagesDesktopDeleteButton">Delete</a>
            </div>
            <div className="col-lg-5 col-sm-12 col-xs-12 col-md-5 p-l-r-0">
              <input type="text"
                name="block_site_name"
                id="block_site_name"
                value={blockedSite.blockedSiteName}
                autoComplete="off"
                onChange={(e) => this.handleInput(e, 'email', blockedSite)}
                className={blockedSite.editEmailValid == false ? "txtError" : ""}
                style={{ marginBottom: 0 }}
                placeholder="Enter email address/domain" />
              {blockedSite.editEmailValid == false && <p className="mb-18"> Please enter a valid email.</p>}
            </div>
            <div className="col-lg-5 col-sm-12 col-xs-12 col-md-5 p-l-r-0">
              <input type="text"
                id="blocked_site_memo"
                name="blocked_site_memo"
                maxLength="25"
                placeholder="Include any notes here"
                value={blockedSite.blockedSiteMemo}
                style={{ marginBottom: 0 }}
                autoComplete="off"
                onChange={(e) => this.handleInput(e, 'memo', blockedSite)} />
            </div>
            <div className="col-lg-1 col-md-1 hidden-sm hidden-xs">
              <a href="javascript: void(0);" className="o-link radio-choose--disabled" data-track="CallsMessagesDesktopEditButton">Edit</a>
            </div>
            <div className="col-lg-1 col-md-1 hidden-sm hidden-xs p-l-r-0">
              <a href="javascript: void(0);" className={reactGlobals.isCsr?"o-link btn-disabled":"o-link" } onClick={(e) => this.deletedBlocks(e, blockedSite)} data-track="CallsMessagesDesktopDeleteButton">Delete</a>
            </div>
          </Fragment> : <Fragment>

            <div className="col-lg-10 col-sm-8 col-xs-8 col-md-10">
              <p>{(blockedSite.blockedSiteName)}</p>
              <p style={{ paddingTop: '15px', paddingBottom: '5px' }}>{blockedSite.blockedSiteMemo}</p>
            </div>
            <div className="col-lg-1 col-sm-2 col-xs-2 col-md-1">
              <a href="javascript: void(0);" className="o-link" onClick={(e) => this.handleEdit(e, blockedSite)} data-track="CallsMessagesDesktopEditButton">Edit</a>
            </div>
            <div className="col-lg-1 col-sm-2 col-xs-2 col-md-1 p-l-r-0">
              <a href="javascript: void(0);" className={reactGlobals.isCsr?"o-link btn-disabled":"o-link" } onClick={(e) => this.deletedBlocks(e, blockedSite)} data-track="CallsMessagesDesktopDeleteButton">Delete</a>
            </div></Fragment>
        }
      </div>
    ));
    return (
      <div className="">
        <div className="">
          {/* <div> <Loader show={isFetching} /></div> */}
          {/* <div className="accordion__title"
            role="button"
            tabIndex="0" onClick={(e) => this.handleEmailsDomains(e, this.props.selectedDevice.encryptedMtn)}
            onKeyPress={(e) => this.handleEmailsDomains(e, this.props.selectedDevice.encryptedMtn)} 
            aria-expanded={this.props.selectedAccordian == 'ED' ? true : false}
          >
            
          </div> */}
          <Body>
          <div >
            {/* {showBanner ? <div id="scrollFix">
              {this.props.newEmails.hasSuccessMsg && newEmails.hasSuccessMsg ? <div id={`overlayFrame-SuccessNotification`}><Alert Message={successMsg} Type={2} closeBanner={true}> </Alert><br /></div> : null}
              {this.props.newEmails.hasFailureMsg && newEmails.hasFailureMsg ? <div id={`overlayFrame-FailureNotification`}><Alert Message={failMsg} Type={3} closeBanner={true}> </Alert><br /></div> : null}
            </div> : null}
            {showNotice ? <div id="scrollFix" data-track={trackingId}><Alert Message={Message} Type={Type} closeBanner={true}> </Alert><br /></div> : null} */}
             <div>
              <div className="row">
                <div className="col-lg-12 p-l-r-0">
                  <Title size='medium' bold='true'>Spam Blocks</Title>

                </div>
              </div>
              <div className="row">
                <div className="col-lg-12 p-l-r-0">
                  <div className="o-block-msg">
                    <p className="p-t-b-10">
                      <Body size="medium">You can block text messages originating from email addresses (name@domain.com), domains (www.domain.com) and/or text names (nickname@vtext.com).</Body>
                    </p>
                    <Body className="p-t-b-10">
                      Add up to <span>{this.props.remainingCount && remainingCount}</span> spam blocks.
                  </Body>
                  </div>
                </div>
              </div>
              {/* <div className="row">
              <div className="col-lg-12 p-l-r-0">
                <a href="javascript:void(0)" onClick={() => this.EditAll()} data-track="EmailDomainsDesktopEditAll"
                  className={
                    !this.state.editall
                      ? "o-link o-edit-all-link"
                      : "o-link o-edit-all-link isdisabled"
                  }>Edit all</a><br />
              </div>
            </div> */}
              <div className={(this.state.editAllEmail || this.state.editEmail || count == 0) ? "radio-choose--disabled" : ""}>
                <div className="row">
                  <div className="col-lg-12 p-l-r-0">
                  <label htmlFor="block_site_name">
                    <br></br>
                    <Body size="large" bold={true}>Email address or domain</Body>
                    <br/>
                    <Input type="text"
                      
                      aria-labelledby="emailAlert"
                      width='40%'
                      placeholder="Enter email address/domain"
                      value={this.state.email}
                      onChange={(e) => this.handleInput(e, "email", e.target.value)}
                      className={this.state.invalidEmail == true ? "txtError" : ""} />
                      </label>
                    {this.state.invalidEmail == true && <Body size="large" bold={true}> Please enter a valid email.</Body>}
                  </div>
                </div>
                <br></br>
                <div className="row">
                  <div className="col-lg-12 p-l-r-0">
                  <label htmlFor="blocked_site_memo">
                    <Body size="large" bold={true}>Memo (Optional. 25 characters max)</Body><br/>
                    <Input type="text"
                      width='80%'
                      size="large"
                      placeholder="Include any notes here"
                      value={this.state.memo}
                      onChange={(e) => this.handleInput(e, "memo", e.target.value)} />
                      </label>
                  </div>
                </div><br/>
                <div className="row">
                  <div className="col-lg-12 p-l-r-0">
                    <label htmlFor="allLinesBlockNum_1" aria-labelledby="confirm2">
                      <Checkbox type="checkbox" name="confirm" id="confirm2" onChange={() => this.handleChecked() } label='Apply block to all eligible lines on this account'></Checkbox>
                                                    </label>
                  </div>
                </div>
                <div className="row">
                  <div className="col-lg-12 p-l-r-0 p-t-b-10">
                    <Button type="button"  onClick={(e) => this.SaveButton(e, this.state)} data-track="EmailDomainsDesktopSave">Save</Button>
                  </div>
                </div>
              </div>
              {Blocked.length > 0 &&
                <div className="row">
                  <div className="col-lg-10 col-md-11 col-sm-10 col-xs-10 p-l-r-0">
                    <Title size='medium' bold='true'>Currently blocked email addresses and domains</Title>
                  </div>
                  <div className="col-lg-2  col-md-1 col-sm-2 col-xs-2 p-l-r-0">
                    <a className={editAllEmail ? "o-link radio-choose--disabled" : "o-link"} onClick={(e) => this.handleEditAll(e)} data-track="EmailDomainsEditAll">Edit All</a>
                  </div>
                </div>}
              {Blocked.length > 0 && <Fragment>
                {Blocked}
                <div className="row">
                  {(this.state.editEmail || this.state.editAllEmail) && < div className="col-lg-12 p-l-r-0 p-t-b-10">
                    <Button type="button" className="o-btn mb-0 btn-block" id="addSpamBtn" disabled={reactGlobals.isCsr || this.state.blockedSites.filter(q => q.editEmailValid != true).length > 0} onClick={(e) => this.handleEditSite(e)} data-track="EmailDomainsDesktopApply">Save Changes</Button>
                    <Button type="button" className="o-btn mb-0 btn-block ml-10" disabled={this.state.blockedSites.filter(q => q.editEmailValid != true).length > 0} id="cancelSpamBtn" onClick={(e) => this.handleCancel(e)} data-track="CancelButton">Cancel</Button>
                  </div>}
                </div>
              </Fragment>}
              <div className="row">
                <div className="col-lg-12 p-l-r-0 mt-18">
                  <Body size='large' bold='true'>Message blocking preferences</Body>
                </div>
              </div>
              <div style={{padding:'3px'}}></div>
              <div className="row">
                <div className="col-lg-12 p-l-r-0">
                  <div className="o-domain-block-prefs o-clr">
                    <div className="row">
                      <div className="col-lg-12 p-l-r-0">
                        <div className="o-inline-block o-special-switch">
                          <Checkbox type="checkbox" size='medium' onChange={(e) => this.handleCheckPreference(e, "blockMessagesFromWeb")} id="blockCheck1_1" checked={this.state.blockMessagesFromWeb} >
                          <span for="blockCheck1_1" className="o-font-normal">Block all text messages sent from the web.</span></Checkbox>
                        </div>
                      </div>
                    </div>
                    <div style={{padding:'3px'}}></div>
                    <div className="row">
                      <div className="col-lg-12 p-l-r-0">
                        <div className="o-inline-block">
                          <Checkbox type="checkbox" onChange={(e) => this.handleCheckPreference(e, "blockMessagesFromEmail")} id="blockCheck2_1" checked={this.state.blockMessagesFromEmail} >
                          <span for="blockCheck2_1" className="o-font-normal">Block all text messages sent from email.</span></Checkbox>
                        </div>
                      </div>
                    </div>
                    <div className="row">
                      <div className="col-lg-12 p-l-r-0 p-t-b-10">
                        <Button type="button" className="o-btn mb-0 btn-block" id="addSpamBtn" 
                         
                        onClick={() => this.handlePreference()} data-track="EmailDomainsDesktopApply">Save</Button>
                      </div>
                    </div>
                  </div>
                </div>
              </div>
            </div> 
          </div>
          </Body>
        </div>
      </div >
    );
  }
}

const FAQsHeadSection = styled.div`
                  margin-top: 0px;
                  padding: 10px 0 12px;
                  border-bottom: 2px solid #000;
                  display: block;
                  width: 100%;
                  font-family: "NeueHaasGroteskDisplayBold", arial;
                  font-size: 18px;
                  color: #000000;
                  clear: both;
                  `;

const FAQsSection = styled.div`
                  border-top: none;
                  `;

const mapStateToProps = state => {
  return {
    emailDomains: state.Detail.sitesBlocked.emailDomains,
    blockedSites: state.Detail.sitesBlocked.blockedSites,
    isFetching: state.Detail.sitesBlocked.isFetching,
    getEmails: state.Detail.sitesBlocked.getEmails,
    newEmails: state.Detail.sitesBlocked.newEmails,
    newEmailSuccess: state.Detail.sitesBlocked.newEmailSuccess,
    postErrorResponse: state.Detail.sitesBlocked.postErrorResponse,
    remainingCount: state.Detail.sitesBlocked.remainingCount,
    editEmails: state.Detail.sitesBlocked.editEmails,
    deleteEmails: state.Detail.sitesBlocked.deleteEmails,
    deleteEmailSuccess: state.Detail.sitesBlocked.deleteEmailSuccess,
    emailEditAll: state.Detail.sitesBlocked.emailEditAll,
    postDeployError: state.Detail.sitesBlocked.postDeployError,
    editAllEmailSuccess: state.Detail.sitesBlocked.editAllEmailSuccess,
    editEmailSuccess: state.Detail.sitesBlocked.editEmailSuccess
  }
}

const mapDispatchToProps = dispatch => ({
  actions: bindActionCreators(actions, dispatch),
})


export default connect(mapStateToProps, mapDispatchToProps)(BSEmailsDomains);
