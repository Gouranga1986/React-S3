import { combineReducers } from "redux";

import callsMessagesReducer from "./callsMessages";
import deviceLandingReducer from "./Devicedetail";
import emailDomainsReducer from "./emailsDomains";
import servicesReducer from "./services";

const rootReducer = combineReducers({
    
    callsMsgs: callsMessagesReducer,
    Details: deviceLandingReducer,
    sitesBlocked: emailDomainsReducer,
    serviceCalls: servicesReducer,
});

export default rootReducer;

  
  