import {
    GET_SERVICES_BEGIN,
    GET_SERVICES_SUCCESS,
    GET_SERVICES_FAIL,
    POST_SERVICES_BEGIN,
    POST_SERVICES_SUCCESS,
    POST_SERVICES_FAIL,
} from '../actions'

const initialState = {
    isFetching: false,
    services:{},
    confirmServices:{},
    servicesError:{},
    serviceErrorFlag: false,
    confirmServiceFlag: false,
    failServices: {},
    getServices : false,
    failServices : false
}

const servicesReducer = (state = initialState, action) => {
    // console.log("Email in Reducer",action.emailDomains)
    //  console.log("Blcoked Emails in Reducer",action.blockedSites)
    console.log(action,'action')
    const { type } = action
    // console.log("TYPE", type)

    console.log(type,'type')
    switch (type) {
        case GET_SERVICES_BEGIN:
            return {
                ...state,
                isFetching: true,
                confirmServices: {},
                failServices: {},
                serviceErrorFlag: false,
                confirmServiceFlag: false,
                getServices : false,
                serviceFail : false
            }

        case GET_SERVICES_SUCCESS:   
            return {
                ...state,
                services : action.services,
                serviceStatus : action.serviceStatus,
                getServices : true,
                isFetching: false
            }
            
        case GET_SERVICES_FAIL: 
            return {
                ...state,
                isFetching: false,
                serviceFail: true,
                failServices: action.failServices
            }

            case POST_SERVICES_BEGIN:
            return {
                ...state,
                isFetching: true,
                confirmServices: {},
                serviceErrorFlag: false,
                confirmServiceFlag: false
            }

            case POST_SERVICES_SUCCESS:   
            return {
                ...state,
                confirmServices : action.confirmServices,
                isFetching: false,
                confirmServiceFlag: true
            }

            case POST_SERVICES_FAIL:
            return {
                ...state,
                isFetching: false,
                servicesError: action.servicesError,
                serviceErrorFlag: true
            }

        default:
            return state
    }
}

export default servicesReducer
