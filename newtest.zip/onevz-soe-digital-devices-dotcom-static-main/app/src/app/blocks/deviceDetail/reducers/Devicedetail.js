
import {
  GET_DEVICE_DETAIL_BEGIN,
  GET_DEVICE_DETAIL_SUCCESS,
  GET_DEVICE_DETAIL_ERROR,
} from "../actions/getSections";


import { updateObject } from '../../../../shared/utilities/reducer';
import common from '../../../../shared/utilities/util';

const initialState = {
  isFetching: false,
  statusCode: "",
  statusMessage: "",
  errorMessage: '',
  errorDesc: '',
  actionName: '',
  actionValue: '',
  actionType: '',
  errorObj: {},
  deviceDetails: {},
  selectedDevice: {},
  
};

export const getDeviceDetailBegin = (state, action) => {
  return updateObject(state, {
    isRedirectedFromDetailPage: false,
    isFetching: true
  });
};

export const getDeviceDetailSuccess = (state, action) => {
  console.log(state,action,'actions')
  return updateObject(state, {
    isFetching: false,
    statusCode: action.msResp.responseInfo.responseCode,
    statusMessage: action.msResp.responseInfo.responseMessage,
    deviceDetails: action.msResp.body.sections[0].sections[1],
    selectedDevice: {}
  });
};

export const getDeviceDetailError = (state, action) => {
  let msResp = action && action.err && action.err.response && action.err.response.data;
  let responseCode = msResp && msResp.responseInfo && msResp.responseInfo.responseCode;
  let responseMessage = msResp && msResp.responseInfo && msResp.responseInfo.responseMessage;
  let body = msResp && msResp.body;
  return updateObject(state, {
    isFetching: false,
    sectionContentMetaData: {},
    selectedDevice: {},
    statusCode: responseCode ? responseCode : '',
    statusMessage: common.isError(responseCode, responseMessage, body),
    errorMessage: common.isError(responseCode, responseMessage, body),
    errorDesc: common.isErrorDesc(responseCode, responseMessage, body),
    actionName: common.isActionName(responseCode, responseMessage, body),
    actionValue: common.isActionValue(responseCode, responseMessage, body),
    actionType: common.isActionType(responseCode, responseMessage, body),
    errorObj: responseCode !== "00" && msResp && msResp.responseInfo ? msResp.responseInfo.sectionErrors : action.err,
  });
};



export const setSelectedDeviceValue = (state, action) => {
  return updateObject(state, {
    selectedDevice: action.data
  });
}


const deviceLandingReducer = (state = initialState, action) => {
  const { type } = action;
  switch (type) {
    case GET_DEVICE_DETAIL_BEGIN:
      return getDeviceDetailBegin(state, action);
    case GET_DEVICE_DETAIL_SUCCESS:
      return getDeviceDetailSuccess(state, action);
    case GET_DEVICE_DETAIL_ERROR:
      return getDeviceDetailError(state, action);
    default:
      return state;
  }
};

export default deviceLandingReducer;
