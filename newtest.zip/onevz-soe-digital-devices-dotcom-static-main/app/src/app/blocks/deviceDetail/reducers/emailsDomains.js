import {
    GET_EMAILS_DOMAINS_BEGIN,
    GET_EMAILS_DOMAINS_SUCCESS,
    GET_EMAILS_DOMAINS_FAIL,
    POST_NEW_EMAILS_DOMAINS_BEGIN,
    POST_NEW_EMAILS_DOMAINS_SUCCESS,
    POST_NEW_EMAILS_DOMAINS_FAIL,
    POST_EDIT_EMAILS_DOMAINS_BEGIN,
    POST_EDIT_EMAILS_DOMAINS_SUCCESS,
    POST_EDIT_EMAILS_DOMAINS_FAIL,
    POST_DELETE_EMAILS_DOMAINS_BEGIN,
    POST_DELETE_EMAILS_DOMAINS_SUCCESS,
    POST_DELETE_EMAILS_DOMAINS_FAIL,
    POST_EDIT_ALL_DOMAINS_BEGIN,
    POST_EDIT_ALL_DOMAINS_SUCCESS,
    POST_EDIT_ALL_DOMAINS_FAIL
} from '../actions'

const initialState = {
    isFetching: false,
    emailDomains:{},
    blockedSites:[],
    newEmails:{},
    remainingCount:[],
    editEmails:{},
    deleteEmails:{},
    postDeployError: false,
    emailEditAll:{},
    // emailEditList:[],
    postErrorResponse: {},
    newEmailSuccess: false,
    deleteEmailSuccess: false,
    editEmailSuccess: false,
    editAllEmailSuccess: false,
    getEmails: false
}

const emailDomainsReducer = (state = initialState, action) => {
    // console.log("Email in Reducer",action.emailDomains)
    //  console.log("Blcoked Emails in Reducer",action.blockedSites)
    const { type } = action
    // console.log("TYPE", type)

    switch (type) {

        case GET_EMAILS_DOMAINS_BEGIN:
            return {
                ...state,
                isFetching: true,
                getEmails: false,
                postDeployError: false,
                newEmailSuccess: false,
                deleteEmailSuccess: false,
                editAllEmailSuccess: false,
                editEmailSuccess: false,
                remainingCount:[]
            }

        case GET_EMAILS_DOMAINS_SUCCESS:   
            return {
                ...state,
                emailDomains : action.emailDomains,
                blockedSites : action.blockedSites,
                remainingCount : action.remainingCount,
                isFetching: false,
                getEmails: true
            }
            
        case GET_EMAILS_DOMAINS_FAIL: 
            return {
                ...state,
                isFetching: false,
                postDeployError: true,
                postErrorResponse: action.errorMsg
            }
            
            case POST_NEW_EMAILS_DOMAINS_BEGIN:
            return {
                ...state,
                isFetching: true,
                newEmails: {},
                newEmailSuccess: false,
                deleteEmailSuccess: false,
                postDeployError: false,
                postErrorResponse: {},
                remainingCount:[]
            }

            case POST_NEW_EMAILS_DOMAINS_SUCCESS:   
            return {
                ...state,
                newEmails : action.newEmails,
                remainingCount : action.remainingCount,
                newEmailSuccess: true,
                isFetching: false
            }

            case POST_NEW_EMAILS_DOMAINS_FAIL:
            return {
                ...state,
                isFetching: false,
                postDeployError: true,
                postErrorResponse: action.errorMsg
            }

            case POST_EDIT_EMAILS_DOMAINS_BEGIN:
            return {
                ...state,
                isFetching: true,
                newEmailSuccess: false,
                editEmailSuccess: false,
                deleteEmailSuccess: false,
                editAllEmailSuccess: false,
                editEmails: {},
                postDeployError: false,
                postErrorResponse: {}
            }

            case POST_EDIT_EMAILS_DOMAINS_SUCCESS:   
            return {
                ...state,
                editEmails : action.editEmails,
                isFetching: false,
                postDeployError: false,
                editEmailSuccess: true
            }

            case POST_EDIT_EMAILS_DOMAINS_FAIL:
            return {
                ...state,
                isFetching: false,
                postDeployError: true,
                postErrorResponse: action.errorMsg
            }
           
            case POST_DELETE_EMAILS_DOMAINS_BEGIN:
            return {
                ...state,
                isFetching: true,
                newEmailSuccess: false,
                postDeployError: false,
                deleteEmailSuccess: false,
                deleteEmails: {},
                postDeployError: false,
                remainingCount:[]
            }

            case POST_DELETE_EMAILS_DOMAINS_SUCCESS:   
            return {
                ...state,
                deleteEmails : action.deleteEmails,
                remainingCount : action.remainingCount,
                deleteEmailSuccess: true,
                isFetching: false
            }
            case POST_DELETE_EMAILS_DOMAINS_FAIL:
            return {
                ...state,
                isFetching: false,
                postDeployError: true,
                postErrorResponse: action.errorMsg
            }
            case POST_EDIT_ALL_DOMAINS_BEGIN:
            return {
                ...state,
                isFetching: true,
                newEmailSuccess: false,
                editEmailSuccess: false,
                editAllEmailSuccess: false,
                deleteEmailSuccess: false,
                postDeployError: false,
                emailEditAll:{},
                postErrorResponse: {}
            }

            case POST_EDIT_ALL_DOMAINS_SUCCESS:   
            return {
                ...state,
                emailEditAll : action.emailEditAll,
                editAllEmailSuccess: true,
                isFetching: false
            }

            case POST_EDIT_ALL_DOMAINS_FAIL:
            return {
                ...state,
                isFetching: false,
                postDeployError: true,
                postErrorResponse: action.errorMsg
            }
           

        default: 
            return state
    }
}

export default emailDomainsReducer
