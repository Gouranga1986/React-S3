import {
  GET_CALLS_MESSAGES_BEGIN,
  GET_CALLS_MESSAGES_SUCCESS,
  GET_CALLS_MESSAGES_FAIL,
  POST_BLOCK_AGAIN_BEGIN,
  POST_BLOCK_AGAIN_SUCCESS,
  POST_BLOCK_AGAIN_FAIL,
  POST_ADD_CALL_MSG_BEGIN,
  POST_ADD_CALL_MSG_SUCCESS,
  POST_ADD_CALL_MSG_FAIL,
  POST_EDIT_CALL_MSG_BEGIN,
  POST_EDIT_CALL_MSG_SUCCESS,
  POST_EDIT_CALL_MSG_FAIL,
  POST_DELETE_CALL_MSG_BEGIN,
  POST_DELETE_CALL_MSG_SUCCESS,
  POST_DELETE_CALL_MSG_FAIL,
  POST_EDIT_ALL_BEGIN,
  POST_EDIT_ALL_SUCCESS,
  POST_EDIT_ALL_FAIL,
} from "../actions/fetchCallsMessages";

const initialState = {
  isFetching: false,
  callsMessages: {},
  blockedNumbers: [],
  expiredNumbers: [],
  blockAgainResponse: {},
  addBlockCallMsg: {},
  editBlockCallMsg: {},
  deleteBlockCallMsg: {},
  editAllBlockCallMsg: {},
  getCMError: {}
};

const callsMessagesReducer = (state = initialState, action) => {
  const {
    type
  } = action;
   console.log("TYPE", type)
  console.log(action,'action')
  switch (type) {
    case GET_CALLS_MESSAGES_BEGIN:
      return {
        ...state,
        isFetching: true
      };

    case GET_CALLS_MESSAGES_SUCCESS:
      return {
        ...state,
        callsMessages: action.payload,
          blockedNumbers: action.blockedNumbers,
          expiredNumbers: action.expiredBlockNumbers,
          isFetching: false
      };

    case GET_CALLS_MESSAGES_FAIL:
      return {
        ...state,
        isFetching: false,
          getCMError: action.payloadGetCMError
      };


    case POST_BLOCK_AGAIN_BEGIN:
      return {
        ...state,
        isFetching: true
      };

    case POST_BLOCK_AGAIN_SUCCESS:
      return {
        ...state,
        blockAgainResponse: action.payloadBlockAgain,
          isFetching: false
      };

    case POST_BLOCK_AGAIN_FAIL:
      return {
        ...state,
        isFetching: false,
          blockAgainResponse: action.payloadBlockAgainError
      };


    case POST_ADD_CALL_MSG_BEGIN:
      return {
        ...state,
        isFetching: true
      };

    case POST_ADD_CALL_MSG_SUCCESS:
      return {
        ...state,
        addBlockCallMsg: action.payloadAddCallMsg,
          isFetching: false
      };

    case POST_ADD_CALL_MSG_FAIL:
      return {
        ...state,
        isFetching: false,
          addBlockCallMsg: action.payloadAddCallMsgError
      };


    case POST_EDIT_CALL_MSG_BEGIN:
      return {
        ...state,
        isFetching: true
      };

    case POST_EDIT_CALL_MSG_SUCCESS:
      return {
        ...state,
        editBlockCallMsg: action.payloadEditCallMsg,
          isFetching: false
      };

    case POST_EDIT_CALL_MSG_FAIL:
      return {
        ...state,
        isFetching: false,
          editBlockCallMsg: action.payloadEditCallMsgError,
      };


    case POST_DELETE_CALL_MSG_BEGIN:
      return {
        ...state,
        isFetching: true
      };

    case POST_DELETE_CALL_MSG_SUCCESS:
      return {
        ...state,
        deleteBlockCallMsg: action.payloadDeleteCallMsg,
          isFetching: false
      };

    case POST_DELETE_CALL_MSG_FAIL:
      return {
        ...state,
        isFetching: false,
          deleteBlockCallMsg: action.payloadDeleteCallMsgError
      };


    case POST_EDIT_ALL_BEGIN:
      return {
        ...state,
        isFetching: true
      };

    case POST_EDIT_ALL_SUCCESS:
      return {
        ...state,
        editAllBlockCallMsg: action.payloadEditAll,
          isFetching: false
      };

    case POST_EDIT_ALL_FAIL:
      return {
        ...state,
        isFetching: false,
          editAllBlockCallMsg: action.payloadEditAllError
      };


    default:
      return state;
  }
};

export default callsMessagesReducer;
