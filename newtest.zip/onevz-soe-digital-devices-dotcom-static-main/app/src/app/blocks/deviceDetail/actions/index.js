export {
  getDeviceDetail
} from './getSections';
export { setSelectedDevice, isRedirectedFromDetailPage } from './pageActions';
export {getCallsMessages,
  postBlockAgain,
  postaddBlockCallMsg,
  postEditBlockCallMsg,
  postDeleteBlockCallMsg,
  postEditAll
} from './fetchCallsMessages';
export {
  GET_EMAILS_DOMAINS_BEGIN,
  GET_EMAILS_DOMAINS_SUCCESS,
  GET_EMAILS_DOMAINS_FAIL,
  POST_NEW_EMAILS_DOMAINS_BEGIN,
  POST_NEW_EMAILS_DOMAINS_SUCCESS,
  POST_NEW_EMAILS_DOMAINS_FAIL,
  POST_DELETE_EMAILS_DOMAINS_BEGIN,
  POST_DELETE_EMAILS_DOMAINS_SUCCESS,
  POST_DELETE_EMAILS_DOMAINS_FAIL,
  POST_EDIT_EMAILS_DOMAINS_BEGIN,
  POST_EDIT_EMAILS_DOMAINS_SUCCESS,
  POST_EDIT_EMAILS_DOMAINS_FAIL,
  POST_EDIT_ALL_DOMAINS_BEGIN,
  POST_EDIT_ALL_DOMAINS_SUCCESS,
  POST_EDIT_ALL_DOMAINS_FAIL
  } from "./fetchEmailsDomains";
export {
    GET_SERVICES_BEGIN,
    GET_SERVICES_SUCCESS,
    GET_SERVICES_FAIL,
    POST_SERVICES_BEGIN,
    POST_SERVICES_SUCCESS,
    POST_SERVICES_FAIL,
    getServices,
    postServices
  } from "./fetchServices";