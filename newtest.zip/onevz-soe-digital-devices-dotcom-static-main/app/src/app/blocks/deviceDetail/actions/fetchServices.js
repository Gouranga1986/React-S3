import apiUrl from '../../../../shared/utilities/apiUrl';
import { getHttpClientRequest, postHttpClientRequest } from '../../../../shared/services/httpClient';


export const GET_SERVICES_BEGIN = "services/GET_SERVICES_BEGIN";
export const GET_SERVICES_SUCCESS = "services/GET_SERVICES_SUCCESS";
export const GET_SERVICES_FAIL = "services/GET_SERVICES_FAIL";

export const POST_SERVICES_BEGIN = "confirmServices/POST_SERVICES_BEGIN";
export const POST_SERVICES_SUCCESS = "confirmServices/POST_SERVICES_SUCCESS";
export const POST_SERVICES_FAIL = "confirmServices/POST_SERVICES_FAIL";

//export const API_EMAILS_DOMAINS_URL = reactGlobals.editBlockEmailDomains;

export const getServices = (encryptedMtn) => async dispatch => {
    dispatch(getServicesBegin())
    const onSuccess = (resp) => {
      if (
        resp &&
        resp.data &&
        resp.data.responseInfo &&
        resp.data.responseInfo.responseCode == "00"
      ) {
        dispatch(getServicesSuccess(resp.data));
      } else {
        dispatch(getServicesFail(resp.data));
      }
    };
  
    const onError = error => {
      // below code is for redirecting to unauthorised screen for member account
      
        dispatch(getServicesFail(error));
      
    };
  
    const callMS = () => {
      let axConfig = {
        headers: {
          flowName:'Blocks',
          contentType: 'application/json',
          // pageName: 'dsrDeviceLanding',
          // flowName: 'Device',
        },
      }
      return getHttpClientRequest(apiUrl().blockServiceV2+'?mdn='+encryptedMtn, axConfig)}
    callMS()
      .then(msResp => {
        console.log(msResp, 'msResp')
        if (msResp && msResp.status == 200) {
          onSuccess(msResp);
        }
      })
      .catch(onError);
      }
  export const getServicesBegin = () => ({
    type: GET_SERVICES_BEGIN
  })
  
  export const getServicesSuccess = (response) => (
    {
    type: GET_SERVICES_SUCCESS,
    services: response.body.sections[0].sections[0].data.serviceDetailsMap,
    serviceStatus: response
    
  })
  export const getServicesFail = (response) => ({
    type: GET_SERVICES_FAIL,
    failServices: response.body
  })
  export const postServices = (payload) => async dispatch => {
    dispatch(postServicesBegin())
    const onSuccess = (resp) => {
      
      if (
        resp &&
        resp.data &&
        resp.data.responseInfo &&
        resp.data.responseInfo.responseCode == "00"
      ) {
          dispatch(postServicesSuccess(resp.data));
      } else {
        dispatch(postServicesFail(resp.data.libErrorInfo));
      }
    };
  
    const onError = error => {
      // below code is for redirecting to unauthorised screen for member account
      let msResp = error && error.response && error.response.data;
      let responseCode = msResp && msResp.responseInfo && msResp.responseInfo.responseCode;
      let responseMessage = msResp && msResp.responseInfo && msResp.responseInfo.responseMessage;
      if (responseCode == "401" && responseMessage.includes("mobileSecure")) {
        window.location.href = apiUrl().mvoLimitedAccessUrl;
      }
      else {
        dispatch(postServicesFail(error));
      }
    };
  
    const callMS = () => {
      let axConfig = {
        headers: {
          flowName:'Blocks',
          contentType: 'application/json',
          // pageName: 'dsrDeviceLanding',
          // flowName: 'Device',
        },
      }
      if (apiUrl().updateService?.indexOf('ApiData') > -1) {
        return getHttpClientRequest(
          apiUrl().updateService,
          axConfig
        ) 
      } 
      else {
        return postHttpClientRequest(
          apiUrl().updateService,
          payload,
          axConfig
        );}
    }
  
    callMS()
      .then(msResp => {
        if (msResp && (msResp.status == 200 )) {
          onSuccess(msResp);
        }
      })
      .catch(onError);
  }

  export const postServicesBegin = () => ({
    type: POST_SERVICES_BEGIN
  })
  
  export const postServicesSuccess = (response) => (
    {
    type: POST_SERVICES_SUCCESS,
    confirmServices: response,
    
  })
  export const postServicesFail = (response) => (
    {
    type: POST_SERVICES_FAIL,
    servicesError: response
  })
  