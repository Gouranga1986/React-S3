import {getHttpClientRequest,postHttpClientRequest } from '@vz/react-util';
import apiUrl from '../../../../shared/utilities/apiUrl';

export const GET_DEVICE_DETAIL_BEGIN = "deviceDetail/GET_DEVICE_DETAIL_BEGIN";
export const GET_DEVICE_DETAIL_SUCCESS = "deviceDetail/GET_DEVICE_DETAIL_SUCCESS";
export const GET_DEVICE_DETAIL_ERROR = "deviceDetail/GET_DEVICE_DETAIL_ERROR";




export const getDeviceDetail = (encryptedMtn) => dispatch => {
  dispatch(getDeviceDetailBegin());
  const onSuccess = (resp) => {
    if (
      resp &&
      resp.data &&
      resp.data.responseInfo &&
      resp.data.responseInfo.responseCode == "00"
    ) {
      
      dispatch(getDeviceDetailSuccess(resp.data));
    } else {
      dispatch(getDeviceDetailError(resp.data));
    }
  };

  const onError = error => {
    // below code is for redirecting to unauthorised screen for member account
    let msResp = error && error.response && error.response.data;
    let responseCode = msResp && msResp.responseInfo && msResp.responseInfo.responseCode;
    let responseMessage = msResp && msResp.responseInfo && msResp.responseInfo.responseMessage;
    if (responseCode == "401" && responseMessage.includes("mobileSecure")) {
      window.location.href = apiUrl().mvoLimitedAccessUrl;
    }
    else {
      dispatch(getDeviceDetailError(error));
    }
  };

  const callMS = () => {
    let axConfig = {
      headers: {
        flowName:'Blocks',
        contentType: 'application/json',
        // pageName: 'dsrDeviceLanding',
        // flowName: 'Device',
      },
    }
    
      return getHttpClientRequest(
        apiUrl().blockDetailsV2+'?mdn='+encryptedMtn,
        axConfig
      )
  }
  callMS()
    .then(msResp => {
      if (msResp && (msResp.status == 200)) {
        onSuccess(msResp);
      }
    })
    .catch(onError);
    
};

export const getDeviceDetailBegin = urlParams => ({
  type: GET_DEVICE_DETAIL_BEGIN,
  urlParams
});

export const getDeviceDetailSuccess = msResp => (
  
  {
  type: GET_DEVICE_DETAIL_SUCCESS,
  msResp
});

export const getDeviceDetailError = err => (
  {
  
  type: GET_DEVICE_DETAIL_ERROR,
  err
});

