import axios from 'axios';
import { cacheHeaders } from '../../../../shared/utilities/commonExp';
import { notifySuccess, notifyError } from "../../../utils/VendorScripts/VendorScripts"
import apiUrl from '../../../../shared/utilities/apiUrl';
import { getHttpClientRequest, postHttpClientRequest } from '../../../../shared/services/httpClient';

export const GET_EMAILS_DOMAINS_BEGIN = "emailsDomains/GET_EMAILS_DOMAINS_BEGIN";
export const GET_EMAILS_DOMAINS_SUCCESS = "emailsDomains/GET_EMAILS_DOMAINS_SUCCESS";
export const GET_EMAILS_DOMAINS_FAIL = "emailDomains/GET_EMAILS_DOMAINS_FAIL";

export const POST_NEW_EMAILS_DOMAINS_BEGIN = "newEmails/POST_NEW_EMAILS_DOMAINS_BEGIN";
export const POST_NEW_EMAILS_DOMAINS_SUCCESS = "newEmails/POST_NEW_EMAILS_DOMAINS_SUCCESS";
export const POST_NEW_EMAILS_DOMAINS_FAIL = "newEmails/POST_NEW_EMAILS_DOMAINS_FAIL";

export const POST_EDIT_EMAILS_DOMAINS_BEGIN = "editEmails/POST_EDIT_EMAILS_DOMAINS_BEGIN";
export const POST_EDIT_EMAILS_DOMAINS_SUCCESS = "editEmails/POST_EDIT_EMAILS_DOMAINS_SUCCESS";
export const POST_EDIT_EMAILS_DOMAINS_FAIL = "editEmails/POST_EDIT_EMAILS_DOMAINS_FAIL";

export const POST_DELETE_EMAILS_DOMAINS_BEGIN = "Emails/POST_DELETE_EMAILS_DOMAINS_BEGIN";
export const POST_DELETE_EMAILS_DOMAINS_SUCCESS = "Emails/POST_DELETE_EMAILS_DOMAINS_SUCCESS";
export const POST_DELETE_EMAILS_DOMAINS_FAIL = "Emails/POST_DELETE_EMAILS_DOMAINS_FAIL";

export const POST_EDIT_ALL_DOMAINS_BEGIN = "editAll/POST_EDIT_ALL_DOMAINS_BEGIN";
export const POST_EDIT_ALL_DOMAINS_SUCCESS = "editAll/POST_EDIT_ALL_DOMAINS_SUCCESS";
export const POST_EDIT_ALL_DOMAINS_FAIL = "editAll/POST_EDIT_ALL_DOMAINS_FAIL";

export const getEmailsDomains = (encryptedMtn) => async dispatch => {
    dispatch(getEmailsDomainsBegin())
    const onSuccess = (resp) => {
      console.log(resp.data,'resp')
      if (
        resp &&
        resp.data &&
        resp.data.responseInfo &&
        resp.data.responseInfo.responseCode == "00"
      ) {
        dispatch(getEmailsDomainsSuccess(resp.data));
      } else {
        dispatch(getEmailsDomainsFail(resp.data));
      }
    };
  
    const onError = error => {
      // below code is for redirecting to unauthorised screen for member account
      let msResp = error && error.response && error.response.data;
      let responseCode = msResp && msResp.responseInfo && msResp.responseInfo.responseCode;
      let responseMessage = msResp && msResp.responseInfo && msResp.responseInfo.responseMessage;
      if (responseCode == "401" && responseMessage.includes("mobileSecure")) {
        window.location.href = apiUrl().mvoLimitedAccessUrl;
      }
      else {
        dispatch(getEmailsDomainsFail(error));
      }
    };
  
    const callMS = () => {
      let axConfig = {
        headers: {
          flowName:'Blocks',
          contentType: 'application/json',
          // pageName: 'dsrDeviceLanding',
          // flowName: 'Device',
        },
      }
      return getHttpClientRequest(apiUrl().emailsDomains+'?mdn='+encryptedMtn, axConfig)
    }
  
    callMS()
      .then(msResp => {
        console.log(msResp, 'msResp')
        if (msResp && msResp.status == 200) {
          onSuccess(msResp);
        }
      })
      .catch((error)=>{console.log("error",error)});
  
  }
  
  export const getEmailsDomainsSuccess = (response) => ({
    type: GET_EMAILS_DOMAINS_SUCCESS,
    emailDomains: response.body,
    blockedSites : response.body.blockedSites,
    remainingCount: response.body.remainingSpamCount
  })
  export const getEmailsDomainsFail = (response) => ({
    type: GET_EMAILS_DOMAINS_FAIL,
    errorMsg: response.body
  })
  
  export const getEmailsDomainsBegin = () => ({
    type: GET_EMAILS_DOMAINS_BEGIN
  })