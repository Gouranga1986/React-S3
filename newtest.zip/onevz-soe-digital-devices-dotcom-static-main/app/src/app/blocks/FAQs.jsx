import React, { Component } from "react";
import PropTypes from "prop-types";
import styled from "styled-components";
import {Tabs,Tab} from "@vds/tabs";
// import Accordion from "./home/Accordion/Accordion";
import { media } from "../utils/VendorScripts/style";
import { Button } from "@vds/buttons";
import {Title,Body} from "@vds/typography"
import { getJsonpAll } from "../numbershare/confirmation/util/http";

import "./style.css";
import { Line } from "@vds/lines";
import { Accordion, AccordionDetail, AccordionHeader, AccordionItem, AccordionSubTitle, AccordionTitle } from "@vds/accordions";

const AccordionComponent = props => {
  let { faqQuestions, activeTabIndex } = props;
  console.log(faqQuestions,'faq');
  if (
    faqQuestions &&
    Object.keys(faqQuestions).length > 0 &&
    faqQuestions[activeTabIndex].length > 0
  ) {
    let filterFaqQuestions = faqQuestions[activeTabIndex].filter(
      faq => !faq.info
    );
    return (
      <React.Fragment>
        {filterFaqQuestions.map((faq, index) => {
          if (faq.question && faq.answer_html) {
            return (
              // <Accordion
              //   key={index}
              //   accordion={{idNum:index}}
              //   anlyticsProps={faq.question.replace(" ", "-")}
              //   title={<a>{faq.question}</a>}
              // >
              //   <p
              //     dangerouslySetInnerHTML={{
              //       __html: faq.answer_html
              //     }}
              //   />
              // </Accordion>
              <Accordion
              topLine={true}
              bottomLine={true} 
            >
              <AccordionItem>
                <AccordionHeader 
                  trigger={{type: "icon"}}
                 >      <AccordionTitle color="#000000">{faq.question}</AccordionTitle>
                </AccordionHeader>
                <AccordionDetail>
                <Body>
                <p
                  dangerouslySetInnerHTML={{
                    __html: faq.answer_html
                  }}
                ></p>
                </Body>
                </AccordionDetail>
              </AccordionItem>
            </Accordion>
            
            );
          }
        })}
      </React.Fragment>
    );
  } else {
    return (
      <NoFaq>
        <div>No Questions Found</div>
      </NoFaq>
    );
  }
};
class FAQs extends Component {
  constructor(props) {
    console.log(props,'props');
    super(props);
    this.state = {
      faqQuestions: {},
      activeTabIndex: 0
    };

    this.handleTabChange = this.handleTabChange.bind(this);
    this.getFaqQuestionsData = this.getFaqQuestionsData.bind(this);
  }

  handleTabChange(e, activeTabIndex) {
    let newFaqQuestions = { ...this.state.faqQuestions };
    let { faqDataSet } = this.props;

    if(faqDataSet.length === 2){
      let faqTab = document.getElementById("faq_tab").className='faq_tab';
       if(activeTabIndex === 1 && faqDataSet){
            if(window.vztag && window.vztag.api && window.vztag.api.dispatch){
              vztag.api.dispatch("openView", {
                name : faqDataSet[activeTabIndex].tabName,
                selector : faqTab+"_"+activeTabIndex
              });
              vztag.api.dispatch("closeView", {
                name : faqDataSet[activeTabIndex-1].tabName,
                selector : faqTab+"_"+activeTabIndex-1
              });
            }
       }else if (activeTabIndex === 0 && faqDataSet ){
        if(window.vztag && window.vztag.api && window.vztag.api.dispatch){
          vztag.api.dispatch("openView", {
            name : faqDataSet[activeTabIndex].tabName,
            selector : faqTab+"_"+activeTabIndex
          });
          vztag.api.dispatch("closeView", {
            name : faqDataSet[activeTabIndex+1].tabName,
            selector : faqTab+"_"+activeTabIndex+1
          });
        }
       }
    }

    if (!newFaqQuestions[activeTabIndex]) {
      this.getFaqQuestionsData(
        faqDataSet[activeTabIndex]?.tagName?.split(","),
        faqDataSet[activeTabIndex].tabUrl,
        activeTabIndex
      );
    } else {
      newFaqQuestions[activeTabIndex] = newFaqQuestions[activeTabIndex];
      this.setState({
        faqQuestions: newFaqQuestions,
        activeTabIndex: activeTabIndex
      });
    }
  }
  
  validateJsonResponse(response) {
    const faqKeys = ["answer", "answer_html", "question", "seo_url"];
    let isValidRes = true;
    for(let res of response) {
      let isAvailable = faqKeys.every(key => key in res);
      if(!isAvailable) {
        isValidRes = false;
        break;
      }
    }
    return isValidRes;
  }
  
  getFaqQuestionsData(tagsData, tagUrl, activeTabIndex) {
    let newFaqQuestions = { ...this.state.faqQuestions };
    let faqList = [];
    tagsData &&
      tagsData.map(tag => {
        faqList.push({
          url: tagUrl ? tagUrl + (tag.tag ? tag.tag : tag) : ""
        });
        return tag;
      });
	  
	   getJsonpAll(faqList)
			  .then(responses => {
				let questions = [];
				for (let response of responses) {
				  if (response && response.status === 200 && response.data && this.validateJsonResponse(response.data)) {
					questions.push(response.data);
				  }
				}
				newFaqQuestions[activeTabIndex] = questions.reduce(
				  (o, m) => m.concat(o),
				  []
				);
				this.setState({
				  faqQuestions: newFaqQuestions,
				  activeTabIndex: activeTabIndex
				});
			  })
			  .catch(error => {
				console.log(error);
			  });
  }

  componentDidMount() {
    let { activeTabIndex } = this.state;
    let { faqDataSet } = this.props;
    this.getFaqQuestionsData(
      faqDataSet[activeTabIndex]?.tagName?.split(","),
      faqDataSet[activeTabIndex].tabUrl,
      activeTabIndex
    );
  }

  allsupportFaq = () => {
    window.location.href = this.props.faqDataSet[
      this.state.activeTabIndex
    ].allFAQUrl;
  };
  
  render() {
    const { faqQuestions, activeTabIndex } = this.state;
    const { faqDataSet } = this.props;
    console.log(faqDataSet[0].tabName)

    return (
      <Container>
        {faqDataSet[0].tabName!=null &&
        <SubContainer>
          <Title size="large" bold={true}>More questions?</Title>
          
          <Title size="small">
          
            Still have questions? Get more answers on our FAQs page.
          </Title>
          <br></br>
          <DTSupportLink>
            <Button
              className="btn vz-odt--btn--secondary"
              analyticstrack="FAQ-view-all-link"
              onClick={this.allsupportFaq}
              role = "link"
              use="secondary"
            >
              All support FAQs
            </Button>
          </DTSupportLink>
        </SubContainer>
  }
        <div style={{ flex: "5" }}>
            <Tabs tabChange={this.handleTabChange} id="faq_tab">
              {faqDataSet.length > 0 &&
                faqDataSet.map(tag => tag.tabName =="Blocks FAQs" &&  (
                  
                    <Tab label={tag.tabName}>

                    <AccordionContainer>
                      <Title>
                      <AccordionComponent
                        faqQuestions={faqQuestions}
                        activeTabIndex={activeTabIndex}
                        />
                      </Title>
                    </AccordionContainer>
                        </Tab>
                ))}
            </Tabs>
            {faqDataSet.length > 0 &&
                faqDataSet.map(tag => tag.tabName !="Blocks FAQs" &&  (
                  
                    
                    <AccordionContainer>
                      <Title>
                      <AccordionComponent
                        faqQuestions={faqQuestions}
                        activeTabIndex={activeTabIndex}
                        />
                      </Title>
                    </AccordionContainer>
                       
                ))}

        </div>
        <MobileSupportLink>
          {/* <Button
            className="btn vz-odt--btn--secondary"
            analyticstrack="FAQ-view-all-link"
            onClick={this.allsupportFaq}
            role = "link"
          >
            All support FAQs
          </Button> */}
        </MobileSupportLink>
      </Container>
    );
  }
}

FAQs.propTypes = {
  handleScrollToElement: PropTypes.func.isRequired,
  tags: PropTypes.array.isRequired,
  tabHeader: PropTypes.array.isRequired,
  allSupportFaq: PropTypes.func,
  faqDataSet: PropTypes.objectOf
};

export default FAQs;

const MobileSupportLink = styled.a`
  display: none !important;
  ${media.mobile`
    display: inline-block !important;
  `}
`;
const SubContainer = styled.div`
  flex: 1;
  padding-right: 35px;
  ${media.mobile`
    padding-right: 0;
  `}
`;
const DTSupportLink = styled.div`
  ${media.mobile`
    display: none !important;
  `}
`;



const NoFaq = styled.div`
  div {
    margin-top: 5rem;
    text-align: center;
  }
`;
const Container = styled.div`
  display: flex;
  padding-top: 25px;
  ${media.mobile`
    display: block;
  `}
  & p {
    font-family: NHaasGroteskDSStd-55Rg;
    margin-bottom: 1.5rem;
  }
  & li {
    font-family: NHaasGroteskDSStd-55Rg;
  }
`;

// const Tabs = styled(VZTabs)`
//   padding: 0 0 10px 0;
//   border: none;
// `;

// const Tab = styled(VZTab)`
//   padding-bottom: 20px;

//   button {
//     font-family: "NeueHaasGroteskDisplayBold", arial;
//     font-size: 18px;
//     padding-bottom: 12px;
//   }
// `;

const H3 = styled.h3`
  font-family: "NeueHaasGroteskDisplayBold", arial;
  font-size: 18px;
  max-width: 95%;
`;

const AccordionContainer = styled.div`
  > div {
    border-top: 1px solid;
  }
`;
