import React, { lazy, Fragment } from 'react'
import { CustomRoute } from './routing/CustomRoute'
import ScrollToTop from './ScrollToTop'
const Home = lazy(() => import('./home/components'))
const DeviceDetail = lazy(() => import('./deviceDetail/components'))

const Routes = ({ reduxStore }) => {
  const routeConfig = (
    <div>
      <ScrollToTop />
      <CustomRoute exact path="/" component={Home} />
      <CustomRoute exact path="/devicedetails/:id" component={DeviceDetail} />
    </div>
  )
  return <Fragment>{routeConfig}</Fragment>
}

export default Routes
