import { combineReducers } from "redux";
import deviceLandingReducer from "./home/reducers";
import deviceDetailReducer from "./deviceDetail/reducers";
import { PURGE, REHYDRATE } from 'redux-persist';

const initialState = {};

export const prodReducer = (state = initialState, actions) => {
  switch (actions.type) {
    default:
      return state;
  }
};

const appReducer = combineReducers({
  Home: deviceLandingReducer,
  Detail: deviceDetailReducer
});

const rootReducer = (state = initialState, action) => {
  if(action.type === REHYDRATE){
  }
  else if(action.type === PURGE){
    sessionStorage.removeItem('persist:root');      
    sessionStorage.clear();    
    state = initialState;      
  }
  return appReducer(state, action);
};

export default rootReducer;
