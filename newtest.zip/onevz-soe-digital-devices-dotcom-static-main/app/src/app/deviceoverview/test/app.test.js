import React from 'react'
import '../../../../config/jest/test-setup'
import App, { createBrowserHistory } from '../app'
import { render } from '@testing-library/react'
import { Provider } from 'react-redux'
import configureStore from '../../../shared/store/configureStore'
import rootReducer from '../reducers'

describe("App", () => {
    const store = configureStore(rootReducer);
    const originalConsoleLog = console.log;
    beforeEach(() => {
        console.log = jest.fn();
    });
    afterEach(() => {
        console.log = originalConsoleLog;
    });
    test("renders app component", () => {
        window.location.hash = "/deviceDetail"
        const { getByTestId } = render(<Provider store={store}><App /></Provider>);
        const appElement = getByTestId("appTestId");
        expect(appElement).toBeTruthy();
    });
    test('should trigger document event listener - OMNI event', async() => {
        vztag?.api.dispatch.mockReset();
        const addEvt = new Event('vztagLoaded');
        document.dispatchEvent(addEvt);
        await expect(vztag?.api.dispatch).toHaveBeenCalledTimes(1);        
    });
    // test("renders session timeout modal", () => {
    //     const { getByTestId } = render(<App />);
    //     const sessionTimeoutModalElement = getByTestId("session-timeout-modal");
    //     expect(sessionTimeoutModalElement).toBeInTheDocument();
    // });
})