import React from "react";
import { act, render, screen, cleanup,waitFor } from "@testing-library/react";
import "@testing-library/jest-dom/extend-expect";
import { BrowserRouter as Router } from 'react-router-dom';
import ScrollToTop from "../ScrollToTop";

window.scrollTo = jest.fn()
describe("ScrollTo Top", () => {
    it("render ", () => {
        render(
            <Router>
                 <div>
                 <ScrollToTop />
                </div>
           </Router>
       )
     });
})
