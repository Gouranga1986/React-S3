import { render } from '@testing-library/react';
import Routes from "./routes";

describe("routes", () => {
 test("click Posts => shows Posts page", async () => {
     const { route } = Routes('reduxStore');
     });
});