import React from "react";
import "../../../../../config/jest/test-setup";
import { act, render, screen, cleanup, fireEvent } from "@testing-library/react";
import "@testing-library/jest-dom/extend-expect";
import { Provider } from "react-redux";
import httpClient, { getHttpClientRequest } from "../../../../shared/services/httpClient";
import configureStore, { history } from "../../../../shared/store/configureStore";
import rootReducer from "../../reducers";
import { persistStore } from 'redux-persist';
import { PersistGate } from 'redux-persist/integration/react';
import DevicesOverview from "../components/index";
import { deviceLanding2 } from "./mockResponse";
import * as getSections from '../actions/getSections';
import * as pageActions from '../actions/pageActions';
import { shallow,configure,mount} from 'enzyme';
import Outage from '../components/outage';
import Adapter from 'enzyme-adapter-react-16';
import {mapStateToProps,mapDispatchToProps} from "../components/index"

const store = configureStore(rootReducer);
const persistor = persistStore(store);

jest.mock("../../../../shared/services/httpClient", () => ({
    ...jest.requireActual("../../../../shared/services/httpClient"),
    getHttpClientRequest: jest.fn()
}));

configure({ adapter: new Adapter() });

describe("<DevicesOverview />", () => {
    reactGlobals.routeLog = { confirmationShown: 'true' }
    global.dotcomConfig = JSON.parse("{\"reactStaticFilePath\":\"\/digital\/nsa\/nos\/devices\/dotcom\/\",\"statusApiUrl\":\"\/digital\/nsa\/secure\/ui\/devices\/suspendreconnect\/status\",\"landingApiUrl\":\"\/digital\/nsa\/secure\/gw\/devices\/suspendreconnect\/landing\",\"networkOutageUrl\":\"\/digital\/nsa\/secure\/gw\/devices\/notification\/network_outage\",\"pendingAcctChangesURL\":\"\/digital\/nsa\/secure\/ui\/acct\/pending-account\",\"pendingAcctChangesCancelOrder\":\"\/digital\/nsa\/secure\/gw\/acct\/pending-account\/pendingAccChangesCancelOrder\",\"pendingAccChanges\":\"\/digital\/nsa\/secure\/gw\/acct\/pending-account\/pendingAccChanges\",\"isPendingDisconnectLink\":\"true\",\"pendingAccChangesFilterByLine\":\"\",\"deviceDetailUrl\":\"\/digital\/nsa\/secure\/gw\/devices\/deviceDetail\",\"getTroubleshootUrl\":\"\/digital\/nsa\/secure\/gw\/troubleshooting\/get-recent-pending-case\",\"getPinAndPukApi\":\"\/digital\/nsa\/secure\/gw\/devices\/pinpuk_details\",\"deviceLandingPageUrl\":\"\/digital\/nsa\/secure\/gw\/devices\/landing\",\"updateNickNameUrl\":\"\/digital\/nsa\/secure\/gw\/devices\/updateNickName\",\"deviceLandingPageRecommendationUrl\":\"\/digital\/nsa\/secure\/gw\/devices\/recommdation\",\"suspendOptionsApiUrl\":\"\/digital\/nsa\/secure\/gw\/devices\/suspendreconnect\/suspend_options\",\"validateSuspendApiUrl\":\"\/digital\/nsa\/secure\/gw\/devices\/suspendreconnect\/validate_suspend\",\"militaryVerificationApiUrl\":\"\/digital\/nsa\/secure\/gw\/devices\/suspendreconnect\/military_verification\",\"saveSuspendApiUrl\":\"\/digital\/nsa\/secure\/gw\/devices\/suspendreconnect\/save_suspend\",\"reconnectOptionsApiUrl\":\"\/digital\/nsa\/secure\/gw\/devices\/suspendreconnect\/reconnect_options\",\"saveReconnectApiUrl\":\"\/digital\/nsa\/secure\/gw\/devices\/suspendreconnect\/save_reconnect\",\"updateReconnectIntentApiUrl\":\"\/digital\/nsa\/secure\/gw\/devices\/suspendreconnect\/update_reconnect_intent\",\"uiLogging\":\"\/digital\/nsa\/nos\/gw\/devices\/suspendreconnect\/clickstream\",\"clickStreamLogging\":\"\/digital\/nsa\/secure\/gw\/devices\/suspendreconnect\/clickstream\",\"suspendFAQsApiUrl\":\"\/support\/spot\/?tag=pause-service-faqs\u0026count=4\u0026intcmp=vzwdom\",\"reconnectFAQsApiUrl\":\"\/support\/spot\/?tag=resume-service-faqs\u0026count=4\u0026intcmp=vzwdom\",\"aemContentApiUrl\":\"\/digital\/nsa\/secure\/gw\/devices\/suspendreconnect\/refresh_aem_content\",\"testApiUrl\":\"\/digital\/nsa\/secure\/gw\/devices\/disconnect\/landing\",\"disconnectLandingApiUrl\":\"\/digital\/nsa\/secure\/gw\/devices\/disconnect\/landing\",\"reviewApiUrl\":\"\/digital\/nsa\/secure\/gw\/devices\/disconnect\/review\",\"cancelReviewApiUrl\":\"\/digital\/nsa\/secure\/gw\/devices\/disconnect\/cancel_review\",\"offerDetailsApiUrl\":\"\/digital\/nsa\/secure\/gw\/devices\/disconnect\/offer_details\",\"offerSelectionApiUrl\":\"\/digital\/nsa\/secure\/gw\/devices\/disconnect\/offer_selection\",\"saveDisconnectApiUrl\":\"\/digital\/nsa\/secure\/gw\/devices\/disconnect\/save_disconnect\",\"mvoLimitedAccessUrl\":\"https:\/\/vzwqa3.verizonwireless.com\/ui\/acct\/unauthorized#\/landing\",\"myVzPage\":\"\",\"suspendLanding\":\"\/digital\/nsa\/secure\/ui\/devices\/suspendreconnect\/#\/\",\"disconnectLanding\":\"\/digital\/nsa\/secure\/ui\/devices\/disconnect\/#\/\",\"zipValidationApiUrl\":\"\/digital\/nsa\/secure\/gw\/devices\/suspendreconnect\/zipcode_validation\",\"validateDeploymentApiUrl\":\"\/digital\/nsa\/secure\/gw\/devices\/suspendreconnect\/validate_deployment\",\"idmeCodeValidationApiUrl\":\"\/digital\/nsa\/secure\/gw\/devices\/suspendreconnect\/idme_code_validation\",\"idMeDenyApiUrl\":\"\/digital\/nsa\/secure\/gw\/devices\/suspendreconnect\/idme_deny\",\"idMeAuthorizationUrl\":\"https:\/\/api.id.me\/oauth\/authorize?client_id=1c69dce1a5bb5c695d7c1b8e43daa811\u0026redirect_uri=https:\/\/vzwqa3.verizonwireless.com\/digital\/nsa\/secure\/ui\/devices\/suspendreconnect\/validate\u0026response_type=code\u0026scope=military_suspend\",\"fiveGBadge\":\"https:\/\/ss7.vzw.com\/is\/image\/VerizonWireless\/5g-logo-d-072822?$pngalpha$\u0026scl=2\",\"cdmaUpgradeUrl\":\"https:\/\/vzwqa3.verizonwireless.com\/shop\/online\/phone-upgrade\/\",\"proActiveNotificationUrl\":\"\/digital\/nsa\/secure\/gw\/devices\/proactive\/notification\",\"callNetworkOutage\":\"true\",\"callProActiveNotifications\":\"true\",\"callRecommendations\":\"true\",\"enableUILogging\":\"true\",\"enableClickStream\":\"true\"}");
    let assignMock = jest.fn();

    delete window.location;
    window.location = { assign: assignMock };
    beforeEach(async () => {
        httpClient.getHttpClientRequest.mockImplementation((url) => {
            return Promise.resolve({ status: 200, data: { ...deviceLanding2 } });
        });

        await act(async () => render(
            <Provider store={store}>
                <PersistGate loading={null} persistor={persistor}>
                    <DevicesOverview />
                </PersistGate>
            </Provider>
        ));

    })

    test("it should mount", () => {
        const doc = screen.getByTestId("DevicesOverviewTestId");
        expect(doc).toBeInTheDocument();
    });

    test("it should mount", () => {
        jest.setTimeout('10000');
        fireEvent.click(screen.getByTestId("managedeviceCtaTestId-1"));
    });
    test("it should have radio option and clickable", () => {
        fireEvent.click(screen.getAllByText("right-arrow icon")[0]);
        expect(screen.getAllByText("right-arrow icon")[0]).toBeInTheDocument();
    });
})