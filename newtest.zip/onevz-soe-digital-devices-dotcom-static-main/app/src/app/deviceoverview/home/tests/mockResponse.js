export const deviceLanding = {
    "responseInfo": {
        "timeStamp": "06-07-2023 08:25:50",
        "correlationId": "adaebc2e-2303-44fd-9af1-3151ffadeca6-22046408",
        "responseCode": "00",
        "responseMessage": "SUCCESS",
        "sectionErrors": []
    },
    "body": {
        "sections": [
            {
                "sectionIndex": "0",
                "sectionId": "devicesLandingMainSection",
                "sectionType": "devicesLandingMainSection",
                "sectionComponentId": "GenericComponent",
                "sections": [
                    {
                        "sectionIndex": "0",
                        "sectionId": "devicesLandingPageSection",
                        "sectionType": "devicesSection",
                        "actions": [
                            {
                                "actionType": "http",
                                "actionValue": "https://vzwqa3.verizonwireless.com/ui/hub/secure/routermgmt?t=",
                                "actionKey": "checkNetworkCompatibiltyAction",
                                "clickStream": "Check Network Compatibilty"
                            },
                            {
                                "actionType": "redirect",
                                "actionValue": "https://www.verizon.com/coverage-map/",
                                "actionKey": "review5gCoverageAction",
                                "clickStream": "review-5g-coverage-cta"
                            },
                            {
                                "actionType": "route",
                                "actionValue": "/deviceDetail",
                                "actionKey": "manageDeviceAction",
                                "clickStream": "manage-device-cta"
                            },
                            {
                                "actionType": "redirect",
                                "actionValue": "https://vzwqa2.verizonwireless.com/smartphones/?flow=AAL",
                                "actionKey": "addALineAction",
                                "clickStream": "add-a-line-cta"
                            },
                            {
                                "actionType": "redirect",
                                "actionValue": "https://vzwqa2.verizonwireless.com/products/",
                                "actionKey": "getAccessoriesAction",
                                "clickStream": "get-accessories-for-your-device-cta"
                            },
                            {
                                "actionType": "redirect",
                                "actionValue": "https://vzwqa2.verizonwireless.com/devices/",
                                "actionKey": "shopADevicetAction",
                                "clickStream": "shop-a-device-cta"
                            },
                            {
                                "actionType": "redirect",
                                "actionValue": "https://vzwqa2.verizonwireless.com/sales/as/home.html",
                                "actionKey": "activateDeviceAction",
                                "clickStream": "activate-your-device-cta"
                            },
                            {
                                "actionType": "redirect",
                                "actionValue": "https://vzwqa2.verizonwireless.com/digital/nsa/secure/ui/cpc/#/",
                                "actionKey": "managePlanAction",
                                "clickStream": "manage-plan-cta"
                            },
                            {
                                "actionType": "redirect",
                                "actionValue": "https://vzwqa2.verizonwireless.com/sales/as/home.html",
                                "actionKey": "bringDeviceAction",
                                "clickStream": "bring-your-device-cta"
                            },
                            {
                                "actionType": "redirect",
                                "actionValue": "https://vzwqa2.verizonwireless.com/ui/hub/secure/routermgmt?t=",
                                "actionKey": "manageRouterAction",
                                "clickStream": "manage-router-cta"
                            },
                            {
                                "actionType": "redirect",
                                "actionValue": "https://vzwqa2.verizonwireless.com/sales/digital/mdnselection.html?flow=EUP&amLogin=true&t=",
                                "actionKey": "upgradeDeviceAction",
                                "clickStream": "upgrade-device-cta"
                            }
                        ],
                        "contents": [
                            {
                                "contentIndex": "0",
                                "items": [
                                    {
                                        "itemKey": "checkNetworkCompatibiltyText",
                                        "itemType": "text",
                                        "itemValue": "Check Network Compatibilty",
                                        "itemAttributes": {},
                                        "actionKey": "checkNetworkCompatibiltyAction"
                                    },
                                    {
                                        "itemKey": "headerText",
                                        "itemType": "text",
                                        "itemValue": "Keep tabs on your devices here.",
                                        "itemAttributes": {}
                                    },
                                    {
                                        "itemKey": "subHeaderText",
                                        "itemType": "text",
                                        "itemValue": "You can easily manage, upgrade, pay off or add a line at anytime.",
                                        "itemAttributes": {}
                                    },
                                    {
                                        "itemKey": "myDevicesHeader",
                                        "itemType": "text",
                                        "itemValue": "My devices",
                                        "itemAttributes": {}
                                    },
                                    {
                                        "itemKey": "relatedTopicsHeader",
                                        "itemType": "text",
                                        "itemValue": "Related topics",
                                        "dataKey": "deviceDetails",
                                        "itemAttributes": {}
                                    },
                                    {
                                        "itemKey": "eligibleforUpgrade",
                                        "itemType": "text",
                                        "itemValue": "Eligible for upgrade",
                                        "itemAttributes": {}
                                    },
                                    {
                                        "itemKey": "manageDeviceBtn",
                                        "itemType": "button",
                                        "itemValue": "Manage ",
                                        "itemAttributes": {},
                                        "actionKey": "manageDeviceAction"
                                    },
                                    {
                                        "itemKey": "addALineBtn",
                                        "itemType": "button",
                                        "itemValue": "Add a line",
                                        "itemAttributes": {},
                                        "actionKey": "addALineAction"
                                    },
                                    {
                                        "itemKey": "getAccessoriesBtn",
                                        "itemType": "button",
                                        "itemValue": "Get accessories for your devices",
                                        "itemAttributes": {},
                                        "actionKey": "getAccessoriesAction"
                                    },
                                    {
                                        "itemKey": "shopADevicetBtn",
                                        "itemType": "button",
                                        "itemValue": "Shop a device",
                                        "itemAttributes": {},
                                        "actionKey": "shopADevicetAction"
                                    },
                                    {
                                        "itemKey": "managePlanBtn",
                                        "itemType": "button",
                                        "itemValue": "Manage plan",
                                        "itemAttributes": {},
                                        "actionKey": "managePlanAction"
                                    },
                                    {
                                        "itemKey": "bringDeviceBtn",
                                        "itemType": "button",
                                        "itemValue": "Bring your own device",
                                        "itemAttributes": {},
                                        "actionKey": "bringDeviceAction"
                                    },
                                    {
                                        "itemKey": "activateDeviceBtn",
                                        "itemType": "button",
                                        "itemValue": "Activate your own devices",
                                        "itemAttributes": {},
                                        "actionKey": "activateDeviceAction"
                                    },
                                    {
                                        "itemKey": "review5gCoverageBtn",
                                        "itemType": "button",
                                        "itemValue": "Review 5G Coverage Map",
                                        "itemAttributes": {},
                                        "actionKey": "review5gCoverageAction"
                                    },
                                    {
                                        "itemKey": "upgradeDeviceBtn",
                                        "itemType": "button",
                                        "itemValue": "Upgrade",
                                        "itemAttributes": {},
                                        "actionKey": "upgradeDeviceAction"
                                    },
                                    {
                                        "itemKey": "remainingBalanceText",
                                        "itemType": "text",
                                        "itemValue": "Remaining balance of $",
                                        "itemAttributes": {}
                                    },
                                    {
                                        "itemKey": "manageNumberShareBtn",
                                        "itemType": "button",
                                        "itemValue": "Manage number share",
                                        "itemAttributes": {},
                                        "actionKey": "manageConnectedDevicesAction"
                                    },
                                    {
                                        "itemKey": "pendingLineChangeText",
                                        "itemType": "text",
                                        "itemValue": "Pending Line Changes",
                                        "itemAttributes": {}
                                    },
                                    {
                                        "itemKey": "deviceSuspended",
                                        "itemType": "text",
                                        "itemValue": "Suspended",
                                        "itemAttributes": {}
                                    }
                                ]
                            }
                        ],
                        "data": {
                            "mobileDeviceList": [
                                {
                                    "mtn": "5852784543",
                                    "displayMtn": "585-278-4543",
                                    "networkBandwidthType": "",
                                    "encryptedMtnAES": "7NHQYDKdAAyxQjhdlQNmWErXdyFuojxne0iEq+xPBMg=",
                                    "encryptedMtnDES": "KPuTPTmdngfU7W%2F1ABTyUw%3D%3D",
                                    "mtnStatus": "A",
                                    "deviceName": "KYLE JONES KYLE JONES KYLE JONES KYLE JONES KYLE JONES KYLE JONES KYLE JONES KYLE JONES",
                                    "userRole": "Member",
                                    "device4G": false,
                                    "device5GE": true,
                                    "device5GA": false,
                                    "smartPhone": true,
                                    "basicPhone": false,
                                    "displayDeviceCategory": "5G Smartphone",
                                    "suspendedWithBilling": false,
                                    "suspendedWithoutBilling": false,
                                    "hasPendingOrder": false,
                                    "isMtnSuspended": false,
                                    "isSuspendResumed": false,
                                    "deviceId": "350686130954177",
                                    "hasPayOffBalance": false,
                                    "fiveGCapable": false,
                                    "cdmaRestricted": false,
                                    "dataOnlyCapableDevice": false,
                                    "upgradeEligible": true,
                                    "images": {
                                        "defaultImage": "https://ss7.vzw.com/is/image/VerizonWireless/02-samsung-palette-gray",
                                        "largeImage": "https://ss7.vzw.com/is/image/VerizonWireless/02-samsung-palette-gray?$device-lg$",
                                        "mediumImage": "https://ss7.vzw.com/is/image/VerizonWireless/02-samsung-palette-gray?$device-med$",
                                        "miniImage": "https://ss7.vzw.com/is/image/VerizonWireless/02-samsung-palette-gray?$device-mini$",
                                        "thumbImage": "https://ss7.vzw.com/is/image/VerizonWireless/02-samsung-palette-gray?$device-thumb$"
                                    },
                                    "router": false,
                                    "isRouter": false,
                                    "isOutstandingBalance": false,
                                    "checkNetworkCompatibiltyText": true,
                                    "pendingLineChange": false,
                                    "deviceCategory": "phone",
                                    "networkExtender": false,
                                    "skuId": "SMG991UZAV",
                                    "hasNumberShare": false,
                                    "secondMtn": "",
                                    "isSecondNumber": false,
                                    "pearlTrialFlow": false,
                                    "simFreezeInfo": {
                                        "simFreezeCode": "N",
                                        "simUnfreezeTimeStamp": "",
                                        "simFreezeDuration": "15",
                                        "isBlocked": "N",
                                        "simFreezeDetails": "QQ"
                                    }
                                },
                                {
                                    "mtn": "2144707276",
                                    "displayMtn": "214.470.7276",
                                    "encryptedMtn": "cDjyZEEksSgNAq0hbkE33g==",
                                    "mtnStatus": "A",
                                    "deviceName": "JACK WRIGHT",
                                    "userRole": "Manager",
                                    "device4G": false,
                                    "device5GE": false,
                                    "device5GA": false,
                                    "smartPhone": true,
                                    "basicPhone": false,
                                    "displayDeviceCategory": "5G Smartphone",
                                    "suspendedWithBilling": false,
                                    "suspendedWithoutBilling": false,
                                    "hasPendingOrder": false,
                                    "isMtnSuspended": true,
                                    "isSuspendResumed": false,
                                    "deviceId": "355502294318155",
                                    "hasPayOffBalance": false,
                                    "fiveGCapable": false,
                                    "cdmaRestricted": false,
                                    "dataOnlyCapableDevice": false,
                                    "upgradeEligible": true,
                                    "images": {
                                        "defaultImage": "https://ss7.vzw.com/is/image/VerizonWireless/samsung-flagship-smartphone-palette-p3-black-128gb-smg998uzkv",
                                        "largeImage": "https://ss7.vzw.com/is/image/VerizonWireless/samsung-flagship-smartphone-palette-p3-black-128gb-smg998uzkv?$device-lg$",
                                        "mediumImage": "https://ss7.vzw.com/is/image/VerizonWireless/samsung-flagship-smartphone-palette-p3-black-128gb-smg998uzkv?$device-med$",
                                        "miniImage": "https://ss7.vzw.com/is/image/VerizonWireless/samsung-flagship-smartphone-palette-p3-black-128gb-smg998uzkv?$device-mini$",
                                        "thumbImage": "https://ss7.vzw.com/is/image/VerizonWireless/samsung-flagship-smartphone-palette-p3-black-128gb-smg998uzkv?$device-thumb$"
                                    },
                                    "router": false,
                                    "isOutstandingBalance": false,
                                    "pendingLineChange": false,
                                    "networkExtender": true
                                },
                                {
                                    "mtn": "2146058791",
                                    "displayMtn": "214.605.8791",
                                    "encryptedMtn": "h329v2lA/x0Nhpe5k3v8Vw==",
                                    "mtnStatus": "A",
                                    "deviceName": "JACK WRIGHT",
                                    "userRole": "Non Registered",
                                    "device4G": false,
                                    "device5GE": false,
                                    "device5GA": false,
                                    "smartPhone": false,
                                    "basicPhone": false,
                                    "displayDeviceCategory": "4G Tablet",
                                    "suspendedWithBilling": false,
                                    "suspendedWithoutBilling": false,
                                    "hasPendingOrder": false,
                                    "isMtnSuspended": false,
                                    "isSuspendResumed": false,
                                    "deviceId": "357166093274932",
                                    "hasPayOffBalance": false,
                                    "fiveGCapable": false,
                                    "cdmaRestricted": false,
                                    "dataOnlyCapableDevice": false,
                                    "upgradeEligible": true,
                                    "images": {
                                        "defaultImage": "https://ss7.vzw.com/is/image/VerizonWireless/Samsung_Galaxy_Tab_A8_Device",
                                        "largeImage": "https://ss7.vzw.com/is/image/VerizonWireless/Samsung_Galaxy_Tab_A8_Device?$device-lg$",
                                        "mediumImage": "https://ss7.vzw.com/is/image/VerizonWireless/Samsung_Galaxy_Tab_A8_Device?$device-med$",
                                        "miniImage": "https://ss7.vzw.com/is/image/VerizonWireless/Samsung_Galaxy_Tab_A8_Device?$device-mini$",
                                        "thumbImage": "https://ss7.vzw.com/is/image/VerizonWireless/Samsung_Galaxy_Tab_A8_Device?$device-thumb$"
                                    },
                                    "router": false,
                                    "isOutstandingBalance": false,
                                    "pendingLineChange": true
                                },
                                {
                                    "mtn": "2146621694",
                                    "displayMtn": "214.662.1694",
                                    "encryptedMtn": "enQJLe0Hux1ZBDJxKvLZ5w==",
                                    "mtnStatus": "A",
                                    "deviceName": "JACK WRIGHT",
                                    "userRole": "Non Registered",
                                    "device4G": false,
                                    "device5GE": false,
                                    "device5GA": false,
                                    "smartPhone": true,
                                    "basicPhone": false,
                                    "displayDeviceCategory": "4G Smartphone",
                                    "suspendedWithBilling": false,
                                    "suspendedWithoutBilling": false,
                                    "hasPendingOrder": false,
                                    "isMtnSuspended": false,
                                    "isSuspendResumed": false,
                                    "deviceId": "352411091113822",
                                    "hasPayOffBalance": false,
                                    "fiveGCapable": false,
                                    "cdmaRestricted": false,
                                    "dataOnlyCapableDevice": false,
                                    "upgradeEligible": true,
                                    "images": {
                                        "defaultImage": "https://ss7.vzw.com/is/image/VerizonWireless/SAMSUNG_Galaxy_S9_Plus_Black",
                                        "largeImage": "https://ss7.vzw.com/is/image/VerizonWireless/SAMSUNG_Galaxy_S9_Plus_Black?$device-lg$",
                                        "mediumImage": "https://ss7.vzw.com/is/image/VerizonWireless/SAMSUNG_Galaxy_S9_Plus_Black?$device-med$",
                                        "miniImage": "https://ss7.vzw.com/is/image/VerizonWireless/SAMSUNG_Galaxy_S9_Plus_Black?$device-mini$",
                                        "thumbImage": "https://ss7.vzw.com/is/image/VerizonWireless/SAMSUNG_Galaxy_S9_Plus_Black?$device-thumb$"
                                    },
                                    "router": false,
                                    "isOutstandingBalance": false,
                                    "pendingLineChange": true
                                },
                                {
                                    "mtn": "2146625673",
                                    "displayMtn": "214.662.5673",
                                    "encryptedMtn": "Xb1Y1B3rQ/EqZXoHhch+kA==",
                                    "mtnStatus": "A",
                                    "deviceName": "JACK WRIGHT",
                                    "userRole": "Non Registered",
                                    "device4G": false,
                                    "device5GE": false,
                                    "device5GA": false,
                                    "smartPhone": true,
                                    "basicPhone": false,
                                    "displayDeviceCategory": "4G Smartphone",
                                    "suspendedWithBilling": false,
                                    "suspendedWithoutBilling": false,
                                    "hasPendingOrder": false,
                                    "isMtnSuspended": false,
                                    "isSuspendResumed": false,
                                    "deviceId": "359032080047798",
                                    "hasPayOffBalance": false,
                                    "fiveGCapable": false,
                                    "cdmaRestricted": false,
                                    "dataOnlyCapableDevice": false,
                                    "upgradeEligible": true,
                                    "images": {
                                        "defaultImage": "https://ss7.vzw.com/is/image/VerizonWireless/Samsung_Galaxy_S8_Black",
                                        "largeImage": "https://ss7.vzw.com/is/image/VerizonWireless/Samsung_Galaxy_S8_Black?$device-lg$",
                                        "mediumImage": "https://ss7.vzw.com/is/image/VerizonWireless/Samsung_Galaxy_S8_Black?$device-med$",
                                        "miniImage": "https://ss7.vzw.com/is/image/VerizonWireless/Samsung_Galaxy_S8_Black?$device-mini$",
                                        "thumbImage": "https://ss7.vzw.com/is/image/VerizonWireless/Samsung_Galaxy_S8_Black?$device-thumb$"
                                    },
                                    "router": false,
                                    "isOutstandingBalance": false,
                                    "pendingLineChange": false
                                },
                                {
                                    "mtn": "2147245483",
                                    "displayMtn": "214.724.5483",
                                    "encryptedMtn": "D9J7E+q9W3la1WMJeAZIWw==",
                                    "mtnStatus": "A",
                                    "deviceName": "JACK WRIGHT",
                                    "userRole": "Non Registered",
                                    "device4G": false,
                                    "device5GE": false,
                                    "device5GA": false,
                                    "smartPhone": true,
                                    "basicPhone": false,
                                    "displayDeviceCategory": "5G Smartphone",
                                    "suspendedWithBilling": false,
                                    "suspendedWithoutBilling": false,
                                    "hasPendingOrder": false,
                                    "isMtnSuspended": false,
                                    "isSuspendResumed": false,
                                    "deviceId": "355901944039270",
                                    "hasPayOffBalance": false,
                                    "fiveGCapable": false,
                                    "cdmaRestricted": false,
                                    "dataOnlyCapableDevice": false,
                                    "upgradeEligible": true,
                                    "images": {
                                        "defaultImage": "https://ss7.vzw.com/is/image/VerizonWireless/iphone-14-pro-max-deep-purple-fall22-a",
                                        "largeImage": "https://ss7.vzw.com/is/image/VerizonWireless/iphone-14-pro-max-deep-purple-fall22-a?$device-lg$",
                                        "mediumImage": "https://ss7.vzw.com/is/image/VerizonWireless/iphone-14-pro-max-deep-purple-fall22-a?$device-med$",
                                        "miniImage": "https://ss7.vzw.com/is/image/VerizonWireless/iphone-14-pro-max-deep-purple-fall22-a?$device-mini$",
                                        "thumbImage": "https://ss7.vzw.com/is/image/VerizonWireless/iphone-14-pro-max-deep-purple-fall22-a?$device-thumb$"
                                    },
                                    "router": false,
                                    "isOutstandingBalance": false,
                                    "pendingLineChange": false
                                },
                                {
                                    "mtn": "2149306540",
                                    "displayMtn": "214.930.6540",
                                    "encryptedMtn": "BE5aH0OpmfD9UxAxeb00HA==",
                                    "mtnStatus": "A",
                                    "deviceName": "JACK WRIGHT",
                                    "userRole": "Manager",
                                    "device4G": false,
                                    "device5GE": false,
                                    "device5GA": false,
                                    "smartPhone": true,
                                    "basicPhone": false,
                                    "displayDeviceCategory": "5G Smartphone",
                                    "suspendedWithBilling": false,
                                    "suspendedWithoutBilling": false,
                                    "hasPendingOrder": false,
                                    "isMtnSuspended": false,
                                    "isSuspendResumed": false,
                                    "deviceId": "356942215646152",
                                    "hasPayOffBalance": false,
                                    "fiveGCapable": false,
                                    "cdmaRestricted": false,
                                    "dataOnlyCapableDevice": false,
                                    "upgradeEligible": true,
                                    "images": {
                                        "defaultImage": "https://ss7.vzw.com/is/image/VerizonWireless/apple-iphone-13-pro-max-sierra-blue",
                                        "largeImage": "https://ss7.vzw.com/is/image/VerizonWireless/apple-iphone-13-pro-max-sierra-blue?$device-lg$",
                                        "mediumImage": "https://ss7.vzw.com/is/image/VerizonWireless/apple-iphone-13-pro-max-sierra-blue?$device-med$",
                                        "miniImage": "https://ss7.vzw.com/is/image/VerizonWireless/apple-iphone-13-pro-max-sierra-blue?$device-mini$",
                                        "thumbImage": "https://ss7.vzw.com/is/image/VerizonWireless/apple-iphone-13-pro-max-sierra-blue?$device-thumb$"
                                    },
                                    "router": false,
                                    "isOutstandingBalance": false,
                                    "pendingLineChange": false
                                },
                                {
                                    "mtn": "4697241375",
                                    "displayMtn": "469.724.1375",
                                    "encryptedMtn": "Bl7wzhUadSVPr9UmisypmQ==",
                                    "mtnStatus": "A",
                                    "deviceName": "JACK WRIGHT",
                                    "userRole": "Non Registered",
                                    "device4G": false,
                                    "device5GE": false,
                                    "device5GA": false,
                                    "smartPhone": false,
                                    "basicPhone": false,
                                    "displayDeviceCategory": "5G Router",
                                    "suspendedWithBilling": false,
                                    "suspendedWithoutBilling": false,
                                    "hasPendingOrder": false,
                                    "isMtnSuspended": false,
                                    "isSuspendResumed": false,
                                    "deviceId": "351468742296563",
                                    "hasPayOffBalance": false,
                                    "fiveGCapable": false,
                                    "cdmaRestricted": false,
                                    "dataOnlyCapableDevice": false,
                                    "upgradeEligible": false,
                                    "images": {
                                        "defaultImage": "https://ss7.vzw.com/is/image/VerizonWireless/vzw-internet-gateway-askey-titan-2-router-white-arc-xci55ax",
                                        "largeImage": "https://ss7.vzw.com/is/image/VerizonWireless/vzw-internet-gateway-askey-titan-2-router-white-arc-xci55ax?$device-lg$",
                                        "mediumImage": "https://ss7.vzw.com/is/image/VerizonWireless/vzw-internet-gateway-askey-titan-2-router-white-arc-xci55ax?$device-med$",
                                        "miniImage": "https://ss7.vzw.com/is/image/VerizonWireless/vzw-internet-gateway-askey-titan-2-router-white-arc-xci55ax?$device-mini$",
                                        "thumbImage": "https://ss7.vzw.com/is/image/VerizonWireless/vzw-internet-gateway-askey-titan-2-router-white-arc-xci55ax?$device-thumb$"
                                    },
                                    "router": false,
                                    "isOutstandingBalance": false,
                                    "pendingLineChange": false
                                }
                            ],
                            "fiveGDeviceList": []
                        }
                    }
                ]
            }
        ]
    }
}

export const deviceLanding2 = {
    "responseInfo": {
        "timeStamp": "06-07-2023 08:25:50",
        "correlationId": "adaebc2e-2303-44fd-9af1-3151ffadeca6-22046408",
        "responseCode": "00",
        "responseMessage": "SUCCESS",
        "sectionErrors": []
    },
    "body": {
        "sections": [
            {
                "sectionIndex": "0",
                "sectionId": "devicesLandingMainSection",
                "sectionType": "devicesLandingMainSection",
                "sectionComponentId": "GenericComponent",
                "sections": [
                    {
                        "sectionIndex": "0",
                        "sectionId": "devicesLandingPageSection",
                        "sectionType": "devicesSection",
                        "actions": [
                            {
                                "actionType": "http",
                                "actionValue": "https://vzwqa3.verizonwireless.com/ui/hub/secure/routermgmt?t=",
                                "actionKey": "checkNetworkCompatibiltyAction",
                                "clickStream": "Check Network Compatibilty"
                            },
                            {
                                "actionType": "route",
                                "actionValue": "/deviceDetail",
                                "actionKey": "manageDeviceAction",
                                "clickStream": "manage-device-cta"
                            },
                            {
                                "actionType": "redirect",
                                "actionValue": "https://vzwqa2.verizonwireless.com/sales/digital/mdnselection.html?flow=EUP&amLogin=true&t=",
                                "actionKey": "upgradeDeviceAction",
                                "clickStream": "upgrade-device-cta"
                            }
                        ],
                        "contents": [
                            {
                                "contentIndex": "0",
                                "items": [
                                    {
                                        "itemKey": "checkNetworkCompatibiltyText",
                                        "itemType": "text",
                                        "itemValue": "Check Network Compatibilty",
                                        "itemAttributes": {},
                                        "actionKey": "checkNetworkCompatibiltyAction"
                                    },
                                    {
                                        "itemKey": "headerText",
                                        "itemType": "text",
                                        "itemValue": "Keep tabs on your devices here.",
                                        "itemAttributes": {}
                                    },
                                    {
                                        "itemKey": "manageDeviceBtn",
                                        "itemType": "button",
                                        "itemValue": "Manage ",
                                        "itemAttributes": {},
                                        "actionKey": "manageDeviceAction"
                                    },
                                ]
                            }
                        ],
                        "data": {
                            "checkNetworkCompatibiltyText": true,
                            "mobileDeviceList": [
                                {
                                    "mtn": "2144707276",
                                    "displayMtn": "214.470.7276",
                                    "encryptedMtn": "cDjyZEEksSgNAq0hbkE33g==",
                                    "mtnStatus": "A",
                                    "deviceName": "JACK WRIGHT",
                                    "userRole": "Manager",
                                    "device4G": false,
                                    "device5GE": false,
                                    "device5GA": false,
                                    "smartPhone": true,
                                    "basicPhone": false,
                                    "displayDeviceCategory": "5G Smartphone",
                                    "suspendedWithBilling": false,
                                    "suspendedWithoutBilling": false,
                                    "hasPendingOrder": false,
                                    "isMtnSuspended": true,
                                    "isSuspendResumed": false,
                                    "deviceId": "355502294318155",
                                    "hasPayOffBalance": false,
                                    "fiveGCapable": false,
                                    "cdmaRestricted": false,
                                    "dataOnlyCapableDevice": false,
                                    "upgradeEligible": true,
                                    "images": {
                                        "defaultImage": "https://ss7.vzw.com/is/image/VerizonWireless/samsung-flagship-smartphone-palette-p3-black-128gb-smg998uzkv",
                                        "largeImage": "https://ss7.vzw.com/is/image/VerizonWireless/samsung-flagship-smartphone-palette-p3-black-128gb-smg998uzkv?$device-lg$",
                                        "mediumImage": "https://ss7.vzw.com/is/image/VerizonWireless/samsung-flagship-smartphone-palette-p3-black-128gb-smg998uzkv?$device-med$",
                                        "miniImage": "https://ss7.vzw.com/is/image/VerizonWireless/samsung-flagship-smartphone-palette-p3-black-128gb-smg998uzkv?$device-mini$",
                                        "thumbImage": "https://ss7.vzw.com/is/image/VerizonWireless/samsung-flagship-smartphone-palette-p3-black-128gb-smg998uzkv?$device-thumb$"
                                    },
                                    "router": true,
                                    "isOutstandingBalance": false,
                                    "pendingLineChange": false
                                }
                            ],
                            "fiveGDeviceList": []
                        }
                    }
                ]
            }
        ]
    }
}

export const fiveGDeviceList1 = {
    "responseInfo": {
        "timeStamp": "06-07-2023 08:25:50",
        "correlationId": "adaebc2e-2303-44fd-9af1-3151ffadeca6-22046408",
        "responseCode": "00",
        "responseMessage": "SUCCESS",
        "sectionErrors": []
    },
    "body": {
        "sections": [
            {
                "sectionIndex": "0",
                "sectionId": "devicesLandingMainSection",
                "sectionType": "devicesLandingMainSection",
                "sectionComponentId": "GenericComponent",
                "sections": [
                    {
                        "sectionIndex": "0",
                        "sectionId": "devicesLandingPageSection",
                        "sectionType": "devicesSection",
                        "actions": [
                            {
                                "actionType": "http",
                                "actionValue": "https://vzwqa3.verizonwireless.com/ui/hub/secure/routermgmt?t=",
                                "actionKey": "checkNetworkCompatibiltyAction",
                                "clickStream": "Check Network Compatibilty"
                            },
                            {
                                "actionType": "redirect",
                                "actionValue": "https://www.verizon.com/coverage-map/",
                                "actionKey": "review5gCoverageAction",
                                "clickStream": "review-5g-coverage-cta"
                            },
                            {
                                "actionType": "route",
                                "actionValue": "/deviceDetail",
                                "actionKey": "manageDeviceAction",
                                "clickStream": "manage-device-cta"
                            },
                            {
                                "actionType": "redirect",
                                "actionValue": "https://vzwqa2.verizonwireless.com/smartphones/?flow=AAL",
                                "actionKey": "addALineAction",
                                "clickStream": "add-a-line-cta"
                            },
                            {
                                "actionType": "redirect",
                                "actionValue": "https://vzwqa2.verizonwireless.com/products/",
                                "actionKey": "getAccessoriesAction",
                                "clickStream": "get-accessories-for-your-device-cta"
                            },
                            {
                                "actionType": "redirect",
                                "actionValue": "https://vzwqa2.verizonwireless.com/devices/",
                                "actionKey": "shopADevicetAction",
                                "clickStream": "shop-a-device-cta"
                            },
                            {
                                "actionType": "redirect",
                                "actionValue": "https://vzwqa2.verizonwireless.com/sales/as/home.html",
                                "actionKey": "activateDeviceAction",
                                "clickStream": "activate-your-device-cta"
                            },
                            {
                                "actionType": "redirect",
                                "actionValue": "https://vzwqa2.verizonwireless.com/digital/nsa/secure/ui/cpc/#/",
                                "actionKey": "managePlanAction",
                                "clickStream": "manage-plan-cta"
                            },
                            {
                                "actionType": "redirect",
                                "actionValue": "https://vzwqa2.verizonwireless.com/sales/as/home.html",
                                "actionKey": "bringDeviceAction",
                                "clickStream": "bring-your-device-cta"
                            },
                            {
                                "actionType": "redirect",
                                "actionValue": "https://vzwqa2.verizonwireless.com/ui/hub/secure/routermgmt?t=",
                                "actionKey": "manageRouterAction",
                                "clickStream": "manage-router-cta"
                            },
                            {
                                "actionType": "redirect",
                                "actionValue": "https://vzwqa2.verizonwireless.com/sales/digital/mdnselection.html?flow=EUP&amLogin=true&t=",
                                "actionKey": "upgradeDeviceAction",
                                "clickStream": "upgrade-device-cta"
                            }
                        ],
                        "contents": [
                            {
                                "contentIndex": "0",
                                "items": [
                                    {
                                        "itemKey": "checkNetworkCompatibiltyText",
                                        "itemType": "text",
                                        "itemValue": "Check Network Compatibilty",
                                        "itemAttributes": {},
                                        "actionKey": "checkNetworkCompatibiltyAction"
                                    },
                                    {
                                        "itemKey": "headerText",
                                        "itemType": "text",
                                        "itemValue": "Keep tabs on your devices here.",
                                        "itemAttributes": {}
                                    },
                                    {
                                        "itemKey": "subHeaderText",
                                        "itemType": "text",
                                        "itemValue": "You can easily manage, upgrade, pay off or add a line at anytime.",
                                        "itemAttributes": {}
                                    },
                                    {
                                        "itemKey": "myDevicesHeader",
                                        "itemType": "text",
                                        "itemValue": "My devices",
                                        "itemAttributes": {}
                                    },
                                    {
                                        "itemKey": "relatedTopicsHeader",
                                        "itemType": "text",
                                        "itemValue": "Related topics",
                                        "dataKey": "deviceDetails",
                                        "itemAttributes": {}
                                    },
                                    {
                                        "itemKey": "eligibleforUpgrade",
                                        "itemType": "text",
                                        "itemValue": "Eligible for upgrade",
                                        "itemAttributes": {}
                                    },
                                    {
                                        "itemKey": "manageDeviceBtn",
                                        "itemType": "button",
                                        "itemValue": "Manage ",
                                        "itemAttributes": {},
                                        "actionKey": "manageDeviceAction"
                                    },
                                    {
                                        "itemKey": "addALineBtn",
                                        "itemType": "button",
                                        "itemValue": "Add a line",
                                        "itemAttributes": {},
                                        "actionKey": "addALineAction"
                                    },
                                    {
                                        "itemKey": "getAccessoriesBtn",
                                        "itemType": "button",
                                        "itemValue": "Get accessories for your devices",
                                        "itemAttributes": {},
                                        "actionKey": "getAccessoriesAction"
                                    },
                                    {
                                        "itemKey": "shopADevicetBtn",
                                        "itemType": "button",
                                        "itemValue": "Shop a device",
                                        "itemAttributes": {},
                                        "actionKey": "shopADevicetAction"
                                    },
                                    {
                                        "itemKey": "managePlanBtn",
                                        "itemType": "button",
                                        "itemValue": "Manage plan",
                                        "itemAttributes": {},
                                        "actionKey": "managePlanAction"
                                    },
                                    {
                                        "itemKey": "bringDeviceBtn",
                                        "itemType": "button",
                                        "itemValue": "Bring your own device",
                                        "itemAttributes": {},
                                        "actionKey": "bringDeviceAction"
                                    },
                                    {
                                        "itemKey": "activateDeviceBtn",
                                        "itemType": "button",
                                        "itemValue": "Activate your own devices",
                                        "itemAttributes": {},
                                        "actionKey": "activateDeviceAction"
                                    },
                                    {
                                        "itemKey": "review5gCoverageBtn",
                                        "itemType": "button",
                                        "itemValue": "Review 5G Coverage Map",
                                        "itemAttributes": {},
                                        "actionKey": "review5gCoverageAction"
                                    },
                                    {
                                        "itemKey": "upgradeDeviceBtn",
                                        "itemType": "button",
                                        "itemValue": "Upgrade",
                                        "itemAttributes": {},
                                        "actionKey": "upgradeDeviceAction"
                                    },
                                    {
                                        "itemKey": "remainingBalanceText",
                                        "itemType": "text",
                                        "itemValue": "Remaining balance of $",
                                        "itemAttributes": {}
                                    },
                                    {
                                        "itemKey": "manageNumberShareBtn",
                                        "itemType": "button",
                                        "itemValue": "Manage number share",
                                        "itemAttributes": {},
                                        "actionKey": "manageConnectedDevicesAction"
                                    },
                                    {
                                        "itemKey": "pendingLineChangeText",
                                        "itemType": "text",
                                        "itemValue": "Pending Line Changes",
                                        "itemAttributes": {}
                                    },
                                    {
                                        "itemKey": "deviceSuspended",
                                        "itemType": "text",
                                        "itemValue": "Suspended",
                                        "itemAttributes": {}
                                    }
                                ]
                            }
                        ],
                        "data": {
                            "fiveGDeviceList": [
                                {
                                    "mtn": "2147245483",
                                    "displayMtn": "214.724.5483",
                                    "encryptedMtn": "D9J7E+q9W3la1WMJeAZIWw==",
                                    "mtnStatus": "A",
                                    "deviceName": "JACK WRIGHT",
                                    "userRole": "Non Registered",
                                    "device4G": false,
                                    "device5GE": false,
                                    "device5GA": false,
                                    "smartPhone": true,
                                    "basicPhone": false,
                                    "displayDeviceCategory": "5G Smartphone",
                                    "suspendedWithBilling": false,
                                    "suspendedWithoutBilling": false,
                                    "hasPendingOrder": false,
                                    "isMtnSuspended": false,
                                    "isSuspendResumed": false,
                                    "deviceId": "355901944039270",
                                    "hasPayOffBalance": false,
                                    "fiveGCapable": true,
                                    "cdmaRestricted": false,
                                    "dataOnlyCapableDevice": false,
                                    "upgradeEligible": true,
                                    "images": {
                                        "defaultImage": "https://ss7.vzw.com/is/image/VerizonWireless/iphone-14-pro-max-deep-purple-fall22-a",
                                        "largeImage": "https://ss7.vzw.com/is/image/VerizonWireless/iphone-14-pro-max-deep-purple-fall22-a?$device-lg$",
                                        "mediumImage": "https://ss7.vzw.com/is/image/VerizonWireless/iphone-14-pro-max-deep-purple-fall22-a?$device-med$",
                                        "miniImage": "https://ss7.vzw.com/is/image/VerizonWireless/iphone-14-pro-max-deep-purple-fall22-a?$device-mini$",
                                        "thumbImage": "https://ss7.vzw.com/is/image/VerizonWireless/iphone-14-pro-max-deep-purple-fall22-a?$device-thumb$"
                                    },
                                    "router": false,
                                    "isOutstandingBalance": false,
                                    "pendingLineChange": false
                                },
                            ]
                        }
                    }
                ]
            }
        ]
    }
}

export const deviceLanding3 = {
    "responseInfo": {
        "timeStamp": "06-07-2023 08:25:50",
        "correlationId": "adaebc2e-2303-44fd-9af1-3151ffadeca6-22046408",
        "responseCode": "00",
        "responseMessage": "SUCCESS",
        "sectionErrors": []
    },
    "body": {
        "sections": [
            {
                "sectionIndex": "0",
                "sectionId": "devicesLandingMainSection",
                "sectionType": "devicesLandingMainSection",
                "sectionComponentId": "GenericComponent",
                "sections": [
                    {
                        "sectionIndex": "0",
                        "sectionId": "devicesLandingPageSection",
                        "sectionType": "devicesSection",
                        "actions": [
                            {
                                "actionType": "http",
                                "actionValue": "https://vzwqa3.verizonwireless.com/ui/hub/secure/routermgmt?t=",
                                "actionKey": "checkNetworkCompatibiltyAction",
                                "clickStream": "Check Network Compatibilty"
                            },
                            {
                                "actionType": "route",
                                "actionValue": "/deviceDetail",
                                "actionKey": "manageDeviceAction",
                                "clickStream": "manage-device-cta"
                            },
                            {
                                "actionType": "redirect",
                                "actionValue": "https://vzwqa2.verizonwireless.com/sales/digital/mdnselection.html?flow=EUP&amLogin=true&t=",
                                "actionKey": "upgradeDeviceAction",
                                "clickStream": "upgrade-device-cta"
                            }
                        ],
                        "contents": [
                            {
                                "contentIndex": "0",
                                "items": [
                                    {
                                        "itemKey": "checkNetworkCompatibiltyText",
                                        "itemType": "text",
                                        "itemValue": "Check Network Compatibilty",
                                        "itemAttributes": {},
                                        "actionKey": "checkNetworkCompatibiltyAction"
                                    },
                                    {
                                        "itemKey": "headerText",
                                        "itemType": "text",
                                        "itemValue": "Keep tabs on your devices here.",
                                        "itemAttributes": {}
                                    },
                                    {
                                        "itemKey": "manageDeviceBtn",
                                        "itemType": "button",
                                        "itemValue": "Manage ",
                                        "itemAttributes": {},
                                        "actionKey": "manageDeviceAction"
                                    },
                                ]
                            }
                        ],
                        "data": {
                            "checkNetworkCompatibiltyText": true,
                            "mobileDeviceList": [
                                {
                                    "mtn": "2144707276",
                                    "displayMtn": "214.470.7276",
                                    "encryptedMtn": "cDjyZEEksSgNAq0hbkE33g==",
                                    "mtnStatus": "A",
                                    "deviceName": "JACK WRIGHT",
                                    "userRole": "Manager",
                                    "device4G": false,
                                    "device5GE": false,
                                    "device5GA": false,
                                    "smartPhone": true,
                                    "basicPhone": false,
                                    "displayDeviceCategory": "5G Smartphone",
                                    "suspendedWithBilling": false,
                                    "suspendedWithoutBilling": false,
                                    "hasPendingOrder": false,
                                    "isMtnSuspended": true,
                                    "isSuspendResumed": false,
                                    "deviceId": "355502294318155",
                                    "hasPayOffBalance": false,
                                    "fiveGCapable": false,
                                    "cdmaRestricted": false,
                                    "dataOnlyCapableDevice": false,
                                    "upgradeEligible": true,
                                    "images": {
                                        "defaultImage": "https://ss7.vzw.com/is/image/VerizonWireless/samsung-flagship-smartphone-palette-p3-black-128gb-smg998uzkv",
                                        "largeImage": "https://ss7.vzw.com/is/image/VerizonWireless/samsung-flagship-smartphone-palette-p3-black-128gb-smg998uzkv?$device-lg$",
                                        "mediumImage": "https://ss7.vzw.com/is/image/VerizonWireless/samsung-flagship-smartphone-palette-p3-black-128gb-smg998uzkv?$device-med$",
                                        "miniImage": "https://ss7.vzw.com/is/image/VerizonWireless/samsung-flagship-smartphone-palette-p3-black-128gb-smg998uzkv?$device-mini$",
                                        "thumbImage": "https://ss7.vzw.com/is/image/VerizonWireless/samsung-flagship-smartphone-palette-p3-black-128gb-smg998uzkv?$device-thumb$"
                                    },
                                    "router": false,
                                    "isOutstandingBalance": false,
                                    "pendingLineChange": false,
                                    "networkExtender": true
                                }
                            ],
                            "fiveGDeviceList": []
                        }
                    }
                ]
            }
        ]
    }
}

export const fiveGDeviceList = {
    "responseInfo": {
        "timeStamp": "06-07-2023 08:25:50",
        "correlationId": "adaebc2e-2303-44fd-9af1-3151ffadeca6-22046408",
        "responseCode": "00",
        "responseMessage": "SUCCESS",
        "sectionErrors": []
    },
    "body": {
        "sections": [
            {
                "sectionIndex": "0",
                "sectionId": "devicesLandingMainSection",
                "sectionType": "devicesLandingMainSection",
                "sectionComponentId": "GenericComponent",
                "sections": [
                    {
                        "sectionIndex": "0",
                        "sectionId": "devicesLandingPageSection",
                        "sectionType": "devicesSection",
                        "actions": [
                            {
                                "actionType": "http",
                                "actionValue": "https://vzwqa3.verizonwireless.com/ui/hub/secure/routermgmt?t=",
                                "actionKey": "checkNetworkCompatibiltyAction",
                                "clickStream": "Check Network Compatibilty"
                            },
                            {
                                "actionType": "redirect",
                                "actionValue": "https://www.verizon.com/coverage-map/",
                                "actionKey": "review5gCoverageAction",
                                "clickStream": "review-5g-coverage-cta"
                            },
                            {
                                "actionType": "route",
                                "actionValue": "/deviceDetail",
                                "actionKey": "manageDeviceAction",
                                "clickStream": "manage-device-cta"
                            },
                            {
                                "actionType": "redirect",
                                "actionValue": "https://vzwqa2.verizonwireless.com/smartphones/?flow=AAL",
                                "actionKey": "addALineAction",
                                "clickStream": "add-a-line-cta"
                            },
                            {
                                "actionType": "redirect",
                                "actionValue": "https://vzwqa2.verizonwireless.com/products/",
                                "actionKey": "getAccessoriesAction",
                                "clickStream": "get-accessories-for-your-device-cta"
                            },
                            {
                                "actionType": "redirect",
                                "actionValue": "https://vzwqa2.verizonwireless.com/devices/",
                                "actionKey": "shopADevicetAction",
                                "clickStream": "shop-a-device-cta"
                            },
                            {
                                "actionType": "redirect",
                                "actionValue": "https://vzwqa2.verizonwireless.com/sales/as/home.html",
                                "actionKey": "activateDeviceAction",
                                "clickStream": "activate-your-device-cta"
                            },
                            {
                                "actionType": "redirect",
                                "actionValue": "https://vzwqa2.verizonwireless.com/digital/nsa/secure/ui/cpc/#/",
                                "actionKey": "managePlanAction",
                                "clickStream": "manage-plan-cta"
                            },
                            {
                                "actionType": "redirect",
                                "actionValue": "https://vzwqa2.verizonwireless.com/sales/as/home.html",
                                "actionKey": "bringDeviceAction",
                                "clickStream": "bring-your-device-cta"
                            },
                            {
                                "actionType": "redirect",
                                "actionValue": "https://vzwqa2.verizonwireless.com/ui/hub/secure/routermgmt?t=",
                                "actionKey": "manageRouterAction",
                                "clickStream": "manage-router-cta"
                            },
                            {
                                "actionType": "redirect",
                                "actionValue": "https://vzwqa2.verizonwireless.com/sales/digital/mdnselection.html?flow=EUP&amLogin=true&t=",
                                "actionKey": "upgradeDeviceAction",
                                "clickStream": "upgrade-device-cta"
                            }
                        ],
                        "contents": [
                            {
                                "contentIndex": "0",
                                "items": [
                                    {
                                        "itemKey": "checkNetworkCompatibiltyText",
                                        "itemType": "text",
                                        "itemValue": "Check Network Compatibilty",
                                        "itemAttributes": {},
                                        "actionKey": "checkNetworkCompatibiltyAction"
                                    },
                                    {
                                        "itemKey": "headerText",
                                        "itemType": "text",
                                        "itemValue": "Keep tabs on your devices here.",
                                        "itemAttributes": {}
                                    },
                                    {
                                        "itemKey": "subHeaderText",
                                        "itemType": "text",
                                        "itemValue": "You can easily manage, upgrade, pay off or add a line at anytime.",
                                        "itemAttributes": {}
                                    },
                                    {
                                        "itemKey": "myDevicesHeader",
                                        "itemType": "text",
                                        "itemValue": "My devices",
                                        "itemAttributes": {}
                                    },
                                    {
                                        "itemKey": "relatedTopicsHeader",
                                        "itemType": "text",
                                        "itemValue": "Related topics",
                                        "dataKey": "deviceDetails",
                                        "itemAttributes": {}
                                    },
                                    {
                                        "itemKey": "eligibleforUpgrade",
                                        "itemType": "text",
                                        "itemValue": "Eligible for upgrade",
                                        "itemAttributes": {}
                                    },
                                    {
                                        "itemKey": "manageDeviceBtn",
                                        "itemType": "button",
                                        "itemValue": "Manage ",
                                        "itemAttributes": {},
                                        "actionKey": "manageDeviceAction"
                                    },
                                    {
                                        "itemKey": "addALineBtn",
                                        "itemType": "button",
                                        "itemValue": "Add a line",
                                        "itemAttributes": {},
                                        "actionKey": "addALineAction"
                                    },
                                    {
                                        "itemKey": "getAccessoriesBtn",
                                        "itemType": "button",
                                        "itemValue": "Get accessories for your devices",
                                        "itemAttributes": {},
                                        "actionKey": "getAccessoriesAction"
                                    },
                                    {
                                        "itemKey": "shopADevicetBtn",
                                        "itemType": "button",
                                        "itemValue": "Shop a device",
                                        "itemAttributes": {},
                                        "actionKey": "shopADevicetAction"
                                    },
                                    {
                                        "itemKey": "managePlanBtn",
                                        "itemType": "button",
                                        "itemValue": "Manage plan",
                                        "itemAttributes": {},
                                        "actionKey": "managePlanAction"
                                    },
                                    {
                                        "itemKey": "bringDeviceBtn",
                                        "itemType": "button",
                                        "itemValue": "Bring your own device",
                                        "itemAttributes": {},
                                        "actionKey": "bringDeviceAction"
                                    },
                                    {
                                        "itemKey": "activateDeviceBtn",
                                        "itemType": "button",
                                        "itemValue": "Activate your own devices",
                                        "itemAttributes": {},
                                        "actionKey": "activateDeviceAction"
                                    },
                                    {
                                        "itemKey": "review5gCoverageBtn",
                                        "itemType": "button",
                                        "itemValue": "Review 5G Coverage Map",
                                        "itemAttributes": {},
                                        "actionKey": "review5gCoverageAction"
                                    },
                                    {
                                        "itemKey": "upgradeDeviceBtn",
                                        "itemType": "button",
                                        "itemValue": "Upgrade",
                                        "itemAttributes": {},
                                        "actionKey": "upgradeDeviceAction"
                                    },
                                    {
                                        "itemKey": "remainingBalanceText",
                                        "itemType": "text",
                                        "itemValue": "Remaining balance of $",
                                        "itemAttributes": {}
                                    },
                                    {
                                        "itemKey": "manageNumberShareBtn",
                                        "itemType": "button",
                                        "itemValue": "Manage number share",
                                        "itemAttributes": {},
                                        "actionKey": "manageConnectedDevicesAction"
                                    },
                                    {
                                        "itemKey": "pendingLineChangeText",
                                        "itemType": "text",
                                        "itemValue": "Pending Line Changes",
                                        "itemAttributes": {}
                                    },
                                    {
                                        "itemKey": "deviceSuspended",
                                        "itemType": "text",
                                        "itemValue": "Suspended",
                                        "itemAttributes": {}
                                    }
                                ]
                            }
                        ],
                        "data": {
                            "mobileDeviceList": [],
                            "fiveGDeviceList": [
                                {
                                    "mtn": "2147245483",
                                    "displayMtn": "214.724.5483",
                                    "encryptedMtn": "D9J7E+q9W3la1WMJeAZIWw==",
                                    "mtnStatus": "A",
                                    "deviceName": "JACK WRIGHT",
                                    "userRole": "Non Registered",
                                    "device4G": false,
                                    "device5GE": false,
                                    "device5GA": false,
                                    "smartPhone": true,
                                    "basicPhone": false,
                                    "displayDeviceCategory": "5G Smartphone",
                                    "suspendedWithBilling": false,
                                    "suspendedWithoutBilling": false,
                                    "hasPendingOrder": false,
                                    "isMtnSuspended": false,
                                    "isSuspendResumed": false,
                                    "deviceId": "355901944039270",
                                    "hasPayOffBalance": false,
                                    "fiveGCapable": true,
                                    "cdmaRestricted": false,
                                    "dataOnlyCapableDevice": false,
                                    "upgradeEligible": true,
                                    "images": {
                                        "defaultImage": "https://ss7.vzw.com/is/image/VerizonWireless/iphone-14-pro-max-deep-purple-fall22-a",
                                        "largeImage": "https://ss7.vzw.com/is/image/VerizonWireless/iphone-14-pro-max-deep-purple-fall22-a?$device-lg$",
                                        "mediumImage": "https://ss7.vzw.com/is/image/VerizonWireless/iphone-14-pro-max-deep-purple-fall22-a?$device-med$",
                                        "miniImage": "https://ss7.vzw.com/is/image/VerizonWireless/iphone-14-pro-max-deep-purple-fall22-a?$device-mini$",
                                        "thumbImage": "https://ss7.vzw.com/is/image/VerizonWireless/iphone-14-pro-max-deep-purple-fall22-a?$device-thumb$"
                                    },
                                    "router": false,
                                    "isOutstandingBalance": false,
                                    "pendingLineChange": false
                                },
                            ]
                        }
                    }
                ]
            }
        ]
    }
}

export const mobileDeviceList = {
    "responseInfo": {
        "timeStamp": "06-07-2023 08:25:50",
        "correlationId": "adaebc2e-2303-44fd-9af1-3151ffadeca6-22046408",
        "responseCode": "00",
        "responseMessage": "SUCCESS",
        "sectionErrors": []
    },
    "body": {
        "sections": [
            {
                "sectionIndex": "0",
                "sectionId": "devicesLandingMainSection",
                "sectionType": "devicesLandingMainSection",
                "sectionComponentId": "GenericComponent",
                "sections": [
                    {
                        "sectionIndex": "0",
                        "sectionId": "devicesLandingPageSection",
                        "sectionType": "devicesSection",
                        "actions": [
                            {
                                "actionType": "http",
                                "actionValue": "https://vzwqa3.verizonwireless.com/ui/hub/secure/routermgmt?t=",
                                "actionKey": "checkNetworkCompatibiltyAction",
                                "clickStream": "Check Network Compatibilty"
                            },
                            {
                                "actionType": "route",
                                "actionValue": "/deviceDetail",
                                "actionKey": "manageDeviceAction",
                                "clickStream": "manage-device-cta"
                            },
                            {
                                "actionType": "redirect",
                                "actionValue": "https://vzwqa2.verizonwireless.com/sales/digital/mdnselection.html?flow=EUP&amLogin=true&t=",
                                "actionKey": "upgradeDeviceAction",
                                "clickStream": "upgrade-device-cta"
                            }
                        ],
                        "contents": [
                            {
                                "contentIndex": "0",
                                "items": [
                                    {
                                        "itemKey": "checkNetworkCompatibiltyText",
                                        "itemType": "text",
                                        "itemValue": "Check Network Compatibilty",
                                        "itemAttributes": {},
                                        "actionKey": "checkNetworkCompatibiltyAction"
                                    },
                                    {
                                        "itemKey": "headerText",
                                        "itemType": "text",
                                        "itemValue": "Keep tabs on your devices here.",
                                        "itemAttributes": {}
                                    },
                                    {
                                        "itemKey": "manageDeviceBtn",
                                        "itemType": "button",
                                        "itemValue": "Manage ",
                                        "itemAttributes": {},
                                        "actionKey": "manageDeviceAction"
                                    },
                                ]
                            }
                        ],
                        "data": {
                            "checkNetworkCompatibiltyText": true,
                            "mobileDeviceList": [
                                {
                                    "mtn": "2144707276",
                                    "displayMtn": "214.470.7276",
                                    "encryptedMtn": "cDjyZEEksSgNAq0hbkE33g==",
                                    "mtnStatus": "A",
                                    "deviceName": "JACK WRIGHT",
                                    "userRole": "Manager",
                                    "device4G": false,
                                    "device5GE": false,
                                    "device5GA": false,
                                    "smartPhone": true,
                                    "basicPhone": false,
                                    "displayDeviceCategory": "5G Smartphone",
                                    "suspendedWithBilling": false,
                                    "suspendedWithoutBilling": false,
                                    "hasPendingOrder": false,
                                    "isMtnSuspended": true,
                                    "isSuspendResumed": false,
                                    "deviceId": "355502294318155",
                                    "hasPayOffBalance": false,
                                    "fiveGCapable": false,
                                    "cdmaRestricted": false,
                                    "dataOnlyCapableDevice": false,
                                    "upgradeEligible": true,
                                    "images": {
                                        "defaultImage": "https://ss7.vzw.com/is/image/VerizonWireless/samsung-flagship-smartphone-palette-p3-black-128gb-smg998uzkv",
                                        "largeImage": "https://ss7.vzw.com/is/image/VerizonWireless/samsung-flagship-smartphone-palette-p3-black-128gb-smg998uzkv?$device-lg$",
                                        "mediumImage": "https://ss7.vzw.com/is/image/VerizonWireless/samsung-flagship-smartphone-palette-p3-black-128gb-smg998uzkv?$device-med$",
                                        "miniImage": "https://ss7.vzw.com/is/image/VerizonWireless/samsung-flagship-smartphone-palette-p3-black-128gb-smg998uzkv?$device-mini$",
                                        "thumbImage": "https://ss7.vzw.com/is/image/VerizonWireless/samsung-flagship-smartphone-palette-p3-black-128gb-smg998uzkv?$device-thumb$"
                                    },
                                    "router": false,
                                    "isOutstandingBalance": false,
                                    "pendingLineChange": false,
                                    "networkExtender": true
                                }
                            ],
                        }
                    }
                ]
            }
        ]
    }
}

export const mobileAndfiveGDeviceList = {
    "responseInfo": {
        "timeStamp": "06-07-2023 08:25:50",
        "correlationId": "adaebc2e-2303-44fd-9af1-3151ffadeca6-22046408",
        "responseCode": "00",
        "responseMessage": "SUCCESS",
        "sectionErrors": []
    },
    "body": {
        "sections": [
            {
                "sectionIndex": "0",
                "sectionId": "devicesLandingMainSection",
                "sectionType": "devicesLandingMainSection",
                "sectionComponentId": "GenericComponent",
                "sections": [
                    {
                        "sectionIndex": "0",
                        "sectionId": "devicesLandingPageSection",
                        "sectionType": "devicesSection",
                        "actions": [
                            {
                                "actionType": "http",
                                "actionValue": "https://vzwqa3.verizonwireless.com/ui/hub/secure/routermgmt?t=",
                                "actionKey": "checkNetworkCompatibiltyAction",
                                "clickStream": "Check Network Compatibilty"
                            },
                            {
                                "actionType": "redirect",
                                "actionValue": "https://www.verizon.com/coverage-map/",
                                "actionKey": "review5gCoverageAction",
                                "clickStream": "review-5g-coverage-cta"
                            },
                            {
                                "actionType": "route",
                                "actionValue": "/deviceDetail",
                                "actionKey": "manageDeviceAction",
                                "clickStream": "manage-device-cta"
                            },
                            {
                                "actionType": "redirect",
                                "actionValue": "https://vzwqa2.verizonwireless.com/smartphones/?flow=AAL",
                                "actionKey": "addALineAction",
                                "clickStream": "add-a-line-cta"
                            },
                            {
                                "actionType": "redirect",
                                "actionValue": "https://vzwqa2.verizonwireless.com/products/",
                                "actionKey": "getAccessoriesAction",
                                "clickStream": "get-accessories-for-your-device-cta"
                            },
                            {
                                "actionType": "redirect",
                                "actionValue": "https://vzwqa2.verizonwireless.com/devices/",
                                "actionKey": "shopADevicetAction",
                                "clickStream": "shop-a-device-cta"
                            },
                            {
                                "actionType": "redirect",
                                "actionValue": "https://vzwqa2.verizonwireless.com/sales/as/home.html",
                                "actionKey": "activateDeviceAction",
                                "clickStream": "activate-your-device-cta"
                            },
                            {
                                "actionType": "redirect",
                                "actionValue": "https://vzwqa2.verizonwireless.com/digital/nsa/secure/ui/cpc/#/",
                                "actionKey": "managePlanAction",
                                "clickStream": "manage-plan-cta"
                            },
                            {
                                "actionType": "redirect",
                                "actionValue": "https://vzwqa2.verizonwireless.com/sales/as/home.html",
                                "actionKey": "bringDeviceAction",
                                "clickStream": "bring-your-device-cta"
                            },
                            {
                                "actionType": "redirect",
                                "actionValue": "https://vzwqa2.verizonwireless.com/ui/hub/secure/routermgmt?t=",
                                "actionKey": "manageRouterAction",
                                "clickStream": "manage-router-cta"
                            },
                            {
                                "actionType": "redirect",
                                "actionValue": "https://vzwqa2.verizonwireless.com/sales/digital/mdnselection.html?flow=EUP&amLogin=true&t=",
                                "actionKey": "upgradeDeviceAction",
                                "clickStream": "upgrade-device-cta"
                            }
                        ],
                        "contents": [
                            {
                                "contentIndex": "0",
                                "items": [
                                    {
                                        "itemKey": "checkNetworkCompatibiltyText",
                                        "itemType": "text",
                                        "itemValue": "Check Network Compatibilty",
                                        "itemAttributes": {},
                                        "actionKey": "checkNetworkCompatibiltyAction"
                                    },
                                    {
                                        "itemKey": "headerText",
                                        "itemType": "text",
                                        "itemValue": "Keep tabs on your devices here.",
                                        "itemAttributes": {}
                                    },
                                    {
                                        "itemKey": "subHeaderText",
                                        "itemType": "text",
                                        "itemValue": "You can easily manage, upgrade, pay off or add a line at anytime.",
                                        "itemAttributes": {}
                                    },
                                    {
                                        "itemKey": "myDevicesHeader",
                                        "itemType": "text",
                                        "itemValue": "My devices",
                                        "itemAttributes": {}
                                    },
                                    {
                                        "itemKey": "relatedTopicsHeader",
                                        "itemType": "text",
                                        "itemValue": "Related topics",
                                        "dataKey": "deviceDetails",
                                        "itemAttributes": {}
                                    },
                                    {
                                        "itemKey": "eligibleforUpgrade",
                                        "itemType": "text",
                                        "itemValue": "Eligible for upgrade",
                                        "itemAttributes": {}
                                    },
                                    {
                                        "itemKey": "manageDeviceBtn",
                                        "itemType": "button",
                                        "itemValue": "Manage ",
                                        "itemAttributes": {},
                                        "actionKey": "manageDeviceAction"
                                    },
                                    {
                                        "itemKey": "addALineBtn",
                                        "itemType": "button",
                                        "itemValue": "Add a line",
                                        "itemAttributes": {},
                                        "actionKey": "addALineAction"
                                    },
                                    {
                                        "itemKey": "getAccessoriesBtn",
                                        "itemType": "button",
                                        "itemValue": "Get accessories for your devices",
                                        "itemAttributes": {},
                                        "actionKey": "getAccessoriesAction"
                                    },
                                    {
                                        "itemKey": "shopADevicetBtn",
                                        "itemType": "button",
                                        "itemValue": "Shop a device",
                                        "itemAttributes": {},
                                        "actionKey": "shopADevicetAction"
                                    },
                                    {
                                        "itemKey": "managePlanBtn",
                                        "itemType": "button",
                                        "itemValue": "Manage plan",
                                        "itemAttributes": {},
                                        "actionKey": "managePlanAction"
                                    },
                                    {
                                        "itemKey": "bringDeviceBtn",
                                        "itemType": "button",
                                        "itemValue": "Bring your own device",
                                        "itemAttributes": {},
                                        "actionKey": "bringDeviceAction"
                                    },
                                    {
                                        "itemKey": "activateDeviceBtn",
                                        "itemType": "button",
                                        "itemValue": "Activate your own devices",
                                        "itemAttributes": {},
                                        "actionKey": "activateDeviceAction"
                                    },
                                    {
                                        "itemKey": "review5gCoverageBtn",
                                        "itemType": "button",
                                        "itemValue": "Review 5G Coverage Map",
                                        "itemAttributes": {},
                                        "actionKey": "review5gCoverageAction"
                                    },
                                    {
                                        "itemKey": "upgradeDeviceBtn",
                                        "itemType": "button",
                                        "itemValue": "Upgrade",
                                        "itemAttributes": {},
                                        "actionKey": "upgradeDeviceAction"
                                    },
                                    {
                                        "itemKey": "remainingBalanceText",
                                        "itemType": "text",
                                        "itemValue": "Remaining balance of $",
                                        "itemAttributes": {}
                                    },
                                    {
                                        "itemKey": "manageNumberShareBtn",
                                        "itemType": "button",
                                        "itemValue": "Manage number share",
                                        "itemAttributes": {},
                                        "actionKey": "manageConnectedDevicesAction"
                                    },
                                    {
                                        "itemKey": "pendingLineChangeText",
                                        "itemType": "text",
                                        "itemValue": "Pending Line Changes",
                                        "itemAttributes": {}
                                    },
                                    {
                                        "itemKey": "deviceSuspended",
                                        "itemType": "text",
                                        "itemValue": "Suspended",
                                        "itemAttributes": {}
                                    }
                                ]
                            }
                        ],
                        "data": {
                            "mobileDeviceList": [
                                {
                                    "mtn": "2144707276",
                                    "displayMtn": "214.470.7276",
                                    "encryptedMtn": "cDjyZEEksSgNAq0hbkE33g==",
                                    "mtnStatus": "A",
                                    "deviceName": "JACK WRIGHT",
                                    "userRole": "Manager",
                                    "device4G": false,
                                    "device5GE": false,
                                    "device5GA": false,
                                    "smartPhone": true,
                                    "basicPhone": false,
                                    "displayDeviceCategory": "5G Smartphone",
                                    "suspendedWithBilling": false,
                                    "suspendedWithoutBilling": false,
                                    "hasPendingOrder": false,
                                    "isMtnSuspended": true,
                                    "isSuspendResumed": false,
                                    "deviceId": "355502294318155",
                                    "hasPayOffBalance": false,
                                    "fiveGCapable": false,
                                    "cdmaRestricted": false,
                                    "dataOnlyCapableDevice": false,
                                    "upgradeEligible": true,
                                    "remainingBalance": "4",
                                    "images": {
                                        "defaultImage": "https://ss7.vzw.com/is/image/VerizonWireless/samsung-flagship-smartphone-palette-p3-black-128gb-smg998uzkv",
                                        "largeImage": "https://ss7.vzw.com/is/image/VerizonWireless/samsung-flagship-smartphone-palette-p3-black-128gb-smg998uzkv?$device-lg$",
                                        "mediumImage": "https://ss7.vzw.com/is/image/VerizonWireless/samsung-flagship-smartphone-palette-p3-black-128gb-smg998uzkv?$device-med$",
                                        "miniImage": "https://ss7.vzw.com/is/image/VerizonWireless/samsung-flagship-smartphone-palette-p3-black-128gb-smg998uzkv?$device-mini$",
                                        "thumbImage": "https://ss7.vzw.com/is/image/VerizonWireless/samsung-flagship-smartphone-palette-p3-black-128gb-smg998uzkv?$device-thumb$"
                                    },
                                    "router": true,
                                    "isOutstandingBalance": false,
                                    "pendingLineChange": false
                                }
                            ],
                            "fiveGDeviceList": [
                                {
                                    "mtn": "2147245483",
                                    "displayMtn": "214.724.5483",
                                    "encryptedMtn": "D9J7E+q9W3la1WMJeAZIWw==",
                                    "mtnStatus": "A",
                                    "deviceName": "JACK WRIGHT",
                                    "userRole": "Non Registered",
                                    "device4G": false,
                                    "device5GE": false,
                                    "device5GA": false,
                                    "smartPhone": true,
                                    "basicPhone": false,
                                    "displayDeviceCategory": "5G Smartphone",
                                    "suspendedWithBilling": false,
                                    "suspendedWithoutBilling": false,
                                    "hasPendingOrder": false,
                                    "isMtnSuspended": false,
                                    "isSuspendResumed": false,
                                    "deviceId": "355901944039270",
                                    "hasPayOffBalance": false,
                                    "fiveGCapable": true,
                                    "cdmaRestricted": false,
                                    "dataOnlyCapableDevice": false,
                                    "upgradeEligible": true,
                                    "images": {
                                        "defaultImage": "https://ss7.vzw.com/is/image/VerizonWireless/iphone-14-pro-max-deep-purple-fall22-a",
                                        "largeImage": "https://ss7.vzw.com/is/image/VerizonWireless/iphone-14-pro-max-deep-purple-fall22-a?$device-lg$",
                                        "mediumImage": "https://ss7.vzw.com/is/image/VerizonWireless/iphone-14-pro-max-deep-purple-fall22-a?$device-med$",
                                        "miniImage": "https://ss7.vzw.com/is/image/VerizonWireless/iphone-14-pro-max-deep-purple-fall22-a?$device-mini$",
                                        "thumbImage": "https://ss7.vzw.com/is/image/VerizonWireless/iphone-14-pro-max-deep-purple-fall22-a?$device-thumb$"
                                    },
                                    "router": true,
                                    "isOutstandingBalance": false,
                                    "pendingLineChange": false
                                },
                            ]
                        }
                    }
                ]
            }
        ]
    }
}

export const recommendationMock = {
    "responseInfo": {
        "timeStamp": "16-02-2024 05:20:54",
        "correlationId": "",
        "responseCode": "00",
        "responseMessage": "SUCCESS",
        "sectionErrors": []
    },
    "body": {
        "relatedTopics": [
            {
                "tileHeader": [
                    "Have a question about your plan?"
                ],
                "tiletText": [
                    "Learn how to review your plan and data allowance details, and how to switch to another plan online."
                ],
                "tileCategory": "FAQs",
                "tileLink": "/support/understand-and-change-your-plan-faqs/",
                "pegaCard": {
                    "tileName": "Support Tile",
                    "rank": "2",
                    "cardId": "C102",
                    "propositionId": "LU_22",
                    "soiEngagementId": "501000102",
                    "cardWeight": "120",
                    "subStrategyId": "Plan FAQ (default support)",
                    "strategyId": "Plan Inquiry",
                    "templateId": "MVO_LT_SUP_PLAN_GENERAL",
                    "dispositionListId": "10"
                }
            },
            {
                "tileHeader": [
                    "Get help from other Verizon customers."
                ],
                "tiletText": [
                    "Post a plan or service question and get an answer on our Community forums."
                ],
                "tileCategory": "Community",
                "tileLink": "https://community.verizonwireless.com/verizon-login.jspa?goto=https%3A%2F%2Fcommunity.verizonwireless.com/community/myverizon/plans_and_services",
                "pegaCard": {
                    "tileName": "Support Tile",
                    "rank": "2",
                    "cardId": "C102",
                    "propositionId": "LU_22",
                    "soiEngagementId": "501000102",
                    "cardWeight": "120",
                    "subStrategyId": "Plan FAQ (default support)",
                    "strategyId": "Plan Inquiry",
                    "templateId": "MVO_LT_SUP_PLAN_GENERAL",
                    "dispositionListId": "10"
                }
            }
        ],
        "nbxResponse": {
            "serviceHeader": {
                "clientId": "MVO",
                "statusMsg": "SUCCESS",
                "serviceName": "NBX",
                "statusCode": "0",
                "routeType": "",
                "clientSessionId": "aa6890bb-b0eb-46f8-b3af-54e3cd3d5f46",
                "clientTransactionId": "aa6890bb-b0eb-46f8-b3af-54e3cd3d5f46",
                "timestamp": "2024-02-16 11:50:36 UTC",
                "channelId": "VZW-DOTCOM",
                "sso_jwt": "",
                "nbxTransactionId": "NBX-LSV23768de149194bb8ab0f2dc78d378888-SQA1"
            },
            "serviceBody": {
                "serviceRequest": {
                    "contextInfo": {
                        "callReason": "LiveTiles",
                        "subServiceName": "",
                        "category": "Support",
                        "pageContext": "MVO_Device_Overview_Support",
                        "isLoggedIn": true,
                        "isTestFlagEnabled": false,
                        "platform": "",
                        "propositionCount": "",
                        "deviceType": "Desktop",
                        "nbaCount": "",
                        "orderNumber": "",
                        "loggedInCountryName": "",
                        "locationCode": "",
                        "standaloneAccessory": "",
                        "sessionId": ""
                    },
                    "customerInfo": {
                        "mtn": "7183442407",
                        "accountNo": "0582350358-00001",
                        "customerRole": "accountHolder",
                        "accountRole": "",
                        "customerType": "",
                        "isNewCustomer": ""
                    }
                }
            }
        },
        "sessionId": "1276553987614303756"
    }
}

export const proActiveNoti = {
    "responseInfo": {
        "timeStamp": "15-09-2023 03:58:14",
        "correlationId": "e28b51a8-5b48-46fe-8904-83c1cdc00b84-20424113",
        "responseCode": "00",
        "responseMessage": "SUCCESS",
        "sectionErrors": []
    },
    "body": {
        "controls": {
            "1": "Protect your account from fraudulent access with Two Factor Authentication",
            "2": "vzwi.mvmapp.LinkName:Protect your account from fraudulent access with Two Factor Authentication"
        },
        "cta": [
            {
                "linkHeader": "Manage settings",
                "linkUrl": "https://myvpostpay.verizon.com/ui/acct/secure/profile/security/enhancedauth"
            }
        ],
        "pegaCards": {
            "rank": "1",
            "cardId": "NID48",
            "propositionId": "LA_84",
            "soiEngagementId": "501004395",
            "tacticLocation": "MVO_Device_Overview",
            "ctaReference": "",
            "dispositionOptionId": "81",
            "category": "Alerts",
            "pegaSessionId": "-1399554462368057025"
        }
    }
}

export const networkOutageDetail = {
    "responseInfo": {
        "timeStamp": "15-09-2023 03:58:14",
        "correlationId": "e28b51a8-5b48-46fe-8904-83c1cdc00b84-20424113",
        "responseCode": "00",
        "responseMessage": "SUCCESS",
        "sectionErrors": []
    },
    "body": {
        "controls": {
            "1": "Protect your account from fraudulent access with Two Factor Authentication",
            "2": "vzwi.mvmapp.LinkName:Protect your account from fraudulent access with Two Factor Authentication"
        },
        "data": {
            "detailedMessage": "Protect your account from fraudulent access with Two Factor Authentication"
        }
    }
}

export const deviceLanding4 = {
    "responseInfo": {
        "timeStamp": "21-11-2023 10:52:36",
        "correlationId": "de4eeecc-f974-4466-9fe5-679f901217e5-5674543",
        "responseCode": "00",
        "responseMessage": "SUCCESS",
        "sectionErrors": []
    },
    "body": {
        "pageAttributes": [
            {
                "itemKey": "pageTitle",
                "itemValue": "Devices Landing Page"
            },
            {
                "itemKey": "hashedAccountNumber",
                "itemValue": "9178c70d873280b1d8f7965c7a76c60ea81f7aec9d8f7ca54483828e17db4765",
                "itemType": "text"
            },
            {
                "itemKey": "hashedMdn",
                "itemValue": "fa49a65a9784421cfb39f0d05c94f0b16ffd1eedfd5b7e52eaa378a93d062d6a",
                "itemType": "text"
            }
        ],
        "sections": [
            {
                "sectionIndex": "0",
                "sectionId": "devicesLandingMainSection",
                "sectionType": "devicesLandingMainSection",
                "sectionComponentId": "GenericComponent",
                "sections": [
                    {
                        "sectionIndex": "0",
                        "sectionId": "devicesLandingPageSection",
                        "sectionType": "devicesSection",
                        "actions": [
                            {
                                "actionType": "redirect",
                                "actionValue": "https://www.verizon.com/coverage-map/",
                                "actionKey": "review5gCoverageAction",
                                "clickStream": "review-5g-coverage-cta"
                            },
                            {
                                "actionType": "route",
                                "actionValue": "/deviceDetail",
                                "actionKey": "manageDeviceAction",
                                "clickStream": "manage-device-cta"
                            },
                            {
                                "actionType": "redirect",
                                "actionValue": "https://vzwqa2.verizonwireless.com/smartphones/?flow=AAL",
                                "actionKey": "addALineAction",
                                "clickStream": "add-a-line-cta"
                            },
                            {
                                "actionType": "redirect",
                                "actionValue": "https://vzwqa2.verizonwireless.com/products/",
                                "actionKey": "getAccessoriesAction",
                                "clickStream": "get-accessories-for-your-device-cta"
                            },
                            {
                                "actionType": "redirect",
                                "actionValue": "https://vzwqa2.verizonwireless.com/devices/",
                                "actionKey": "shopADevicetAction",
                                "clickStream": "shop-a-device-cta"
                            },
                            {
                                "actionType": "redirect",
                                "actionValue": "https://vzwqa2.verizonwireless.com/sales/as/home.html",
                                "actionKey": "activateDeviceAction",
                                "clickStream": "activate-your-device-cta"
                            },
                            {
                                "actionType": "redirect",
                                "actionValue": "https://vzwqa2.verizonwireless.com/digital/nsa/secure/ui/cpc/#/",
                                "actionKey": "managePlanAction",
                                "clickStream": "manage-plan-cta"
                            },
                            {
                                "actionType": "redirect",
                                "actionValue": "https://vzwqa2.verizonwireless.com/sales/as/home.html",
                                "actionKey": "bringDeviceAction",
                                "clickStream": "bring-your-device-cta"
                            },
                            {
                                "actionType": "redirect",
                                "actionValue": "https://vzwqa2.verizonwireless.com/digital/nsa/secure/ui/devices/routermgmt/?t=",
                                "actionKey": "manageRouterAction",
                                "clickStream": "manage-router-cta"
                            },
                            {
                                "actionType": "redirect",
                                "actionValue": "https://vzwqa2.verizonwireless.com/sales/digital/mdnselection.html?flow=EUP&amLogin=true&t=",
                                "actionKey": "upgradeDeviceAction",
                                "clickStream": "upgrade-device-cta"
                            },
                            {
                                "actionType": "http",
                                "actionValue": "https://vzwqa2.verizonwireless.com/digital/nsa/secure/ui/support/networkcompatibility",
                                "actionKey": "checkNetworkCompatibiltyAction"
                            },
                            {
                                "actionType": "http",
                                "actionValue": "https://vzwqa2.verizonwireless.com/ui/ntwk/ao/networkextender",
                                "actionKey": "manageNetworkExtender",
                                "clickStream": "manage-network-extender-cta"
                            },
                            {
                                "actionType": "http",
                                "actionValue": "https://vzwqa2.verizonwireless.com/digital/nsa/secure/ui/devices/suspendreconnect/",
                                "actionKey": "reconnecAction",
                                "clickStream": "re-connec-device-cta"
                            }
                        ],
                        "contents": [
                            {
                                "contentIndex": "0",
                                "items": [
                                    {
                                        "itemKey": "headerText",
                                        "itemType": "text",
                                        "itemValue": "Keep tabs on your devices here.",
                                        "itemAttributes": {}
                                    },
                                    {
                                        "itemKey": "subHeaderText",
                                        "itemType": "text",
                                        "itemValue": "You can easily manage, upgrade, pay off or add a line at anytime.",
                                        "itemAttributes": {}
                                    },
                                    {
                                        "itemKey": "myDevicesHeader",
                                        "itemType": "text",
                                        "itemValue": "My devices",
                                        "itemAttributes": {}
                                    },
                                    {
                                        "itemKey": "secondNumber",
                                        "itemType": "text",
                                        "itemValue": "(Second Number)",
                                        "itemAttributes": {}
                                    },
                                    {
                                        "itemKey": "relatedTopicsHeader",
                                        "itemType": "text",
                                        "itemValue": "Related topics",
                                        "dataKey": "deviceDetails",
                                        "itemAttributes": {}
                                    },
                                    {
                                        "itemKey": "eligibleforUpgrade",
                                        "itemType": "text",
                                        "itemValue": "Eligible for upgrade",
                                        "itemAttributes": {}
                                    },
                                    {
                                        "itemKey": "manageDeviceBtn",
                                        "itemType": "button",
                                        "itemValue": "Manage ",
                                        "itemAttributes": {},
                                        "actionKey": "manageDeviceAction"
                                    },
                                    {
                                        "itemKey": "addALineBtn",
                                        "itemType": "button",
                                        "itemValue": "Add a line",
                                        "itemAttributes": {},
                                        "actionKey": "addALineAction"
                                    },
                                    {
                                        "itemKey": "getAccessoriesBtn",
                                        "itemType": "button",
                                        "itemValue": "Get accessories for your devices",
                                        "itemAttributes": {},
                                        "actionKey": "getAccessoriesAction"
                                    },
                                    {
                                        "itemKey": "shopADevicetBtn",
                                        "itemType": "button",
                                        "itemValue": "Shop a device",
                                        "itemAttributes": {},
                                        "actionKey": "shopADevicetAction"
                                    },
                                    {
                                        "itemKey": "managePlanBtn",
                                        "itemType": "button",
                                        "itemValue": "Manage plan",
                                        "itemAttributes": {},
                                        "actionKey": "managePlanAction"
                                    },
                                    {
                                        "itemKey": "bringDeviceBtn",
                                        "itemType": "button",
                                        "itemValue": "Bring your own device",
                                        "itemAttributes": {},
                                        "actionKey": "bringDeviceAction"
                                    },
                                    {
                                        "itemKey": "activateDeviceBtn",
                                        "itemType": "button",
                                        "itemValue": "Activate your own devices",
                                        "itemAttributes": {},
                                        "actionKey": "activateDeviceAction"
                                    },
                                    {
                                        "itemKey": "review5gCoverageBtn",
                                        "itemType": "button",
                                        "itemValue": "Review 5G Coverage Map",
                                        "itemAttributes": {},
                                        "actionKey": "review5gCoverageAction"
                                    },
                                    {
                                        "itemKey": "upgradeDeviceBtn",
                                        "itemType": "button",
                                        "itemValue": "Upgrade",
                                        "itemAttributes": {},
                                        "actionKey": "upgradeDeviceAction"
                                    },
                                    {
                                        "itemKey": "remainingBalanceText",
                                        "itemType": "text",
                                        "itemValue": "Remaining balance of $",
                                        "itemAttributes": {}
                                    },
                                    {
                                        "itemKey": "manageNumberShareBtn",
                                        "itemType": "button",
                                        "itemValue": "Manage number share",
                                        "itemAttributes": {},
                                        "actionKey": "manageConnectedDevicesAction"
                                    },
                                    {
                                        "itemKey": "checkNetworkCompatibiltyBtn",
                                        "itemType": "button",
                                        "itemValue": "Check Network Compatibility",
                                        "itemAttributes": {},
                                        "actionKey": "checkNetworkCompatibiltyAction"
                                    },
                                    {
                                        "itemKey": "deviceSuspended",
                                        "itemType": "text",
                                        "itemValue": "Suspended",
                                        "itemAttributes": {}
                                    },
                                    {
                                        "itemKey": "pendingLineChangeText",
                                        "itemType": "text",
                                        "itemValue": "Pending Line Changes",
                                        "itemAttributes": {}
                                    },
                                    {
                                        "itemKey": "deviceSuspendedReconnect",
                                        "itemType": "button",
                                        "itemValue": "Re-connect",
                                        "itemAttributes": {},
                                        "actionKey": "reconnecAction"
                                    }
                                ]
                            }
                        ],
                        "data": {
                            "mobileDeviceList": [
                                {
                                    "mtn": "3152728473",
                                    "displayMtn": "315-272-8473",
                                    "secondMtn": "3152721111",
                                    "isSecondNumber": false,
                                    "encryptedMtnAES": "VIBC21bT4+Drasf2pkwyKpHomY3QdROO1/z1bcEEfaQ=",
                                    "encryptedMtnDES": "C68Veb6Lhu8qZXoHhch%2BkA%3D%3D",
                                    "mtnStatus": "A",
                                    "deviceName": "KENNY MANUEL",
                                    "userRole": "Owner",
                                    "device4G": false,
                                    "device5GE": true,
                                    "device5GA": false,
                                    "smartPhone": true,
                                    "basicPhone": false,
                                    "displayDeviceCategory": "5G Smartphone",
                                    "suspendedWithBilling": false,
                                    "suspendedWithoutBilling": false,
                                    "hasPendingOrder": false,
                                    "isMtnSuspended": false,
                                    "isSuspendResumed": false,
                                    "deviceId": "353352954419485",
                                    "hasPayOffBalance": false,
                                    "fiveGCapable": false,
                                    "cdmaRestricted": false,
                                    "dataOnlyCapableDevice": false,
                                    "upgradeEligible": true,
                                    "images": {
                                        "defaultImage": "https://ss7.vzw.com/is/image/VerizonWireless/apple-iphone-15-plus-128gb-black-mtxr3ll-a-a",
                                        "largeImage": "https://ss7.vzw.com/is/image/VerizonWireless/apple-iphone-15-plus-128gb-black-mtxr3ll-a-a?$device-lg$",
                                        "mediumImage": "https://ss7.vzw.com/is/image/VerizonWireless/apple-iphone-15-plus-128gb-black-mtxr3ll-a-a?$device-med$",
                                        "miniImage": "https://ss7.vzw.com/is/image/VerizonWireless/apple-iphone-15-plus-128gb-black-mtxr3ll-a-a?$device-mini$",
                                        "thumbImage": "https://ss7.vzw.com/is/image/VerizonWireless/apple-iphone-15-plus-128gb-black-mtxr3ll-a-a?$device-thumb$"
                                    },
                                    "router": false,
                                    "isOutstandingBalance": false,
                                    "checkNetworkCompatibiltyText": false,
                                    "pendingLineChange": true,
                                    "deviceCategory": "phone",
                                    "networkExtender": false,
                                    "skuId": "MTXR3LL/A"
                                },
                                {
                                    "mtn": "3152721111",
                                    "displayMtn": "315-272-1111",
                                    "secondMtn": "",
                                    "isSecondNumber": true,
                                    "encryptedMtnAES": "VIBC21bT4+Drasf2pkwyKpHomY3QdROO1/z1bcEEfaQ=",
                                    "encryptedMtnDES": "C68Veb6Lhu8qZXoHhch%2BkA%3D%3D",
                                    "mtnStatus": "A",
                                    "deviceName": "KENNY MANUEL",
                                    "userRole": "Owner",
                                    "device4G": false,
                                    "device5GE": true,
                                    "device5GA": false,
                                    "smartPhone": true,
                                    "basicPhone": false,
                                    "displayDeviceCategory": "5G Smartphone",
                                    "suspendedWithBilling": false,
                                    "suspendedWithoutBilling": false,
                                    "hasPendingOrder": false,
                                    "isMtnSuspended": false,
                                    "isSuspendResumed": false,
                                    "deviceId": "353352954419485",
                                    "hasPayOffBalance": false,
                                    "fiveGCapable": false,
                                    "cdmaRestricted": false,
                                    "dataOnlyCapableDevice": false,
                                    "upgradeEligible": true,
                                    "images": {
                                        "defaultImage": "https://ss7.vzw.com/is/image/VerizonWireless/apple-iphone-15-plus-128gb-black-mtxr3ll-a-a",
                                        "largeImage": "https://ss7.vzw.com/is/image/VerizonWireless/apple-iphone-15-plus-128gb-black-mtxr3ll-a-a?$device-lg$",
                                        "mediumImage": "https://ss7.vzw.com/is/image/VerizonWireless/apple-iphone-15-plus-128gb-black-mtxr3ll-a-a?$device-med$",
                                        "miniImage": "https://ss7.vzw.com/is/image/VerizonWireless/apple-iphone-15-plus-128gb-black-mtxr3ll-a-a?$device-mini$",
                                        "thumbImage": "https://ss7.vzw.com/is/image/VerizonWireless/apple-iphone-15-plus-128gb-black-mtxr3ll-a-a?$device-thumb$"
                                    },
                                    "router": false,
                                    "isOutstandingBalance": false,
                                    "checkNetworkCompatibiltyText": false,
                                    "pendingLineChange": true,
                                    "deviceCategory": "phone",
                                    "networkExtender": false,
                                    "skuId": "MTXR3LL/A"
                                },
                                {
                                    "mtn": "3152404685",
                                    "displayMtn": "315-240-4685",
                                    "secondMtn": "1231231231",
                                    "isSecondNumber": false,
                                    "encryptedMtnAES": "lJsjZ41oaz6Xd0yhNodWBJNAMqqhY5QG8RLjdFZDEek=",
                                    "encryptedMtnDES": "9Y9PqeahDKZ3JjYyfbHDPg%3D%3D",
                                    "mtnStatus": "AR",
                                    "deviceName": "KENNY MANUEL",
                                    "userRole": "Non Registered",
                                    "device4G": false,
                                    "device5GE": true,
                                    "device5GA": false,
                                    "smartPhone": false,
                                    "basicPhone": false,
                                    "displayDeviceCategory": "5G Tablet",
                                    "suspendedWithBilling": false,
                                    "suspendedWithoutBilling": false,
                                    "hasPendingOrder": false,
                                    "isMtnSuspended": false,
                                    "isSuspendResumed": false,
                                    "deviceId": "357528940891848",
                                    "hasPayOffBalance": false,
                                    "fiveGCapable": false,
                                    "cdmaRestricted": false,
                                    "dataOnlyCapableDevice": false,
                                    "upgradeEligible": true,
                                    "images": {
                                        "defaultImage": "https://ss7.vzw.com/is/image/VerizonWireless/ipad-pro-cellular-11-in-space-gray-5g",
                                        "largeImage": "https://ss7.vzw.com/is/image/VerizonWireless/ipad-pro-cellular-11-in-space-gray-5g?$device-lg$",
                                        "mediumImage": "https://ss7.vzw.com/is/image/VerizonWireless/ipad-pro-cellular-11-in-space-gray-5g?$device-med$",
                                        "miniImage": "https://ss7.vzw.com/is/image/VerizonWireless/ipad-pro-cellular-11-in-space-gray-5g?$device-mini$",
                                        "thumbImage": "https://ss7.vzw.com/is/image/VerizonWireless/ipad-pro-cellular-11-in-space-gray-5g?$device-thumb$"
                                    },
                                    "router": false,
                                    "isOutstandingBalance": false,
                                    "checkNetworkCompatibiltyText": false,
                                    "pendingLineChange": false,
                                    "deviceCategory": "tablet",
                                    "networkExtender": false,
                                    "skuId": "MHMT3LL/A"
                                },
                                {
                                    "mtn": "1231231231",
                                    "displayMtn": "123-123-1231",
                                    "secondMtn": "",
                                    "isSecondNumber": true,
                                    "encryptedMtnAES": "lJsjZ41oaz6Xd0yhNodWBJNAMqqhY5QG8RLjdFZDEek=",
                                    "encryptedMtnDES": "9Y9PqeahDKZ3JjYyfbHDPg%3D%3D",
                                    "mtnStatus": "AR",
                                    "deviceName": "KENNY MANUEL",
                                    "userRole": "Non Registered",
                                    "device4G": false,
                                    "device5GE": true,
                                    "device5GA": false,
                                    "smartPhone": false,
                                    "basicPhone": false,
                                    "displayDeviceCategory": "5G Tablet",
                                    "suspendedWithBilling": false,
                                    "suspendedWithoutBilling": false,
                                    "hasPendingOrder": false,
                                    "isMtnSuspended": false,
                                    "isSuspendResumed": false,
                                    "deviceId": "357528940891848",
                                    "hasPayOffBalance": false,
                                    "fiveGCapable": false,
                                    "cdmaRestricted": false,
                                    "dataOnlyCapableDevice": false,
                                    "upgradeEligible": true,
                                    "images": {
                                        "defaultImage": "https://ss7.vzw.com/is/image/VerizonWireless/ipad-pro-cellular-11-in-space-gray-5g",
                                        "largeImage": "https://ss7.vzw.com/is/image/VerizonWireless/ipad-pro-cellular-11-in-space-gray-5g?$device-lg$",
                                        "mediumImage": "https://ss7.vzw.com/is/image/VerizonWireless/ipad-pro-cellular-11-in-space-gray-5g?$device-med$",
                                        "miniImage": "https://ss7.vzw.com/is/image/VerizonWireless/ipad-pro-cellular-11-in-space-gray-5g?$device-mini$",
                                        "thumbImage": "https://ss7.vzw.com/is/image/VerizonWireless/ipad-pro-cellular-11-in-space-gray-5g?$device-thumb$"
                                    },
                                    "router": false,
                                    "isOutstandingBalance": false,
                                    "checkNetworkCompatibiltyText": false,
                                    "pendingLineChange": false,
                                    "deviceCategory": "tablet",
                                    "networkExtender": false,
                                    "skuId": "MHMT3LL/A"
                                },
                                {
                                    "mtn": "3155255095",
                                    "displayMtn": "315-525-5095",
                                    "secondMtn": "",
                                    "isSecondNumber": false,
                                    "encryptedMtnAES": "1fy/ULHUn2rTwFwJ+MqH5OIwQGPKCjSCcWMXZzn7270=",
                                    "encryptedMtnDES": "staWyQX%2FIXHal16UOZfJrQ%3D%3D",
                                    "mtnStatus": "B",
                                    "deviceName": "KENNY MANUEL",
                                    "userRole": "Non Registered",
                                    "device4G": false,
                                    "device5GE": false,
                                    "device5GA": false,
                                    "smartPhone": true,
                                    "basicPhone": false,
                                    "displayDeviceCategory": "4G Smartphone",
                                    "suspendedWithBilling": false,
                                    "suspendedWithoutBilling": false,
                                    "hasPendingOrder": false,
                                    "isMtnSuspended": true,
                                    "isSuspendResumed": false,
                                    "deviceId": "356112098846671",
                                    "hasPayOffBalance": false,
                                    "fiveGCapable": false,
                                    "cdmaRestricted": false,
                                    "dataOnlyCapableDevice": false,
                                    "upgradeEligible": true,
                                    "images": {
                                        "defaultImage": "https://ss7.vzw.com/is/image/VerizonWireless/iPhone8Plus-Svr",
                                        "largeImage": "https://ss7.vzw.com/is/image/VerizonWireless/iPhone8Plus-Svr?$device-lg$",
                                        "mediumImage": "https://ss7.vzw.com/is/image/VerizonWireless/iPhone8Plus-Svr?$device-med$",
                                        "miniImage": "https://ss7.vzw.com/is/image/VerizonWireless/iPhone8Plus-Svr?$device-mini$",
                                        "thumbImage": "https://ss7.vzw.com/is/image/VerizonWireless/iPhone8Plus-Svr?$device-thumb$"
                                    },
                                    "router": false,
                                    "isOutstandingBalance": false,
                                    "checkNetworkCompatibiltyText": false,
                                    "pendingLineChange": false,
                                    "deviceCategory": "phone",
                                    "networkExtender": false,
                                    "skuId": "MQ972LL/A"
                                }
                            ],
                            "fiveGDeviceList": [
                                {
                                    "mtn": "3152690419",
                                    "displayMtn": "315-269-0419",
                                    "encryptedMtnAES": "v+wswE4GzRmUR5VlnF/G+V6/Dd5/0FjOHfC59p0nPig=",
                                    "encryptedMtnDES": "3GXXnolx9Jpc7Ny26AGV4w%3D%3D",
                                    "mtnStatus": "A",
                                    "deviceName": "KENNY MANUEL",
                                    "userRole": "Non Registered",
                                    "device4G": false,
                                    "device5GE": true,
                                    "device5GA": false,
                                    "smartPhone": false,
                                    "basicPhone": false,
                                    "displayDeviceCategory": "5G Router",
                                    "suspendedWithBilling": false,
                                    "suspendedWithoutBilling": false,
                                    "hasPendingOrder": false,
                                    "isMtnSuspended": false,
                                    "isSuspendResumed": false,
                                    "deviceId": "350627354518702",
                                    "hasPayOffBalance": false,
                                    "fiveGCapable": false,
                                    "cdmaRestricted": false,
                                    "dataOnlyCapableDevice": false,
                                    "upgradeEligible": false,
                                    "images": {
                                        "defaultImage": "https://ss7.vzw.com/is/image/VerizonWireless/vzw-internet-gateway-askey-titan-2-router-white-arc-xci55ax",
                                        "largeImage": "https://ss7.vzw.com/is/image/VerizonWireless/vzw-internet-gateway-askey-titan-2-router-white-arc-xci55ax?$device-lg$",
                                        "mediumImage": "https://ss7.vzw.com/is/image/VerizonWireless/vzw-internet-gateway-askey-titan-2-router-white-arc-xci55ax?$device-med$",
                                        "miniImage": "https://ss7.vzw.com/is/image/VerizonWireless/vzw-internet-gateway-askey-titan-2-router-white-arc-xci55ax?$device-mini$",
                                        "thumbImage": "https://ss7.vzw.com/is/image/VerizonWireless/vzw-internet-gateway-askey-titan-2-router-white-arc-xci55ax?$device-thumb$"
                                    },
                                    "router": true,
                                    "isOutstandingBalance": false,
                                    "checkNetworkCompatibiltyText": false,
                                    "pendingLineChange": false,
                                    "deviceCategory": "router",
                                    "networkExtender": false,
                                    "skuId": "ASK-NCQ1338FA"
                                }
                            ],
                            "checkNetworkCompatibiltyText": false
                        }
                    }
                ]
            }
        ],
        "featureFlags": {
			"secondNumberPerkDisplayFFlag": true,
			"familyLineDigitalFlowControlFFlag": true
		},
    }
}

export const deviceLandingnew = {
    "responseInfo": {
        "timeStamp": "25-04-2023 12:25:02",
        "correlationId": "c9157103-edb2-46c0-a05e-f2649253e437-24371",
        "responseCode": "00",
        "responseMessage": "SUCCESS",
        "sectionErrors": []
    },
    "body": {
        "pageId": "devicesLandingPage",
        "pageAttributes": [
            {
                "itemKey": "pageTitle",
                "itemValue": "Devices Landing Page"
            }
        ],
        "sections": [
            {
                "sectionIndex": "0",
                "sectionId": "devicesLandingMainSection",
                "sectionType": "devicesLandingMainSection",
                "sectionComponentId": "GenericComponent",
                "sections": [
                    {
                        "sectionIndex": "0",
                        "sectionId": "devicesLandingPageSection",
                        "sectionType": "devicesSection",
                        "actions": [
                            {
                                "actionType": "route",
                                "actionValue": "/",
                                "actionKey": "review5gCoverageAction",
                                "clickStream": "review-5g-coverage-cta"
                            },
                            {
                                "actionType": "http",
                                "actionValue": "https://vzwqa1.verizonwireless.com//sales/digital/dvm/dashboard.html",
                                "actionKey": "pearlTrialAction",
                                "clickStream": "pearlTrial"
                            },
                            {
                                "actionType": "http",
                                "actionValue": "https://vzwqa1.verizonwireless.com//sales/digital/dvm/conversion.html",
                                "actionKey": "pearlTrialPlanAction",
                                "clickStream": "pearlTrialDashboard"
                            },
                            {
                                "actionType": "route",
                                "actionValue": "/deviceDetail",
                                "actionKey": "manageDeviceAction",
                                "clickStream": "manage-device-cta"
                            },
                            {
                                "actionType": "route",
                                "actionValue": "/",
                                "actionKey": "addALineAction",
                                "clickStream": "add-a-line-cta"
                            },
                            {
                                "actionType": "route",
                                "actionValue": "/",
                                "actionKey": "getAccessoriesAction",
                                "clickStream": "get-accessories-for-your-device-cta"
                            },
                            {
                                "actionType": "route",
                                "actionValue": "/",
                                "actionKey": "shopADevicetAction",
                                "clickStream": "shop-a-device-cta"
                            },
                            {
                                "actionType": "route",
                                "actionValue": "/",
                                "actionKey": "activateDeviceAction",
                                "clickStream": "activate-your-device-cta"
                            },
                            {
                                "actionType": "route",
                                "actionValue": "/",
                                "actionKey": "managePlanAction",
                                "clickStream": "manage-plan-cta"
                            },
                            {
                                "actionType": "route",
                                "actionValue": "/deviceDetail",
                                "actionKey": "bringDeviceAction",
                                "clickStream": "bring-your-device-cta"
                            },
                            {
                                "actionType": "http",
                                "actionValue": "https://www.verizon.com/digital/nsa/secure/ui/devices/suspendreconnect/",
                                "actionKey": "reconnecAction",
                                "clickStream": "re-connec-device-cta"
                            }
                        ],
                        "contents": [
                            {
                                "contentIndex": "0",
                                "items": [
                                    {
                                        "itemKey": "headerText",
                                        "itemType": "text",
                                        "itemValue": "Keep tabs on your devices here.",
                                        "itemAttributes": {}
                                    },
                                    {
                                        "itemKey": "pearlSubHeaderText",
                                        "itemType": "text",
                                        "itemValue": "Easily manage your device or review your plan.",
                                        "itemAttributes": {}
                                    },
                                    {
                                        "itemKey": "pearlTrialBtn",
                                        "itemType": "button",
                                        "itemValue": "Join now",
                                        "itemAttributes": {},
                                        "actionKey": "pearlTrialPlanAction"
                                    },
                                    {
                                        "itemKey": "pearlTrialReviewPlanBtn",
                                        "itemType": "button",
                                        "itemValue": "Review Plan",
                                        "itemAttributes": {},
                                        "actionKey": "pearlTrialAction"
                                    },
                                    {
                                        "itemKey": "subHeaderText",
                                        "itemType": "text",
                                        "itemValue": "You can easily manage, upgrade, pay off or add a line at anytime.",
                                        "itemAttributes": {}
                                    },
                                    {
                                        "itemKey": "myDevicesHeader",
                                        "itemType": "text",
                                        "itemValue": "My devices",
                                        "itemAttributes": {}
                                    },
                                    {
                                        "itemKey": "relatedTopicsHeader",
                                        "itemType": "text",
                                        "itemValue": "Related topics",
                                        "dataKey": "deviceDetails",
                                        "itemAttributes": {}
                                    },
                                    {
                                        "itemKey": "eligibleforUpgrade",
                                        "itemType": "text",
                                        "itemValue": "Eligible for upgrade",
                                        "itemAttributes": {}
                                    },
                                    {
                                        "itemKey": "manageDeviceBtn",
                                        "itemType": "button",
                                        "itemValue": "Manage",
                                        "itemAttributes": {},
                                        "actionKey": "manageDeviceAction"
                                    },
                                    {
                                        "itemKey": "addALineBtn",
                                        "itemType": "button",
                                        "itemValue": "Add a line",
                                        "itemAttributes": {},
                                        "actionKey": "addALineAction"
                                    },
                                    {
                                        "itemKey": "getAccessoriesBtn",
                                        "itemType": "button",
                                        "itemValue": "Get accessories for your devices",
                                        "itemAttributes": {},
                                        "actionKey": "getAccessoriesAction"
                                    },
                                    {
                                        "itemKey": "shopADevicetBtn",
                                        "itemType": "button",
                                        "itemValue": "Shop a device",
                                        "itemAttributes": {},
                                        "actionKey": "shopADevicetAction"
                                    },
                                    {
                                        "itemKey": "managePlanBtn",
                                        "itemType": "button",
                                        "itemValue": "Manage plan",
                                        "itemAttributes": {},
                                        "actionKey": "managePlanAction"
                                    },
                                    {
                                        "itemKey": "bringDeviceBtn",
                                        "itemType": "button",
                                        "itemValue": "Bring your own device",
                                        "itemAttributes": {},
                                        "actionKey": "bringDeviceAction"
                                    },
                                    {
                                        "itemKey": "activateDeviceBtn",
                                        "itemType": "button",
                                        "itemValue": "Activate your own devices",
                                        "itemAttributes": {},
                                        "actionKey": "activateDeviceAction"
                                    },
                                    {
                                        "itemKey": "review5gCoverageBtn",
                                        "itemType": "button",
                                        "itemValue": "Review 5G Coverage Map",
                                        "itemAttributes": {},
                                        "actionKey": "review5gCoverageAction"
                                    }
                                ]
                            }
                        ],
                        "data": {
                            "mobileDeviceList": [
                                {
                                    "mtn": "2153568074",
                                    "displayMtn": "215.356.8074",
                                    "modelName": "Apple Watch Series 7 GPS + Cellular, 45mm Midnight Aluminum Case with Midnight Sport Band - Regular",
                                    "userRole": "Member",
                                    "device4G": false,
                                    "device5GE": false,
                                    "device5GA": false,
                                    "smartPhone": false,
                                    "basicPhone": false,
                                    "displayDeviceCategory": "4G Connected Device",
                                    "suspendedWithBilling": false,
                                    "suspendedWithoutBilling": false,
                                    "hasPendingOrder": false,
                                    "isMtnSuspended": true,
                                    "isSuspendResumed": false,
                                    "deviceId": "350589172433383",
                                    "hasPayOffBalance": false,
                                    "fiveGCapable": false,
                                    "cdmaRestricted": false,
                                    "dataOnlyCapableDevice": false,
                                    "upgradeEligible": false,
                                    "images": {
                                        "defaultImage": "https://ss7.vzw.com/is/image/VerizonWireless/apple-watch-series-7-lte-45mm-midnight-aluminum-midnight-sport-band-mkj73ll-a-sku4790171",
                                        "largeImage": "https://ss7.vzw.com/is/image/VerizonWireless/apple-watch-series-7-lte-45mm-midnight-aluminum-midnight-sport-band-mkj73ll-a-sku4790171?$device-lg$",
                                        "mediumImage": "https://ss7.vzw.com/is/image/VerizonWireless/apple-watch-series-7-lte-45mm-midnight-aluminum-midnight-sport-band-mkj73ll-a-sku4790171?$device-med$",
                                        "miniImage": "https://ss7.vzw.com/is/image/VerizonWireless/apple-watch-series-7-lte-45mm-midnight-aluminum-midnight-sport-band-mkj73ll-a-sku4790171?$device-mini$",
                                        "thumbImage": "https://ss7.vzw.com/is/image/VerizonWireless/apple-watch-series-7-lte-45mm-midnight-aluminum-midnight-sport-band-mkj73ll-a-sku4790171?$device-thumb$"
                                    }
                                },
                                {
                                    "mtn": "3308120801",
                                    "displayMtn": "330.812.0801",
                                    "modelName": "Apple iPhone 12 128GB in White",
                                    "userRole": "Member",
                                    "pearlTrialFlow": true,
                                    "device4G": false,
                                    "device5GE": true,
                                    "device5GA": false,
                                    "smartPhone": true,
                                    "basicPhone": false,
                                    "pearlTrialFlow": true,
                                    "displayDeviceCategory": "5G Smartphone",
                                    "suspendedWithBilling": false,
                                    "suspendedWithoutBilling": false,
                                    "hasPendingOrder": false,
                                    "isMtnSuspended": false,
                                    "isSuspendResumed": false,
                                    "deviceId": "353779332013343",
                                    "hasPayOffBalance": false,
                                    "fiveGCapable": false,
                                    "cdmaRestricted": false,
                                    "dataOnlyCapableDevice": false,
                                    "remainingBalance": "479.09",
                                    "upgradeEligible": true,
                                    "images": {
                                        "defaultImage": "https://ss7.vzw.com/is/image/VerizonWireless/apple-iphone-12-white-10132020",
                                        "largeImage": "https://ss7.vzw.com/is/image/VerizonWireless/apple-iphone-12-white-10132020?$device-lg$",
                                        "mediumImage": "https://ss7.vzw.com/is/image/VerizonWireless/apple-iphone-12-white-10132020?$device-med$",
                                        "miniImage": "https://ss7.vzw.com/is/image/VerizonWireless/apple-iphone-12-white-10132020?$device-mini$",
                                        "thumbImage": "https://ss7.vzw.com/is/image/VerizonWireless/apple-iphone-12-white-10132020?$device-thumb$"
                                    }
                                },
                                {
                                    "mtn": "4049327795",
                                    "displayMtn": "404.932.7795",
                                    "encryptedMtnDES": "hLlBeQerYRjwZE3gecGGsA%3D%3D",
                                    "modelName": "Apple iPhone XS 64GB in Space Gray",
                                    "userRole": "Member",
                                    "device4G": false,
                                    "device5GE": false,
                                    "device5GA": false,
                                    "smartPhone": true,
                                    "basicPhone": false,
                                    "displayDeviceCategory": "4G Smartphone",
                                    "suspendedWithBilling": false,
                                    "suspendedWithoutBilling": false,
                                    "hasPendingOrder": false,
                                    "isMtnSuspended": false,
                                    "isSuspendResumed": false,
                                    "deviceId": "357205096172386",
                                    "hasPayOffBalance": false,
                                    "fiveGCapable": false,
                                    "cdmaRestricted": false,
                                    "dataOnlyCapableDevice": false,
                                    "upgradeEligible": false,
                                    "images": {
                                        "defaultImage": "https://ss7.vzw.com/is/image/VerizonWireless/apple-iphonexs-spacegrey",
                                        "largeImage": "https://ss7.vzw.com/is/image/VerizonWireless/apple-iphonexs-spacegrey?$device-lg$",
                                        "mediumImage": "https://ss7.vzw.com/is/image/VerizonWireless/apple-iphonexs-spacegrey?$device-med$",
                                        "miniImage": "https://ss7.vzw.com/is/image/VerizonWireless/apple-iphonexs-spacegrey?$device-mini$",
                                        "thumbImage": "https://ss7.vzw.com/is/image/VerizonWireless/apple-iphonexs-spacegrey?$device-thumb$"
                                    }
                                },
                                {
                                    "mtn": "4049819316",
                                    "displayMtn": "404.981.9316",
                                    "modelName": "Apple iPhone XS 256GB in Space Gray",
                                    "userRole": "Non Registered",
                                    "device4G": false,
                                    "device5GE": false,
                                    "device5GA": false,
                                    "smartPhone": true,
                                    "basicPhone": false,
                                    "displayDeviceCategory": "4G Smartphone",
                                    "suspendedWithBilling": false,
                                    "suspendedWithoutBilling": false,
                                    "hasPendingOrder": false,
                                    "isMtnSuspended": false,
                                    "isSuspendResumed": false,
                                    "deviceId": "356171096284590",
                                    "hasPayOffBalance": false,
                                    "fiveGCapable": false,
                                    "cdmaRestricted": false,
                                    "dataOnlyCapableDevice": false,
                                    "upgradeEligible": false,
                                    "router": true,
                                    "images": {
                                        "defaultImage": "https://ss7.vzw.com/is/image/VerizonWireless/apple-iphonexs-spacegrey",
                                        "largeImage": "https://ss7.vzw.com/is/image/VerizonWireless/apple-iphonexs-spacegrey?$device-lg$",
                                        "mediumImage": "https://ss7.vzw.com/is/image/VerizonWireless/apple-iphonexs-spacegrey?$device-med$",
                                        "miniImage": "https://ss7.vzw.com/is/image/VerizonWireless/apple-iphonexs-spacegrey?$device-mini$",
                                        "thumbImage": "https://ss7.vzw.com/is/image/VerizonWireless/apple-iphonexs-spacegrey?$device-thumb$"
                                    }
                                },
                                {
                                    "mtn": "4703947344",
                                    "displayMtn": "470.394.7344",
                                    "modelName": "Moto G6 Unlocked XT1925-6",
                                    "userRole": "Non Registered",
                                    "device4G": false,
                                    "device5GE": false,
                                    "device5GA": false,
                                    "smartPhone": true,
                                    "basicPhone": false,
                                    "displayDeviceCategory": "4G Smartphone",
                                    "suspendedWithBilling": false,
                                    "suspendedWithoutBilling": false,
                                    "hasPendingOrder": false,
                                    "isMtnSuspended": false,
                                    "isSuspendResumed": false,
                                    "deviceId": "351849091510201",
                                    "hasPayOffBalance": false,
                                    "fiveGCapable": false,
                                    "cdmaRestricted": false,
                                    "dataOnlyCapableDevice": false,
                                    "upgradeEligible": false,
                                    "images": {
                                        "defaultImage": "https://ss7.vzw.com/is/image/VerizonWireless/motorola-moto-g6-u",
                                        "largeImage": "https://ss7.vzw.com/is/image/VerizonWireless/motorola-moto-g6-u?$device-lg$",
                                        "mediumImage": "https://ss7.vzw.com/is/image/VerizonWireless/motorola-moto-g6-u?$device-med$",
                                        "miniImage": "https://ss7.vzw.com/is/image/VerizonWireless/motorola-moto-g6-u?$device-mini$",
                                        "thumbImage": "https://ss7.vzw.com/is/image/VerizonWireless/motorola-moto-g6-u?$device-thumb$"
                                    }
                                },
                                {
                                    "mtn": "4703947735",
                                    "displayMtn": "470.394.7735",
                                    "modelName": "Apple iPhone 12 mini 128GB in White",
                                    "userRole": "Manager",
                                    "device4G": false,
                                    "device5GE": true,
                                    "device5GA": false,
                                    "smartPhone": true,
                                    "basicPhone": false,
                                    "displayDeviceCategory": "5G Smartphone",
                                    "suspendedWithBilling": false,
                                    "suspendedWithoutBilling": false,
                                    "hasPendingOrder": false,
                                    "isMtnSuspended": false,
                                    "isSuspendResumed": false,
                                    "deviceId": "353006111163846",
                                    "hasPayOffBalance": false,
                                    "fiveGCapable": false,
                                    "cdmaRestricted": false,
                                    "dataOnlyCapableDevice": false,
                                    "upgradeEligible": true,
                                    "images": {
                                        "defaultImage": "https://ss7.vzw.com/is/image/VerizonWireless/apple-128gb-5-4in-iphone-12-mini-white-mg6n3ll-a",
                                        "largeImage": "https://ss7.vzw.com/is/image/VerizonWireless/apple-128gb-5-4in-iphone-12-mini-white-mg6n3ll-a?$device-lg$",
                                        "mediumImage": "https://ss7.vzw.com/is/image/VerizonWireless/apple-128gb-5-4in-iphone-12-mini-white-mg6n3ll-a?$device-med$",
                                        "miniImage": "https://ss7.vzw.com/is/image/VerizonWireless/apple-128gb-5-4in-iphone-12-mini-white-mg6n3ll-a?$device-mini$",
                                        "thumbImage": "https://ss7.vzw.com/is/image/VerizonWireless/apple-128gb-5-4in-iphone-12-mini-white-mg6n3ll-a?$device-thumb$"
                                    }
                                },
                                {
                                    "mtn": "4704562440",
                                    "displayMtn": "470.456.2440",
                                    "modelName": "Apple iPhone 7 32GB in Black",
                                    "userRole": "Non Registered",
                                    "device4G": false,
                                    "device5GE": false,
                                    "device5GA": false,
                                    "smartPhone": true,
                                    "basicPhone": false,
                                    "displayDeviceCategory": "4G Smartphone",
                                    "suspendedWithBilling": false,
                                    "suspendedWithoutBilling": false,
                                    "hasPendingOrder": false,
                                    "isMtnSuspended": false,
                                    "isSuspendResumed": false,
                                    "deviceId": "354909096348028",
                                    "hasPayOffBalance": false,
                                    "fiveGCapable": false,
                                    "cdmaRestricted": false,
                                    "dataOnlyCapableDevice": false,
                                    "upgradeEligible": false,
                                    "images": {
                                        "defaultImage": "https://ss7.vzw.com/is/image/VerizonWireless/iphone7-front-matblk",
                                        "largeImage": "https://ss7.vzw.com/is/image/VerizonWireless/iphone7-front-matblk?$device-lg$",
                                        "mediumImage": "https://ss7.vzw.com/is/image/VerizonWireless/iphone7-front-matblk?$device-med$",
                                        "miniImage": "https://ss7.vzw.com/is/image/VerizonWireless/iphone7-front-matblk?$device-mini$",
                                        "thumbImage": "https://ss7.vzw.com/is/image/VerizonWireless/iphone7-front-matblk?$device-thumb$"
                                    }
                                },
                                {
                                    "mtn": "4706556626",
                                    "displayMtn": "470.655.6626",
                                    "modelName": "Apple iPhone X 256GB in Space Gray",
                                    "userRole": "Non Registered",
                                    "device4G": false,
                                    "device5GE": false,
                                    "device5GA": false,
                                    "smartPhone": true,
                                    "basicPhone": false,
                                    "displayDeviceCategory": "4G Smartphone",
                                    "suspendedWithBilling": false,
                                    "suspendedWithoutBilling": false,
                                    "hasPendingOrder": false,
                                    "isMtnSuspended": false,
                                    "isSuspendResumed": false,
                                    "deviceId": "353051094429822",
                                    "hasPayOffBalance": false,
                                    "fiveGCapable": false,
                                    "cdmaRestricted": false,
                                    "dataOnlyCapableDevice": false,
                                    "upgradeEligible": false,
                                    "images": {
                                        "defaultImage": "https://ss7.vzw.com/is/image/VerizonWireless/iPhoneX-SpGry",
                                        "largeImage": "https://ss7.vzw.com/is/image/VerizonWireless/iPhoneX-SpGry?$device-lg$",
                                        "mediumImage": "https://ss7.vzw.com/is/image/VerizonWireless/iPhoneX-SpGry?$device-med$",
                                        "miniImage": "https://ss7.vzw.com/is/image/VerizonWireless/iPhoneX-SpGry?$device-mini$",
                                        "thumbImage": "https://ss7.vzw.com/is/image/VerizonWireless/iPhoneX-SpGry?$device-thumb$"
                                    }
                                },
                                {
                                    "mtn": "4707010583",
                                    "displayMtn": "470.701.0583",
                                    "modelName": "Apple iPhone 13 128GB in Midnight",
                                    "userRole": "Non Registered",
                                    "device4G": false,
                                    "device5GE": true,
                                    "device5GA": false,
                                    "smartPhone": true,
                                    "basicPhone": false,
                                    "displayDeviceCategory": "5G Smartphone",
                                    "suspendedWithBilling": false,
                                    "suspendedWithoutBilling": false,
                                    "hasPendingOrder": false,
                                    "isMtnSuspended": false,
                                    "isSuspendResumed": false,
                                    "deviceId": "357068947374282",
                                    "hasPayOffBalance": false,
                                    "fiveGCapable": false,
                                    "cdmaRestricted": false,
                                    "dataOnlyCapableDevice": false,
                                    "remainingBalance": "680.40",
                                    "upgradeEligible": true,
                                    "images": {
                                        "defaultImage": "https://ss7.vzw.com/is/image/VerizonWireless/apple-iphone-13-midnight-09142021",
                                        "largeImage": "https://ss7.vzw.com/is/image/VerizonWireless/apple-iphone-13-midnight-09142021?$device-lg$",
                                        "mediumImage": "https://ss7.vzw.com/is/image/VerizonWireless/apple-iphone-13-midnight-09142021?$device-med$",
                                        "miniImage": "https://ss7.vzw.com/is/image/VerizonWireless/apple-iphone-13-midnight-09142021?$device-mini$",
                                        "thumbImage": "https://ss7.vzw.com/is/image/VerizonWireless/apple-iphone-13-midnight-09142021?$device-thumb$"
                                    }
                                },
                                {
                                    "mtn": "4707183302",
                                    "displayMtn": "470.718.3302",
                                    "modelName": "Apple iPhone 11 64GB in Black",
                                    "userRole": "Member",
                                    "device4G": false,
                                    "device5GE": false,
                                    "device5GA": false,
                                    "smartPhone": true,
                                    "basicPhone": false,
                                    "displayDeviceCategory": "4G Smartphone",
                                    "suspendedWithBilling": false,
                                    "suspendedWithoutBilling": false,
                                    "hasPendingOrder": false,
                                    "isMtnSuspended": false,
                                    "isSuspendResumed": false,
                                    "deviceId": "356859119721107",
                                    "hasPayOffBalance": false,
                                    "fiveGCapable": false,
                                    "cdmaRestricted": false,
                                    "dataOnlyCapableDevice": false,
                                    "remainingBalance": "999.99",
                                    "upgradeEligible": true,
                                    "images": {
                                        "defaultImage": "https://ss7.vzw.com/is/image/VerizonWireless/Apple_iPhone_11_Black_09102019",
                                        "largeImage": "https://ss7.vzw.com/is/image/VerizonWireless/Apple_iPhone_11_Black_09102019?$device-lg$",
                                        "mediumImage": "https://ss7.vzw.com/is/image/VerizonWireless/Apple_iPhone_11_Black_09102019?$device-med$",
                                        "miniImage": "https://ss7.vzw.com/is/image/VerizonWireless/Apple_iPhone_11_Black_09102019?$device-mini$",
                                        "thumbImage": "https://ss7.vzw.com/is/image/VerizonWireless/Apple_iPhone_11_Black_09102019?$device-thumb$"
                                    }
                                },
                                {
                                    "mtn": "4707996990",
                                    "displayMtn": "470.799.6990",
                                    "modelName": "iPhone 14 Pro 128GB in Deep Purple",
                                    "userRole": "Member",
                                    "device4G": false,
                                    "device5GE": true,
                                    "device5GA": false,
                                    "smartPhone": true,
                                    "basicPhone": false,
                                    "displayDeviceCategory": "5G Smartphone",
                                    "suspendedWithBilling": false,
                                    "suspendedWithoutBilling": false,
                                    "hasPendingOrder": false,
                                    "isMtnSuspended": false,
                                    "isSuspendResumed": false,
                                    "deviceId": "353559560541326",
                                    "hasPayOffBalance": false,
                                    "fiveGCapable": false,
                                    "cdmaRestricted": false,
                                    "dataOnlyCapableDevice": false,
                                    "remainingBalance": "860.87",
                                    "upgradeEligible": true,
                                    "images": {
                                        "defaultImage": "https://ss7.vzw.com/is/image/VerizonWireless/iphone-14-pro-deep-purple-fall22-a",
                                        "largeImage": "https://ss7.vzw.com/is/image/VerizonWireless/iphone-14-pro-deep-purple-fall22-a?$device-lg$",
                                        "mediumImage": "https://ss7.vzw.com/is/image/VerizonWireless/iphone-14-pro-deep-purple-fall22-a?$device-med$",
                                        "miniImage": "https://ss7.vzw.com/is/image/VerizonWireless/iphone-14-pro-deep-purple-fall22-a?$device-mini$",
                                        "thumbImage": "https://ss7.vzw.com/is/image/VerizonWireless/iphone-14-pro-deep-purple-fall22-a?$device-thumb$"
                                    }
                                },
                                {
                                    "mtn": "4708659768",
                                    "displayMtn": "470.865.9768",
                                    "modelName": "Apple iPhone 11 128GB in Purple (2019)",
                                    "userRole": "Non Registered",
                                    "device4G": false,
                                    "device5GE": false,
                                    "device5GA": false,
                                    "smartPhone": true,
                                    "basicPhone": false,
                                    "displayDeviceCategory": "4G Smartphone",
                                    "suspendedWithBilling": false,
                                    "suspendedWithoutBilling": false,
                                    "hasPendingOrder": false,
                                    "isMtnSuspended": false,
                                    "isSuspendResumed": false,
                                    "deviceId": "352904114378299",
                                    "hasPayOffBalance": false,
                                    "fiveGCapable": false,
                                    "cdmaRestricted": false,
                                    "dataOnlyCapableDevice": false,
                                    "upgradeEligible": false,
                                    "images": {
                                        "defaultImage": "https://ss7.vzw.com/is/image/VerizonWireless/Apple_iPhone_11_Purple_09102019",
                                        "largeImage": "https://ss7.vzw.com/is/image/VerizonWireless/Apple_iPhone_11_Purple_09102019?$device-lg$",
                                        "mediumImage": "https://ss7.vzw.com/is/image/VerizonWireless/Apple_iPhone_11_Purple_09102019?$device-med$",
                                        "miniImage": "https://ss7.vzw.com/is/image/VerizonWireless/Apple_iPhone_11_Purple_09102019?$device-mini$",
                                        "thumbImage": "https://ss7.vzw.com/is/image/VerizonWireless/Apple_iPhone_11_Purple_09102019?$device-thumb$"
                                    }
                                },
                                {
                                    "mtn": "5122033892",
                                    "displayMtn": "512.203.3892",
                                    "modelName": "Apple iPhone 12 Pro 128GB in Silver",
                                    "userRole": "Non Registered",
                                    "device4G": false,
                                    "device5GE": true,
                                    "device5GA": false,
                                    "smartPhone": true,
                                    "basicPhone": false,
                                    "displayDeviceCategory": "5G Smartphone",
                                    "suspendedWithBilling": false,
                                    "suspendedWithoutBilling": false,
                                    "hasPendingOrder": false,
                                    "isMtnSuspended": false,
                                    "isSuspendResumed": false,
                                    "deviceId": "358915484678286",
                                    "hasPayOffBalance": false,
                                    "fiveGCapable": false,
                                    "cdmaRestricted": false,
                                    "dataOnlyCapableDevice": false,
                                    "upgradeEligible": false,
                                    "images": {
                                        "defaultImage": "https://ss7.vzw.com/is/image/VerizonWireless/iphone-12-pro-silver",
                                        "largeImage": "https://ss7.vzw.com/is/image/VerizonWireless/iphone-12-pro-silver?$device-lg$",
                                        "mediumImage": "https://ss7.vzw.com/is/image/VerizonWireless/iphone-12-pro-silver?$device-med$",
                                        "miniImage": "https://ss7.vzw.com/is/image/VerizonWireless/iphone-12-pro-silver?$device-mini$",
                                        "thumbImage": "https://ss7.vzw.com/is/image/VerizonWireless/iphone-12-pro-silver?$device-thumb$"
                                    }
                                },
                                {
                                    "mtn": "5127778132",
                                    "displayMtn": "512.777.8132",
                                    "modelName": "IPHONE 12 PRO 128 GRAPH-E",
                                    "userRole": "Member",
                                    "device4G": false,
                                    "device5GE": true,
                                    "device5GA": false,
                                    "smartPhone": true,
                                    "basicPhone": false,
                                    "displayDeviceCategory": "5G Smartphone",
                                    "suspendedWithBilling": false,
                                    "suspendedWithoutBilling": false,
                                    "hasPendingOrder": false,
                                    "isMtnSuspended": false,
                                    "isSuspendResumed": false,
                                    "deviceId": "356403874736651",
                                    "hasPayOffBalance": false,
                                    "fiveGCapable": false,
                                    "cdmaRestricted": false,
                                    "dataOnlyCapableDevice": false,
                                    "remainingBalance": "199.98",
                                    "upgradeEligible": true,
                                    "images": {
                                        "defaultImage": "https://ss7.vzw.com/is/image/VerizonWireless/iphone-12-pro-graphite",
                                        "largeImage": "https://ss7.vzw.com/is/image/VerizonWireless/iphone-12-pro-graphite?$device-lg$",
                                        "mediumImage": "https://ss7.vzw.com/is/image/VerizonWireless/iphone-12-pro-graphite?$device-med$",
                                        "miniImage": "https://ss7.vzw.com/is/image/VerizonWireless/iphone-12-pro-graphite?$device-mini$",
                                        "thumbImage": "https://ss7.vzw.com/is/image/VerizonWireless/iphone-12-pro-graphite?$device-thumb$"
                                    }
                                },
                                {
                                    "mtn": "6786897264",
                                    "displayMtn": "678.689.7264",
                                    "modelName": "Apple iPhone 7 32GB in Black",
                                    "userRole": "Non Registered",
                                    "device4G": false,
                                    "device5GE": false,
                                    "device5GA": false,
                                    "smartPhone": true,
                                    "basicPhone": false,
                                    "displayDeviceCategory": "4G Smartphone",
                                    "suspendedWithBilling": false,
                                    "suspendedWithoutBilling": false,
                                    "hasPendingOrder": false,
                                    "isMtnSuspended": false,
                                    "isSuspendResumed": false,
                                    "deviceId": "354917095326432",
                                    "hasPayOffBalance": false,
                                    "fiveGCapable": false,
                                    "cdmaRestricted": false,
                                    "dataOnlyCapableDevice": false,
                                    "upgradeEligible": false,
                                    "images": {
                                        "defaultImage": "https://ss7.vzw.com/is/image/VerizonWireless/iphone7-front-matblk",
                                        "largeImage": "https://ss7.vzw.com/is/image/VerizonWireless/iphone7-front-matblk?$device-lg$",
                                        "mediumImage": "https://ss7.vzw.com/is/image/VerizonWireless/iphone7-front-matblk?$device-med$",
                                        "miniImage": "https://ss7.vzw.com/is/image/VerizonWireless/iphone7-front-matblk?$device-mini$",
                                        "thumbImage": "https://ss7.vzw.com/is/image/VerizonWireless/iphone7-front-matblk?$device-thumb$"
                                    }
                                },
                                {
                                    "mtn": "7159694025",
                                    "displayMtn": "715.969.4025",
                                    "modelName": "IPHONE 12 MINI 64GB PURPLE-E",
                                    "userRole": "Manager",
                                    "device4G": false,
                                    "device5GE": true,
                                    "device5GA": false,
                                    "smartPhone": true,
                                    "basicPhone": false,
                                    "displayDeviceCategory": "5G Smartphone",
                                    "suspendedWithBilling": false,
                                    "suspendedWithoutBilling": false,
                                    "hasPendingOrder": false,
                                    "isMtnSuspended": false,
                                    "isSuspendResumed": false,
                                    "deviceId": "357804761815715",
                                    "hasPayOffBalance": false,
                                    "fiveGCapable": false,
                                    "cdmaRestricted": false,
                                    "dataOnlyCapableDevice": false,
                                    "remainingBalance": "319.84",
                                    "upgradeEligible": true,
                                    "images": {
                                        "defaultImage": "https://ss7.vzw.com/is/image/VerizonWireless/apple-iphone-12-mini-purple-2021",
                                        "largeImage": "https://ss7.vzw.com/is/image/VerizonWireless/apple-iphone-12-mini-purple-2021?$device-lg$",
                                        "mediumImage": "https://ss7.vzw.com/is/image/VerizonWireless/apple-iphone-12-mini-purple-2021?$device-med$",
                                        "miniImage": "https://ss7.vzw.com/is/image/VerizonWireless/apple-iphone-12-mini-purple-2021?$device-mini$",
                                        "thumbImage": "https://ss7.vzw.com/is/image/VerizonWireless/apple-iphone-12-mini-purple-2021?$device-thumb$"
                                    }
                                },
                                {
                                    "mtn": "7324706683",
                                    "displayMtn": "732.470.6683",
                                    "modelName": "Apple iPhone 13 Pro 128GB in Sierra Blue",
                                    "userRole": "Non Registered",
                                    "device4G": false,
                                    "device5GE": true,
                                    "device5GA": false,
                                    "smartPhone": true,
                                    "basicPhone": false,
                                    "displayDeviceCategory": "5G Smartphone",
                                    "suspendedWithBilling": false,
                                    "suspendedWithoutBilling": false,
                                    "hasPendingOrder": false,
                                    "isMtnSuspended": false,
                                    "isSuspendResumed": false,
                                    "deviceId": "358823346988663",
                                    "hasPayOffBalance": false,
                                    "fiveGCapable": false,
                                    "cdmaRestricted": false,
                                    "dataOnlyCapableDevice": false,
                                    "upgradeEligible": false,
                                    "images": {
                                        "defaultImage": "https://ss7.vzw.com/is/image/VerizonWireless/apple-iphone-13-pro-sierra-blue-09142021",
                                        "largeImage": "https://ss7.vzw.com/is/image/VerizonWireless/apple-iphone-13-pro-sierra-blue-09142021?$device-lg$",
                                        "mediumImage": "https://ss7.vzw.com/is/image/VerizonWireless/apple-iphone-13-pro-sierra-blue-09142021?$device-med$",
                                        "miniImage": "https://ss7.vzw.com/is/image/VerizonWireless/apple-iphone-13-pro-sierra-blue-09142021?$device-mini$",
                                        "thumbImage": "https://ss7.vzw.com/is/image/VerizonWireless/apple-iphone-13-pro-sierra-blue-09142021?$device-thumb$"
                                    }
                                },
                                {
                                    "mtn": "7703166567",
                                    "displayMtn": "770.316.6567",
                                    "modelName": "IPHONE 12 PRO MAX 128 SILVER-E",
                                    "userRole": "Member",
                                    "device4G": false,
                                    "device5GE": true,
                                    "device5GA": false,
                                    "smartPhone": true,
                                    "basicPhone": false,
                                    "displayDeviceCategory": "5G Smartphone",
                                    "suspendedWithBilling": false,
                                    "suspendedWithoutBilling": false,
                                    "hasPendingOrder": false,
                                    "isMtnSuspended": false,
                                    "isSuspendResumed": false,
                                    "deviceId": "353541320927524",
                                    "hasPayOffBalance": false,
                                    "fiveGCapable": false,
                                    "cdmaRestricted": false,
                                    "dataOnlyCapableDevice": false,
                                    "remainingBalance": "99.96",
                                    "upgradeEligible": true,
                                    "images": {
                                        "defaultImage": "https://ss7.vzw.com/is/image/VerizonWireless/apple-iphone-12-pro-max-silver-10132020",
                                        "largeImage": "https://ss7.vzw.com/is/image/VerizonWireless/apple-iphone-12-pro-max-silver-10132020?$device-lg$",
                                        "mediumImage": "https://ss7.vzw.com/is/image/VerizonWireless/apple-iphone-12-pro-max-silver-10132020?$device-med$",
                                        "miniImage": "https://ss7.vzw.com/is/image/VerizonWireless/apple-iphone-12-pro-max-silver-10132020?$device-mini$",
                                        "thumbImage": "https://ss7.vzw.com/is/image/VerizonWireless/apple-iphone-12-pro-max-silver-10132020?$device-thumb$"
                                    }
                                },
                                {
                                    "mtn": "7705970016",
                                    "displayMtn": "770.597.0016",
                                    "modelName": "IPHONE 14 PRO 128 SPACE BLACK-2",
                                    "userRole": "Owner",
                                    "device4G": false,
                                    "device5GE": true,
                                    "device5GA": false,
                                    "smartPhone": true,
                                    "basicPhone": false,
                                    "displayDeviceCategory": "5G Smartphone",
                                    "suspendedWithBilling": false,
                                    "suspendedWithoutBilling": false,
                                    "hasPendingOrder": false,
                                    "isMtnSuspended": false,
                                    "isSuspendResumed": false,
                                    "deviceId": "352228701640873",
                                    "hasPayOffBalance": false,
                                    "fiveGCapable": false,
                                    "cdmaRestricted": false,
                                    "dataOnlyCapableDevice": false,
                                    "remainingBalance": "183.32",
                                    "upgradeEligible": true,
                                    "images": {
                                        "defaultImage": "https://ss7.vzw.com/is/image/VerizonWireless/iphone-14-pro-space-black-fall22-a",
                                        "largeImage": "https://ss7.vzw.com/is/image/VerizonWireless/iphone-14-pro-space-black-fall22-a?$device-lg$",
                                        "mediumImage": "https://ss7.vzw.com/is/image/VerizonWireless/iphone-14-pro-space-black-fall22-a?$device-med$",
                                        "miniImage": "https://ss7.vzw.com/is/image/VerizonWireless/iphone-14-pro-space-black-fall22-a?$device-mini$",
                                        "thumbImage": "https://ss7.vzw.com/is/image/VerizonWireless/iphone-14-pro-space-black-fall22-a?$device-thumb$"
                                    }
                                },
                                {
                                    "mtn": "9199990408",
                                    "displayMtn": "919.999.0408",
                                    "modelName": "Apple iPhone 7 Plus 128GB in Rose Gold",
                                    "userRole": "Non Registered",
                                    "device4G": false,
                                    "device5GE": false,
                                    "device5GA": false,
                                    "smartPhone": true,
                                    "basicPhone": false,
                                    "displayDeviceCategory": "4G Smartphone",
                                    "suspendedWithBilling": false,
                                    "suspendedWithoutBilling": false,
                                    "hasPendingOrder": false,
                                    "isMtnSuspended": false,
                                    "isSuspendResumed": false,
                                    "deviceId": "359473086352834",
                                    "hasPayOffBalance": false,
                                    "fiveGCapable": false,
                                    "cdmaRestricted": false,
                                    "dataOnlyCapableDevice": false,
                                    "upgradeEligible": false,
                                    "images": {
                                        "defaultImage": "https://ss7.vzw.com/is/image/VerizonWireless/iphone7-plus-front-rsgld",
                                        "largeImage": "https://ss7.vzw.com/is/image/VerizonWireless/iphone7-plus-front-rsgld?$device-lg$",
                                        "mediumImage": "https://ss7.vzw.com/is/image/VerizonWireless/iphone7-plus-front-rsgld?$device-med$",
                                        "miniImage": "https://ss7.vzw.com/is/image/VerizonWireless/iphone7-plus-front-rsgld?$device-mini$",
                                        "thumbImage": "https://ss7.vzw.com/is/image/VerizonWireless/iphone7-plus-front-rsgld?$device-thumb$"
                                    }
                                }
                            ],
                            "fiveGDeviceList": [
                                {
                                    "mtn": "9090909089",
                                    "displayMtn": "215.356.8074",
                                    "modelName": "Apple Watch Series 7 GPS + Cellular, 45mm Midnight Aluminum Case with Midnight Sport Band - Regular",
                                    "userRole": "Member",
                                    "device4G": false,
                                    "device5GE": false,
                                    "device5GA": false,
                                    "smartPhone": false,
                                    "basicPhone": false,
                                    "displayDeviceCategory": "4G Connected Device",
                                    "suspendedWithBilling": false,
                                    "suspendedWithoutBilling": false,
                                    "hasPendingOrder": false,
                                    "isMtnSuspended": true,
                                    "isSuspendResumed": false,
                                    "deviceId": "350589172433383",
                                    "hasPayOffBalance": false,
                                    "fiveGCapable": false,
                                    "cdmaRestricted": false,
                                    "dataOnlyCapableDevice": false,
                                    "upgradeEligible": false,
                                    "images": {
                                        "defaultImage": "https://ss7.vzw.com/is/image/VerizonWireless/apple-watch-series-7-lte-45mm-midnight-aluminum-midnight-sport-band-mkj73ll-a-sku4790171",
                                        "largeImage": "https://ss7.vzw.com/is/image/VerizonWireless/apple-watch-series-7-lte-45mm-midnight-aluminum-midnight-sport-band-mkj73ll-a-sku4790171?$device-lg$",
                                        "mediumImage": "https://ss7.vzw.com/is/image/VerizonWireless/apple-watch-series-7-lte-45mm-midnight-aluminum-midnight-sport-band-mkj73ll-a-sku4790171?$device-med$",
                                        "miniImage": "https://ss7.vzw.com/is/image/VerizonWireless/apple-watch-series-7-lte-45mm-midnight-aluminum-midnight-sport-band-mkj73ll-a-sku4790171?$device-mini$",
                                        "thumbImage": "https://ss7.vzw.com/is/image/VerizonWireless/apple-watch-series-7-lte-45mm-midnight-aluminum-midnight-sport-band-mkj73ll-a-sku4790171?$device-thumb$"
                                    }
                                },
                            ]
                        }
                    }
                ]
            }
        ]
    }
}




