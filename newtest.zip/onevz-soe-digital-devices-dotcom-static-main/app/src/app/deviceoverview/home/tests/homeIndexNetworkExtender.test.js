import React from "react";
import "../../../../../config/jest/test-setup";
import { act, render, screen, fireEvent  } from "@testing-library/react";
import "@testing-library/jest-dom/extend-expect";
import { Provider } from "react-redux";
import httpClient, { getHttpClientRequest } from "../../../../shared/services/httpClient";
import configureStore from "../../../../shared/store/configureStore";
import rootReducer from "../../reducers";
import { persistStore } from 'redux-persist';
import { PersistGate } from 'redux-persist/integration/react';
import DevicesOverview from "../components/index";
import { deviceLanding3, fiveGDeviceList1, mobileDeviceList } from "./mockResponse";
import { setDeviceDetails } from "../../../../shared/utilities/tagging";

const store = configureStore(rootReducer);
const persistor = persistStore(store);

jest.mock("../../../../shared/services/httpClient", () => ({
    ...jest.requireActual("../../../../shared/services/httpClient"),
    getHttpClientRequest: jest.fn()
}));

describe("<DevicesOverview />", () => {
    reactGlobals.routeLog = {confirmationShown : 'true'}
    beforeEach(async () => {
        httpClient.getHttpClientRequest.mockImplementation((url) => {
            return Promise.resolve({ status: 200, data: { ...deviceLanding3} });
        });

        await act(async () => render(
            <Provider store={store}>
                <PersistGate loading={null} persistor={persistor}>
                    <DevicesOverview />
                </PersistGate>
            </Provider>
        ));

    })

    test("it should mount", () => {
        const doc = screen.getByTestId("DevicesOverviewTestId");
        expect(doc).toBeInTheDocument();
    });

    test("Manage device mount", () => {
       jest.setTimeout('10000');
       fireEvent.click(screen.getByTestId("managedeviceCtaTestId0"));
    });

});

describe("<DevicesOverview />", () => {
    reactGlobals.deviceOverviewTaggingFFlag = true;
    reactGlobals.routeLog = {confirmationShown : 'true'}
    beforeEach(async () => {
        httpClient.getHttpClientRequest.mockImplementation((url) => {
            return Promise.resolve({ status: 200, data: { ...deviceLanding3} });
        });

        await act(async () => render(
            <Provider store={store}>
                <PersistGate loading={null} persistor={persistor}>
                    <DevicesOverview />
                </PersistGate>
            </Provider>
        ));

    })

    test("it should mount", () => {
        const doc = screen.getByTestId("DevicesOverviewTestId");
        expect(doc).toBeInTheDocument();
    });

    test("deviceoverview", () => {
       jest.setTimeout('10000');
       expect(setDeviceDetails).toBeDefined();
    });

});

describe("<DevicesOverview />", () => {
    reactGlobals.deviceOverviewTaggingFFlag = true;
    reactGlobals.routeLog = {confirmationShown : 'true'}
    window.vzdl = JSON.parse("{\"cmp\":{\"all\":\"\"},\"env\":{\"businessUnit\":\"wireless\"},\"error\":{\"code\":\"\"},\"event\":{\"value\":\"\"},\"page\":{\"channel\":\"Account Management\",\"channelSession\":\"49d2ca90-dcd0-4d12-a867-8890a16028da\",\"detail\":\"\",\"displayChannel\":\"VZW\",\"flow\":\"suspend \\u0026 reconnect\",\"name\":\"LANDING\",\"sourceChannel\":\"VZW\",\"subFlow\":\"\",\"throttle\":\"desktop:northstar\",\"contentFragments\":\"\",\"link\":\"\",\"LQZip\":\"\"},\"platform\":{\"call\":\"\"},\"search\":{\"term\":\"\",\"type\":\"\",\"results\":\"\"},\"support\":{\"issueNumber\":\"\",\"tsaIssueName\":\"\",\"tsaStepName\":\"\"},\"target\":{\"assetsRequested\":\"\",\"assetAttributes\":\"\",\"assetsLeveraged\":\"\",\"abTest\":\"\",\"campaign\":\"\",\"experience\":\"\",\"message\":\"\",\"offer\":\"\",\"cloud\":\"\",\"mktgId\":\"\",\"sandBox\":\"\",\"engagement\":{\"intent\":\"Account Management\",\"id\":\"\",\"offered\":\"\"}},\"txn\":{\"agent\":\"\",\"autoPay\":\"\",\"id\":\"\",\"offer\":\"\",\"discountId\":\"\",\"orderType\":\"\",\"status\":\"\",\"cartId\":\"\",\"outletId\":\"\",\"quoteId\":\"\",\"paymentType\":\"\",\"shippingZip\":\"\",\"shippingTotal\":\"\",\"tradeInQty\":\"\",\"tradeInAmt\":\"\",\"total\":\"\",\"taxAmt\":\"\",\"recurringCharges\":\"\",\"nonRecurringCharges\":\"\",\"futurePayment\":\"\",\"installOptions\":\"\",\"discount\":\"\",\"paymentAmt\":\"\",\"reasonCode\":\"\",\"reviewOption\":\"\",\"accBundleFlag\":\"\",\"cpcFlag\":\"\",\"wishListFlag\":\"\",\"product\":{\"owns\":[],\"current\":[]}},\"user\":{\"existingServices\":\"\",\"account\":\"D8F7B665D4A84D3436CEC1BFDCA80FC5\",\"accountType\":\"postpay\",\"customerRole\":\"accountManager\",\"customerType\":\"B2C\",\"numberOfLines\":\"\",\"planType\":\"\",\"authStatus\":\"Logged In\",\"id\":\"463C61F94CE310F9EBA586243ABC8E6B\",\"tenure\":\"\",\"prospect\":\"\",\"session\":\"1a5bba91-b9be-442a-b6da-1ec5ebc36c03\",\"chatId\":\"\",\"childId\":\"\",\"creditAppNum\":\"\",\"deviceDollars\":\"\",\"zip\":\"\",\"emcAccountId\":\"\",\"emcEmailId\":\"\",\"emcMdn\":\"\",\"productsQualified\":\"\",\"acctId_unhashed\":\"0423716985-00001\",\"custId_unhashed\":\"7748269468\",\"visionAcctID_unhashed\":\"\",\"visionCustID_unhashed\":\"\",\"customerBusiness\":\"vzw_cust\"},\"utils\":{\"StrategyApiKey\":\"\",\"appApiKey\":\"\",\"pegaCaseId\":\"\",\"athenaSession\":\"\",\"outcome\":\"\",\"pegaOffer\":\"\"}}");;;

    beforeEach(async () => {
        httpClient.getHttpClientRequest.mockImplementation((url) => {
            return Promise.resolve({ status: 200, data: { ...mobileDeviceList} });
        });

        await act(async () => render(
            <Provider store={store}>
                <PersistGate loading={null} persistor={persistor}>
                    <DevicesOverview />
                </PersistGate>
            </Provider>
        ));

    })

    test("it should mount", () => {
        const doc = screen.getByTestId("DevicesOverviewTestId");
        expect(doc).toBeInTheDocument();
    });

    test("deviceoverview", () => {
       jest.setTimeout('10000');
       expect(setDeviceDetails).toBeDefined();
    });

});
describe("<DevicesOverview />", () => {
    reactGlobals.deviceOverviewTaggingFFlag = true;
    reactGlobals.routeLog = {confirmationShown : 'true'}
    window.vzdl = JSON.parse("{\"cmp\":{\"all\":\"\"},\"env\":{\"businessUnit\":\"wireless\"},\"error\":{\"code\":\"\"},\"event\":{\"value\":\"\"},\"page\":{\"channel\":\"Account Management\",\"channelSession\":\"49d2ca90-dcd0-4d12-a867-8890a16028da\",\"detail\":\"\",\"displayChannel\":\"VZW\",\"flow\":\"suspend \\u0026 reconnect\",\"name\":\"LANDING\",\"sourceChannel\":\"VZW\",\"subFlow\":\"\",\"throttle\":\"desktop:northstar\",\"contentFragments\":\"\",\"link\":\"\",\"LQZip\":\"\"},\"platform\":{\"call\":\"\"},\"search\":{\"term\":\"\",\"type\":\"\",\"results\":\"\"},\"support\":{\"issueNumber\":\"\",\"tsaIssueName\":\"\",\"tsaStepName\":\"\"},\"target\":{\"assetsRequested\":\"\",\"assetAttributes\":\"\",\"assetsLeveraged\":\"\",\"abTest\":\"\",\"campaign\":\"\",\"experience\":\"\",\"message\":\"\",\"offer\":\"\",\"cloud\":\"\",\"mktgId\":\"\",\"sandBox\":\"\",\"engagement\":{\"intent\":\"Account Management\",\"id\":\"\",\"offered\":\"\"}},\"txn\":{\"agent\":\"\",\"autoPay\":\"\",\"id\":\"\",\"offer\":\"\",\"discountId\":\"\",\"orderType\":\"\",\"status\":\"\",\"cartId\":\"\",\"outletId\":\"\",\"quoteId\":\"\",\"paymentType\":\"\",\"shippingZip\":\"\",\"shippingTotal\":\"\",\"tradeInQty\":\"\",\"tradeInAmt\":\"\",\"total\":\"\",\"taxAmt\":\"\",\"recurringCharges\":\"\",\"nonRecurringCharges\":\"\",\"futurePayment\":\"\",\"installOptions\":\"\",\"discount\":\"\",\"paymentAmt\":\"\",\"reasonCode\":\"\",\"reviewOption\":\"\",\"accBundleFlag\":\"\",\"cpcFlag\":\"\",\"wishListFlag\":\"\",\"product\":{\"owns\":[],\"current\":[]}},\"user\":{\"existingServices\":\"\",\"account\":\"D8F7B665D4A84D3436CEC1BFDCA80FC5\",\"accountType\":\"postpay\",\"customerRole\":\"accountManager\",\"customerType\":\"B2C\",\"numberOfLines\":\"\",\"planType\":\"\",\"authStatus\":\"Logged In\",\"id\":\"463C61F94CE310F9EBA586243ABC8E6B\",\"tenure\":\"\",\"prospect\":\"\",\"session\":\"1a5bba91-b9be-442a-b6da-1ec5ebc36c03\",\"chatId\":\"\",\"childId\":\"\",\"creditAppNum\":\"\",\"deviceDollars\":\"\",\"zip\":\"\",\"emcAccountId\":\"\",\"emcEmailId\":\"\",\"emcMdn\":\"\",\"productsQualified\":\"\",\"acctId_unhashed\":\"0423716985-00001\",\"custId_unhashed\":\"7748269468\",\"visionAcctID_unhashed\":\"\",\"visionCustID_unhashed\":\"\",\"customerBusiness\":\"vzw_cust\"},\"utils\":{\"StrategyApiKey\":\"\",\"appApiKey\":\"\",\"pegaCaseId\":\"\",\"athenaSession\":\"\",\"outcome\":\"\",\"pegaOffer\":\"\"}}");;;

    beforeEach(async () => {
        httpClient.getHttpClientRequest.mockImplementation((url) => {
            return Promise.resolve({ status: 200, data: { ...fiveGDeviceList1} });
        });

        await act(async () => render(
            <Provider store={store}>
                <PersistGate loading={null} persistor={persistor}>
                    <DevicesOverview />
                </PersistGate>
            </Provider>
        ));

    })

    test("deviceoverview", () => {
       jest.setTimeout('10000');
       expect(setDeviceDetails).toBeDefined();
    });

});

describe("<DevicesOverview />", () => {
    reactGlobals.deviceOverviewTaggingFFlag = true;
    reactGlobals.routeLog = {confirmationShown : 'true'}
    window.vzdl = JSON.parse("{\"cmp\":{\"all\":\"\"},\"env\":{\"businessUnit\":\"wireless\"},\"error\":{\"code\":\"\"},\"event\":{\"value\":\"\"},\"page\":{\"channel\":\"Account Management\",\"channelSession\":\"49d2ca90-dcd0-4d12-a867-8890a16028da\",\"detail\":\"\",\"displayChannel\":\"VZW\",\"flow\":\"suspend \\u0026 reconnect\",\"name\":\"LANDING\",\"sourceChannel\":\"VZW\",\"subFlow\":\"\",\"throttle\":\"desktop:northstar\",\"contentFragments\":\"\",\"link\":\"\",\"LQZip\":\"\"},\"platform\":{\"call\":\"\"},\"search\":{\"term\":\"\",\"type\":\"\",\"results\":\"\"},\"support\":{\"issueNumber\":\"\",\"tsaIssueName\":\"\",\"tsaStepName\":\"\"},\"target\":{\"assetsRequested\":\"\",\"assetAttributes\":\"\",\"assetsLeveraged\":\"\",\"abTest\":\"\",\"campaign\":\"\",\"experience\":\"\",\"message\":\"\",\"offer\":\"\",\"cloud\":\"\",\"mktgId\":\"\",\"sandBox\":\"\",\"engagement\":{\"intent\":\"Account Management\",\"id\":\"\",\"offered\":\"\"}},\"txn\":{\"agent\":\"\",\"autoPay\":\"\",\"id\":\"\",\"offer\":\"\",\"discountId\":\"\",\"orderType\":\"\",\"status\":\"\",\"cartId\":\"\",\"outletId\":\"\",\"quoteId\":\"\",\"paymentType\":\"\",\"shippingZip\":\"\",\"shippingTotal\":\"\",\"tradeInQty\":\"\",\"tradeInAmt\":\"\",\"total\":\"\",\"taxAmt\":\"\",\"recurringCharges\":\"\",\"nonRecurringCharges\":\"\",\"futurePayment\":\"\",\"installOptions\":\"\",\"discount\":\"\",\"paymentAmt\":\"\",\"reasonCode\":\"\",\"reviewOption\":\"\",\"accBundleFlag\":\"\",\"cpcFlag\":\"\",\"wishListFlag\":\"\",\"product\":{\"owns\":[],\"current\":[]}},\"user\":{\"existingServices\":\"\",\"account\":\"D8F7B665D4A84D3436CEC1BFDCA80FC5\",\"accountType\":\"postpay\",\"customerRole\":\"accountManager\",\"customerType\":\"B2C\",\"numberOfLines\":\"\",\"planType\":\"\",\"authStatus\":\"Logged In\",\"id\":\"463C61F94CE310F9EBA586243ABC8E6B\",\"tenure\":\"\",\"prospect\":\"\",\"session\":\"1a5bba91-b9be-442a-b6da-1ec5ebc36c03\",\"chatId\":\"\",\"childId\":\"\",\"creditAppNum\":\"\",\"deviceDollars\":\"\",\"zip\":\"\",\"emcAccountId\":\"\",\"emcEmailId\":\"\",\"emcMdn\":\"\",\"productsQualified\":\"\",\"acctId_unhashed\":\"0423716985-00001\",\"custId_unhashed\":\"7748269468\",\"visionAcctID_unhashed\":\"\",\"visionCustID_unhashed\":\"\",\"customerBusiness\":\"vzw_cust\"},\"utils\":{\"StrategyApiKey\":\"\",\"appApiKey\":\"\",\"pegaCaseId\":\"\",\"athenaSession\":\"\",\"outcome\":\"\",\"pegaOffer\":\"\"}}");

    beforeEach(async () => {
       
        await act(async () => render(
            <Provider store={store}>
                <PersistGate loading={null} persistor={persistor}>
                    <DevicesOverview />
                </PersistGate>
            </Provider>
        ));

    })

    afterEach(()=>{
        delete window.vzdl;
    })

    test("deviceoverview", () => {
       jest.setTimeout('10000');
       setDeviceDetails({})
    });

})


describe("<DevicesOverview />", () => {
    reactGlobals.deviceOverviewTaggingFFlag = true;
    reactGlobals.routeLog = {confirmationShown : 'true'}
    window.vzdl = JSON.parse("{\"cmp\":{\"all\":\"\"},\"env\":{\"businessUnit\":\"wireless\"},\"error\":{\"code\":\"\"},\"event\":{\"value\":\"\"},\"page\":{\"channel\":\"Account Management\",\"channelSession\":\"49d2ca90-dcd0-4d12-a867-8890a16028da\",\"detail\":\"\",\"displayChannel\":\"VZW\",\"flow\":\"suspend \\u0026 reconnect\",\"name\":\"LANDING\",\"sourceChannel\":\"VZW\",\"subFlow\":\"\",\"throttle\":\"desktop:northstar\",\"contentFragments\":\"\",\"link\":\"\",\"LQZip\":\"\"},\"platform\":{\"call\":\"\"},\"search\":{\"term\":\"\",\"type\":\"\",\"results\":\"\"},\"support\":{\"issueNumber\":\"\",\"tsaIssueName\":\"\",\"tsaStepName\":\"\"},\"target\":{\"assetsRequested\":\"\",\"assetAttributes\":\"\",\"assetsLeveraged\":\"\",\"abTest\":\"\",\"campaign\":\"\",\"experience\":\"\",\"message\":\"\",\"offer\":\"\",\"cloud\":\"\",\"mktgId\":\"\",\"sandBox\":\"\",\"engagement\":{\"intent\":\"Account Management\",\"id\":\"\",\"offered\":\"\"}},\"txn\":{\"agent\":\"\",\"autoPay\":\"\",\"id\":\"\",\"offer\":\"\",\"discountId\":\"\",\"orderType\":\"\",\"status\":\"\",\"cartId\":\"\",\"outletId\":\"\",\"quoteId\":\"\",\"paymentType\":\"\",\"shippingZip\":\"\",\"shippingTotal\":\"\",\"tradeInQty\":\"\",\"tradeInAmt\":\"\",\"total\":\"\",\"taxAmt\":\"\",\"recurringCharges\":\"\",\"nonRecurringCharges\":\"\",\"futurePayment\":\"\",\"installOptions\":\"\",\"discount\":\"\",\"paymentAmt\":\"\",\"reasonCode\":\"\",\"reviewOption\":\"\",\"accBundleFlag\":\"\",\"cpcFlag\":\"\",\"wishListFlag\":\"\",\"product\":{\"owns\":[],\"current\":[]}},\"user\":{\"existingServices\":\"\",\"account\":\"D8F7B665D4A84D3436CEC1BFDCA80FC5\",\"accountType\":\"postpay\",\"customerRole\":\"accountManager\",\"customerType\":\"B2C\",\"numberOfLines\":\"\",\"planType\":\"\",\"authStatus\":\"Logged In\",\"id\":\"463C61F94CE310F9EBA586243ABC8E6B\",\"tenure\":\"\",\"prospect\":\"\",\"session\":\"1a5bba91-b9be-442a-b6da-1ec5ebc36c03\",\"chatId\":\"\",\"childId\":\"\",\"creditAppNum\":\"\",\"deviceDollars\":\"\",\"zip\":\"\",\"emcAccountId\":\"\",\"emcEmailId\":\"\",\"emcMdn\":\"\",\"productsQualified\":\"\",\"acctId_unhashed\":\"0423716985-00001\",\"custId_unhashed\":\"7748269468\",\"visionAcctID_unhashed\":\"\",\"visionCustID_unhashed\":\"\",\"customerBusiness\":\"vzw_cust\"},\"utils\":{\"StrategyApiKey\":\"\",\"appApiKey\":\"\",\"pegaCaseId\":\"\",\"athenaSession\":\"\",\"outcome\":\"\",\"pegaOffer\":\"\"}}");
    const deviceList = {
        body:{
            sections:[
                {
                    sections:[
                        {
                            data:{
                                
                            }
                        }
                    ]
                }
            ]
        }
    
    }
    beforeEach(async () => {
        
        await act(async () => render(
            <Provider store={store}>
                <PersistGate loading={null} persistor={persistor}>
                    <DevicesOverview />
                </PersistGate>
            </Provider>
        ));

    })

    afterEach(()=>{
        delete window.vzdl;
    })

    test("deviceoverview", () => {
       jest.setTimeout('10000');
       setDeviceDetails(deviceList)
    });

    test("deviceoverview",()=>{
        window.vzdl = {
            txn:{
                product:{
                    owns:"",
                }
            }
        }

        jest.setTimeout("10000");
        setDeviceDetails(deviceList);
    })

    test("deviceoverview",()=>{
        window.vzdl = 'undefined';
        jest.setTimeout("10000");
        setDeviceDetails(deviceList);
    })

})
