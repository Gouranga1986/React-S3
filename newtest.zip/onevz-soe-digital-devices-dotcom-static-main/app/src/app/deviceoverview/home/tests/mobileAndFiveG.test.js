import React from "react";
import "../../../../../config/jest/test-setup";
import { act, render, screen } from "@testing-library/react";
import "@testing-library/jest-dom/extend-expect";
import { Provider } from "react-redux";
import httpClient, { getHttpClientRequest } from "../../../../shared/services/httpClient";
import configureStore, { history } from "../../../../shared/store/configureStore";
import rootReducer from "../../reducers";
import { persistStore } from 'redux-persist';
import { PersistGate } from 'redux-persist/integration/react';
import DevicesOverview from "../components/index";
import { mobileAndfiveGDeviceList } from "./mockResponse";

const store = configureStore(rootReducer);
const persistor = persistStore(store);

jest.mock("../../../../shared/services/httpClient", () => ({
    ...jest.requireActual("../../../../shared/services/httpClient"),
    getHttpClientRequest: jest.fn()
}));

describe("<DevicesOverview />", () => {
    reactGlobals.routeLog = {confirmationShown : 'true'}
    window.VZTAG_IS_READY = 'true';
    beforeEach(async () => {
        httpClient.getHttpClientRequest.mockImplementation((url) => {
            return Promise.resolve({ status: 200, data: { ...mobileAndfiveGDeviceList} });
        });

        await act(async () => render(
            <Provider store={store}>
                <PersistGate loading={null} persistor={persistor}>
                    <DevicesOverview />
                </PersistGate>
            </Provider>
        ));

    })

    test("it should mount", () => {
        const doc = screen.getByTestId("DevicesOverviewTestId");
        expect(doc).toBeInTheDocument();
    });
});