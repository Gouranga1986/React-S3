import React from "react";
import "../../../../../config/jest/test-setup";
import { act, render, screen, fireEvent } from "@testing-library/react";
import "@testing-library/jest-dom/extend-expect";
import { Provider } from "react-redux";
import httpClient, { getHttpClientRequest, postHttpClientRequest } from "../../../../shared/services/httpClient";
import configureStore, { history } from "../../../../shared/store/configureStore";
import rootReducer from "../../reducers";
import { persistStore } from 'redux-persist';
import { PersistGate } from 'redux-persist/integration/react';
import DevicesOverview from "../components/index";
import { deviceLanding, recommendationMock, proActiveNoti, networkOutageDetail,deviceLanding4, deviceLandingnew} from "./mockResponse";
import * as getSections from '../actions/getSections';
import * as pageActions from '../actions/pageActions';
import { getCaptureResponse } from "../actions/pageActions";

const store = configureStore(rootReducer);
const persistor = persistStore(store);

jest.mock("../../../../shared/services/httpClient", () => ({
    ...jest.requireActual("../../../../shared/services/httpClient"),
    getHttpClientRequest: jest.fn(),
    postHttpClientRequest: jest.fn()
}));


describe("<DevicesOverviewPearl />", () => {
    window.VZTAG_IS_READY = 'false';
    reactGlobals.routeLog = { confirmationShown: 'true' }
    beforeEach(async () => {
        httpClient.getHttpClientRequest.mockImplementation((url) => {
            return Promise.resolve({ status: 200, data: { ...deviceLandingnew } });
        });

        await act(async () => render(
            <Provider store={store}>
                <PersistGate loading={null} persistor={persistor}>
                    <DevicesOverview />
                </PersistGate>
            </Provider>
        ));
    })
    test("addALineBtnTestId", () => {
        const doc = screen.getByTestId('pearlTrialBtn');
        expect(doc).toBeInTheDocument();
        fireEvent.click(doc);
    })
});

describe("<DevicesOverview />", () => {
    reactGlobals.routeLog = { confirmationShown: 'true' }
    beforeEach(async () => {
        httpClient.getHttpClientRequest.mockImplementation((url) => {
            return Promise.resolve({ status: 200, data: { ...deviceLanding } });
        });

        await act(async () => render(
            <Provider store={store}>
                <PersistGate loading={null} persistor={persistor}>
                    <DevicesOverview />
                </PersistGate>
            </Provider>
        ));

    })

    test("it should mount", () => {
        const doc = screen.getByTestId("DevicesOverviewTestId");
        expect(doc).toBeInTheDocument();
    });

    test("it should mount", () => {
        jest.setTimeout('10000');
        fireEvent.click(screen.getByTestId("managedeviceCtaTestId1"));
    });

    test("it should mount", () => {
        jest.setTimeout('10000');
        //fireEvent.click(screen.getByTestId("upgradeDeviceBtnTestId0"));
    });

    test("getDeviceLandingError api error", () => {
        httpClient.getHttpClientRequest.mockImplementation((url) => {
            return Promise.reject({ data: 'error' });
        });

        store.dispatch(getSections.getDeviceLandingError('getSection'));
    });


    test("recommendation test", () => {
        jest.setTimeout('10000');

        httpClient.getHttpClientRequest.mockImplementation((url) => {
            return Promise.resolve({ status: 200, data: { ...recommendationMock } });
        })
        store.dispatch(pageActions?.getRecommendation('2144707276'));
    });

    test("CaptureResponse test", () => {
        httpClient.postHttpClientRequest.mockImplementation((url) => {
            return Promise.resolve({ status: 200, data: { ...recommendationMock}})
        })
        let payload = {
            "source": "deviceOverviewFeedbackRec",
            "contextInfo": {
                "callReason": "LiveTiles",
                "category": "Support",
                "subServiceName": "CaptureResponse",
                "pageContext": "MVO_Device_Overview_Support",
                "sessionId": "-8713991925375068437"
            },
            "customerResponse": {
                "responseList": [
                    {
                        "dispositionOptionId": "82",
                        "propositionId": "LU_12",
                        "rank": "1",
                        "soiEngagementId": "500017832",
                        "tacticLocation": "MVO_Device_Overview_Support"
                    }
                ]
            }
        }
        getCaptureResponse(payload)
    });


    test("getProactiveNotificationSuccess api success", () => {
        httpClient.getHttpClientRequest.mockImplementation((url) => {
            return Promise.resolve({ status: 200, data: { ...proActiveNoti } });
        });

        store.dispatch(pageActions.getProactiveNotification({
            pageContext: "",
            category: "Alerts",
        }));
    });

    test("getNetworkOutageSuccess api success", () => {
        httpClient.getHttpClientRequest.mockImplementation((url) => {
            return Promise.resolve({ status: 200, data: { ...networkOutageDetail } });
        });

        store.dispatch(pageActions.getNetworkOutage());
    });

    test("getProactiveNotificationError api error", () => {
        httpClient.getHttpClientRequest.mockImplementation((url) => {
            return Promise.reject({ data: 'error' });
        });

        store.dispatch(pageActions.getProactiveNotificationError('getAction'));
    });

    test("getProactiveNotificationSuccess api error", () => {
        httpClient.getHttpClientRequest.mockImplementation((url) => {
            return Promise.reject({ data: 'error' });
        });

        store.dispatch(pageActions.getProactiveNotificationSuccess('getSection'));
    });

    test("getNetworkOutageError api error", () => {
        httpClient.getHttpClientRequest.mockImplementation((url) => {
            return Promise.reject({ data: 'error' });
        });

        store.dispatch(pageActions.getNetworkOutageError('getAction'));
    });

    test("getRecommendationError api error", () => {
        httpClient.getHttpClientRequest.mockImplementation((url) => {
            return Promise.reject({ data: 'error' });
        });

        store.dispatch(pageActions.getRecommendationError('getAction'));
    });

    test("setSelectedDevice api error", () => {
        httpClient.getHttpClientRequest.mockImplementation((url) => {
            return Promise.reject({ data: 'error' });
        });

        store.dispatch(pageActions.setSelectedDevice('getAction'));
    });

    test("getSections api error", () => {
        httpClient.getHttpClientRequest.mockImplementation((url) => {
            return Promise.reject({ data: 'error' });
        });

        store.dispatch(getSections.getSections('getSection'))
            // .then((res) => {
            // }, (error) => {
            //     expect(error.data).toEqual('error');
            // });

    });
});

describe("<DevicesOverview />", () => {
    reactGlobals.routeLog = { confirmationShown: 'true' }
    beforeEach(async () => {
        httpClient.getHttpClientRequest.mockImplementation((url) => {
            return Promise.resolve({ status: 200, data: { ...deviceLanding4 } });
        });

        await act(async () => render(
            <Provider store={store}>
                <PersistGate loading={null} persistor={persistor}>
                    <DevicesOverview />
                </PersistGate>
            </Provider>
        ));

    })

    test("it should mount", () => {
        const doc = screen.getByTestId("DevicesOverviewTestId");
        expect(doc).toBeInTheDocument();
    });

    test("it should mount second number", () => {
        const txt = screen.getAllByTestId("secondNum");
        expect(txt).toHaveLength(2);
    });

    
});

const DeviceOverviewTestSuite = () => {
    describe("<DevicesOverview />", () => {
        reactGlobals.routeLog = { confirmationShown: 'true' }
        test("it should mount", async () => {
            httpClient.getHttpClientRequest.mockImplementation((url) => {
                return Promise.resolve({ status: 200, data: { ...deviceLanding4 } });
            });
            await act(async () => render(
                <Provider store={store}>
                    <PersistGate loading={null} persistor={persistor}>
                        <DevicesOverview />
                    </PersistGate>
                </Provider>
            ));
            jest.setTimeout('10000');
            fireEvent.click(screen.getByTestId("upgradeDeviceBtnTestId0"));
        });
        test("it should mount", async () => {
            const newResp = { ...deviceLanding4 };
            newResp.body.sections[0].sections[0].data.mobileDeviceList[0] = {
                ...newResp.body.sections[0].sections[0].data.mobileDeviceList[0],
                secondMtn: '',
                encryptedMtnDES: '',
            };
            httpClient.getHttpClientRequest.mockImplementation((url) => {
                return Promise.resolve({ status: 200, data: { ...newResp } });
            });
            await act(async () => render(
                <Provider store={store}>
                    <PersistGate loading={null} persistor={persistor}>
                        <DevicesOverview />
                    </PersistGate>
                </Provider>
            ));
            jest.setTimeout('10000');
            fireEvent.click(screen.getByTestId("upgradeDeviceBtnTestId0"));
        });
    });
};

DeviceOverviewTestSuite();
