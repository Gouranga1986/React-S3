import { PURGE } from 'redux-persist';
import { getHttpClientRequest } from '../../../../shared/services/httpClient';
import {
  setVzDLVaribale, dispatchPageView, dispatchVzdlData, dispatchVzdlFlow, setDeviceDetails,
} from '../../../../shared/utilities/tagging';
import apiUrl from '../../../../shared/utilities/apiUrl';

export const GET_DEVICE_LANDING_BEGIN = 'deviceLanding/GET_DEVICE_LANDING_BEGIN';
export const GET_DEVICE_LANDING_SUCCESS = 'deviceLanding/GET_DEVICE_LANDING_SUCCESS';
export const GET_DEVICE_LANDING_ERROR = 'deviceLanding/GET_DEVICE_LANDING_ERROR';

export const getSections = () => (dispatch) => {
  console.log('inside getSections');

  dispatch(getDeviceLandingBegin());

  const onSuccess = (responseSections) => {
    if (
      responseSections
      && responseSections.data
      && responseSections.data.responseInfo
      && responseSections.data.responseInfo.responseCode === '00'
    ) {
      const { body } = responseSections.data;
      const { pageAttributes } = body;
      try {
        setVzDLVaribale(pageAttributes);
        setTimeout(() => {
          dispatchVzdlData('devices overview landing', 'device overview');
          dispatchVzdlFlow('device overview');
          setDeviceDetails(responseSections.data);
          if (window.VZTAG_IS_READY) {
            dispatchPageView('devices overview landing');
          } else {
            document.addEventListener('vztagReady', () => {
              dispatchPageView('devices overview landing');
            });
          }
        }, 2000);
      } catch (ex) { console.log(ex); }
      dispatch(getDeviceLandingSuccess(responseSections.data));
    } else {
      dispatch(getDeviceLandingError(responseSections.data));
    }
  };

  const onError = (error) => {
    console.log('error', error);

    // below code is for redirecting to unauthorised screen for member account
    const msResp = error && error.response && error.response.data;
    const responseCode = msResp && msResp.responseInfo && msResp.responseInfo.responseCode;
    const responseMessage = msResp && msResp.responseInfo && msResp.responseInfo.responseMessage;
    if (responseCode === '401' && responseMessage.includes('mobileSecure')) {
      window.location.href = apiUrl().mvoLimitedAccessUrl;
    } else {
      dispatch(getDeviceLandingError(error));
    }
  };

  const callMS = () => {
    const axConfig = {
      headers: { pageName: 'devicesLandingPage', flowName: 'Devices' },
    };
    return getHttpClientRequest(
      apiUrl().deviceLandingPageUrl,
      axConfig
    );
  };

  callMS()
    .then((msResp) => {
      console.log('msResp', msResp);
      if (msResp && msResp.status === 200) {
        onSuccess(msResp);
      }
    })
    .catch(onError);
};

export const getDeviceLandingBegin = (urlParams) => ({
  type: GET_DEVICE_LANDING_BEGIN,
  urlParams,
});

export const getDeviceLandingSuccess = (msResp) => ({
  type: GET_DEVICE_LANDING_SUCCESS,
  msResp,
});

export const getDeviceLandingError = (err) => ({
  type: GET_DEVICE_LANDING_ERROR,
  err,
});

export const purgeStore = () => (dispatch) => {
  dispatch({
    type: PURGE,
    key: 'clearSession',
    result: () => null,
  });
};
