import { getHttpClientRequest, postHttpClientRequest } from "../../../../shared/services/httpClient";
import apiUrl from '../../../../shared/utilities/apiUrl';

export const SET_SELECTED_DEVICE = "deviceLanding/SET_SELECTED_DEVICE";
export const SET_RECOMMENDATION_DEVICE_TILE = "deviceLanding/SET_RECOMMENDATION_DEVICE_TILE";
export const GET_RECOMMENDATION_BEGIN = "deviceLanding/GET_RECOMMENDATION_BEGIN";
export const GET_RECOMMENDATION_SUCCESS = "deviceLanding/GET_RECOMMENDATION_SUCCESS";
export const GET_RECOMMENDATION_ERROR = "deviceLanding/GET_RECOMMENDATION_ERROR";

export const GET_NETWORK_OUTAGE_BEGIN = "deviceLanding/GET_NETWORK_OUTAGE_BEGIN";
export const GET_NETWORK_OUTAGE_SUCCESS = "deviceLanding/GET_NETWORK_OUTAGE_SUCCESS";
export const GET_NETWORK_OUTAGE_ERROR = "deviceLanding/GET_NETWORK_OUTAGE_ERROR";

export const GET_PROACTIVE_NOTIFICATION_BEGIN = "deviceLanding/GET_PROACTIVE_NOTIFICATION_BEGIN";
export const GET_PROACTIVE_NOTIFICATION_SUCCESS = "deviceLanding/GET_PROACTIVE_NOTIFICATION_SUCCESS";
export const GET_PROACTIVE_NOTIFICATION_ERROR = "deviceLanding/GET_PROACTIVE_NOTIFICATION_ERROR";

export const getCaptureResponse = (payload) => {
	let axConfig = {
		headers: { 
			pageName: "dsrDeviceLanding", 
			flowName: "Device"
		}
	};
	return postHttpClientRequest(
		apiUrl().deviceCaptureResponseUrl,
		payload,
		axConfig
	)
}


export const getRecommendation = (mtn) => dispatch => {
	if (apiUrl().callRecommendations === "false") {
		return;
	}

	dispatch(getRecommendationBegin());

	const onSuccess = successResp => {
		if (
			successResp &&
			successResp.data &&
			successResp.data.responseInfo &&
			successResp.data.responseInfo.responseCode == "00"
		) {
			dispatch(getRecommendationSuccess(successResp.data));
			let contextInfo = successResp?.data?.body?.nbxResponse?.serviceBody?.serviceRequest?.contextInfo;
		    let responseList = [];
		    successResp?.data?.body?.relatedTopics.map((tilesData) => {
			const responseData = {
				rank: `${tilesData?.pegaCard?.rank}`,
				propositionId: `${tilesData?.pegaCard?.propositionId}`,
				dispositionOptionId: '82',
				soiEngagementId: `${tilesData?.pegaCard?.soiEngagementId}`,
				tacticLocation: `${contextInfo?.pageContext}`,
			  };
			  responseList.push(responseData);
		})
		const payload = {
			"source": "deviceOverviewFeedbackRec",
			"contextInfo": {
				"callReason": `${contextInfo?.callReason}`,
				"category": `${contextInfo?.category}`,
				"subServiceName": `${contextInfo?.subServiceName}`,
				"pageContext": `${contextInfo?.pageContext}`,
				"sessionId": `${successResp?.data?.body?.sessionId}`
			},
			"customerResponse": {
				"responseList": responseList
			}
		}
		getCaptureResponse(payload);
		}
	};

	const onError = error => {
		dispatch(getRecommendationError(error));
	};

	const callMS = () => {
		let axConfig = {
			headers: { pageName: "dsrDeviceLanding", flowName: "Device" }
		};
		return getHttpClientRequest(
			apiUrl().deviceLandingPageRecommendationUrl,
			axConfig
		)
	};

	callMS()
		.then(msResp => {
			if (msResp && msResp.status == 200) {
				onSuccess(msResp);
			}
		})
		.catch(onError);
};

export const getNetworkOutage = (mtn) => dispatch => {
	if (apiUrl().callNetworkOutage === "false") {
		return;
	}

	dispatch(getNetworkOutageBegin());

	const onSuccess = networkRes => {
		if (
			networkRes &&
			networkRes.data &&
			networkRes.data.responseInfo &&
			networkRes.data.responseInfo.responseCode == "00"
		) {
			dispatch(getNetworkOutageSuccess(networkRes.data));
		}
	};

	const onError = error => {
		dispatch(getNetworkOutageError(error));
	};

	const callMS = () => {
		let axConfig = {
			headers: { contentType: "application/json", pageName: "dsrDeviceLanding", flowName: "Device" }
		};
		return getHttpClientRequest(
			apiUrl().networkOutageUrl,
			axConfig
		)
	};

	callMS()
		.then(msResp => {
			if (msResp && msResp.status == 200) {
				onSuccess(msResp);
			}
		})
		.catch(onError);
};

export const getProactiveNotification = () => (dispatch) => {
	if (apiUrl().callProActiveNotifications === "false") {
	  return;
	}
	dispatch(getProactiveNotificationBegin());
  
	const onSuccess = (responseNoti) => {
	  if (
		responseNoti &&
		responseNoti.data &&
		responseNoti.data.responseInfo &&
		responseNoti.data.responseInfo.responseCode == "00"
	  ) {
		dispatch(getProactiveNotificationSuccess(responseNoti.data));
	  }
	};
  
	const onError = (error) => {
	  dispatch(getProactiveNotificationError(error));
	};
  
	const callMS = () => {
	  const axConfig = {
		headers: {
		  contentType: "application/json",
		  pageName: "dsrDeviceLanding",
		  flowName: "Device",
		},
	  };
	  const data = {
		pageContext: "MVO_Device_Overview",
		category: "Alerts",
	  };
  
	  if (apiUrl().updateNickNameUrl?.indexOf("ApiData") > -1) {
		return getHttpClientRequest(apiUrl().proActiveNotificationUrl, axConfig);
	  } else {
		return postHttpClientRequest(
		  apiUrl().proActiveNotificationUrl,
		  data,
		  axConfig
		);
	  }
	};
  
	callMS()
	  .then((msResp) => {
		if (msResp && msResp.status == 200) {
		  onSuccess(msResp);
		}
	  })
	  .catch(onError);
};

export const setSelectedDevice = data => ({
	type: SET_SELECTED_DEVICE,
	data
});

export const setRecommendationValueCache = () => ({
	type: SET_RECOMMENDATION_VALUE_CACHE
});

export const getRecommendationBegin = () => ({
	type: GET_RECOMMENDATION_BEGIN,
});


export const getRecommendationSuccess = msResp => ({
	type: GET_RECOMMENDATION_SUCCESS,
	msResp
});

export const getRecommendationError = err => ({
	type: GET_RECOMMENDATION_ERROR,
	err
});

export const getNetworkOutageBegin = () => ({
	type: GET_NETWORK_OUTAGE_BEGIN,
});


export const getNetworkOutageSuccess = msResp => ({
	type: GET_NETWORK_OUTAGE_SUCCESS,
	msResp
});

export const getNetworkOutageError = err => ({
	type: GET_NETWORK_OUTAGE_ERROR,
	err
});

export const getProactiveNotificationBegin = () => ({
	type: GET_PROACTIVE_NOTIFICATION_BEGIN,
});
  
export const getProactiveNotificationSuccess = (msResp) => ({
	type: GET_PROACTIVE_NOTIFICATION_SUCCESS,
	msResp,
});
  
export const getProactiveNotificationError = (err) => ({
	type: GET_PROACTIVE_NOTIFICATION_ERROR,
	err,
});