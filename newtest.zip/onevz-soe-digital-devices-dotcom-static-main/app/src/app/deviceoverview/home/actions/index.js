export { getSections, purgeStore } from './getSections';
export { getRecommendation, setSelectedDevice, getNetworkOutage, getProactiveNotification } from './pageActions';