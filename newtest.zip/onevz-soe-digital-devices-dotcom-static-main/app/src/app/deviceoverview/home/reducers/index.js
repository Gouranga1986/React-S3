import {
  GET_DEVICE_LANDING_BEGIN,
  GET_DEVICE_LANDING_SUCCESS,
  GET_DEVICE_LANDING_ERROR
} from "../actions/getSections";

import {
  SET_SELECTED_DEVICE,
  GET_RECOMMENDATION_SUCCESS,
  GET_RECOMMENDATION_ERROR,
  GET_NETWORK_OUTAGE_SUCCESS,
  GET_NETWORK_OUTAGE_ERROR,
  GET_PROACTIVE_NOTIFICATION_SUCCESS,
  GET_PROACTIVE_NOTIFICATION_ERROR,    
} from "../actions/pageActions";

import { updateObject } from '../../../../shared/utilities/reducer';
import common from '../../../../shared/utilities/util';

const initialState = {
  isFetching: true,
  statusCode: "",
  statusMessage: "",
  errorMessage: '',
  errorDesc: '',
  actionName: '',
  actionValue: '',
  actionType: '',
  errorObj: {},
  sectionContentMetaData: {},
  selectedDevice: {},
  recommendation: {},
  isRecommendationFetching: true,
  recommendationStatusCode: '',
  recommendationStatusMessage: '',
  recommendationErrorMessage: '',
  recommendationErrorDesc: '',
  recommendationActionName: '',
  recommendationActionValue: '',
  recommendationActionType: '',
  recommendationErrorObj: '',
  isNetworkOutage: false,
  networkOutageDetail: {},
  isProactiveNotification: false,
  proactiveNotificationDetail: {}
};

export const getDevice_LandingBegin = (state, action) => {
  return updateObject(state, {
    isFetching: true
  });
};

export const getDevice_LandingSuccess = (state, action) => {
  return updateObject(state, {
    errorMessage: common.isError(action.msResp.responseInfo.responseCode, action.msResp.responseInfo.responseMessage, action.msResp.body),
    isFetching: false,
    statusCode: action.msResp.responseInfo.responseCode,
    statusMessage: action.msResp.responseInfo.responseMessage,
    sectionContentMetaData: action.msResp.body,
    errorDesc: common.isErrorDesc(action.msResp.responseInfo.responseCode, action.msResp.responseInfo.responseMessage, action.msResp.body),
    actionValue: common.isActionValue(action.msResp.responseInfo.responseCode, action.msResp.responseInfo.responseMessage, action.msResp.body),
    actionType: common.isActionType(action.msResp.responseInfo.responseCode, action.msResp.responseInfo.responseMessage, action.msResp.body),
    errorObj: action.msResp.responseInfo.responseCode !== "00" && action.msResp.responseInfo ? action.msResp.responseInfo.sectionErrors : null,
    actionName: common.isActionName(action.msResp.responseInfo.responseCode, action.msResp.responseInfo.responseMessage, action.msResp.body),
    selectedDevice: {}
  });
};

export const getDevice_LandingError = (state, action) => {
  let msResp = action && action.err && action.err.response && action.err.response.data;
  if(!msResp){
    msResp = action && action.err;
  }
  let responseCode = msResp && msResp.responseInfo && msResp.responseInfo.responseCode;
  let responseMessage = msResp && msResp.responseInfo && msResp.responseInfo.responseMessage;
  let body = msResp && msResp.body;
  return updateObject(state, {
    errorDesc: common.isErrorDesc(responseCode, responseMessage, body),
    isFetching: false,
    selectedDevice: {},
    statusCode: responseCode ? responseCode : '',
    statusMessage: common.isError(responseCode, responseMessage, body),
    errorMessage: common.isError(responseCode, responseMessage, body),
    sectionContentMetaData: {},
    actionName: common.isActionName(responseCode, responseMessage, body),
    actionValue: common.isActionValue(responseCode, responseMessage, body),
    actionType: common.isActionType(responseCode, responseMessage, body),
    errorObj: responseCode !== "00" && msResp && msResp.responseInfo ? msResp.responseInfo.sectionErrors : action.err,
  });
};

export const setSelectedDeviceValue = (state, action) => {
  return updateObject(state, {
    selectedDevice: action.data
  });
}

export const setRecommendationValue = (state, action) => {
  return updateObject(state, {
    recommendation: action.msResp.body,
    isRecommendationFetching: false,
    recommendationStatusCode: action.msResp.responseInfo.responseCode,
    recommendationStatusMessage: common.isError(action.msResp.responseInfo.responseCode, action.msResp.responseInfo.responseMessage, action.msResp.body),
    recommendationErrorMessage: common.isError(action.msResp.responseInfo.responseCode, action.msResp.responseInfo.responseMessage, action.msResp.body),
    recommendationActionName: common.isActionName(action.msResp.responseInfo.responseCode, action.msResp.responseInfo.responseMessage, action.msResp.body),
    recommendationActionType: common.isActionType(action.msResp.responseInfo.responseCode, action.msResp.responseInfo.responseMessage, action.msResp.body),
    recommendationActionValue: common.isActionValue(action.msResp.responseInfo.responseCode, action.msResp.responseInfo.responseMessage, action.msResp.body),
    recommendationErrorObj: action.msResp.responseInfo.responseCode !== "00" && action.msResp.responseInfo ? action.msResp.responseInfo.sectionErrors : null,
  });
}

export const setRecommendation_error = (state, action) => {
  let msResp = action && action.err && action.err.response && action.err.response.data;
  let responseCode = msResp && msResp.responseInfo && msResp.responseInfo.responseCode;
  let responseMessage = msResp && msResp.responseInfo && msResp.responseInfo.responseMessage;
  let body = msResp && msResp.body;
  return updateObject(state, {
    isRecommendationFetching: false,
    recommendation: {},
    recommendationStatusCode: responseCode ? responseCode : '',
    recommendationStatusMessage: common.isError(responseCode, responseMessage, body),
    recommendationErrorMessage: common.isError(responseCode, responseMessage, body),
    recommendationErrorDesc: common.isErrorDesc(responseCode, responseMessage, body),
    recommendationActionName: common.isActionName(responseCode, responseMessage, body),
    recommendationActionValue: common.isActionValue(responseCode, responseMessage, body),
    recommendationActionType: common.isActionType(responseCode, responseMessage, body),
    recommendationErrorObj: responseCode !== "00" && msResp && msResp.responseInfo ? msResp.responseInfo.sectionErrors : action.err,
  });
}

export const setNetworkOutageSuccess = (state, action) => {
  return updateObject(state, {
    networkOutageDetail: action.msResp.body,
    isNetworkOutage: true
  });
}

export const setNetworkOutageError = (state, action) => {
  return updateObject(state, {
    isNetworkOutage: false,
    networkOutageDetail: {}
  });
}

export const setProactiveNotificationSuccess = (state, action) => {
  return updateObject(state, {
    proactiveNotificationDetail: action.msResp.body,
    isProactiveNotification: true,
  });
};

export const setProactiveNotificationError = (state, action) => {
  return updateObject(state, {
    isProactiveNotification: false,
    proactiveNotificationDetail: {},
  });
};


const deviceLandingReducer = (state = initialState, action) => {
  const { type } = action;
  switch (type) {
    case GET_DEVICE_LANDING_BEGIN:
      return getDevice_LandingBegin(state, action);
    case GET_DEVICE_LANDING_SUCCESS:
      return getDevice_LandingSuccess(state, action);
    case GET_DEVICE_LANDING_ERROR:
      return getDevice_LandingError(state, action);
    case SET_SELECTED_DEVICE:
      return setSelectedDeviceValue(state, action);
    case GET_RECOMMENDATION_SUCCESS:
      return setRecommendationValue(state, action);
    case GET_RECOMMENDATION_ERROR:
      return setRecommendation_error(state, action);
    case GET_NETWORK_OUTAGE_SUCCESS:
      return setNetworkOutageSuccess(state, action);
    case GET_NETWORK_OUTAGE_ERROR:
      return setNetworkOutageError(state, action);
    case GET_PROACTIVE_NOTIFICATION_SUCCESS:
      return setProactiveNotificationSuccess(state, action);
    case GET_PROACTIVE_NOTIFICATION_ERROR:
      return setProactiveNotificationError(state, action);
    default:
      return state;
  }
};

export default deviceLandingReducer;
