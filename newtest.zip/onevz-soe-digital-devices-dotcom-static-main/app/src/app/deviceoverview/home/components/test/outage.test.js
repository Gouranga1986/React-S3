import Outage from '../outage';
import { act, render, screen, cleanup, fireEvent } from "@testing-library/react";

describe("For Outage file", () => {
    test("Outage  render", () => {
        const res = render(
            <Outage topMessage="Network Disruption Detected"
                ctaTextLabel="Go to network status"
                message="An outage might be affecting you"
                redirectUrl="/digital/nsa/secure/ui/support/network-events#/"
                goToMyNetworkStatus="/digital/nsa/secure/ui/support/network-events#/"
                customerType="Pe"
                userAccount="test"
                userId="1"
            />
        )
        expect(res).toBeTruthy()
    }
    )

    test("cover the vzdl object", () => {
        global.window.vzdl = {
            page: {
                channel: 'vzw'
            },
            target: {
                engagement: { intent: 'Account Management' },
                message: 'Network Disruption Detected'
            },
            user: {
                customerType: 'PE',
                authStatus: 'Logged In'
            }
        }
        const res = render(
            <Outage topMessage="Network Disruption Detected"
                ctaTextLabel="Go to network status"
                message="An outage might be affecting you"
                redirectUrl="/digital/nsa/secure/ui/support/network-events#/"
                goToMyNetworkStatus="/digital/nsa/secure/ui/support/network-events#/"
                customerType="Pe"
                userAccount="test"
                userId="1"
            />
        )
        expect(res).toBeTruthy()
    }
    )
})
