import React, { Component, Fragment } from 'react';
import styled from 'styled-components';
import { connect } from 'react-redux';
import { bindActionCreators } from 'redux';
import { ErrorBoundary } from '@vz/react-util';
import { Title, Body } from '@vds/typography';
import { Tabs, Tab } from '@vds/tabs';
import { TileContainer } from '@vds/tiles';
import { isRedirectedFromDetailPage } from "../../deviceDetail/actions/pageActions";
import { ListGroup, ListGroupItem, ListGroupItemTitle } from '@vds/lists';
import { Grid, Row, Col } from '@vds/grids';
import { Button, TextLink, TextLinkCaret } from '@vds/buttons';
import { Carousel } from '@vds/carousels';
import Loader from '../../../../shared/components/Loader/Loader';
import common from '../../../../shared/utilities/util';
import { logClickStream } from '../../../../shared/utilities/logger';
import * as deviceLandingActions from '../actions';
import { Notification } from '@vds/notifications';
import { getCaptureResponse } from '../actions/pageActions';
import { dispatchVzdlSubflow } from '../../../../shared/utilities/tagging';
import { setCookie,getCookie } from '../../../../shared/components/Helpers';
import SimFreezeBlockModal from '../../deviceDetail/components/SimFreezeBlockModal';
import  Outage  from '../components/outage';
import { finishMonitoring } from '../../../../shared/services/monitoring';
import { dispatchNotifyEvent } from '../../../../shared/utilities/tagging';

const TitleContainer = styled.div`
	margin-top: 56px;

	h1 {
		font-weight: 400;
	}
`;

const SubTitleContainer = styled.div`
	margin-top: 16px;
	
	p {
		font-weight: 400;
	}
`;

const TabContainer = styled.div`
	margin-top: 36px;
	
	ul {
		max-width:1232px;
		margin: 0 auto;
	}

	@media only screen
	and (min-device-width : 768px)
	and (max-device-width : 1024px)
	and (orientation : portrait) {
		ul {
			max-width:944px;
			margin:0 20px auto;
		}
	}
`;

const TabContentContainer = styled.div`
	background-color: #F6F6F6;
	padding-top: 52px;
	padding-bottom: 32px;
	padding-right: 20px;
	margin-top: 48px;

	#inner-tileContainer {
		display: flex;
		flex-direction: column;
	}

	[id^="carousel-container"]{
		padding-left: 0px;
	}
`;

const MyDeviceHeaderContainer = styled.div`
		// max-width: 1232px;
		margin: 0 auto;
		margin-bottom: 32px;
	h2 {
		font-weight: 700;
		font-size: 24px;
		line-height: 28px;
	}
`;

const ListGroupContainer = styled.div`
	padding: 48px 0;
`;


const RecommendationTileContainer = styled.div`
	// max-width: 1252px;
	// margin: 0 auto;
	margin-bottom: 32px;

	[id^="carousel-container"]{
		padding-left: 0px;
	}
	
	#inner-tileContainer {
		display: flex;
		flex-direction: column;
	}

	#tileContainer {
		background-color: #f6f6f6;
	}

	#column:first-child {
		padding-left: 0px;
	}
`;

const DeviceDetailContainer = styled.div`
  display: flex;
  flex-direction: column;
  justify-content: space-between;
  width: 100%;
  padding-top: 18px;
`;

const LeftContent = styled.div`
  width: 100%;
  display: flex;
  flex-direction: column;
`;

const RightContent = styled.div`
  width: 100%;
  padding-top: 10px;
`;

const ProductImg = styled.div`
  width: 100%;
  text-align: center;
  img {
    // height: 185px; 
    // width: 18%;
	max-width: 250px; 
  }

  ${(props) =>
		props.isMtnSuspended &&
		`
    img {
            opacity: 0.5;
        } 
    `}  
`;

const FiveGImg = styled.div`
	img {
		width: 30px; 
	}
`;

const UserRole = styled.div`
	p {
		font-weight: 400;
		font-size: 12px;
		line-height: 16px;
	}
`;

const Badge = styled.div`
  	padding: 10px 0px;
	p {
		font-weight: 400;
		font-size: 12px;
		line-height: 16px;
	}
    width: 100%;
    display: flex;
    justify-content: space-between;
`;

const TileWrapper = styled.div`
	display: flex;
	flex-direction: column;
	width: 100%;
`;

const DeviceName = styled.div`
  padding-top: 8px;
  margin-bottom:8px;
  h2 {
    font-weight: 700;
	font-size: 24px;
	line-height: 28px;
  }
`;

const DeviceMdnNumber = styled.div`
    p {
	font-weight: 400;
	font-size: 12px;
	line-height: 16px;
  }
`;

// const DeviceBrand = styled.div`
//   padding-top: 16px;
//   p {
//     font-weight: 400;
//     font-size: 12px;
//     line-height: 16px;
//     color: #6F7171;
//   }
// `;

const DeviceRemainningBalance = styled.div`
  padding-top: 16px;
  p {
    font-weight: 400;
    font-size: 14px;
    line-height: 16px;
	letter-spacing: 0.5px;
  }
`;

const DeviceCtaContainer = styled.div`
//   padding-top: 45px;
  	position: absolute;
	bottom: 16px;
	display: flex;
	flex-direction: row;
	align-items: baseline;

	button {
		line-height: 12px;
		margin-right: 10px;

		span {
			font-size: 12px;
    		padding: 12px 18px;
		}
	}

	a {
		line-height: 20px;
		margin-right: 10px;

		span {
			font-size: 14px;
		}
	}
`;

const RecommendationBadge = styled.div`
	padding-bottom: 24px;
	p {
		color: #6F7171;
		font-weight: 400;
		font-size: 12px;
		line-height: 16px;
	}
`;

const RecommendationTitle = styled.div`

	h2{
		font-weight: 700;
		font-size: 20px;
		line-height: 24px;
		letter-spacing: 1px;
	}
`;

const RecommendationSubTitle = styled.div`
	padding-top: 10px;
	p{
		font-weight: 400;
		font-size: 12px;
		line-height: 16px;
		letter-spacing: 1px;
		color: #000;
	}
`;

const StyledNotification = styled(Notification)`
	div[class^="ContentWrapper"]{
		align-items: center;
	}
`;

const IconContainer = styled(TextLinkCaret)`
	display: inline;
    position: absolute;
    right: 24px;
    bottom: 18px;
	cursor: pointer;
	border: none;
`;

// const ListGroupItemTitleContent = styled.span`
// 	font-size: 18px;
// 	line-height: 20px;
// `;

const TextLinkContainer = styled.div`
	position: relative;

	a {
		position: absolute;
		top: ${(props) => (props.isTab ? '9rem' : '4rem')};
		right: 1rem;
		font-weight: 400;
		font-size: 12px;
		line-height: 16px;
		z-index: 3;
	}
`;

const HeaderTitleWrapper = styled.div`
padding: 10px 0px;
width:70%
`;

const DeviceCtaContainerAddLine = styled.div`
//   padding-top: 45px;
  	position: absolute;
	bottom: 16px;
	display: flex;
	flex-direction: row;
	align-items: baseline;
	width:100%;

	button {
		line-height: 12px;
		margin-right: 10px;

		span {
			font-size: 12px;
    		padding: 12px 18px;
		}
	}

	a {
		line-height: 20px;
		margin-right: 10px;

		span {
			font-size: 14px;
		}
	}
`;


class DevicesOverview extends Component {
	constructor(props) {
		super(props);

		this.state = {
			impressionSent: false,
			showSimFreezeModel: false,      
			showSimFreezeNotification: false, 
			simFreezeDuration: 0,
			simUnfreezeTimeStamp: ""
		}

		this.renderDevices = this.renderDevices.bind(this);
		this.renderRecommendationTile = this.renderRecommendationTile.bind(this);

		this.getOnClickInfo = common.getOnClickInfo.bind(this);
	}
	
	setSlideAria() {
		setTimeout(() => {
			let slotContainer = document.querySelectorAll('.slotContainer');
			if (typeof (slotContainer) != 'undefined' && slotContainer != null) {
				slotContainer.forEach((item, index) => {
					console.log("inside setSlideAria");
					let disabledSlide = item.querySelector('.disabledSlide');
					if (typeof (disabledSlide) != 'undefined' && disabledSlide != null) {
						item?.querySelector('div[role="button"]')?.setAttribute('tabindex', '-1');
						item?.querySelector('div[role="button"]')?.removeAttribute('role');
						console.log("disabledSlide", item?.querySelector('div[role="button"]'));

					} else {
						// let devicename = item?.querySelector('.devicename');
						// let devicenameText = typeof(devicename) != 'undefined' && devicename != null ? devicename.textContent : '';
						item?.querySelector('div[role="button"]')?.setAttribute('aria-label', '');
						console.log("item.querySelector", item?.querySelector('div[role="button"]'));
					}

				});
			}
		}, 3000);
	}

	componentWillMount() {
		if (reactGlobals && reactGlobals.routeLog && reactGlobals.routeLog.confirmationShown) {
			this.props.actions.purgeStore();
		}
	}

	componentDidMount() {
		if (this.props.statusCode !== '00' || (this.props.isRedirectedFromDetailPage && this.props.isNickNameUpdated) || (reactGlobals && reactGlobals.routeLog && reactGlobals.routeLog.confirmationShown)) {
			console.log("inside componentDidMount");		
			this.props.actions.getSections();
			this.props.actions.isRedirectedFromDetailPage(false);
			this.props.actions.getRecommendation();
			this.props.actions.getNetworkOutage();
			this.props.actions.getProactiveNotification();
			logClickStream('PAGE-LOADED', 'PAGE-LOADED', 'PAGE-LOADED', 'landingPage');
		
		}

		if (!(typeof reactGlobals === 'undefined' || reactGlobals === null)
			&& reactGlobals && reactGlobals.routeLog && reactGlobals.routeLog.confirmationShown) {
			reactGlobals.routeLog.confirmationShown = false;
		}

		this.setSlideAria();
	}

	componentDidUpdate(prevProps) {
		if (!this.props.isFetching) {
			finishMonitoring()
		}
		if (this.props.recommendation && this.props.recommendation.relatedTopics && this.props && this.props.proactiveNotificationDetail && this.props.proactiveNotificationDetail.pegaCards && this.props.proactiveNotificationDetail.pegaCards.pegaSessionId) {
			let impression = '';
			let relatedTopics = [];

			const pegaId = this.props.proactiveNotificationDetail.pegaCards.pegaSessionId;

			if (this.props.recommendation && this.props.recommendation[`relatedTopics`]) {
				relatedTopics = this.props.recommendation[`relatedTopics`];
				relatedTopics = relatedTopics.filter((value, index) => (index < 2));
				if (relatedTopics.length) {
					relatedTopics?.forEach((value, index) => {
						if (!impression.length) {
							impression += `L1|P${index + 1}|recommendationTileSection|||||Recommendation Tile`;
						} else {
							impression += `^L1|P${index + 1}|recommendationTileSection|||||Recommendation Tile`;
						}
					});
				}
			}
			if (!this.state.impressionSent) {
				this.setState({ impressionSent: true }, () => {
					if (window.vztag?.api) {
						window.vztag.api.dispatch("impression", {
							"list": impression,
							data: {
								utils:
									{ athenaSession: pegaId }
							}
						});
					}
				})
			}
		}
		let pageContent;
		if ((this?.props?.deviceLandingInfoSection?.sections?.length != prevProps?.deviceLandingInfoSection?.sections?.length) && this?.props?.deviceLandingInfoSection?.sections) {
			pageContent = common.getContentFromSection(this?.props?.deviceLandingInfoSection, 'devicesLandingMainSection');
			pageContent = pageContent?.sections?.[0];
			const mobileDeviceList = pageContent?.data?.mobileDeviceList || [];
			const isPearlDevice = mobileDeviceList?.some(list => list?.pearlTrialFlow);
			if (isPearlDevice) {
				dispatchVzdlSubflow('DVM');
				sessionStorage.setItem('pearlTrialFlow', "true");
     			 setCookie('pearlTrialFlow', "true");
			}
			
		}
			
	}

	handleManageDeviceCtaClick = (data, manage_device_click_info) => {
		let pageContent;
		if (this.props.deviceLandingInfoSection && this.props.deviceLandingInfoSection.sections) {
			pageContent = common.getContentFromSection(this.props.deviceLandingInfoSection, 'devicesLandingMainSection');
			pageContent = pageContent?.sections[0];
		}
		const pageActions = pageContent && pageContent.actions;
		this.props.actions.setSelectedDevice(data);
		if (data?.router) {
			const action = common.getActionByKey(pageActions, "manageRouterAction");
			const actionValue = action && action.actionValue;
			window.location.href = `${actionValue}${data?.encryptedMtnAES}`;
		} else if (data?.networkExtender) {
			const action = common.getActionByKey(pageActions, "manageNetworkExtender");
			const actionValue = action && action.actionValue;
			window.location.href = `${actionValue}?deviceid=${data?.deviceId}`;
		} else {
			manage_device_click_info?.onclick();
		}
	}

    /* istanbul ignore next */
	handleArrowClick = (url, pegaCard) => {
		let relatedTopicsData = this.props?.recommendation?.nbxResponse?.serviceBody?.serviceRequest;
		const payload =
		{
			"source": "deviceOverviewFeedbackRec",
			"contextInfo": {
				"callReason": `${relatedTopicsData?.contextInfo?.callReason}`,
				"category": `${relatedTopicsData?.contextInfo?.category}`,
				"subServiceName": `${relatedTopicsData?.contextInfo?.subServiceName}`,
				"pageContext": `${relatedTopicsData?.contextInfo?.pageContext}`,
				"sessionId": `${this.props?.recommendation?.sessionId}`
			},
			"customerResponse": {
				"responseList": [
					{
						"dispositionOptionId": "81",
						"propositionId": `${pegaCard?.propositionId}`,
						"rank": `${pegaCard?.rank}`,
						"soiEngagementId": `${pegaCard?.soiEngagementId}`,
						"tacticLocation": `${relatedTopicsData?.contextInfo?.pageContext}`
					}
				]
			}
		}
		getCaptureResponse(payload).then(() => {
			if (url.includes('http')) {
				window.location.href = url;
			} else {
				window.location.pathname = url;
			}
		});

	}

    /* istanbul ignore next */
	handleShopDeviceCtaClick = (url) => {
		window.location.href = "/shop/online/free-cell-phones/";
	}

	
    /* istanbul ignore next */
	handleSimFreezeModalChange = (data) => {
		this.setState({ showSimFreezeModel: data });
	};

    /* istanbul ignore next */
	handleSimFreezeCancel = () => {
		this.setState({ showSimFreezeModel: false, simFreezeDuration: 0 });
	};

    /* istanbul ignore next */
	handleSimFreezeNotificationCancel = () => {
		this.setState({ showSimFreezeNotification: false, simFreezeDuration: 0, simUnfreezeTimeStamp: "" });
	};

	
	renderDevices(device) {
		let pageContent;
		if (this.props.deviceLandingInfoSection && this.props.deviceLandingInfoSection.sections) {
			pageContent = common.getContentFromSection(this.props.deviceLandingInfoSection, 'devicesLandingMainSection');
			pageContent = pageContent?.sections[0];
		}
		const pageItems = pageContent && pageContent.contents && pageContent.contents[0].items;
		const pageActions = pageContent && pageContent.actions;
		const manageDeviceActionKey = pageContent && common.getActionKey(pageItems, 'manageDeviceBtn');
		const manage_device_click_info = this.getOnClickInfo(pageContent, manageDeviceActionKey);

		const upgradeDeviceActionKey = pageContent && common.getActionByKey(pageActions, "upgradeDeviceAction");
		const actionValue = upgradeDeviceActionKey && upgradeDeviceActionKey.actionValue;

		const reConnectDeviceActionKey = pageContent && common.getActionByKey(pageActions, "reconnecAction");

		const mobileDeviceList = pageContent && pageContent.data && pageContent.data.mobileDeviceList || [];

		const devicesList = mobileDeviceList.filter(list => list.isSecondNumber == true);

		const singleDevice = devicesList && devicesList.filter(deviceMtn => deviceMtn.mtn == device.secondMtn)

		const simfreezeInfoValue = (device?.simFreezeInfo?.simFreezeCode+device?.simFreezeInfo?.simUnfreezeTimeStamp+device?.simFreezeInfo?.isBlocked);
		const simFreezeKey = pageContent && common.cipher(simfreezeInfoValue, 29);
		// console.log("simFreezeKey CHECK ==> ", simFreezeKey, " == ", device?.simFreezeInfo?.simFreezeDetails);
		const familyLineFFlag = this.props.deviceLandingInfoSection?.featureFlags?.familyLineDigitalFlowControlFFlag;
		let index = '';
		if (device?.router) {
			index = pageContent && pageContent.data[`fiveGDeviceList`].findIndex((value) => (value.mtn == device.mtn));
		} else {
			index = pageContent && pageContent.data[`mobileDeviceList`].findIndex((value) => (value.mtn == device.mtn));
		}
		const label = device?.isMtnSuspended ? common.getItemValue(pageItems, 'deviceSuspendedReconnect') : common.getItemValue(pageItems, 'upgradeDeviceBtn');
		if (device?.mtn == "addaline") {
			console.log("deviceIndex zero.......");
			return (
				<TileContainer
					{...device}
					key={`${device.mtn}`}
					id={"tileContainer-" + index}
					backgroundColor="#ffffff"
					backgroundImage="none"
					padding="16px 24px 16px 16px"
					height="480px"
					onClick={() => { }}
					ariaLabel=''
				>
					<TileWrapper >
						<HeaderTitleWrapper>
							<Title size="medium" bold={true} >Get a phone on us with a new line.</Title>
						</HeaderTitleWrapper>
					</TileWrapper>

					<DeviceCtaContainerAddLine>
						<Button
							use="primary"
							width="50%"
							data-testid="shop phones button"
							data-track="shop phones button"
							ariaLabel="shop phones"
							onClick={() => this.handleShopDeviceCtaClick()}
							tabIndex={device.inView ? 0 : -1}
						>
							Shop phones
						</Button>
					</DeviceCtaContainerAddLine>
				</TileContainer>
			)
		}
		else
			return (
				<TileContainer
				{...device}
					key={`${device.mtn}`}
					id={"tileContainer-" + index}
					backgroundColor="#ffffff"
					backgroundImage="none"
					padding="16px 24px 16px 16px"
					height="480px"
					onClick={() => { }}
					ariaLabel=''
				>
					<TileWrapper >
						<Badge>
							<Title primitive="p">
								{device?.isMtnSuspended && common.getItemValue(pageItems, "deviceSuspended")}
								{!device?.isMtnSuspended && device?.pendingLineChange && common.getItemValue(pageItems, 'pendingLineChangeText')}
								{/* {!device?.isMtnSuspended && device?.upgradeEligible && !device?.pendingLineChange && common.getItemValue(pageItems, 'eligibleforUpgrade')} */}
							</Title>
						
								<FiveGImg>
									{device.device5GE ? (<img src="https://ss7.vzw.com/is/image/VerizonWireless/5g-logo-d-072822?$pngalpha$&scl=2" />): (<span style={{padding: '10px'}}> </span>)}
								</FiveGImg>
						
						</Badge>
						<div>
							<DeviceDetailContainer className={device.isMtnSuspended ? "disabledSlide" : null}>
								<LeftContent>
									<ProductImg isMtnSuspended={device?.isMtnSuspended}>
										<img src={device?.images?.mediumImage} />
									</ProductImg>
								</LeftContent>
								<RightContent>
									{device?.userRole && <UserRole>
										<Body color={device.isMtnSuspended ? "#a7a7a7" : "#6F7171"}>
											<span className="role" data-cs-mask>{device?.userRole}</span>
										</Body>
									</UserRole>}
									{device?.deviceName && <DeviceName>
										<Title
											size="small"
											primitive="h2"
											color={device?.isMtnSuspended ? "#a7a7a7" : "#000000"}
										>
											<span className="devicename" data-cs-mask>{common?.truncate(device?.deviceName, 15)}</span>
										</Title>
									</DeviceName>}
									{device?.displayMtn && <DeviceMdnNumber>
										<Body color={device?.isMtnSuspended ? "#a7a7a7" : "#000000"}>
											<span className="mdn" data-cs-mask>{device?.displayMtn}</span>
										</Body>
									</DeviceMdnNumber>}
									{device?.secondMtn && singleDevice?.[0] && <DeviceMdnNumber data-testid="secondNum">
										<Body color={device?.isMtnSuspended ? "#a7a7a7" : "#6F7171"}>
											<span className="contains-PII mdn" data-cs-mask>{singleDevice[0]?.displayMtn} {common.getItemValue(pageItems, "secondNumber")}</span>
										</Body>
									</DeviceMdnNumber>}

									{device?.remainingBalance && (
										<DeviceRemainningBalance>
											<Title primitive="p" color={device?.isMtnSuspended ? "#a7a7a7" : "#000000"}>
												{`${common.getItemValue(pageItems, 'remainingBalanceText')}${device?.remainingBalance}`}
											</Title>
										</DeviceRemainningBalance>
									)}

									<DeviceCtaContainer>
										<Button
											use="secondary"
											data-testid={`managedeviceCtaTestId${index}`}
											ariaLabel={`${common.getItemValue(pageItems, 'manageDeviceBtn')} ${device?.deviceName} ${device?.displayMtn}`}
											data-track={`${common.getItemValue(pageItems, 'manageDeviceBtn')}`}
											onClick={() => this.handleManageDeviceCtaClick(device, manage_device_click_info)}
											tabIndex={device.inView? 0 : -1 }
										>
											{common.getItemValue(pageItems, 'manageDeviceBtn')}
										</Button>
										{device?.pearlTrialFlow ? 
										  <TextLink
											type="standAlone"
											data-testid = 'pearlTrialBtn'
											data-track= 'Join now'
											tabIndex={device.inView ? 0 : -1}
											onClick={() => {
											let actionKey = pageContent && common.getActionKey(pageItems, `pearlTrialBtn`);
											const actionKeyValue = pageContent && common.getActionByKey(pageActions, actionKey);
											const actionValue = actionKeyValue && actionKeyValue.actionValue;
											window.location.href = `${actionValue}`;
											}}
											>
											{common.getItemValue(pageItems, 'pearlTrialBtn')}
                                          </TextLink> : !device?.networkExtender && !device?.router && (device?.upgradeEligible || device?.isMtnSuspended) && (device?.skuId != 'FMTLK')  && <TextLink
											type="standAlone"
											data-testid={`upgradeDeviceBtnTestId${index}`}
											ariaLabel={`${label} ${device?.deviceName} ${device?.displayMtn}`}
											data-track={`${label}`}
											// data-track={`L1|P${index + 1}|${device?.router ? `router` : `mobile`}DeviceTileSection||||||${common.getItemValue(pageItems, 'upgradeDeviceBtn')}`}
    										/* istanbul ignore next */
											onClick={() => {
												if(simFreezeKey === device?.simFreezeInfo?.simFreezeDetails) {
												if(device?.simFreezeInfo?.simFreezeCode == "F" && device?.simFreezeInfo?.isBlocked == "Y") {
													this.setState({
														showSimFreezeModel: true, 
														simFreezeDuration: device?.simFreezeInfo?.simFreezeDuration, 
														simUnfreezeTimeStamp: device?.simFreezeInfo?.simUnfreezeTimeStamp 
													});  // Open SimFreeze Popup
												} else if(device?.simFreezeInfo?.simFreezeCode == "N" && device?.simFreezeInfo?.isBlocked == "Y") {
													this.setState({
														showSimFreezeNotification: true, 
														simFreezeDuration: device?.simFreezeInfo?.simFreezeDuration,
														simUnfreezeTimeStamp: device?.simFreezeInfo?.simUnfreezeTimeStamp
													});  // Open SimFreeze Notification
													dispatchNotifyEvent("Disable SIM protection", "Upgrade are blocked");
												} else { // simFreezeInfo?.simFreezeCode == "U/N" && simFreezeInfo?.isBlocked == "N/N"
													if (device?.isMtnSuspended)
														window.location.href = `${reConnectDeviceActionKey.actionValue}`;
													else {
														if (device?.secondMtn) {
															const secondNumberObj = {
																isSecondNumber: true,
																primaryMtn: device?.mtn,
																secondMtn: device?.secondMtn,
															};
															sessionStorage.setItem('secondaryProcessingMTN', JSON.stringify(secondNumberObj));
														}
														if (device?.encryptedMtnDES) {
															window.location.href = `${actionValue}${device?.encryptedMtnDES}&dc=${device?.deviceCategory}`;
														}
														else {
															window.location.href = `${actionValue}${device?.mtn}&dc=${device?.deviceCategory}`;
														}
													}
												}
												} else {
												  window.location.reload();
												}
											}}
											tabIndex={device.inView ? 0 : -1}

										>
											{label}
										</TextLink>}
									</DeviceCtaContainer>
								</RightContent>
							</DeviceDetailContainer>

						</div>
					</TileWrapper>
				</TileContainer>
			);
	}

	renderRecommendationTile(tile, index) {
		return (
			<Col id="column" key={`${index}`}>
				<TileContainer
					key={`${index}`}
					id="tileContainer"
					backgroundImage="none"
					padding="16px 24px 24px 24px"
					aspectRatio="1:1"
					height="222px"
				>
					<RecommendationBadge>
						<Body primitive="p">
							{tile.tileCategory}
						</Body>
					</RecommendationBadge>
					{tile.tileHeader.length > 0 && tile.tileHeader.map((header, index) => (
						<RecommendationTitle key={`${header}_${index}`}>
							<Title primitive="h3" bold={true}>{header}</Title>
						</RecommendationTitle>
					))}
					{tile.tiletText.length > 0 && tile.tiletText.map((text, index) => (
						<RecommendationSubTitle key={`${text}_${index}`}>
							<Title primitive="p">{text}</Title>
						</RecommendationSubTitle>
					))}
					{tile.tileLink && tile.tileLink !== '' && (
						<IconContainer
							data-track={`L1|P${index + 1}|recommendationTileSection|||||${tile?.tileHeader || ''}|caret`}
							onClick={() => this.handleArrowClick(tile.tileLink, tile.pegaCard)}
							ariaLabel={tile.tileHeader}
						>
						</IconContainer>
					)
					}
				</TileContainer>
			</Col>
		);
	}

	renderLinkList = (singleLink) => {
		let pageContent;
		if (this.props.deviceLandingInfoSection && this.props.deviceLandingInfoSection.sections) {
			pageContent = common.getContentFromSection(this.props.deviceLandingInfoSection, 'devicesLandingMainSection');
			pageContent = pageContent?.sections[0];
		}
		let pageItems = pageContent && pageContent.contents && pageContent.contents[0].items;

		return <Col key={`${singleLink}`} className={`${singleLink}`} colSizes={{ tablet: 6, desktop: 6 }}>
			<ListGroup
				topLine={false}
				bottomLine={true}
				surface="light"
				viewport="mobile"
			>
				<ListGroupItem
					ariaLabel={`${common.getItemValue(pageItems, `${singleLink}`)}`}
					actionElement="icon"
					onClick={() => {
						let actionKey = pageContent && common.getActionKey(pageItems, `${singleLink}`);
						let click_info = this.getOnClickInfo(pageContent, actionKey);
						click_info?.onclick();
					}}
				>
					<ListGroupItemTitle bold={false}>
						<span data-track={`${common.getItemValue(pageItems, `${singleLink}`)}`} aria-label={`${common.getItemValue(pageItems, `${singleLink}`)}`}>{common.getItemValue(pageItems, `${singleLink}`)}</span>
					</ListGroupItemTitle>
				</ListGroupItem>
			</ListGroup>
		</Col>
	}

    /* istanbul ignore next */
	handleClickForError = (actionType, actionValue) => {
		if (actionType === "http") {
			window.location.assign(actionValue);
		} else if (actionType === "route") {
			window.location.hash = actionValue;
		}
	}

	
	//  pegaCardDataAssign = (data,jsonPayloadDateTime,eventId) => {
	// 	const payloadData = {pegaTiles:[]};
	// 	PegaCard.rank = data?.rank;
	// 	 PegaCard.cardId = data?.cardId;
	// 	 PegaCard.propositionId = data?.propositionId; 
	// 	 PegaCard.dispositionOptionId = data?.dispositionOptionId ? data?.dispositionOptionId : "82";
	// 	 PegaCard.soiEngagementId = data?.soiEngagementId; 
	// 	 PegaCard.tacticLocation = data?.tacticLocation; 
	// 	 PegaCard.ctaReference = data?.ctaReference; 
	// 	 PegaCard.category = data?.category; 
	// 	 PegaCard.pegaSessionId = data?.pegaSessionId;
	// 	 PegaCard.dateAndMonth = data?.dateAndMonth;
	// 	 PegaCard.tileName = data?.tileName;
	// 	 PegaCard.jsonPayloadDateTime = jsonPayloadDateTime,
	// 	 PegaCard.eventId = eventId

	// 	 payloadData["pegaTiles"].push(PegaCard);

		 
	// 	 //outageBannerResponse(payloadData,1)
	// 	}
	goToMyNetworkStatus = () => {

		//PegaCard.dispositionOptionId = "81";
		//outageBannerResponse(PegaCard,3)
		window.location.href = this.props.networkOutageDetail.data.ctaUrl;
	}
	
	render() {
		let pageContent;
		if (this.props.deviceLandingInfoSection && this.props.deviceLandingInfoSection?.sections) {
			pageContent = common.getContentFromSection(this.props.deviceLandingInfoSection, 'devicesLandingMainSection');
			if(pageContent){
				pageContent = pageContent?.sections[0];
			}else {
			window.location.reload();
			}
		}

		const pageItems = pageContent && pageContent.contents && pageContent.contents[0].items;
		let pageData = pageContent && pageContent.data && pageContent.data;

		const mobileDeviceList = pageContent && pageContent.data && pageContent.data.mobileDeviceList || [];

		// const devicesList = mobileDeviceList;//mobileDeviceList.filter(list => list.isSecondNumber == false);
		let devicesList = [];

		const isPearlTrial = mobileDeviceList.some(data => data.pearlTrialFlow) || false;
     if (!isPearlTrial) {
      devicesList.push(
        {
          "mtn": "addaline",
          "displayMtn": "addaline"
        }
      )
     }

		if (mobileDeviceList?.length) {
			mobileDeviceList?.forEach((singleDevice, index) => {
				if (!singleDevice?.isSecondNumber) {
					devicesList.push(singleDevice);
				}
			})
		}

		const fiveGDeviceList = pageContent && pageContent.data && pageContent.data.fiveGDeviceList || [];

		const reviewFiveGActionKey = pageContent && common.getActionKey(pageItems, 'review5gCoverageBtn');
		const review_five_g_click_info = this.getOnClickInfo(pageContent, reviewFiveGActionKey);

		const gotoCoverageMapActionKey = pageContent && common.getActionKey(pageItems, 'gotoCoverageMapBtn');
		const goto_our_coverage_map = this.getOnClickInfo(pageContent, gotoCoverageMapActionKey);
		
		console.log("gotoCoverageMapActionKey", gotoCoverageMapActionKey);

		let relatedTopics = [];
		const pearlTrial = mobileDeviceList?.find(
			(list) => list?.pearlTrialFlow == true
		  );
		if (this.props.recommendation && this.props.recommendation.relatedTopics) {
			relatedTopics = this.props.recommendation.relatedTopics;
			relatedTopics = relatedTopics.filter((value, index) => (index < 2));
		}

		// let linkList = ['addALineBtn', 'getAccessoriesBtn', 'shopADevicetBtn', 'activateDeviceBtn', 'managePlanBtn', 'bringDeviceBtn', 'troubleshootDeviceBtn'];

		const deviceLinkList = pageContent && pageContent?.data && pageContent?.data?.deviceLandingLinks || {};

		let linkList  = [];

		Object.keys(deviceLinkList)?.forEach((singleLinkValue) => {
			if (deviceLinkList[`${singleLinkValue}`]) {
				linkList.push(singleLinkValue);
			}
		});		

		if(pearlTrial?.pearlTrialFlow){
			linkList = ['checkNetworkCompatibiltyBtn', 'pearlTrialReviewPlanBtn'];
		  }
		if (pageContent?.data?.deviceLandingLinks?.reviewPlanBtn && pageData && pageData[`checkNetworkCompatibiltyText`] == true && !pearlTrial?.pearlTrialFlow){
			linkList.splice(3, 0, 'checkNetworkCompatibiltyBtn');
		}
		else if(!pearlTrial?.pearlTrialFlow && pageData && pageData[`checkNetworkCompatibiltyText`] == true) {
			linkList.splice(4, 0, 'checkNetworkCompatibiltyBtn');
		}

		// if (!pearlTrial?.pearlTrialFlow && pageData && pageData[`checkNetworkCompatibiltyText`] == true) {
		// 		linkList.splice(4, 0, 'checkNetworkCompatibiltyBtn');
		// 	}

		const proactiveNotificationDetail = this.props.proactiveNotificationDetail;
				let proactiveNotificationCTAData = [];

		if (proactiveNotificationDetail?.cta) {
			proactiveNotificationCTAData = proactiveNotificationDetail.cta.map(
				(data) => {
					return {
						children: data.linkHeader,
						"data-track": JSON.stringify({
							type: "link",
							name: data.linkHeader,
							event: "event70",
						}),
						onClick: () => {
							if (data.linkUrl !== "") {
								window.location.href = data.linkUrl;
							}

						},
					};
				}
			);
		}
		
	

		console.log('deviceoverview render---', this.props);
		if (!this.props.isFetching) {
			//const pegaData = this.props?.networkOutageDetail?.data?.pegaCards[0];
			//const jsonPayloadDateTime = this.props?.networkOutageDetail?.data?.jsonPayloadDateTime;
			//const eventId = this.props?.networkOutageDetail?.data?.eventId;

			//this.pegaCardDataAssign(pegaData,jsonPayloadDateTime,eventId)
			return (
				<div className={`${this.props.statusCode !== "00" ? `main grid` : ``}`} id="deviceSection">
					<ErrorBoundary
                        errorcode={this.props.statusCode}
						title={{text: this.props.errorMessage, size: 'small', width: '100%',margin:'24px 0px 10px 0px'}}
                        message={ {text: this.props.errorDesc, size: 'small', width: '100%', margin:'5px 0px'}}
                        action={ {name: this.props.actionName, value: () => this.handleClickForError(this.props.actionType, this.props.actionValue), margin:'50px 0px' } }
                    >
						<Fragment>
							<div data-testid="DevicesOverviewTestId"></div>
							{this.props.isProactiveNotification &&
								proactiveNotificationDetail?.controls &&
								proactiveNotificationDetail?.controls["1"]?.trim() !==
								"" && (
									<StyledNotification
										type="warning"
										title={this.props.proactiveNotificationDetail?.controls["1"]}
										buttonData={proactiveNotificationCTAData}
										fullBleed
										inlineTreatment={false}
									/>
								)}
							{this.props.isNetworkOutage && this.props.networkOutageDetail?.data?.topMessage && this.props.networkOutageDetail?.data?.topMessage.trim() !== '' &&
								<Outage topMessage ={this.props.networkOutageDetail?.data?.topMessage}
								ctaTextLabel={this.props.networkOutageDetail?.data?.ctaTextLabel}
								message={this.props.networkOutageDetail?.data?.message}
								redirectUrl={this.props.networkOutageDetail.data.ctaUrl}
								goToMyNetworkStatus={this.goToMyNetworkStatus}
								deviceOverviewVDSComplianceFFlag={this.props.networkOutageDetail?.data?.deviceOverviewVDSComplianceFFlag}
                                customerType={this.props.deviceLandingInfoSection?.pageAttributes[3]?.itemValue}
                                userAccount={this.props.deviceLandingInfoSection?.pageAttributes[1]?.itemValue}
                                userId={this.props.deviceLandingInfoSection?.pageAttributes[2]?.itemValue}
								/>
							}
							
							

							{this.state.showSimFreezeNotification && (
								<Notification
									type='warning'
									title={common.getItemValue(pageItems, 'SIMFreezeNotificationTitle').replace('<unfreeze timestamp>', this.state.simUnfreezeTimeStamp)}
									subtitle={common.getItemValue(pageItems, 'SIMFreezeNotificationDesc').replace('<thaw threshold>', this.state.simFreezeDuration)}
									fullBleed={true}
									inlineTreatment={false}
									disableFocus={false}
									layout='horizontal'
									onCloseButtonClick={this.handleSimFreezeNotificationCancel}
								/>
							)}
							
							{this.state.showSimFreezeModel && (
								<SimFreezeBlockModal
									handleModalChange={this.handleSimFreezeModalChange}
									handleCancel={this.handleSimFreezeCancel}
									showModal={this.state.showSimFreezeModel}
									deviceDetailInfoSection={this.props.deviceLandingInfoSection}
									simFreezeDuration={this.state.simFreezeDuration}
								/>
							)}

							<TitleContainer className='grid main'>
								<Title
									size="large"
									primitive="h1"
								>
									{pearlTrial?.pearlTrialFlow ? common.getItemValue(pageItems, "pearlHeaderText") : common.getItemValue(pageItems, "headerText")}
								</Title>
							</TitleContainer>
							<SubTitleContainer className='grid main'>
								<Body
									color="#6F7171"
								>
                                  {pearlTrial?.pearlTrialFlow ? common.getItemValue(pageItems, "pearlSubHeaderText") : common.getItemValue(pageItems, "subHeaderText")}
								</Body>
							</SubTitleContainer>
							<TextLinkContainer
								className="grid main"
								isTab={devicesList.length !== 0 && fiveGDeviceList.length !== 0}
							>
								{isPearlTrial ? <TextLink
									type="standAlone"
									onClick={goto_our_coverage_map?.onclick}
								>
									{common.getItemValue(pageItems, "gotoCoverageMapBtn")}
								</TextLink> :
									<TextLink
										type="standAlone"
										onClick={review_five_g_click_info?.onclick}
									>
										{common.getItemValue(pageItems, "review5gCoverageBtn")}
									</TextLink>
								}
							</TextLinkContainer>

							{(devicesList.length !== 0 && fiveGDeviceList.length !== 0) && <TabContainer>
								<Tabs
									orientation="horizontal"
									indicatorPosition="bottom"
									onTabChange={
    									/* istanbul ignore next */
										(event, index) => {
											const checkNet = document.querySelector('.checkNetworkCompatibiltyBtn')
											if (index === 1 && checkNet) {
												checkNet.style.display = 'none'
											}
											else if (index === 0 && checkNet) {
												checkNet.style.display = 'block'
											}
											this.setSlideAria();
										}
									}
								>
									<Tab label="Mobile" >
										<TabContentContainer>
											<div className='main grid'>
												<Carousel
													layout="3UP"
													gutter="24px"
													peek="standard"
													surface="light"
													paginationFill="light"
													paginationInset="12px"
													paginationDisplay="onHover"
													aspectRatio="1:2"
													data={devicesList}
													renderItem={(device) => this.renderDevices(device)}
												/>
											</div>
										</TabContentContainer>
									</Tab>
									<Tab label="5G Home">
										<TabContentContainer>
											<div className='main grid'>
												<Carousel
													layout="3UP"
													gutter="24px"
													peek="standard"
													surface="light"
													paginationFill="light"
													paginationInset="12px"
													paginationDisplay="onHover"
													aspectRatio="1:2"
													data={fiveGDeviceList}
													renderItem={(device) => this.renderDevices(device)}
												/>
											</div>
										</TabContentContainer>
									</Tab>
								</Tabs>
							</TabContainer>}
							<TabContainer>

							</TabContainer>
							{(fiveGDeviceList.length == 0 && devicesList.length !== 0) && <TabContentContainer>
								<div className='main grid'>
									<Carousel
										layout="3UP"
										gutter="24px"
										peek="standard"
										surface="light"
										paginationFill="light"
										paginationInset="12px"
										paginationDisplay="onHover"
										aspectRatio="1:2"
										data={devicesList}
										renderItem={(device) => this.renderDevices(device)}
									/>
								</div>
							</TabContentContainer>}
							{(devicesList.length == 0 && fiveGDeviceList.length !== 0) && <TabContentContainer>
								<div className='main grid'>
									<Carousel
										layout="3UP"
										gutter="24px"
										peek="standard"
										surface="light"
										paginationFill="light"
										paginationInset="12px"
										paginationDisplay="onHover"
										aspectRatio="1:2"
										data={fiveGDeviceList}
										renderItem={(device) => this.renderDevices(device)}
									/>
								</div>
							</TabContentContainer>}

							<ListGroupContainer className='grid main'>
								<Grid
									bleed="full"
									rowGutter="10px"
									colSizes={{
										desktop: 6,
										tablet: 6,
									}}
								>
									<Row>
										{linkList?.map(this.renderLinkList)}
									</Row>
								</Grid>
							</ListGroupContainer>
							{!this.props.isRecommendationFetching && <div>
								<MyDeviceHeaderContainer className="grid main">
									<Title
										size="small"
										primitive="h2"
									>
										{common.getItemValue(pageItems, "relatedTopicsHeader")}
									</Title>
								</MyDeviceHeaderContainer>

								<RecommendationTileContainer className='main grid'>
									<Grid
										bleed="full"
										rowGutter="10px"
										colSizes={{
											desktop: 6,
											tablet: 6,
										}}
									>
										<Row>
											{relatedTopics?.map(this.renderRecommendationTile)}
										</Row>
									</Grid>

								</RecommendationTileContainer>

							</div>}
						</Fragment>
					</ErrorBoundary>
				</div>
			)
		} else {
			const loadingImg = <Loader />;
			return <div data-testid="DevicesOverviewTestId">{loadingImg}</div>;
		}
	}
}

const mapStateToProps = store => {
	return {
		isFetching: store.Home.isFetching,
		statusCode: store.Home.statusCode,
		statusMessage: store.Home.statusMessage,
		errorMessage: store.Home.errorMessage,
		errorObj: store.Home.errorObj,
		errorDesc: store.Home.errorDesc,
		actionName: store.Home.actionName,
		actionValue: store.Home.actionValue,
		actionType: store.Home.actionType,
		deviceLandingInfoSection:
			store.Home.sectionContentMetaData &&
				store.Home.sectionContentMetaData.body
				? store.Home.sectionContentMetaData.body
				: store.Home.sectionContentMetaData,
		recommendation: store.Home.recommendation,
		isRecommendationFetching: store.Home.isRecommendationFetching,
		networkOutageDetail: store.Home.networkOutageDetail,
		isNetworkOutage: store.Home.isNetworkOutage,
		isRedirectedFromDetailPage: store.Detail.isRedirectedFromDetailPage,
		isNickNameUpdated: store.Detail.isNickNameUpdated,
		isProactiveNotification: store.Home.isProactiveNotification,
		proactiveNotificationDetail: store.Home.proactiveNotificationDetail
	};
};

const mapDispatchToProps = (dispatch) => ({
	actions: bindActionCreators({ ...deviceLandingActions, isRedirectedFromDetailPage }, dispatch),
});

export default connect(mapStateToProps, mapDispatchToProps)(DevicesOverview);
