import React, { useState, useEffect } from 'react';
import Icon from "@vds/icons";
import { Notification } from '@vds/notifications';
import { setCookie, getCookie } from '../../../../shared/components/Helpers';

const Outage = ({ topMessage, ctaTextLabel, message, goToMyNetworkStatus, customerType, userAccount, userId,deviceOverviewVDSComplianceFFlag }) => {
    const [hover, setHover] = useState(false);
    const buttonStyle = {
        border: `0.065rem solid ${hover ? '  black' : '  rgb(0, 0, 0)'}`,
        boxShadow: ` ${hover ? '  15px yellow' : ' 30px red'}`,
      
        cursor: 'pointer',
        transition: 'border-color 0.1s ease', // Smooth transition
        outline: ` ${hover ? ' 1px ridge black ' : ' none'}`,
         fontWeight: "700",
        backgroundColor: "white",
        marginBottom: "16px", fontSize: "0.75rem",
        borderRadius: "18px",
        width: "auto",
        height: "33px",
       

    };
    const buttonLabel = [{
        children: ctaTextLabel,
        onClick: () => goToMyNetworkStatus(),
    }]
    useEffect(() => {
        if (window?.vzdl?.page) {
            vzdl.page.channel = 'my devices';
            vzdl.page.sourceChannel = 'VZW';
            vzdl.page.displayChannel = 'VZW';
            window.coreData = window.coreData || [];
            window.coreData.push({
                task: 'emit',
                event: 'notify',
                params: {
                    name: 'Network disruption',
                    message: 'Network disruption detected.',
                },
            });
            vzdl.page.name = 'devices overview landing';
            vzdl.page.flow = 'Device Overview';
            vzdl.page.throttle = 'NSA';
            vzdl.page.link = ctaTextLabel;
        }
        if (window?.vzdl?.target) {
            vzdl.target.engagement = { intent: 'Account Management' };
            vzdl.target.message = topMessage;
        }
        if(window?.vzdl?.env){
            vzdl.env.businessUnit = 'Wireless';
        }   
        if (window?.vzdl?.user) {
            vzdl.user.customerType = customerType;
            vzdl.user.account = userAccount;
            vzdl.user.id = userId;
            vzdl.user.session = getCookie('GLOBALID');
            window.vzdl.user.authStatus = 'Logged in';
        }
        
    }, []);

    return (
        <div>
            {deviceOverviewVDSComplianceFFlag?<div className='bannerParent'><Notification
        type="warning"
        title={topMessage}
        subtitle={message}
        fullBleed
        inlineTreatment={false}
        buttonData={buttonLabel}
        hideCloseButton={true}
        data-track={ctaTextLabel}
    /></div>:<>
            <div style={{
                background: "#ffbc3d",

                width: "100%",
                border: "0",
                padding: "20px",


            }}
            >
                <div className="grid main" style={{ paddingLeft: "21px" }}>
                    <container style={{ margin: "20px 0 " }}>
                        <div style={{ position: "relative", display: "flex" }}>
                            <b style={{ display: "flex", justifyContent: "center" }}>
                                <span style={{ marginRight: "14px", fontWeight: "bold" }}>
                                    <Icon style={{ height: "20px", width: "20px", minHeight: "20px", minWidth: "20px" }} name="warning" size="medium" />
                                </span>
                                <span
                                    style={{ letterSpacing: '0.03125rem', lineHeight: '1.25rem',textDecoration:'none', fontFamily: "Verizon-NHG-eDS, Helvetica, Arial, Sans-serif", fontWeight: "700", textAlign: "left", width: "100%", fontSize: "1rem" }}>
                                    {topMessage}</span></b>
                        </div>
                    </container></div>
            </div>

            <div className="grid main" style={{ paddingLeft: "52px" }} >
                <p style={{ letterSpacing: '0.03125rem', lineHeight: '1.25rem', fontFamily: 'Verizon-NHG-eDS, Serif', fontSize: "1rem", margin: " 16px 0 24px 0" }}>{message}</p>
                <b><button onClick={goToMyNetworkStatus} data-testid="GoToNetworkStatus" data-track={ctaTextLabel}
                    style={buttonStyle}
                    onMouseEnter={() => setHover(true)}
                    onMouseLeave={() => setHover(false)}>
                    <span style={{padding: '0.63rem',
                    fontSize: '0.75rem',
                    lineHeight: '1rem',
                    fontWeight: '700',
                    whitSspace: 'nowrap',
    fontFamily: 'Verizon-NHG-eTX'} }>  {ctaTextLabel}
        </span>   
                </button></b>
            </div></>} </div>);
};

export default Outage;
