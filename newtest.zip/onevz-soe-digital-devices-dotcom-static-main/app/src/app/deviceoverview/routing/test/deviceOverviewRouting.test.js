import React from 'react';
import '../../../../../config/jest/test-setup';
import {
  render, screen, fireEvent
} from '@testing-library/react';
import '@testing-library/jest-dom/extend-expect';
import { Provider } from 'react-redux';

import configureStore, { history } from '../../../../shared/store/configureStore';
import rootReducer from '../../reducers';
import '@testing-library/jest-dom';
import Home from '../../home/components/index';
import { CustomRoute } from '../CustomRoute';
import { GlobalGuard } from '../GlobalGuard';
import { BrowserRouter as Router } from 'react-router-dom';


const store = configureStore(rootReducer);

describe("custom route render tests", () => {
  it("render ", () => {
    global.reactGlobals.routeLog = {
      confirmationShown: true,
      routerShown: true
    }
    global.dotcomConfig = {
      reactStaticFilePath: "/",
      myVzPage: "/digital/nsa/secure/gw/devices/landing"

    }

    render(
      <Provider store={store}>
        <Router>
          <CustomRoute exact path="/" component={Home} guardComponent={GlobalGuard} />
        </Router>
      </Provider>
    )
  });

  it(" GlobalGuard canActivate else part ", () => {
    global.reactGlobals.routeLog = {
      routerShown: false
    }
    global.dotcomConfig = {
      reactStaticFilePath: "/",
      myVzPage: "/digital/nsa/secure/gw/devices/landing"

    }

    render(
      <Provider store={store}>
        <Router>
          <CustomRoute exact path="/" component={Home} guardComponent={GlobalGuard} />
        </Router>
      </Provider>
    )
  });
     
  it("GlobalGuard fallbackRoute else part ", () => {
    global.reactGlobals.routeLog = {
      routerShown: true
    }
    global.dotcomConfig = {
      reactStaticFilePath: "/",
      myVzPage: "/"

    }

    render(
      <Provider store={store}>
        <Router>
          <CustomRoute exact path="/" component={Home} guardComponent={GlobalGuard} />
        </Router>
      </Provider>
    )
  });

     test("fallback ", () => {
     const result = GlobalGuard.fallbackRoute('reduxStore', 'currentLocation');
     });
})