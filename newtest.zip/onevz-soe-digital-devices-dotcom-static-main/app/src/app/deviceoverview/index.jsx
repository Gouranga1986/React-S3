import "babel-polyfill";
import React from "react";
import { render } from "react-dom";
import { Provider } from "react-redux";
import configureStore, {history} from "@shared/store/configureStore";
import rootReducer from "@pwd/reducers";
import * as serviceWorker from '@pwd/serviceWorker';
import '@pwd/public-path';
import App from '@pwd/app';
import { persistStore } from 'redux-persist';
import { PersistGate } from 'redux-persist/integration/react';

import '@assets/ak-cached/2h/stylesheets/base/base.css';
import '@assets/ak-cached/2h/stylesheets/base/fonts.css';
import '@assets/ak-cached/2h/stylesheets/layout/layout.css';
import '@assets/ak-cached/2h/stylesheets/layout/grid.css';
import '@assets/ak-cached/2h/stylesheets/layout/style.css';
import '@assets/ak-cached/2h/stylesheets/modules/icons.css';
import '@assets/ak-cached/2h/stylesheets/modules/buttons.css';
import '@assets/ak-cached/2h/stylesheets/modules/singles.css';

const store = configureStore(rootReducer);

const persistor = persistStore(store);

render(
  <Provider store={store}>
    <PersistGate loading={null} persistor={persistor}>
      <App history={history} />
    </PersistGate>
  </Provider>, document.getElementById('app')
);

  
// If you want your app to work offline and load faster, you can change
// unregister() to register() below. Note this comes with some pitfalls.
// Learn more about service workers: http://bit.ly/CRA-PWA
serviceWorker.unregister();

