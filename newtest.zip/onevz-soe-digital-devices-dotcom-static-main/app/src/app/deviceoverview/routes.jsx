import React, { lazy, Fragment } from 'react'
import { CustomRoute } from './routing/CustomRoute'
import ScrollToTop from './ScrollToTop'
const Home = lazy(() => import('./home/components'))
const DeviceDetail = lazy(() => import('./deviceDetail/components'))
// const SignalBooster = lazy(() => import('./signalBooster'))
// const SignalBoosterRegisterForm = lazy(() => import('./signalBooster/components/registerForm'))
// const SignalBoosterManage = lazy(() => import('./signalBooster/components/manage'))

const Routes = ({ reduxStore }) => {
  const routeConfig = (
    <div>
      <ScrollToTop />
      <CustomRoute exact path="/" component={Home} />
      <CustomRoute exact path="/deviceDetail" component={DeviceDetail} />
      <CustomRoute exact path="/deviceDetail/:mtn" component={DeviceDetail} />
      <CustomRoute exact path="/ManageDevice/:mtn" component={DeviceDetail} />
      {/* <CustomRoute exact path="/signalBooster" component={SignalBooster} />
      <CustomRoute exact path="/signalBooster/register" component={SignalBoosterRegisterForm} />
      <CustomRoute exact path="/signalBooster/manage" component={SignalBoosterManage} /> */}
    </div>
  )
  return <Fragment>{routeConfig}</Fragment>
}

export default Routes
