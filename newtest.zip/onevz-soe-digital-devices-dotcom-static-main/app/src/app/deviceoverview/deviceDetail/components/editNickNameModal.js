import React, { Component, Fragment } from 'react';
import styled from 'styled-components';
import { connect } from 'react-redux';
import { bindActionCreators } from 'redux';
import { Modal, ModalTitle, ModalBody, ModalFooter } from '@vds/modals';
import { Body } from '@vds/typography';
import { Input } from '@vds/inputs';
import * as deviceDetailAction from '../actions';
import Loader from '../../../../shared/components/Loader/Loader';
import common from '../../../../shared/utilities/util';

const CustomInput = styled(Input)`
border: none !important;
    background-color: transparent !important;
`;

const StyledModalBody = styled.div`
    [class^="ComponentContainer-VDS"]{
        height: auto;
    }

    ul {
        margin-top: 20px;
        // // list-style: none;

        // li {
        //     display: flex;
        //     align-items: center;
        //     position: relative;
        // }

        // // svg {
        // //     position: absolute;
        // //     left: -25px;
        // // }

        p {
            font-weight: 400;
            margin: 5px 0px;
        }
    }
`;

class EditNickNameModal extends Component {
    constructor(props) {
        super(props);

        this.state = {
            mdnNickName: props?.selectedDevice?.nickName || '',
            showNickNameErrorFlag: false,
            disableButton: true,
            isAjaxCallSent: false,
            showSplCharNotAllowedError:false
        }

        this.editNickName = this.editNickName.bind(this);
    }

    componentWillUpdate(prevProps, nextProps) {
        if (prevProps.isNickNameError && nextProps.isAjaxCallSent) {
            this.setState({
                showNickNameErrorFlag: true,
                isAjaxCallSent: false,
                // showSplCharNotAllowedError:true
            })
        }
    }


    editNickName = (e) => {
        const { selectedDevice } = this.props;
        const mdnNickName = e.target.value.toUpperCase();
        const allowedPattern = /^[A-Za-z0-9@'" ]*$/;
       
        if (mdnNickName === '') {
            this.setState({ disableButton: true, mdnNickName: mdnNickName, showNickNameErrorText: "Please enter a nick name.", showNickNameErrorFlag: true, isAjaxCallSent: false,showSplCharNotAllowedError:false });
        } else if ((mdnNickName.includes('-') || mdnNickName.includes('/') || mdnNickName.includes('<') || mdnNickName.includes('>')) && (reactGlobals?.featureFlag?.deviceNickNameSpecialCharFFlag == "false" || reactGlobals?.featureFlag?.deviceNickNameSpecialCharFFlag == undefined) ) {
            this.setState({ disableButton: true, showNickNameErrorText: "Cannot use '-', '/', '>' or '<'.", showNickNameErrorFlag: true, isAjaxCallSent: false,showSplCharNotAllowedError:false  });
        } else if(!allowedPattern.test(mdnNickName) && reactGlobals?.featureFlag?.deviceNickNameSpecialCharFFlag == "true"){
            this.setState({ disableButton: true, showNickNameErrorText: "Cannot use '-', '/', '>' or '<'.", showNickNameErrorFlag: true, isAjaxCallSent: false,showSplCharNotAllowedError:true });       
        } else if (selectedDevice?.nickName.toUpperCase() == mdnNickName.trim()) {
            this.setState({ disableButton: true, mdnNickName: mdnNickName, showNickNameErrorText: "Must be different from other nicknames on your account.", showNickNameErrorFlag: true, isAjaxCallSent: false,showSplCharNotAllowedError:false  });
        } else {
            this.setState({ disableButton: false, mdnNickName: mdnNickName, showNickNameErrorFlag: false, isAjaxCallSent: false,showSplCharNotAllowedError:false  });
        }
    }

    render() {

        const { isOpened, handleCloseEditNickNameModal, selectedDevice, pageItems } = this.props;
        const { mdnNickName, disableButton, showNickNameErrorFlag,showSplCharNotAllowedError } = this.state;

        if (!this.props.isUpdatingNickName) {
            return (
                <Fragment>
                    <div data-testid="editNicknameTestID"></div>
                    <Modal
                        surface="light"
                        opened={isOpened}
                        fullScreenDialog={false}
                        disableAnimation={false}
                        disableOutsideClick={true}
                        ariaLabel="EditNickName Modal"
                        onOpenedChange={(e) => {
                            if (!e) {
                                handleCloseEditNickNameModal && handleCloseEditNickNameModal()
                            }
                        }}
                    >
                        <ModalTitle>Edit device nickname</ModalTitle>
                        <StyledModalBody>
                            <ModalBody>
                                <CustomInput
                                    type="text"
                                    label="Device nickname"
                                    readOnly={false}
                                    required={true}
                                    disabled={false}
                                    error={reactGlobals?.featureFlag?.deviceNickNameSpecialCharFFlag == "true"? showSplCharNotAllowedError:showNickNameErrorFlag}
                                    errorText={(reactGlobals?.featureFlag?.deviceNickNameSpecialCharFFlag == "true" && showSplCharNotAllowedError) && common.getItemValue(pageItems, 'splCharNotAllowedText')}
                                    maxLength="25"
                                    value={mdnNickName}
                                    onChange={(e) => this.editNickName(e)}
                                />
                                <ul>
                                    <li><Body primitive="p">Cannot be over 25 characters</Body></li>
                                    <li><Body primitive="p">Cannot contain {'>'} or {'<'} or {'/'} or {'-'} symbols</Body></li>
                                    <li><Body primitive="p">Must be different from other nicknames on your account</Body></li>
                                </ul>
                            </ModalBody>
                        </StyledModalBody>
                        <ModalFooter
                            buttonData={{
                                primary: {
                                    width: '100%',
                                    children: 'Save',
                                    disabled: disableButton,
                                    onClick: () => {
                                        this.setState({ isAjaxCallSent: true }, () => {
                                            let payload = {
                                                mdn: selectedDevice.mtn,
                                                mdnNickName: mdnNickName
                                            }
                                            this.props.actions.updateNickName(payload);
                                            this.props.changedNickname(payload);
                                            // handleCloseEditNickNameModal && handleCloseEditNickNameModal()
                                        });
                                    },
                                },
                                close: {
                                    width: '100%',
                                    children: 'Cancel',
                                    onClick: () => { handleCloseEditNickNameModal && handleCloseEditNickNameModal() },
                                },
                            }}
                        />
                    </Modal>

                </Fragment>
            )
        } else {
            const loadingImg = <Loader />;
            return <div data-testid="editNickNameModalTestId">{loadingImg}</div>;
        }
    }
}

const mapStateToProps = store => {
    return {
        isFetching: store.Detail.isFetching,
        isUpdatingNickName: store.Detail.isUpdatingNickName,
        isNickNameError: store.Detail.isNickNameError
    };
};

const mapDispatchToProps = (dispatch) => ({
    actions: bindActionCreators(deviceDetailAction, dispatch),
});

export default connect(mapStateToProps, mapDispatchToProps)(EditNickNameModal);
