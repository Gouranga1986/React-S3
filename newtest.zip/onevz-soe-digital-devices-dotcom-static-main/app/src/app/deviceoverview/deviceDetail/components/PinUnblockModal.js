import React, { Component, Fragment } from 'react';
import styled from 'styled-components';
import { connect } from 'react-redux';
import { bindActionCreators } from 'redux';
import { Modal, ModalTitle, ModalBody } from '@vds/modals'
import { Title} from '@vds/typography';
import * as deviceDetailActions from '../actions';

const Left = styled.div`
  display: flex;  
  flex-direction: column; 
  margin-top: 1rem;
  width: 60%;
`;

const Right = styled.div`
  text-align: right; 
  width:40%;
`;

const Content = styled.div`
  display: flex; 
  flex-direction: row;
  justify-content: space-around;
`;

const Container = styled.div`
  display: flex;
  flex-direction: column;

  h5 {
    letter-spacing: normal;
    color: rgb(0,0,0);
    font-weight: 600;
    font-size: 15px;
    margin-bottom: 2px;
  }

  p {
    font-size: 16px;
    margin-bottom: 5px;
  }
`;

const Wrapper = styled.div`
    display: flex;
    flex-direction: row;
`;

const StyleHeaderContainer = styled.div`

`;

class PinUnblockModal extends Component {
    constructor(props) {
        super(props);
    }

    render() {
        
        const { selectedDeviceForPinPuk } = this.props;
            return (
                <Fragment>
                    <div data-testid="pinUnblockTestID"></div>
                    {!this.props.isFetching ? <Modal
                        surface="light"
                        opened={this.props.showPinAndPukModal}
                        fullScreenDialog={false}
                        disableAnimation={false}
                        disableOutsideClick={true}
                        ariaLabel="Pin And Puk Detail Modal"
                        onOpenedChange={(e) => {
                            if (!e) {
                                this.props.actions.closePinAndPukModal()
                            }
                        }}
                    >
                        <ModalTitle>
                            PIN and Unblocking Key
                        </ModalTitle>
                        <ModalTitle>
                            {selectedDeviceForPinPuk?.nickName}
                        </ModalTitle>
                        <ModalTitle>{selectedDeviceForPinPuk?.displayMtn}</ModalTitle>

                        <ModalBody>
                            <Content>
                                <Left>
                                    <Container>
                                        <Title primitive="h5">
                                            Device model
                                        </Title>
                                        <Title primitive="p" data-cs-mask>{selectedDeviceForPinPuk?.modelName}</Title>
                                    </Container>
                                    <Container>
                                        <Wrapper>
                                            <Title primitive="h5">Default PIN</Title>
                                            {/* <Tooltip
                                                title=" "
                                                size="medium"
                                                surface="light"
                                                z-index="1000"
                                            >
                                                Up to $168 device payment purchase or full retail price purchase req’d. Less up to $168 promo credit applied over 24 mos.; promo credit ends if req’s are no longer met; 0% APR.
                                            </Tooltip> */}
                                        </Wrapper>
                                        <Title primitive="p" data-cs-mask>{this.props.pinAndPukDetail?.pin1}</Title>
                                    </Container>
                                    <Container>
                                        <Wrapper>
                                            <Title primitive="h5">Unblocking Key (PUK)</Title>
                                            {/* <Tooltip
                                                title=" "
                                                size="medium"
                                                surface="light"
                                            >
                                                Up to $168 device payment purchase or full retail price purchase req’d. Less up to $168 promo credit applied over 24 mos.; promo credit ends if req’s are no longer met; 0% APR.
                                            </Tooltip> */}
                                        </Wrapper>
                                        <Title primitive="p" data-cs-mask>{this.props.pinAndPukDetail.puk1}</Title>
                                    </Container>
                                </Left>
                                <Right>
                                    <img src={selectedDeviceForPinPuk?.images?.mediumImage} alt="" />
                                </Right>
                            </Content>
                        </ModalBody>
                    </Modal>: null}
                </Fragment>
            )
    }
}

const mapStateToProps = store => {
    return {
        isFetching: store.Detail.isFetching,
        showPinAndPukModal: store.Detail.showPinAndPukModal,
        pinAndPukDetail: store.Detail.pinAndPukDetail,
        pinAndPukDetailError: store.Detail.pinAndPukDetailError
    };
};

const mapDispatchToProps = (dispatch) => ({
    actions: bindActionCreators(deviceDetailActions, dispatch),
});

export default connect(mapStateToProps, mapDispatchToProps)(PinUnblockModal);
