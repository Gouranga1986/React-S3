import React from 'react';
import {
  Modal, ModalTitle, ModalBody, ModalFooter,
} from '@vds/modals';
import { Button } from '@vds/buttons';
import { Body } from '@vds/typography';
import common from '../../../../shared/utilities/util';

const ChangeOrReplaceModal = ({
  handleCancel, handleModalChange, isChangeOrReplaceModal, deviceDetailInfoSection,
}) => {
  let pageContent;
  if (deviceDetailInfoSection?.sections) {
    pageContent = common.getContentFromSection(deviceDetailInfoSection, 'devicesLandingMainSection');
    pageContent = pageContent?.sections?.[0];
  }
  const pageItems = pageContent && pageContent?.contents && pageContent?.contents?.[0]?.items;
  return (
    <>
      <div data-testid="ChangeOrReplaceModalTestId">
        <Modal
          surface="light"
          opened={isChangeOrReplaceModal}
          disableOutsideClick={false}
          ariaLabel="Update your device"
          onOpenedChange={handleModalChange}
        >
          <ModalTitle>
            {common.getItemValue(pageItems, 'ChangeDeviceModalHeader')}
          </ModalTitle>
          <ModalBody>
            <Body
              size="large"
            >
              {common.getItemValue(pageItems, 'ChangeDeviceModalSubHeader')}
            </Body>


          </ModalBody>
          <ModalFooter>
            <Button ariaLabel="Got it" data-testid="GotItModalTestId" onClick={handleCancel}>
              {' '}
              {common.getItemValue(pageItems, 'ChangeDeviceModalBtn')}
            </Button>
          </ModalFooter>
        </Modal>
      </div>
    </>
  );
};

export default ChangeOrReplaceModal;
