import React, { Component, Fragment } from 'react';
import styled from 'styled-components';
import { connect } from 'react-redux';
import { bindActionCreators } from 'redux';
import { Modal, ModalTitle, ModalBody, ModalFooter } from '@vds/modals'
import { Body } from '@vds/typography';
import * as deviceDetailActions from '../actions';
import common from '../../../../shared/utilities/util';

const StyledModalBody = styled.div`
    p:nth-of-type(even) {
        margin-top: 15px;
        margin-bottom: 15px;
    }
`

class PendingLineDetailModal extends Component {
    constructor(props) {
        super(props);
    }

    render() {
        let pageContent;
        if (this.props.deviceDetailInfoSection && this.props.deviceDetailInfoSection.sections) {
            pageContent = common.getContentFromSection(this.props.deviceDetailInfoSection, 'devicesLandingMainSection');
            pageContent = pageContent.sections[0];
        }
        let pageItems = pageContent && pageContent.contents && pageContent.contents[0].items;

            return (
                <Fragment>
                    <div data-testid="pinUnblockTestID"></div>
                    {!this.props.isFetching ? <Modal
                        surface="light"
                        opened={this.props.isPendingLineChangeModalOpen}
                        fullScreenDialog={false}
                        disableAnimation={false}
                        disableOutsideClick={true}
                        ariaLabel="Pending Line Detail Modal"
                        onOpenedChange={(e) => {
                            if (!e) {
                                this.props.actions.closePendingLineChangeDetailModal();
                            }
                        }}
                    >
                        <ModalTitle>
                            {common.getItemValue(pageItems, "pendingLineChangeModalTitle")}
                        </ModalTitle>
                        <ModalBody>
                            <StyledModalBody>
                                <Body primitive="p">{common.getItemValue(pageItems, "pendingLineChangeModalSubTitle1")}</Body>
                                <Body primitive="p">{common.getItemValue(pageItems, "pendingLineChangeModalSubTitle2")}</Body>
                                <Body primitive="p">{common.getItemValue(pageItems, "pendingLineChangeModalSubTitle3")}</Body>
                            </StyledModalBody>
                        </ModalBody>
                        <ModalFooter
                            buttonData={{
                                primary: {
                                    width: '100%',
                                    children: common.getItemValue(pageItems, "reviewDetail"),
                                    onClick: () => { },
                                },
                                close: {
                                    width: '100%',
                                    children: common.getItemValue(pageItems, "close"),
                                    onClick: () => { this.props.actions.closePendingLineChangeDetailModal(); },
                                },
                            }}
                        />
                    </Modal>: null}

                </Fragment>
            )
    }
}

const mapStateToProps = store => {
    return {
        isFetching: store.Detail.isFetching,
        deviceDetailInfoSection:
            store.Detail.sectionContentMetaData
                && store.Detail.sectionContentMetaData.body
                ? store.Detail.sectionContentMetaData.body
                : store.Detail.sectionContentMetaData,
        isPendingLineChangeModalOpen: store.Detail.isPendingLineChangeModalOpen
    };
};

const mapDispatchToProps = (dispatch) => ({
    actions: bindActionCreators(deviceDetailActions, dispatch),
});

export default connect(mapStateToProps, mapDispatchToProps)(PendingLineDetailModal);
