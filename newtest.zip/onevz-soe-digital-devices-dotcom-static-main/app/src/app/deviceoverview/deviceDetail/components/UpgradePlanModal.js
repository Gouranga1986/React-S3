import React from "react";
import { Modal, ModalTitle, ModalBody,ModalFooter } from '@vds/modals';
import { Button } from "@vds/buttons";
import common from '../../../../shared/utilities/util';

const UpgradePlanModal = ({ handleCancel, handleModalChange, showModal, deviceDetailInfoSection }) =>{

    let pageContent;
    if (deviceDetailInfoSection?.sections) {
        pageContent = common.getContentFromSection(deviceDetailInfoSection, 'devicesLandingMainSection');
        pageContent = pageContent?.sections[0];
    }
    let pageItems = pageContent && pageContent.contents && pageContent.contents[0].items;
    
    return(<>
    <div data-testid="upgradePlanTestId">
        <Modal
            surface="light"
            opened={showModal}
            disableOutsideClick={false}
            ariaLabel="Upgrade your Second Number Modal"
            onOpenedChange={handleModalChange}
        >
            <ModalTitle>
                {common.getItemValue(pageItems, "upgradeToPlanText")}
            </ModalTitle>
            <ModalBody>
                {common.getItemValue(pageItems, "upgradeToPlanText2")}
            </ModalBody>
            <ModalFooter>
                <Button ariaLabel="Got it" onClick={handleCancel}>Got it</Button>
            </ModalFooter>
        </Modal>
        </div>
</>)

}

export default UpgradePlanModal;