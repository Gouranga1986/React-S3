import React, { Component, Fragment } from 'react';
import styled from 'styled-components';
import { connect } from 'react-redux';
import { bindActionCreators } from 'redux';
import { ErrorBoundary } from '@vz/react-util';
import { Title, Body } from '@vds/typography';
import { TileContainer } from '@vds/tiles';
import { ListGroup, ListGroupItem, ListGroupItemTitle } from '@vds/lists';
import { Grid, Row, Col } from '@vds/grids';
import { Icon } from '@vds/icons';
import { DropdownSelect } from '@vds/selects';
import { TextLink, Button } from '@vds/buttons';
import Loader from '../../../../shared/components/Loader/Loader';
import common from '../../../../shared/utilities/util';
import * as deviceDetailActions from '../actions';
import PinUnblockModal from './PinUnblockModal';
import EditNickNameModal from './editNickNameModal';
import { Notification } from '@vds/notifications';
import { Tabs, Tab } from '@vds/tabs';
import UpgradePlanModal from './UpgradePlanModal';
import SimFreezeBlockModal from './SimFreezeBlockModal';
import { getCookie} from '../../../../shared/components/Helpers';
import xss from 'xss';
import { finishMonitoring } from '../../../../shared/services/monitoring';
import ChangeOrReplaceModal from './ChangeOrReplaceModal';
import { dispatchNotifyEvent } from '../../../../shared/utilities/tagging';

const TitleContainer = styled.div`
  margin-top: 56px;
  padding-bottom: 36px;

  h1 {
    font-weight: 400;
    color: #222222;
  }
`;

const MyDeviceHeaderContainer = styled.div`
  // // max-width: 1232px;
  // margin: 0 auto;
  // margin-bottom: 20px;
  h2 {
    margin-top: 32px;
    font-weight: 700;
    font-size: 24px;
    line-height: 28px;
    color: #222222;
  }
`;

const ListGroupContainer = styled.div`
  padding: 0px;
  margin-bottom: 48px;

  h2 {
    font-weight: 700;
    font-size: 24px;
    line-height: 28px;
  }
`;

const DropdownSelectContainer = styled.div`
  position: relative;
  margin-bottom: 40px;

  #deviceListSelectBox {
    width: 328px;
  }
`;

const TextLinkContainer = styled.div`
  position: absolute;
  left: 365px;
  top: 40%;
`;

const DeviceDetailContainer = styled.div`
  margin-top: 1rem;
  padding-left: 0px;
`;

const DeviceWrapper = styled.div`
  // margin: 0px 20px;
`;

const DeviceNameContainer = styled.div`
  padding: 12px 0px;
  display: flex;

  h2 {
    font-weight: 700;
    font-size: 24px;
    line-height: 28px;
  }
`;

const EditNickNameContainer = styled.div`
  margin-left: 16px;

  a {
    font-weight: 400;
    font-size: 14px;
    line-height: 20px;
    /* identical to box height, or 125% */

    letter-spacing: 0.5px;
  }
`;

const DeviceInfoContainer = styled.div`
  background: #f6f6f6;
  border-radius: 8px;
  max-width: 1232px;
  margin: 0 auto;
  // margin:0 20px;
  padding-top: 44px;
  padding-bottom: 44px;
  margin-top: 36px;
  margin-bottom: 24px;

  @media only screen and (min-device-width: 768px) and (max-device-width: 1024px) and (orientation: portrait) {
    max-width: 944px;
    // margin:0 20px;
  }
`;

const DeviceInfoContainer2 = styled.div`
  border-radius: 8px;
  margin-top: 24px;
  margin-bottom: 50px;
  margin-right:-30px;
  margin-left:-20px;
`;

const ProductImg = styled.div`
  width: 100%;
  text-align: center;

  @media only screen and (min-device-width: 768px) and (max-device-width: 1024px) and (orientation: portrait) {
    img {
      width: 100%;
    }
  }

  ${(props) =>
    props.isMtnSuspended &&
    `
			img {
					opacity: 0.5;
				} 
	`}
`;

const FiveGImg = styled.div`
  padding-top: 8px;

  img {
    width: 30px;
  }
`;

const SubHeaderTitle = styled.div`
  margin-bottom: 18px;
  height: ${(props) => (props.modalSpacing ? '100px' : 'auto')};

  h2 {
    font-weight: ${(props)=>props.isPearlFlow ? 400 :700};
    font-size: ${(props)=>props.isPearlFlow ? '14px' : '16px'};
    line-height: 20px;
    /* identical to box height, or 125% */

    letter-spacing: 0.5px;
    color: ${(props)=>props.isPearlFlow ? '#6F7171':'#222222'};
  }

  p {
    margin-top: 5px;
    font-weight: 400;
    font-size: 14px;
    line-height: 20px;
    /* identical to box height, or 125% */

    letter-spacing: 0.5px;
    color: ${(props)=>props.isPearlFlow ? '#000000':'#222222'};
  }
`;

const Wrapper = styled.div``;

const ContentContainer = styled.div`
  display: flex;
  flex-direction: column;
  align-items: ${(props) => `${props.center ? `center` : `left`}`};
`;

const InlineContentBox = styled.div`
  display: flex;
  align-items: center;
  margin-top: 5px;

  p {
    margin-top: 0px;
    margin-left: 3px;
  }
`;

const TileContainerWrapper = styled.div`
  position: relative;
  margin-top: 20px;
  #tileContainer {
    background-color: #f6f6f6;

    #inner-tileContainer {
      flex-direction: column;
    }
  }
`;

const TileContainerWrapperDark = styled.div`
  position: relative;

  #tileContainer {
    background-color: ${(props) => (props.isDarkTile ? `#000` : `#F6F6F6`)};

    #inner-tileContainer {
      flex-direction: column;
    }
  }
  margin-top: 20px;
`;

const MyPlanTitle = styled.div`
  h2 {
    font-weight: 700;
    font-size: 20px;
    line-height: 24px;
    letter-spacing: 1px;
  }
`;

const MyPlanSubTitle = styled.div`
  padding-top: 10px;
  p {
    font-weight: 400;
    font-size: 12px;
    line-height: 16px;
    letter-spacing: 1px;
  }
`;

const MyPlanDeviceCtaContainer = styled.div`
  position: absolute;
  bottom: 32px;
  display: flex;
  flex-direction: row;

  button {
    height: 36px;
    margin-right: 8px;

    span {
      padding-top: 0px;
      padding-bottom: 0px;
      font-size: 12px;
      letter-spacing: 0.5px;
    }
  }
`;

const ProtectioTitle = styled.div`
  h2 {
    font-weight: 700;
    font-size: 20px;
    line-height: 24px;
    letter-spacing: 1px;
    color: ${(props) => (props.isDarkTile ? `#fff` : `#000`)};
  }
`;

const ProtectioSubTitle = styled.div`
  padding-top: 10px;
  p {
    font-weight: 400;
    font-size: 12px;
    line-height: 16px;
    letter-spacing: 1px;
    color: ${(props) => (props.isDarkTile ? `#fff` : `#000`)};
  }
`;

const DeviceCtaContainer = styled.div`
  position: absolute;
  bottom: 32px;
  display: flex;
  button {
    border: 1px solid ${(props) => (props.isDarkTile ? `#F6F6F6` : `#000`)};
    height: 36px;
    margin-left: 28px;

    span {
      // padding: 0px;
      font-size: 12px;
      letter-spacing: 0.5px;
    }
  }
`;

const MyPlanContent = styled.div`
  padding-top: 32px;

  p {
    margin-bottom: 8px;
    font-weight: 400;
    font-size: 14px;
    line-height: 16px;
    /* identical to box height, or 125% */

    letter-spacing: 0.5px;
  }
`;

const UpgradeTileContent = styled.div`
  display: flex;
  flex-direction: column;
`;

const SecondRow = styled.div`
  margin-top: 20px;
  margin-bottom: 25px;

  // display: flex;
  // flex-direction: row;
  // justify-content: space-between;

  p {
    font-weight: 400;
    font-size: 14px;
    line-height: 16px;
    letter-spacing: 0.5px;
  }
`;

const ThirdRow = styled.div`
  // display: flex;
  // flex-direction: row;
  // justify-content: space-between;
  margin-top: 12px;
  margin-bottom: 17px;
  position: relative;

  #paid {
    border-radius: 20px;
    height: 16px;
    background: #006fc1;
    width: ${(props) => `${props.paidPercentage}%`};
    z-index: 2;
    position: absolute;
  }

  #total {
    border-radius: 20px;
    height: 16px;
    background: #d8dada;
    width: 100%;
    position: absolute;
  }
`;

const TextLinkWrapper = styled.div``;

const ListGroupItemTitleContent = styled.span`
  font-size: 18px;
  line-height: 20px;
`;

const Banner = styled.div`
  visibility: ${(props) => (props.showBanner !== 'NO_PROMO' ? 'visible' : 'hidden')};
  background-color: #000;
  padding-left: 4px;
  padding-top: 5px;
  padding-bottom: 5px;
  border-top-right-radius: 4px;
  border-bottom-right-radius: 4px;
`;

class DeviceDetail extends Component {
  constructor(props) {
    super(props);

    this.state = {
      selectedMdn: '',
      encMdn: '',
      selectedDevice: {},
      index: 0,
      showModal: false,
      changeOrReplaceModal: false,
      showSimFreezeModel: false,      
      showSimFreezeNotification1: false, 
      showSimFreezeNotification2: false, 
			simFreezeDuration: 0,
			simUnfreezeTimeStamp: "",
      changeNickName:""
    };

    this.getOnClickInfo = common.getOnClickInfo.bind(this);
  }

  componentDidMount() {
    const selectedMdn = this.props?.selectedDevice?.mtn;
    this.props?.actions?.getSections(selectedMdn , this.props?.match?.params?.mtn);
    this.setState({
      selectedMdn: this.props?.selectedDevice?.mtn,
      encMdn: this.props?.match?.params?.mtn || '',
    }); 
  }

  componentDidUpdate(prevProps) {

    if(!this.props.isFetching){
      finishMonitoring();
    }

    if (
      this.props.deviceDetailInfoSection &&
      this.props.deviceDetailInfoSection.sections &&
      this.props?.match?.params?.mtn !== '' &&
      (this.state?.selectedMdn == '' || !this.state?.selectedMdn)
    ) {
      let pageContent;
      let selectedMdn = '';
      let pageActions = '';
      let singleSelectedMdn = [];
      let allDevices = [];
      if (this.props.deviceDetailInfoSection && this.props.deviceDetailInfoSection.sections) {
        pageContent = common.getContentFromSection(this.props.deviceDetailInfoSection, 'devicesLandingMainSection');
        pageContent = pageContent.sections[0];
        pageActions = pageContent && pageContent.actions;
      }
      if (pageContent && pageContent?.data) {
        pageContent &&
          pageContent?.data &&
          pageContent?.data?.forEach((singleDevice, index) => {
            if (!singleDevice?.isSecondNumber) {
              allDevices.push(singleDevice);
            }
          });
      }
      if (this.props?.match?.params?.mtn !== '') {
        singleSelectedMdn = pageContent?.data?.filter((singleMdnDetail) => singleMdnDetail?.encryptedMtnDES == this.props?.match?.params?.mtn);
        selectedMdn = singleSelectedMdn[0]?.mtn || allDevices[0]?.mtn;
      } else {
        selectedMdn = allDevices[0]?.mtn;
      }
      if (singleSelectedMdn.length && singleSelectedMdn[0]?.router) {
        const action = common.getActionByKey(pageActions, 'manageRouterAction');
        const actionValue = action && action.actionValue;
        window.location.href = `${actionValue}${singleSelectedMdn[0]?.encryptedMtnAES}`;
      } else if (singleSelectedMdn.length && singleSelectedMdn[0]?.networkExtender) {
        const action = common.getActionByKey(pageActions, 'manageNetworkExtender');
        const actionValue = action && action.actionValue;
        window.location.href = `${actionValue}?deviceid=${singleSelectedMdn[0]?.deviceId}`;
      } else {
        if (!selectedMdn && (pageContent && pageContent?.data && pageContent?.data[0]?.router) || pageContent?.data[0]?.networkExtender) {
          window.location.hash = `/`;
        } else {
          this.setState({ selectedMdn: selectedMdn });
        }
      }
    }

    if ((this?.props?.deviceDetailInfoSection?.sections?.length != prevProps?.deviceDetailInfoSection?.sections?.length) && this?.props?.deviceDetailInfoSection?.sections) {
      let pageContent1 = common.getContentFromSection(this?.props?.deviceDetailInfoSection, 'devicesLandingMainSection');
			let newPageContent = pageContent1?.sections?.[0];
			const mobileDeviceList = newPageContent?.data || [];
			const isPearlDevice = mobileDeviceList?.some(list => list?.pearlTrialFlow);
			if (isPearlDevice) {
				sessionStorage.setItem('pearlTrialFlow', "true");
			}
			
		}
  }

  handleSelectBoxChange(e) {
    if (this.props.deviceDetailInfoSection && this.props.deviceDetailInfoSection.sections) {
      let pageContent = common.getContentFromSection(this.props.deviceDetailInfoSection, 'devicesLandingMainSection');
      pageContent = pageContent.sections[0];
      const pageActions = pageContent && pageContent.actions;
      let deviceList = (pageContent && pageContent.data) || [];
      let selectedDevice = deviceList.filter((value) =>
        value?.networkExtender ? value?.deviceId === e.target.value : value?.mtn === e.target.value
      );
      const selectedMdn = e.target.value;
      let pageItems = pageContent && pageContent?.contents && pageContent?.contents[0]?.items;
      const isNewEndpoint = common.getItemValue(pageItems, 'newRecommendationTileEnabled') === 'true';
      if(isNewEndpoint){
        this.props.actions.getRecommendedTiles(selectedMdn);
      }
      if (selectedDevice.length && selectedDevice[0]?.router) {
        const action = common.getActionByKey(pageActions, 'manageRouterAction');
        const actionValue = action && action.actionValue;
        window.location.href = `${actionValue}${selectedDevice[0]?.encryptedMtnAES}`;
      } else if (selectedDevice.length && selectedDevice[0]?.networkExtender) {
        const action = common.getActionByKey(pageActions, 'manageNetworkExtender');
        const actionValue = action && action.actionValue;
        window.location.href = `${actionValue}?deviceid=${selectedDevice[0]?.deviceId}`;
      } else {
        this.setState({
          index: 0,
          selectedMdn,
          changeNickName:""
        });
      }
    }
    this.setState({ showSimFreezeNotification1: false, showSimFreezeNotification2: false });
  }

  handleShowAllDevices = () => {
    this.props.actions.isRedirectedFromDetailPage(true);
    window.location.hash = `/`;
  };

  personalizationFlag = () => {
    return window.enablePesonalizedOffer;
  }

  handleReviewDetailLink = () => {
    let pageContent;
    if (this.props.deviceDetailInfoSection && this.props.deviceDetailInfoSection.sections) {
      pageContent = common.getContentFromSection(this.props.deviceDetailInfoSection, 'devicesLandingMainSection');
      pageContent = pageContent.sections[0];
    }
    let pageItems = pageContent && pageContent.contents && pageContent.contents[0].items;

    let actionKey = pageContent && common.getActionKey(pageItems, `reviewDetail`);
    let click_info = this.getOnClickInfo(pageContent, actionKey);
    click_info?.onclick();
  };

  handleUpgradeRedirection = ({ actionValue, selectedDeviceInfo = {}, primaryMtnDetails }) => {
    let { encryptedMtnDES, deviceCategory } = selectedDeviceInfo;
    const qParams = window.location.href.includes('upgradeFlowTest=true');
    let redirectionUrl = '';
    if (selectedDeviceInfo?.secondMtn || selectedDeviceInfo?.isSecondNumber) {
      let secondNumberObj;
      if (selectedDeviceInfo?.isSecondNumber && primaryMtnDetails?.secondMtn) {
        encryptedMtnDES = primaryMtnDetails?.encryptedMtnDES;
        deviceCategory = primaryMtnDetails?.deviceCategory;
        secondNumberObj = {
          isSecondNumber: true,
          primaryMtn: primaryMtnDetails?.mtn,
          secondMtn: primaryMtnDetails?.secondMtn,
        };
      } else {
        secondNumberObj = {
          isSecondNumber: true,
          primaryMtn: selectedDeviceInfo?.mtn,
          secondMtn: selectedDeviceInfo?.secondMtn,
        };
      }
      sessionStorage.setItem('secondaryProcessingMTN', JSON.stringify(secondNumberObj));
    }
    redirectionUrl = `${actionValue}${encryptedMtnDES}&dc=${deviceCategory}`;
    if (qParams){ // if qParams or cookie  only for mobile
      redirectionUrl = `${actionValue}${encryptedMtnDES}&dc=${deviceCategory}&upgradeFlowTest=true`;
    }
    window.location.href = redirectionUrl;
  };

  getUpgradeActionValue = (selectedDeviceDetail, pageContent, pageItems, pageActions, buttonName) => {
    const upgradeFlowTestCookie = getCookie('upgradeFlowTest') ? true : false;
    const qParams = window.location.href.includes('upgradeFlowTest=true');
    const buttonType = ((selectedDeviceDetail[0]?.deviceCategory === 'phone' && selectedDeviceDetail[0]?.newSelectedMdnFlowFFlag) || qParams || upgradeFlowTestCookie) ? 'dppUpgradeBtn' : buttonName;
    const actionKey = pageContent && common.getActionKey(pageItems, buttonType);
    let actionKeyValue = pageContent && common.getActionByKey(pageActions, actionKey);
    let actionValue = actionKeyValue && actionKeyValue.actionValue;
  
    if (buttonType === 'dppUpgradeBtn') {
      const allowedBrands = ['apple', 'samsung', 'google'];
      const actionValueWithBrandName = actionValue?.replace('##BRAND##', selectedDeviceDetail[0]?.brandName?.toLowerCase());
      const actionValueWithoutBrandName = actionValue?.replace('##BRAND##', '');
      if (allowedBrands?.includes(selectedDeviceDetail[0]?.brandName?.toLowerCase())) {
        actionValue = actionValueWithBrandName;
      } else {
        actionValue = actionValueWithoutBrandName;
      }
    }
  
    return actionValue;
  };
  


  pageContentCommonCode = () => {
    let pageContent;
    if (this.props.deviceDetailInfoSection && this.props.deviceDetailInfoSection.sections) {
      pageContent = common.getContentFromSection(this.props.deviceDetailInfoSection, 'devicesLandingMainSection');
      pageContent = pageContent.sections[0];
    }
    let pageItems = pageContent && pageContent.contents && pageContent.contents[0].items;
    const pageActions = pageContent && pageContent.actions;
    let deviceList = (pageContent && pageContent.data) || [];

    let selectedDeviceDetail = (deviceList && deviceList.filter((singleDevice) => singleDevice.mtn == this.state.selectedMdn)) || [];
    return { pageContent, pageItems, pageActions, deviceList, selectedDeviceDetail };
  };

  listGroupCommonCode = (pageItems, singleLink) => {
    return (
      <ListGroupItemTitle bold={false}>
        <ListGroupItemTitleContent
          data-track={`${common.getItemValue(pageItems, `${singleLink}`)}`}
          aria-label={`${common.getItemValue(pageItems, `${singleLink}`)}`}
        >
          {common.getItemValue(pageItems, `${singleLink}`)}
        </ListGroupItemTitleContent>
      </ListGroupItemTitle>
    );
  };

  setCookieForRecommendedDeviceUpgrade = (cookieName, value) => {
    const domainName = window?.location?.hostname;
    const getTheHostName = domainName?.split('.')[1];
    const subDomainName = domainName?.split('.')[2];
    const domainString = `${getTheHostName}.${subDomainName}`;
    let cookieString = `${this.validateUrl(cookieName)}=${this.validateUrl(value)};path=/;`;
    if (domainName === 'localhost' || domainName === '127.0.0.1') document.cookie = xss(cookieString);
    document.cookie = `${this.validateUrl(cookieString)}domain=.${this.validateUrl(domainString)}`;
  }

  validateUrl = (str) => {
    if (str) {
      return xss(str);
    }
    return '';
  };

  renderRecommendedDeviceUpgradeLink = (selectedMdn) => {
    let selectedMtnRecommendedDevice = "";
    let offerId = "";
    let oneClickEnabled = "&oneClickEnabled=true&intent=EUP";
    let recommendedDeviceId = "";
    let actionUrl = "";
    let recommendedDeviceDetails = "";
    let impressionFragments = "";
    if (this.props?.recommendedDevice) {
      let selectedMtnRecommendedDeviceArray = Object.values(this.props?.recommendedDevice);
      if(selectedMtnRecommendedDeviceArray && selectedMtnRecommendedDeviceArray?.length >0){
        selectedMtnRecommendedDevice =
        selectedMtnRecommendedDeviceArray[0]?.filter(
          (device) => device?.processingMTN == selectedMdn
        );
      }
      //To get the PDP URL based on canonical url , offerid and one click enabled
      if(selectedMtnRecommendedDevice && selectedMtnRecommendedDevice?.length > 0){
        if(selectedMtnRecommendedDevice[0]?.deviceId){
          recommendedDeviceId = selectedMtnRecommendedDevice[0]?.deviceId;
          if(selectedMtnRecommendedDevice[0]?.offerId){
            offerId = `?sedOfferId=${selectedMtnRecommendedDevice[0]?.offerId}`;
          }

          if (this.props?.productList) 
          {
            const entries = Object.entries(this.props?.productList);
            const entry = entries?.find(([key, value]) => key === recommendedDeviceId);
            let canonicalUrlValue = '';
            if (entry) {
              const [key, value] = entry;
              canonicalUrlValue = value.canonicalUrl;
              console.log(`Canonical URL: ${canonicalUrlValue}`);
              actionUrl = `${canonicalUrlValue}${offerId}${oneClickEnabled}`;
              let domainUrl = window?.location?.origin;
              actionUrl = domainUrl + "/" + actionUrl;
            } else {
              console.log(`No entry found for deviceId: ${recommendedDeviceId}`);
            }
          }
        }
      }
    }
    return { recommendedDeviceId, actionUrl, impressionFragments, recommendedDeviceDetails };
  }

  renderRecommendedDeviceNewUpgradeLink = (selectedMdn) => {
    let selectedMtnRecommendedDevice = "";
    let oneClickEnabled = "?oneClickEnabled=true&intent=EUP";
    let canonicalUrlValue = '';
    let actionUrl = "";
    let impressionFragments = "";
    let recommendedDeviceId = "";
    let offerId = ''
    if (this.props?.recommendedTiles && this.props?.recommendedTiles?.recommendedDevices?.length >0 ) { 
      let selectedMtnRecommendedDeviceArray = Object.values(this.props?.recommendedTiles);
      if(selectedMtnRecommendedDeviceArray && selectedMtnRecommendedDeviceArray?.length >0){
        selectedMtnRecommendedDevice =
        selectedMtnRecommendedDeviceArray?.[0]?.filter(
          (device) => device?.processingMTN == selectedMdn
        );
      }
      if(selectedMtnRecommendedDevice?.length > 0){
      canonicalUrlValue = selectedMtnRecommendedDevice?.[0]?.recommendedDeviceURL;
      recommendedDeviceId = selectedMtnRecommendedDevice?.[0]?.deviceId;
      //offerId = `?sedOfferId=${selectedMtnRecommendedDevice?.[0]?.offerId}`;
      actionUrl = `${canonicalUrlValue}${oneClickEnabled}`;
      let domainUrl = window.location.origin;
      let oneClickRequest = {
        cartInfo: {
          cartId: '',
          caseId: '',
          accountNumber: '',
          cartCreator: '',
          processingMTN: selectedMdn,
          processStep: 'GridWallPDP',
          processAction: 'ExpressUpgrade',
          intendType: 'EUP',
          isTradeInSelected: false,
          disableMyLink: false,
          editDevice: false,
          expressCheckout: null,
          noPendingOfferExists: false,
          isPromoPDP: false,
          mtnFlow: 'M',
        },
        data: {
          lines: [
            {
              isCommonPDP: true,
              mtn: selectedMdn,
              purchasePath: 'EUP',
              portInNumber: '',
              eupNoPromoFlow: false,
              device: {
                id: selectedMtnRecommendedDevice?.[0]?.sorId,
                contractTerm: 'VERIZON_EDGE',
                iconicPhone: true,
                dppMonths: 36,
                productId: selectedMtnRecommendedDevice?.[0]?.deviceId,
                category: 'Smartphones',
                preconfigure: true,
              },
              sim: {
                id: selectedMtnRecommendedDevice?.[0]?.simId,
              },
              ispuFlow: false,
              estimatedReadyByDate: '',
              depletionLocationCode: '',
              depletionType: 'F',
              isKeepingExistingEqProtection: true,
              newLineOrAAL: false,
              isNewLine: false,
              selectedPromoId: selectedMtnRecommendedDevice?.[0]?.promotionId,
              selectedPromoType: selectedMtnRecommendedDevice?.[0]?.promoType,
              promoRejectionIndicator: false,
              isIconicPhone: true,
              selectedSedOfferId: selectedMtnRecommendedDevice?.[0]?.offerId,
              selectedSpoId: '',
              isStrategicOffer: selectedMtnRecommendedDevice?.[0]?.isStrategicOffer || false,
              restricted: (selectedMtnRecommendedDevice?.[0]?.isStrategicOffer) ? 'Y' : '',
              restrictedProductType: (selectedMtnRecommendedDevice?.[0]?.isStrategicOffer) ? 'EQP' : '',
              isTradeInIntentSelected: true,
            },
          ],
          rtm: {
            url: '',
            img: '',
            name: selectedMtnRecommendedDevice?.[0]?.productDisplayName,
            make: '',
            categoryId: '',
            pageURL: '',
          },
          enableFcc: true,
          couponCode: '',
        },
      };
      actionUrl = this.recommendedDeviceTile(oneClickRequest, selectedMtnRecommendedDevice, actionUrl);
      actionUrl = domainUrl + "/" + actionUrl;
      impressionFragments = { "list": `L1|P1|Manage device_rtm|Smartphones|||dispid_82|${selectedMtnRecommendedDevice[0]?.sorId ? `sorid_${selectedMtnRecommendedDevice[0]?.sorId}` : ''}^L1|P2||||||PlanUsage Tile^L1|P3||||||Device Protect Tile` };
    }
    }
    return { recommendedDeviceId, actionUrl, impressionFragments, selectedMtnRecommendedDevice };
  }

  renderDeviceManagementLink = (singleLink, index) => {
    const { pageContent, pageItems, pageActions, deviceList, selectedDeviceDetail } = this.pageContentCommonCode();
    let { encryptedMtnDES, deviceManagement, changeMobileNumberThrottle, mtn, encryptedSimId, isSecondNumber } = selectedDeviceDetail.length && selectedDeviceDetail[0];
    let primaryMtn = (isSecondNumber && deviceList && deviceList.find((singleDevice) => singleDevice.secondMtn == mtn));

		const simfreezeInfoValue = (selectedDeviceDetail[0]?.simFreezeInfo?.simFreezeCode+selectedDeviceDetail[0]?.simFreezeInfo?.simUnfreezeTimeStamp+selectedDeviceDetail[0]?.simFreezeInfo?.isBlocked);
		const simFreezeKey = pageContent && common.cipher(simfreezeInfoValue, 29);
		// console.log("renderDeviceManagementLink simFreezeKey CHECK ==> ", simFreezeKey, " == ", selectedDeviceDetail[0]?.simFreezeInfo?.simFreezeDetails);
    const deviceDetailBtnFFlag = (selectedDeviceDetail?.[0]?.deviceDetailsFeatureFlags?.deviceDetailBtnFFlag && selectedDeviceDetail?.[0]?.pearlTrialFlow);

    return deviceManagement[`${singleLink}`] ? (
      <Col
        key={`${singleLink}`}
        colSizes={{
          desktop: 6,
          tablet: 6,
        }}
      >
        <ListGroup topLine={false} bottomLine={true} surface='light' viewport='desktop'>
          <ListGroupItem
            actionElement='icon'
            ariaLabel={`${common.getItemValue(pageItems, `${singleLink}`)}`}
            onClick={() => {
              if (singleLink == 'changeMobileNumberBtn' && changeMobileNumberThrottle) {
                let actionKey = pageContent && common.getActionKey(pageItems, `${singleLink}`);
                let click_info = this.getOnClickInfo(pageContent, `nsa_${actionKey}`);
                click_info?.onclick();
              } else if (singleLink == 'tradeInBtn') {
                let actionKey = pageContent && common.getActionKey(pageItems, `${singleLink}`);
                const actionKeyValue = pageContent && common.getActionByKey(pageActions, actionKey);
                const actionValue = actionKeyValue && actionKeyValue.actionValue;
                window.location.href = `${actionValue}${encryptedMtnDES}`;
              } else if (singleLink == 'pinandPersonalUnblockingKeyBtn') {
                const payload = { encryptedSimID: `${encryptedSimId}`, selectedMsisdn: `${mtn}` };
                this.props.actions.getPinAndPukCode(payload);
              } else if (deviceDetailBtnFFlag && singleLink == 'changeOrReplaceDeviceLineBtn') {
                this.setState({
                  changeOrReplaceModal: true
                });
              } else if (singleLink == 'upgradeDeviceBtn') {
                if(simFreezeKey === selectedDeviceDetail[0]?.simFreezeInfo?.simFreezeDetails) {
                if(selectedDeviceDetail[0].simFreezeInfo?.simFreezeCode == "F" && selectedDeviceDetail[0].simFreezeInfo?.isBlocked == "Y") {
                  this.setState({
                    showSimFreezeModel: true, 
                    simFreezeDuration: selectedDeviceDetail[0].simFreezeInfo?.simFreezeDuration,
                    simUnfreezeTimeStamp: selectedDeviceDetail[0].simFreezeInfo?.simUnfreezeTimeStamp
                  });  // Open SimFreeze Popup
                } else if(selectedDeviceDetail[0].simFreezeInfo?.simFreezeCode == "N" && selectedDeviceDetail[0].simFreezeInfo?.isBlocked == "Y") {
                  this.setState({
                    showSimFreezeNotification2: true, 
                    simFreezeDuration: selectedDeviceDetail[0].simFreezeInfo?.simFreezeDuration,
                    simUnfreezeTimeStamp: selectedDeviceDetail[0].simFreezeInfo?.simUnfreezeTimeStamp
                  });  // Open SimFreeze Notification2
                } else { // simFreezeInfo?.simFreezeCode == "U/N" && simFreezeInfo?.isBlocked == "N/N"
                  let actionKey = pageContent && common.getActionKey(pageItems, `${singleLink}`);
                  const actionKeyValue = pageContent && common.getActionByKey(pageActions, actionKey);
                  const actionValue = actionKeyValue && actionKeyValue.actionValue;
                  this.handleUpgradeRedirection({
                    actionValue,
                    selectedDeviceInfo: selectedDeviceDetail[0],
                    primaryMtnDetails: primaryMtn,
                  });
                }
                } else {
                  window.location.reload();
                }
              } else if(singleLink == 'changeMobileNumberBtn'){
                let actionKey = pageContent && common.getActionKey(pageItems, `${singleLink}`);
                let click_info = this.getOnClickInfo(pageContent, actionKey);
                window.location.href = `${click_info.actionHref}${selectedDeviceDetail[0].encryptedMtnDES}`;
             } else {
                let actionKey = pageContent && common.getActionKey(pageItems, `${singleLink}`);
                let click_info = this.getOnClickInfo(pageContent, actionKey);
                click_info?.onclick();
              }
            }}
          >
            {this.listGroupCommonCode(pageItems, singleLink)}
          </ListGroupItem>
        </ListGroup>
      </Col>
    ) : null;
  };

  renderPreferenceLink = (singleLink, index) => {
    let enableSharenameid, enableCallFilter, enableBlocks;
    if (this.props.deviceDetailInfoSection && this.props.deviceDetailInfoSection.pageAttributes) {
      enableSharenameid = common.getItemValue(
        this.props.deviceDetailInfoSection.pageAttributes,
        'enableSharenameid'
      )
      enableCallFilter = common.getItemValue(
        this.props.deviceDetailInfoSection.pageAttributes,
        'enableCallFilter'
      )
      enableBlocks = common.getItemValue(
        this.props.deviceDetailInfoSection.pageAttributes,
        'enableBlocks'
      )
    }

    let pageContent;
    if (this.props.deviceDetailInfoSection && this.props.deviceDetailInfoSection.sections) {
      pageContent = common.getContentFromSection(this.props.deviceDetailInfoSection, 'devicesLandingMainSection');
      pageContent = pageContent.sections[0];
    }
    let pageItems = pageContent && pageContent.contents && pageContent.contents[0].items;
    let deviceList = (pageContent && pageContent.data) || [];
    let selectedDeviceDetail = (deviceList && deviceList.filter((singleDevice) => singleDevice.mtn == this.state.selectedMdn)) || [];
    let { preferences, shareNameIDBtnThrottle } = selectedDeviceDetail.length && selectedDeviceDetail[0];

    return preferences[`${singleLink}`] ? (
      <Col
        key={`${singleLink}`}
        colSizes={{
          desktop: 6,
          tablet: 6,
        }}
      >
        <ListGroup topLine={false} bottomLine={true} surface='light' viewport='desktop'>
          <ListGroupItem
            ariaLabel={`${common.getItemValue(pageItems, `${singleLink}`)}`}
            actionElement='icon'
            onClick={() => {
              if (
                singleLink == 'shareNameIDBtn' &&
                (enableSharenameid === 'true' || shareNameIDBtnThrottle)
              ) {
                let actionKey = pageContent && common.getActionKey(pageItems, `${singleLink}`);
                let click_info = this.getOnClickInfo(pageContent, `nsa_${actionKey}`);
                click_info?.onclick();
              } else if (singleLink == 'blockSpecificServicesBtn' && enableBlocks === 'true') {
                let actionKey = pageContent && common.getActionKey(pageItems, `${singleLink}`);
                let click_info = this.getOnClickInfo(pageContent, `nsa_${actionKey}`);
                click_info?.onclick();
              } else if (singleLink == 'blockCallsAndMessagesBtn' && enableBlocks === 'true') {
                let actionKey = pageContent && common.getActionKey(pageItems, `${singleLink}`);
                let click_info = this.getOnClickInfo(pageContent, `nsa_${actionKey}`);
                click_info?.onclick();
              } else if (singleLink == 'manageCallFilterBtn' && enableCallFilter === 'true') {
                let actionKey = pageContent && common.getActionKey(pageItems, `${singleLink}`);
                let click_info = this.getOnClickInfo(pageContent, `nsa_${actionKey}`);
                click_info?.onclick();
              } else {
                let actionKey = pageContent && common.getActionKey(pageItems, `${singleLink}`);
                let click_info = this.getOnClickInfo(pageContent, actionKey);
                click_info?.onclick();
              }
            }}
          >
            {this.listGroupCommonCode(pageItems, singleLink)}
          </ListGroupItem>
        </ListGroup>
      </Col>
    ) : null;
  };

  renderTroubleshootAndSupportLink = (singleLink, index) => {
    let pageContent;
    if (this.props.deviceDetailInfoSection && this.props.deviceDetailInfoSection.sections) {
      pageContent = common.getContentFromSection(this.props.deviceDetailInfoSection, 'devicesLandingMainSection');
      pageContent = pageContent.sections[0];
    }
    let pageItems = pageContent && pageContent.contents && pageContent.contents[0].items;
    let deviceList = (pageContent && pageContent.data) || [];

    let selectedDeviceDetail = (deviceList && deviceList.filter((singleDevice) => singleDevice.mtn == this.state.selectedMdn)) || [];
    let { skuId, mtn, troubleshootAndSupport } = selectedDeviceDetail.length && selectedDeviceDetail[0];

    return troubleshootAndSupport[`${singleLink}`] ? (
      <Col
        key={`${singleLink}`}
        colSizes={{
          desktop: 6,
          tablet: 6,
        }}
      >
        <ListGroup topLine={false} bottomLine={true} surface='light' viewport='desktop'>
          <ListGroupItem
            ariaLabel={`${common.getItemValue(pageItems, `${singleLink}`)}`}
            actionElement='icon'
            onClick={() => {
              if (singleLink == 'troubleshootBtn' && skuId) {
                let defaultUrl = common.getActionValue(pageItems, pageContent && pageContent.actions, 'troubleshootBtn');
                const payload = {
                  mdn: `${mtn}`,
                  skuId: `${skuId}`,
                };
                this.props.actions.getTroubleshootUrlResp(payload, defaultUrl);
              } else {
                let actionKey = pageContent && common.getActionKey(pageItems, `${singleLink}`);
                let click_info = this.getOnClickInfo(pageContent, actionKey);
                click_info?.onclick();
              }
            }}
          >
            {this.listGroupCommonCode(pageItems, singleLink)}
          </ListGroupItem>
        </ListGroup>
      </Col>
    ) : null;
  };

  handleDeviceMangement(deviceManagement) {
    let newArray = [];
    Object.keys(deviceManagement)?.forEach((singleLinkValue) => {
      if (deviceManagement[`${singleLinkValue}`]) {
        newArray.push(singleLinkValue);
      }
    });
    if (newArray.includes('checkNetworkCompatibiltyText') && newArray.includes('upgradeDeviceBtn')) {
      const index1 = newArray.findIndex((value) => value == 'checkNetworkCompatibiltyText');
      newArray.splice(index1, 1);
      const index2 = newArray.findIndex((value) => value == 'upgradeDeviceBtn');
      newArray.splice(index2 + 1, 0, 'checkNetworkCompatibiltyText');
    }

    return newArray?.map(this.renderDeviceManagementLink);
  }

  handlePreferences(preferences) {
    let newArray = [];
    delete preferences.shareNameIDBtnThrottle;
    Object.keys(preferences)?.forEach((singleLinkValue) => {
      if (preferences[`${singleLinkValue}`]) {
        newArray.push(singleLinkValue);
      }
    });
    return newArray?.map(this.renderPreferenceLink);
  }

  handleTroubleshootAndSupport(troubleshootAndSupport) {
    let newArray = [];
    Object.keys(troubleshootAndSupport)?.forEach((singleLinkValue) => {
      if (troubleshootAndSupport[`${singleLinkValue}`]) {
        newArray.push(singleLinkValue);
      }
    });
    return newArray?.map(this.renderTroubleshootAndSupportLink);
  }

  handleClickForError = (actionType, actionValue) => {
    if (actionType === 'http') {
      window.location.assign(actionValue);
    } else if (actionType === 'route') {
      window.location.hash = actionValue;
    }
  };

  handleModalChange = (data) => {
    this.setState({ showModal: data });
  };

  handleCancel = () => {
    this.setState({ showModal: false });
  };
  
  handleChangeOrReplaceModalChange = (data) => {
    this.setState({ changeOrReplaceModal: data });
  };

  handleChangeOrReplaceModalCancel = () => {
    this.setState({ changeOrReplaceModal: false });
  };

   recommendedDeviceTile = (oneClickRequest, selectedMtnRecommendedDevice, url) => {
    let isQuickUpgrade = selectedMtnRecommendedDevice[0]?.isQuickCartEnabled && selectedMtnRecommendedDevice[0]?.simId && selectedMtnRecommendedDevice[0]?.promoType && selectedMtnRecommendedDevice[0]?.promotionId;
    if(isQuickUpgrade){
      url = 'sales/nextgen/oneclick.html';
    }
    if(url?.includes('oneclick')){
      sessionStorage?.setItem('ONE_CLICK_ADD_DEVICE', JSON?.stringify(oneClickRequest));
    }
    return url;
   }

  
  handleSimFreezeModalChange = (data) => {
    this.setState({ showSimFreezeModel: data });
  };

  handleSimFreezeCancel = () => {
    this.setState({ showSimFreezeModel: false, simFreezeDuration: 0 });
  };

  handleSimFreezeNotification1Cancel = () => {
    this.setState({ showSimFreezeNotification1: false, simFreezeDuration: 0, simUnfreezeTimeStamp: "" });
  };

  handleSimFreezeNotification2Cancel = () => {
    this.setState({ showSimFreezeNotification2: false, simFreezeDuration: 0, simUnfreezeTimeStamp: "" });
  };

  displayProgressBar = (paymentInfo) => {
    return ((buyoutRedesignFFlag && paymentInfo?.buyoutElvisFlag) || (!buyoutRedesignFFlag && paymentInfo?.hasPayOffBalance && !paymentInfo?.promoDevice))
  }

  payNowFunction = (pageItems) => {
    let PayNowLabel = common.getItemValue(pageItems, "payOffDeviceBtn");
    if(buyoutRedesignFFlag) {
      PayNowLabel = "Pay now"
    }
    return PayNowLabel;
    }

    displayUpgradeBtn = (selectedDeviceDetail, pageContent, simFreezeKey, simFreezeInfo, actionUrl, selectedMdn, primaryMtn) => {
      let pageItems = pageContent && pageContent.contents && pageContent.contents[0].items;
      const pageActions = pageContent && pageContent.actions;
      let {
        paymentInfo = {},
        isMtnSuspended
      } = selectedDeviceDetail?.[0];
  
      return (selectedDeviceDetail?.[0]?.pearlTrialFlow) ? 
      <Button
      use='primary'
      data-track={`L1|P1||||||Pearl Trial Tile|${common.getItemValue(pageItems, 'pearlTrialBtn')}`}
      data-testid='pearlTrialBtnTestId'
      onClick={() => {
        let actionKey = pageContent && common.getActionKey(pageItems, `pearlTrialBtn`);
        const actionKeyValue = pageContent && common.getActionByKey(pageActions, actionKey);
        const actionValue = actionKeyValue && actionKeyValue.actionValue;
        window.location.href = `${actionValue}`;
      }}
      >
        {common.getItemValue(pageItems, 'pearlTrialBtn')}
    </Button>
    : !isMtnSuspended && !paymentInfo?.hasPayOffBalance && 
    <Button
      use='primary'
      data-testid="payOffDeviceUpgBtnTestId"
      data-track= {common.getItemValue(pageItems, "upgradeBtn")}
      onClick={() => {
      if(simFreezeKey === simFreezeInfo?.simFreezeDetails) {
        if(simFreezeInfo?.simFreezeCode == "F" && simFreezeInfo?.isBlocked == "Y"){
          this.setState({
            showSimFreezeModel: true, 
            simFreezeDuration: simFreezeInfo?.simFreezeDuration,
            simUnfreezeTimeStamp: simFreezeInfo?.simUnfreezeTimeStamp
          });  // Open SimFreeze Popup
        } else if (simFreezeInfo?.simFreezeCode == "N" && simFreezeInfo?.isBlocked == "Y"){
          this.setState({
            showSimFreezeNotification1: true, 
            simFreezeDuration: simFreezeInfo?.simFreezeDuration,
            simUnfreezeTimeStamp: simFreezeInfo?.simUnfreezeTimeStamp
          });  // Open SimFreeze Notification1
          dispatchNotifyEvent("Disable SIM protection", "Upgrade are blocked");
        } else { // simFreezeInfo?.simFreezeCode == "U/N" && simFreezeInfo?.isBlocked == "N/N"
          if(actionUrl !== undefined && actionUrl !== null && actionUrl  !== ''){
            this.setCookieForRecommendedDeviceUpgrade('selectedMtn', selectedMdn);
            window.location.href = actionUrl;
          }else{
            let actionValue = this.getUpgradeActionValue(selectedDeviceDetail, pageContent, pageItems, pageActions, "upgradeBtn");
            this.handleUpgradeRedirection({
              selectedDeviceInfo: selectedDeviceDetail[0],
              actionValue,
              primaryMtnDetails: primaryMtn,
            });
          }
        }
        } else {
          window.location.reload();
        }
        
  
      }}
      ariaLabel={"Device Payment Agreement section's Upgrade now"}
  
    >
      {common.getItemValue(pageItems, "upgradeBtn")}
    </Button>
    }

  displayPayNowBtn = (paymentInfo) => {
    return ((buyoutRedesignFFlag && paymentInfo?.buyoutElvisFlag) || (!buyoutRedesignFFlag && paymentInfo?.payOffEligible && paymentInfo?.hasPayOffBalance && !paymentInfo?.promoDevice))
  }

  displayNumber = (selectedMdn = '') => { 
    let pageContent;
    if (this.props.deviceDetailInfoSection && this.props.deviceDetailInfoSection.sections) {
      pageContent = common.getContentFromSection(this.props.deviceDetailInfoSection, 'devicesLandingMainSection');
      pageContent = pageContent.sections[0];
    }
    let pageItems = pageContent && pageContent.contents && pageContent.contents[0].items;
    const pageActions = pageContent && pageContent.actions;
    let deviceList = (pageContent && pageContent.data) || [];

    let selectedDeviceDetail = (deviceList && deviceList.filter((singleDevice) => singleDevice.mtn == selectedMdn)) || [];
    const upgradeFlowTestCookie = getCookie('upgradeFlowTest') ? true : false;
    const qParams = window.location.href.includes('upgradeFlowTest=true');
    const buttonType = ((selectedDeviceDetail[0]?.deviceCategory === 'phone' && selectedDeviceDetail[0]?.newSelectedMdnFlowFFlag) || qParams || upgradeFlowTestCookie) ? 'dppUpgradeBtn' : 'returnAndUpgradeBtn';
    const actionKey = pageContent && common.getActionKey(pageItems, buttonType);
    let {
      images = {},
      esim = false,
      psim = false,
      mtn = '',
      device5GE,
      displayMtn = '',
      modelName = '',
      nickName = '',
      simId = '',
      simType = '',
      userRole = '',
      deviceId = '',
      planUsageInfo = {},
      paymentInfo = {},
      accountPlan = {},
      openEnrollmentPeriod = '',
      deviceProtectionEnrolled = '',
      encryptedMtnDES,
      deviceCategory,
      isMtnSuspended,
      secondMtn,
      isSecondNumber,
      hasSecondNumberEligible,
      eSimActive,
      pSimActive,
      fileAClaim,
      simFreezeInfo,
      smartPhone,
      deviceImeiFlag,
      skuId
    } = selectedDeviceDetail.length && selectedDeviceDetail[0];

    const dppPayOffBtn = ((buttonType === 'dppUpgradeBtn') && (paymentInfo?.payOffEligible && paymentInfo?.hasPayOffBalance && !paymentInfo?.promoDevice));
    let primaryMtn = (deviceList && deviceList.find((singleDevice) => singleDevice.secondMtn == mtn)) || [];

    let secondMdn = deviceList && deviceList.find((singleDevice) => singleDevice.mtn == secondMtn);

    let paymentBalanceInfo = common.getItemValue(pageItems, 'PaymentBalanceHeader');

    if (paymentInfo?.pendingNumberOfInstallments && paymentBalanceInfo !== '') {
      paymentBalanceInfo = paymentBalanceInfo?.replace('##Months##', paymentInfo?.pendingNumberOfInstallments);
    }

    if (paymentInfo?.remainingBalance && paymentBalanceInfo !== '') {
      paymentBalanceInfo = paymentBalanceInfo?.replace('##balance##', `$${paymentInfo?.remainingBalance}`);
    }
    const isNewEndpoint = common.getItemValue(pageItems, 'newRecommendationTileEnabled') === 'true';
    let { recommendedDeviceId, actionUrl, impressionFragments, selectedMtnRecommendedDevice } = isNewEndpoint ? this.renderRecommendedDeviceNewUpgradeLink(selectedMdn) : this.renderRecommendedDeviceUpgradeLink(selectedMdn);
    const enablePersonalizedTile = (this.personalizationFlag() && !isMtnSuspended && !paymentInfo?.hasPayOffBalance && smartPhone) && (selectedMtnRecommendedDevice?.length > 0);
    if (enablePersonalizedTile && window?.vztag?.api ) {
      window?.vztag?.api?.dispatch("impression", impressionFragments);
    }
    let subFlow = actionUrl ? "EXPUPG" : "BAUUPG";
    let name = `L1|P1||||||PaymentInfo Tile|${common.getItemValue(pageItems, "upgradeBtn")}`;
    let dataTrackObject = {
      "type": "impression",
      "name": name,
      "format": "ONLY_USE_WHEN_DIRECTED_BY_TAGGING",
      "data": {
          "page": {
              "subFlow":subFlow 
          }
      }
    };

		const simfreezeInfoValue = (simFreezeInfo?.simFreezeCode+simFreezeInfo?.simUnfreezeTimeStamp+simFreezeInfo?.isBlocked);
		const simFreezeKey = pageContent && common.cipher(simfreezeInfoValue, 29);
	  // console.log("displayNumber simFreezeKey CHECK ==> ", simFreezeKey, " == ", simFreezeInfo?.simFreezeDetails);

    let DPASubtext = '';
    if(paymentInfo?.lessThan30Days){
      DPASubtext = common.getItemValue(pageItems,'BeforeThirtyDaysSubtext');
    } else if(paymentInfo?.edgeUpRequiredPercent === "50.00")
    {
      let earlyUpgradePaidPercentage = 0;
      earlyUpgradePaidPercentage = Math.round(
                (
                  parseFloat(paymentInfo?.numberOfInstallmentsBilled) /
                  (parseFloat(paymentInfo?.pendingNumberOfInstallments) + parseFloat(paymentInfo?.numberOfInstallmentsBilled))
                ) *
                100
      )
      if(earlyUpgradePaidPercentage < 50){
        DPASubtext = common.getItemValue(pageItems,'earlyUpgradepaidlessSubHeaderText');
        DPASubtext = DPASubtext.replace("##balance##" , '$' + paymentInfo?.dppEarlyUpgradeAmount)
      } else if (earlyUpgradePaidPercentage >= 50){
        DPASubtext = common.getItemValue(pageItems,'earlyUpgradepaidhighSubHeaderText');
      }
      else{
        DPASubtext = common.getItemValue(pageItems,'upgradeEligibilitySubtHeader');
      }
    } else if(paymentInfo?.upgradeEligible){
      DPASubtext = common.getItemValue(pageItems,'DevicePaymentAgreementText');
    } else {
      DPASubtext = common.getItemValue(pageItems,'upgradeEligibilitySubtHeader');
    }

    const changedNickName = (args) => {
      this.setState({
        changeNickName:args.mdnNickName
      }); 
    };
    
    let imeiTxt = reactGlobals?.featureFlag?.deviceImeiFFlag === "true" ? (deviceImeiFlag === "S"?common.getItemValue(pageItems, 'imei2Text'):common.getItemValue(pageItems, 'imeiText')):common.getItemValue(pageItems, 'imei2Text') ? common.getItemValue(pageItems, 'imei2Text'):`IMEI2`;  
    
    return (
      <>
        <DeviceDetailContainer className='grid main'>
          <Body size='large' color='#000000' bold={false}>
            <span data-cs-mask>{userRole}</span>
          </Body>
          <DeviceNameContainer>
            <Title size='small' primitive='h2'>
              <span data-cs-mask>{ this.state.changeNickName !== "" ? this.state.changeNickName: nickName}</span>
            </Title>
            <EditNickNameContainer>
              { this.props?.deviceHomeInfoSection?.updateNickNameFlag && (<TextLink
                type='standAlone'
                data-testid='editNickNameTestId'
                onClick={() => {
                  this.props.actions.openEditNickNameModal();
                }}
              >
              {selectedDeviceDetail?.[0]?.pearlTrialFlow? common.getItemValue(pageItems, 'pearlTrialEditDeviceNameTextlink'):common.getItemValue(pageItems, 'editDeviceNameTextlink')}
              </TextLink>)}
            </EditNickNameContainer>
          </DeviceNameContainer>
          {this.props.isOpenNickNameModal && (
            <EditNickNameModal
              isOpened={this.props.isOpenNickNameModal}
              handleCloseEditNickNameModal={() => this.props.actions.closeEditNickNameModal()}
              selectedDevice={selectedDeviceDetail.length && selectedDeviceDetail[0]}
              changedNickname = {(eve) => changedNickName(eve)}
              pageItems={pageItems}
            />
          )}
        </DeviceDetailContainer>
        <span>{!selectedDeviceDetail?.[0]?.pearlTrialFlow && displayMtn}</span>
        <DeviceInfoContainer>
          <Grid
            bleed='full'
            rowGutter='0px'
            colSizes={{
              tablet: 4,
              desktop: 3,
            }}
          >
            <Row>
              <Col colSizes={{ desktop: 2, tablet: 2 }}>
                <ContentContainer center>
                  <ProductImg isMtnSuspended={isMtnSuspended}>
                    <img src={images.mediumImage} />
                  </ProductImg>
                  {device5GE && !selectedDeviceDetail?.[0]?.pearlTrialFlow && (
                    <FiveGImg>
                      <img src='https://ss7.vzw.com/is/image/VerizonWireless/5g-logo-d-072822?$pngalpha$&scl=2' />
                    </FiveGImg>
                  )}
                </ContentContainer>
              </Col>
              <Col colSizes={{ desktop: 3, tablet: 3 }}>
                <ContentContainer>
                  <SubHeaderTitle modalSpacing={window.enableDualNumExp} isPearlFlow={selectedDeviceDetail?.[0]?.pearlTrialFlow}>
                    <Title primitive='h2'>{common.getItemValue(pageItems, 'modelHeader')}</Title>
                    <Title primitive='p'>
                      <span data-cs-mask>{modelName}</span>
                    </Title>
                    {device5GE && selectedDeviceDetail?.[0]?.pearlTrialFlow && (
                      <FiveGImg>
                        <img src='https://ss7.vzw.com/is/image/VerizonWireless/5g-logo-d-072822?$pngalpha$&scl=2' />
                      </FiveGImg>
                    )}
                  </SubHeaderTitle>
                  <SubHeaderTitle isPearlFlow={selectedDeviceDetail?.[0]?.pearlTrialFlow}>
                    {window.enableDualNumExp ? (
                      (secondMtn || isSecondNumber || hasSecondNumberEligible) ? (
                        <Title primitive='h2'>{common.getItemValue(pageItems, 'firstNumberHeader')}</Title>
                      ) : (
                        <Title primitive='h2'>{common.getItemValue(pageItems, 'mobileNumberHeader')}</Title>
                      )
                    ) : (
                      <Title primitive='h2'>{common.getItemValue(pageItems, 'mobileNumberHeader')}</Title>
                    )}

                    <Title primitive='p'>
                      <span data-cs-mask>
                        {!isSecondNumber ? displayMtn : primaryMtn && primaryMtn.displayMtn}{' '}
                        {!secondMtn &&
                          isSecondNumber &&
                          (!window.enableDualNumExp ? (
                          <TextLink
                            type='standAlone'
                            data-testid='manageTextTestId'
                            onClick={() => this.setState({ index: 0 })}
                          >
                              {common.getItemValue(pageItems, 'manageText')}
                            </TextLink>
                          ) : (
                            <TextLinkWrapper>
                              <TextLink
                                type='standAlone'
                                data-testid='manageTextTestId'
                                onClick={() => this.setState({ index: 0 })}
                              >
                                {common.getItemValue(pageItems, 'manageText')}
                              </TextLink>
                            </TextLinkWrapper>
                          ))}
                      </span>
                    </Title>
                    {!window.enableDualNumExp && (
                      <Title primitive='p'>
                        <span data-cs-mask>
                          {secondMdn ? secondMdn.displayMtn : !secondMtn && isSecondNumber && displayMtn}{' '}
                          {secondMtn && (
                            <TextLink
                              type='standAlone'
                              data-testid='manageTextTestId'
                              onClick={() => this.setState({ index: 1 })}
                            >
                              {common.getItemValue(pageItems, 'manageText')}
                            </TextLink>
                          )}
                        </span>
                      </Title>
                    )}
                  </SubHeaderTitle>
                </ContentContainer>
              </Col>
              <Col colSizes={{ desktop: 3, tablet: 3 }}>
                <ContentContainer>
                  <SubHeaderTitle modalSpacing={window.enableDualNumExp} isPearlFlow={selectedDeviceDetail?.[0]?.pearlTrialFlow}>
                    <Title primitive="h2">{common.getItemValue(pageItems, 'deviceIdHeader')}</Title>
                    <Title primitive="p">
                      <span className="contains-PII" aria-label={`${imeiTxt}: ${deviceId}`} data-cs-mask>{`${imeiTxt}: ${deviceId}`}</span>
                    </Title>
                    {esim && (
                      <InlineContentBox>
                        <Icon name='alternate-checkmark' color='rgb(0, 131, 48)' size='small' />
                        <Title primitive='p'>{common.getItemValue(pageItems, 'eSIMCapableHeader')}</Title>
                      </InlineContentBox>
                    )}
                  </SubHeaderTitle>
                  {window.enableDualNumExp && (secondMtn || isSecondNumber || hasSecondNumberEligible) && (
                    <SubHeaderTitle isPearlFlow={selectedDeviceDetail?.[0]?.pearlTrialFlow}>
                      {<Title primitive='h2'>{common.getItemValue(pageItems, 'secondNumberHeader')}</Title>}
                      {
                        <Title primitive='p'>
                          <span data-cs-mask>
                            {secondMdn ? secondMdn.displayMtn : !secondMtn && isSecondNumber && displayMtn}
                            {secondMtn && (
                              <TextLinkWrapper>
                                <TextLink
                                  type='standAlone'
                                  data-testid='manageTextTestId'
                                  onClick={() => this.setState({ index: 1 })}
                                >
                                  {common.getItemValue(pageItems, 'manageText')}
                                </TextLink>
                              </TextLinkWrapper>
                            )}
                          </span>
                        </Title>
                      }
                      {!secondMtn && !isSecondNumber && hasSecondNumberEligible && (
                        <Title primitive='p'>
                          <span className="contains-PII" data-cs-mask>
                            {common.getItemValue(pageItems, "getSeconNumberSubHeaderText")}
                            <TextLinkWrapper>
                              <TextLink
                                type="standAlone"
                                size='large'
                                data-track= {common.getItemValue(pageItems, 'getSecondNumberLinkText')} 
                                ariaLabel= {common.getItemValue(pageItems, 'getSecondNumberLinkText')} 
                                onClick={() => this.getOnClickInfo(pageContent, 'getSecondNumberAction')?.onclick()
                                }
                                data-testid="getASecondNumberLink"
                              >
                                {common.getItemValue(pageItems, 'getSecondNumberLinkText')}
                              </TextLink>
                            </TextLinkWrapper>
                          </span>
                        </Title>
                      )}
                    </SubHeaderTitle>
                  )}
                </ContentContainer>
              </Col>
              <Col colSizes={{ desktop: 4, tablet: 4 }}>
                <ContentContainer>
                  <SubHeaderTitle isPearlFlow={selectedDeviceDetail?.[0]?.pearlTrialFlow}>
                    <Title primitive='h2'>{common.getItemValue(pageItems, 'simIdHeader')}</Title>

                    <Title primitive='p'>
                      {' '}
                      <span className='contains-PII' data-cs-mask>
                        {simType}ID{' '}
                        {eSimActive ? (
                          `${common.getItemValue(pageItems, 'eSIMText')}:${simId}`
                        ) : pSimActive ? (
                          <span>
                            (Removable SIM card):<Title primitive='p'>{simId}</Title>
                          </span>
                        ) : (
                          `:${simId}`
                        )}
                      </span>
                    </Title>
                  </SubHeaderTitle>
                </ContentContainer>
              </Col>
            </Row>
          </Grid>
        </DeviceInfoContainer>
      
        {this.state.showSimFreezeNotification1 && (
          <Notification
            type='warning'
            title={common.getItemValue(pageItems, 'SIMFreezeNotificationTitle').replace('<unfreeze timestamp>', this.state.simUnfreezeTimeStamp)}
            subtitle={common.getItemValue(pageItems, 'SIMFreezeNotificationDesc').replace('<thaw threshold>', this.state.simFreezeDuration)}
            fullBleed={true}
            inlineTreatment={false}
            disableFocus={false}
            layout='horizontal'
            onCloseButtonClick={this.handleSimFreezeNotification1Cancel}
          />
        )}
        {(skuId != 'FMTLK') &&
        <DeviceInfoContainer2>
          <Grid
            bleed='full'
            rowGutter='0px'
            colSizes={{
              tablet: 6,
              desktop: 4,
            }}
          >
            <Row>
              <Col colSizes={{ desktop: 4, tablet: 6 }}>
                {(!enablePersonalizedTile) && (<TileContainerWrapper>
                  <TileContainer
                    backgroundColor='#F6F6F6'
                    padding='16px 24px 24px 24px'
                    backgroundImage='none'
                    id='tileContainer'
                    width='100%'
                    height='280px'
                  >
                    {paymentInfo?.hasPayOffBalance && paymentInfo?.promoDevice && (
                      <Fragment>
                        <MyPlanTitle>
                          <Title primitive='h2'>{common.getItemValue(pageItems, 'DevicePaymentAgreementHeader')}</Title>
                        </MyPlanTitle>
                        <MyPlanSubTitle>
                          <Title primitive='p'>{common.getItemValue(pageItems, 'DevicePaymentAgreemenPromotiontText')}</Title>
                        </MyPlanSubTitle>
                      </Fragment>
                    )}
                    {paymentInfo?.hasPayOffBalance && !paymentInfo?.promoDevice && (
                      <Fragment>
                        <MyPlanTitle>
                          <Title primitive='h2'>{common.getItemValue(pageItems, 'DevicePaymentAgreementHeader')}</Title>
                        </MyPlanTitle>
                        <MyPlanSubTitle>
                          <Title primitive='p'>
                            <span dangerouslySetInnerHTML={{ __html: DPASubtext }} />
                          </Title>
                        </MyPlanSubTitle>
                      </Fragment>
                    )}
                    {selectedDeviceDetail?.[0]?.pearlTrialFlow ? 
                      <Fragment>
                        <MyPlanTitle>
                          <Title primitive='h2'>{common.getItemValue(pageItems, 'pearlEligibleHeaderText')}</Title>
                        </MyPlanTitle>
                        <MyPlanSubTitle>
                          <Title primitive='p'>{common.getItemValue(pageItems, 'pearlEligibleSubHeader')}</Title>
                        </MyPlanSubTitle>
                      </Fragment>
                    : !paymentInfo?.hasPayOffBalance && (
                      <Fragment>
                        <MyPlanTitle>
                          <Title primitive='h2'>{common.getItemValue(pageItems, 'upgradeEligibilityHeaderText')}</Title>
                        </MyPlanTitle>
                        {recommendedDeviceId ? (
                    <MyPlanSubTitle>
                      <Title primitive='p'>{common.getItemValue(pageItems, 'upgradeEligibilityOneclickSubtHeader')}</Title>
                    </MyPlanSubTitle>) : 
                    (
                    <MyPlanSubTitle>
                      <Title primitive='p'>{common.getItemValue(pageItems, 'upgradeEligibilitySubtHeader')}</Title>
                    </MyPlanSubTitle>
                 )}

                      </Fragment>
                  )}
                    {this.displayProgressBar(paymentInfo) && (
                      <UpgradeTileContent>
                        <SecondRow>
                          <Title primitive='p'>{paymentBalanceInfo}</Title>
                        </SecondRow>
                        <ThirdRow
                          edgeUpRequiredPercent={paymentInfo?.edgeUpRequiredPercent}
                          paidPercentage={Math.round(
                            (parseFloat(paymentInfo?.numberOfInstallmentsBilled) /
                              (parseFloat(paymentInfo?.pendingNumberOfInstallments) + parseFloat(paymentInfo?.numberOfInstallmentsBilled))) *
                              100
                          )}
                        >
                          <Title id='total' primitive='p'></Title>
                          {paymentInfo?.edgeUpRequiredPercent && parseInt(paymentInfo?.edgeUpRequiredPercent) == 50 && (
                            <Title id='middleDot' primitive='p'></Title>
                          )}
                          <Title id='paid' primitive='p'></Title>
                        </ThirdRow>
                      </UpgradeTileContent>
                    )}
                    <MyPlanDeviceCtaContainer>
                      {isMtnSuspended && (common.getItemValue(pageItems, 'reconnectServiceBtn') ? <Button
                        use='secondary'
                        data-track={`L1|P1||||||PaymentInfo Tile|${common.getItemValue(pageItems, 'reconnectServiceBtn')}`}
                        data-testid="reconnectServiceBtnTestId"
                        onClick={() => {
                          const reConnectDeviceActionKey = pageContent && common.getActionKey(pageItems, "reconnectServiceBtn");
                          const reConnectDeviceAction = pageContent && common.getActionByKey(pageActions, reConnectDeviceActionKey);
                          window.location.href = reConnectDeviceAction.actionValue;
                        }}
                        ariaLabel={"Device Payment Agreement section's Re-connect"}

                      >
                        {common.getItemValue(pageItems, 'reconnectServiceBtn')}
                      </Button> : <Button
                        use='secondary'
                        data-track={`L1|P1||||||PaymentInfo Tile|${common.getItemValue(pageItems, 'suspendOrReconnectServiceBtn')}`}
                        data-testid="suspendOrReconnectServiceBtnTestId"
                        onClick={() => {
                          const reConnectDeviceActionKey = pageContent && common.getActionKey(pageItems, "suspendOrReconnectServiceBtn");
                          const reConnectDeviceAction = pageContent && common.getActionByKey(pageActions, reConnectDeviceActionKey);
                          window.location.href = reConnectDeviceAction.actionValue;
                        }}
                        ariaLabel={"Device Payment Agreement section's Suspend or reconnect service"}
                      >
                        {common.getItemValue(pageItems, 'suspendOrReconnectServiceBtn')}
                      </Button>)}
                      {this.displayUpgradeBtn(selectedDeviceDetail, pageContent, simFreezeKey, simFreezeInfo, actionUrl, selectedMdn, primaryMtn)}
                      {paymentInfo?.payOffEligible && paymentInfo?.hasPayOffBalance && paymentInfo?.promoDevice && <Button
                        use='primary'
                        data-track={`L1|P1||||||PaymentInfo Tile|${common.getItemValue(pageItems, "payOffDeviceBtn")}`}
                        data-testid="payOffDeviceBtnTestId"
                        onClick={() => {
                          let actionKey = pageContent && common.getActionKey(pageItems, `payOffDeviceBtn`);
                          const actionKeyValue = pageContent && common.getActionByKey(pageActions, actionKey);
                          const actionValue = actionKeyValue && actionKeyValue.actionValue;
                          window.location.href = `${actionValue}${mtn}`;
                        }}
                        ariaLabel={"Device Payment Agreement section's Pay off device"}

                      >
                        {common.getItemValue(pageItems, "payOffDeviceBtn")}
                      </Button>}
                      {!isMtnSuspended && (paymentInfo?.displayReturnOption || dppPayOffBtn) && paymentInfo?.hasPayOffBalance && !paymentInfo?.promoDevice && <Button
                        use="primary"
                        data-testid="returnAndUpgradeBtnTestId"
                        data-track={`L1|P1||||||PaymentInfo Tile|${common.getItemValue(pageItems, 'returnAndUpgradeBtn')}`}
                        onClick={() => {  
                          let actionValue = this.getUpgradeActionValue(selectedDeviceDetail, pageContent, pageItems, pageActions, 'returnAndUpgradeBtn' );                     
                          this.handleUpgradeRedirection({
                            actionValue,
                            selectedDeviceInfo: selectedDeviceDetail[0],
                            primaryMtnDetails: primaryMtn,
                          });
                        }}
                        ariaLabel={"Device Payment Agreement section's Return And Upgrade"}
                      >
                        {common.getItemValue(pageItems, buttonType)}
                      </Button>}
                      {!isMtnSuspended && !paymentInfo?.displayReturnOption && paymentInfo?.upgradeEligible && paymentInfo?.hasPayOffBalance && !paymentInfo?.promoDevice && <Button
                        use='primary'
                        data-testid="upgradeBtnTestId"
                        data-track={common.getItemValue(pageItems, "upgradeBtn")}
                        onClick={() => {
                          if(simFreezeKey === simFreezeInfo?.simFreezeDetails) {
                          if(simFreezeInfo?.simFreezeCode == "F" && simFreezeInfo?.isBlocked == "Y"){
                            this.setState({
                              showSimFreezeModel: true, 
                              simFreezeDuration: simFreezeInfo?.simFreezeDuration,
                              simUnfreezeTimeStamp: simFreezeInfo?.simUnfreezeTimeStamp
                            });  // Open SimFreeze Popup
                          } else if (simFreezeInfo?.simFreezeCode == "N" && simFreezeInfo?.isBlocked == "Y"){
                            this.setState({
                              showSimFreezeNotification1: true, 
                              simFreezeDuration: simFreezeInfo?.simFreezeDuration,
                              simUnfreezeTimeStamp: simFreezeInfo?.simUnfreezeTimeStamp
                            });  // Open SimFreeze Notification1
                          } else { // simFreezeInfo?.simFreezeCode == "U/N" && simFreezeInfo?.isBlocked == "N/N"
                            let actionKey = pageContent && common.getActionKey(pageItems, `upgradeBtn`);
                            const actionKeyValue = pageContent && common.getActionByKey(pageActions, actionKey);
                            const actionValue = actionKeyValue && actionKeyValue.actionValue;
                            this.handleUpgradeRedirection({
                              actionValue,
                              selectedDeviceInfo: selectedDeviceDetail[0],
                              primaryMtnDetails: primaryMtn,
                            });
                          }
                          } else {
                            window.location.reload();
                          }
                        }}
                        ariaLabel={"Device Payment Agreement section's Upgrade now"}

                      >
                        {common.getItemValue(pageItems, "upgradeBtn")}
                      </Button>}
                      {this.displayPayNowBtn(paymentInfo) && <Button
                        use='secondary'
                        data-track={`L1|P1||||||PaymentInfo Tile|${common.getItemValue(pageItems, "payOffDeviceBtn")}`}
                        data-testid="payOffDeviceBtnNotPromoDevTestId"
                        onClick={() => {
                          let actionKey = pageContent && common.getActionKey(pageItems, `payOffDeviceBtn`);
                          const actionKeyValue = pageContent && common.getActionByKey(pageActions, actionKey);
                          const actionValue = actionKeyValue && actionKeyValue.actionValue;
                          window.location.href = `${actionValue}${mtn}`;
                        }}
                        ariaLabel={"Device Payment Agreement section's Pay office device"}

                      >
                        {this.payNowFunction(pageItems)}
                      </Button>}
                    </MyPlanDeviceCtaContainer>
                  </TileContainer>
                </TileContainerWrapper>)}
                {(enablePersonalizedTile) && (<TileContainerWrapper>
                  <TileContainer
                    backgroundColor='#F6F6F6'
                    padding='16px 24px 24px 24px'
                    backgroundImage='none'
                    id='tileContainer'
                    width='100%'
                    height='280px'
                  >
                    <Row>
                      <Col xs={8}>
                        <Banner showBanner={selectedMtnRecommendedDevice?.[0]?.offerAmount || 'NO_PROMO'}>
                          <Body size="small" primitive="p" color="#fff" bold>Save ${selectedMtnRecommendedDevice?.[0]?.offerAmount}</Body>
                        </Banner>
                        {selectedDeviceDetail?.[0]?.pearlTrialFlow ?
                          <Fragment>
                            <MyPlanTitle>
                              <Title primitive='h2'>{common.getItemValue(pageItems, 'pearlEligibleHeaderText')}</Title>
                            </MyPlanTitle>
                            <MyPlanSubTitle>
                              <Title primitive='p'>{common.getItemValue(pageItems, 'pearlEligibleSubHeader')}</Title>
                            </MyPlanSubTitle>
                          </Fragment>
                          : !paymentInfo?.hasPayOffBalance && (
                            <Fragment>
                              <MyPlanTitle>
                                <Title primitive='h2'>{common.getItemValue(pageItems, 'upgradeEligibilityHeaderText')}</Title>
                              </MyPlanTitle>
                              <MyPlanSubTitle>
                                <Title primitive='p'>Based on your current device, we recommend the {selectedMtnRecommendedDevice?.[0]?.productDisplayName}</Title>
                              </MyPlanSubTitle>
                            </Fragment>
                          )}
                      </Col>
                      <Col xs={4}>
                        <ProductImg>
                          <img style={{width : '100%'}} src={selectedMtnRecommendedDevice?.[0]?.imageUrl} />
                        </ProductImg>
                      </Col>
                    </Row>
                    <MyPlanDeviceCtaContainer>
                      {selectedDeviceDetail?.[0]?.pearlTrialFlow ? 
                        <Button
                        use='primary'
                        data-track={`L1|P2||||||PlanUsage Tile|${common.getItemValue(pageItems, 'pearlTrialBtn')}`}
                        data-testid='pearlTrialBtnTestId'
                        onClick={() => {
                          let actionKey = pageContent && common.getActionKey(pageItems, `pearlTrialBtn`);
                          const actionKeyValue = pageContent && common.getActionByKey(pageActions, actionKey);
                          const actionValue = actionKeyValue && actionKeyValue.actionValue;
                          window.location.href = `${actionValue}`;
                        }}
                        >
                          {common.getItemValue(pageItems, 'pearlTrialBtn')}
                      </Button>
                      : !isMtnSuspended && !paymentInfo?.hasPayOffBalance && <Button
                        use='primary'
                        data-testid="payOffPersonalizedDeviceUpgBtnTestId"
                        data-track={common.getItemValue(pageItems, "upgradeBtn")}
                        onClick={() => {
                          if(simFreezeKey === simFreezeInfo?.simFreezeDetails) {
                          if (simFreezeInfo?.simFreezeCode == "F" && simFreezeInfo?.isBlocked == "Y") {
                            this.setState({
                              showSimFreezeModel: true,
                              simFreezeDuration: simFreezeInfo?.simFreezeDuration,
                              simUnfreezeTimeStamp: simFreezeInfo?.simUnfreezeTimeStamp
                            });  // Open SimFreeze Popup
                          } else if (simFreezeInfo?.simFreezeCode == "N" && simFreezeInfo?.isBlocked == "Y") {
                            this.setState({
                              showSimFreezeNotification1: true,
                              simFreezeDuration: simFreezeInfo?.simFreezeDuration,
                              simUnfreezeTimeStamp: simFreezeInfo?.simUnfreezeTimeStamp
                            });  // Open SimFreeze Notification1
                          } else { // simFreezeInfo?.simFreezeCode == "U/N" && simFreezeInfo?.isBlocked == "N/N"
                            if (actionUrl !== undefined && actionUrl !== null && actionUrl !== '') {
                              this.setCookieForRecommendedDeviceUpgrade('selectedMtn', selectedMdn);
                              window.location.href = actionUrl;
                            }else{
                              let actionKey = pageContent && common.getActionKey(pageItems, `upgradeBtn`);
                              const actionKeyValue = pageContent && common.getActionByKey(pageActions, actionKey);
                              const actionValue = actionKeyValue && actionKeyValue.actionValue;
                              this.handleUpgradeRedirection({
                                selectedDeviceInfo: selectedDeviceDetail[0],
                                actionValue,
                                primaryMtnDetails: primaryMtn,
                              });
                            }
                          }
                          } else {
                            window.location.reload();
                          }
                        }}
                        ariaLabel={"Device Payment Agreement section's Upgrade now"}
                      >
                        {common.getItemValue(pageItems, "upgradeBtn")}
                      </Button>}
                      <Button
                        use='secondary'
                        data-testid='shopAllPhonesBtnTestId'
                        data-track= {JSON.stringify({...dataTrackObject, "name": `L1|P1||||||paymentinfo tile|Shop all phones`
                        })}
                        onClick={() => { window.location.href = `${window.origin}/smartphones`; }}
                        ariaLabel={"Device Payment Agreement section's Shop all phones"}
                      >
                        {"Shop all phones"}
                      </Button>
                    </MyPlanDeviceCtaContainer>
                  </TileContainer>
                </TileContainerWrapper>)}
              </Col>
              <Col colSizes={{ desktop: 4, tablet: 6 }}>
                {planUsageInfo?.planName && (
                  <TileContainerWrapper>
                    <TileContainer
                      backgroundColor='#F6F6F6'
                      padding='16px 24px 24px 24px'
                      backgroundImage='none'
                      id='tileContainer'
                      width='100%'
                      height='280px'
                    >
                      <MyPlanTitle>
                        <Title primitive='h2'>{common.getItemValue(pageItems, 'myPlanCardHeader')}</Title>
                      </MyPlanTitle>
                      <MyPlanSubTitle>
                        <Title primitive='p'>{planUsageInfo.planName}</Title>
                      </MyPlanSubTitle>
                      <MyPlanContent>
                        {accountPlan?.dataUsed && (
                          <Title primitive='p'>{`${accountPlan?.dataUsed} ${
                            accountPlan?.unlimitedDataPlan
                              ? `${accountPlan?.unitOfMeasureCDForData} / ${common.getItemValue(pageItems, 'accountPlanUnlimitedDataText')}`
                              : `${accountPlan?.unitOfMeasureCDForData} / ${accountPlan?.dataPlan}`
                          }`}</Title>
                        )}
                        {accountPlan?.messageUsed && accountPlan?.messagePlan && (
                          <Title primitive='p'>{`${accountPlan?.messageUsed} ${
                            accountPlan?.unlimitedMessagePlan
                              ? `/ ${common.getItemValue(pageItems, 'accountPlanUnlimitedMessageText')}`
                              : `/ ${accountPlan?.messagePlan}`
                          }`}</Title>
                        )}
                        {accountPlan?.minutesUsed && (
                          <Title primitive='p'>{`${accountPlan?.minutesUsed} ${
                            accountPlan?.unlimitedDataPlan
                              ? `/ ${common.getItemValue(pageItems, 'accountPlanUnlimitedMinutesText')}`
                              : `/ ${accountPlan?.dataPlan}`
                          }`}</Title>
                        )}
                      </MyPlanContent>
                      <MyPlanDeviceCtaContainer>
                        {selectedDeviceDetail?.[0]?.pearlTrialFlow ? 
                          (<Button
                          use='primary'
                          data-track={`L1|P2||||||PlanUsage Tile|${common.getItemValue(pageItems, 'pearlTrialPlanBtn')}`}
                          data-testid = 'pearlTrialPlanBtn'
                          onClick={() => {
                            let actionKey = pageContent && common.getActionKey(pageItems, `pearlTrialPlanBtn`);
                                const actionKeyValue = pageContent && common.getActionByKey(pageActions, actionKey);
                                const actionValue = actionKeyValue && actionKeyValue.actionValue;
                                window.location.href = `${actionValue}`;
                          }}
                          >
                            {common.getItemValue(pageItems, 'pearlTrialPlanBtn')}
                          </Button>)
                        : !isSecondNumber ? (
                          <Button
                            use='primary'
                            data-testid='managePlanBtnTestId'
                            data-track={`L1|P2||||||PlanUsage Tile|${common.getItemValue(pageItems, 'managePlanBtn')}`}
                            onClick={() => {
                              let actionKey = pageContent && common.getActionKey(pageItems, `managePlanBtn`);
                              let click_info = this.getOnClickInfo(pageContent, actionKey);
                              click_info?.onclick();
                            }}
                            ariaLabel={"My Plan section's Manage plan"}

                          >
                            {common.getItemValue(pageItems, 'managePlanBtn')}
                          </Button>
                        ) : (
                          <Button
                            use='primary'
                            data-testid='upgradePlanBtnTestId'
                            data-track={`L1|P2||||||PlanUsage Tile|${common.getItemValue(pageItems, 'upgradePlanBtn')}`}
                            onClick={() => {
                              this.handleModalChange(true);
                            }}
                            ariaLabel={"My Plan section's Upgrade to full plan"}

                          >
                            {common.getItemValue(pageItems, 'upgradePlanBtn')}
                          </Button>
                        )}
                        <Button
                          use='secondary'
                          data-testid='reviewUsageBtnTestId'
                          data-track={`L1|P2||||||PlanUsage Tile|${common.getItemValue(pageItems, 'reviewUsageBtn')}`}
                          onClick={() => {
                            let actionKey = pageContent && common.getActionKey(pageItems, `reviewUsageBtn`);
                            let click_info = this.getOnClickInfo(pageContent, actionKey);
                            click_info?.onclick();
                          }}
                          ariaLabel={"My Plan section's Review usage"}

                        >
                        {selectedDeviceDetail?.[0]?.pearlTrialFlow ? common.getItemValue(pageItems, 'checkUsageBtn') : common.getItemValue(pageItems, 'reviewUsageBtn')}
                        </Button>
                      </MyPlanDeviceCtaContainer>
                    </TileContainer>
                  </TileContainerWrapper>
                )}
              </Col>
              
              
              <Col colSizes={{ desktop: 4, tablet: 6 }}>
                {deviceProtectionEnrolled == 'Y' ? (
                  <TileContainerWrapperDark isDarkTile={false}>
                    <TileContainer
                      backgroundColor='#000'
                      padding='16px 24px 24px 24px'
                      backgroundImage='none'
                      id='tileContainer'
                      width='100%'
                      height='280px'
                    >
                      <ProtectioTitle isDarkTile={false}>
                        <Title primitive='h2'>{common.getItemValue(pageItems, 'deviceProtectionHeaderText')}</Title>
                      </ProtectioTitle>
                      <ProtectioSubTitle isDarkTile={false}>
                        <Title primitive='p'>{common.getItemValue(pageItems, 'deviceProtectionSubHeaderText')}</Title>
                      </ProtectioSubTitle>
                      <DeviceCtaContainer isDarkTile={false}>
                        <Button
                          use='secondary'
                          data-track={`L1|P3||||||Device Protect Tile|${common.getItemValue(pageItems, 'manageDeviceProtection')}`}
                          data-testid='manageDeviceProtectionTestId'
                          onClick={() => {
                            let actionKey = pageContent && common.getActionKey(pageItems, `manageDeviceProtection`);
                            let productGroupID = selectedDeviceDetail?.[0]?.productGroupId; 
                            const actionKeyValue = pageContent && common.getActionByKey(pageActions, actionKey);
                            let actionValue = actionKeyValue && actionKeyValue.actionValue;
                            actionValue = (productGroupID != "" && productGroupID != null) ? actionValue+productGroupID : actionValue;
                            window.location.href = `${actionValue}`;
                          }}
                          ariaLabel={"Manage your device protection section's Review coverage"}

                        >
                          {common.getItemValue(pageItems, 'manageDeviceProtection')}
                        </Button>
                        {fileAClaim === 'Y' && (
                          <Button
                            use='secondary'
                            data-testid='fileClaimbtnTestId'
                            data-track={`L1|P2||||||PlanUsage Tile|${common.getItemValue(pageItems, 'fileClaimbtn')}`}
                            onClick={() => {
                              let actionKey = pageContent && common.getActionKey(pageItems, `fileClaimbtn`);
                              let click_info = this.getOnClickInfo(pageContent, actionKey);
                              click_info?.onclick();
                            }}
                            ariaLabel={"Manage your device protection section's FileAClaim"}

                          >
                            
                            {common.getItemValue(pageItems, 'fileClaimbtn')}
                          </Button>
                        )}
                        
                       
                      </DeviceCtaContainer>
                    </TileContainer>
                  </TileContainerWrapperDark>
                ) : openEnrollmentPeriod == 'N' && deviceProtectionEnrolled == 'N'  && !selectedDeviceDetail?.[0]?.pearlTrialFlow ? (
                  <TileContainerWrapperDark isDarkTile={false}>
                    <TileContainer
                      backgroundColor='#000'
                      padding='16px 24px 24px 24px'
                      backgroundImage='none'
                      id='tileContainer'
                      width='100%'
                      height='280px'
                    >
                      <ProtectioTitle isDarkTile={false}>
                        <Title primitive='h2'>{common.getItemValue(pageItems, `deviceProtectionNotEligibleHeaderText`)}</Title>
                      </ProtectioTitle>
                      <ProtectioSubTitle isDarkTile={false}>
                        <Title primitive='p'>
                          <span
                            dangerouslySetInnerHTML={{ __html: common.getItemValue(pageItems, `deviceProtectionNotEligibleSubHeaderText`) }}
                          ></span>
                        </Title>
                      </ProtectioSubTitle>
                      <DeviceCtaContainer isDarkTile={false}>
                        <Button
                          use='secondary'
                          data-track={`L1|P3||||||Device Protect Tile|${common.getItemValue(pageItems, 'learnMore')}`}
                          data-testid='learnMoreTestId'
                          onClick={() => {
                            let actionKey = pageContent && common.getActionKey(pageItems, `learnMore`);
                            let click_info = this.getOnClickInfo(pageContent, actionKey);
                            click_info?.onclick();
                          }}
                          ariaLabel={"Manage your device protection section's Learn More"}

                        >
                          {common.getItemValue(pageItems, 'learnMore')}
                        </Button>
                      </DeviceCtaContainer>
                    </TileContainer>
                  </TileContainerWrapperDark>
                ) : (
                  !selectedDeviceDetail?.[0]?.pearlTrialFlow ?
                  <TileContainerWrapperDark isDarkTile={true}>
                    <TileContainer
                      backgroundColor='#000'
                      padding='16px 24px 24px 24px'
                      backgroundImage='none'
                      id='tileContainer'
                      width='100%'
                      height='280px'
                    >
                      <ProtectioTitle isDarkTile={true}>
                        <Title primitive='h2'>{common.getItemValue(pageItems, `cardHeaderText`)}</Title>
                      </ProtectioTitle>
                      <ProtectioSubTitle isDarkTile={true}>
                        <Title primitive='p'>
                          <span dangerouslySetInnerHTML={{ __html: common.getItemValue(pageItems, `cardSubHeaderText`) }}></span>
                        </Title>
                      </ProtectioSubTitle>
                      <DeviceCtaContainer isDarkTile={true}>
                        <Button
                          use='primary'
                          data-track={`L1|P3||||||Device Protect Tile|${common.getItemValue(pageItems, 'enrollBtn')}`}
                          data-testid='enrollBtnTestId'
                          onClick={() => {
                            let actionKey = pageContent && common.getActionKey(pageItems, `enrollBtn`);
                            let click_info = this.getOnClickInfo(pageContent, actionKey);
                            click_info?.onclick();
                          }}
                          ariaLabel={"Manage your device protection section's Get it now"}

                        >
                          {common.getItemValue(pageItems, 'enrollBtn')}
                        </Button>
                      </DeviceCtaContainer>
                    </TileContainer>
                  </TileContainerWrapperDark>:""
                )}
              </Col>
              
            </Row>
          </Grid>
        </DeviceInfoContainer2>
        }
        
        {this.state.showSimFreezeNotification2 && (
          <Notification
            type='warning'
            title={common.getItemValue(pageItems, 'SIMFreezeNotificationTitle').replace('<unfreeze timestamp>', this.state.simUnfreezeTimeStamp)}
            subtitle={common.getItemValue(pageItems, 'SIMFreezeNotificationDesc').replace('<thaw threshold>', this.state.simFreezeDuration)}
            fullBleed={true}
            inlineTreatment={false}
            disableFocus={false}
            layout='horizontal'
            onCloseButtonClick={this.handleSimFreezeNotification2Cancel}
          />
        )}

      </>
    );
  };

  render() {

    console.log("session stro", sessionStorage.getItem("pearlTrialFlow"));
    const { pageContent, pageItems, pageActions, deviceList, selectedDeviceDetail } = this.pageContentCommonCode();
    let { pendingLineChange = false, paymentInfo = {}, secondMtn, skuId } = selectedDeviceDetail.length && selectedDeviceDetail[0];
    const familyLineFFlag = this.props.deviceDetailInfoSection?.featureFlags?.familyLineDigitalFlowControlFFlag;
    let paymentBalanceInfo = common.getItemValue(pageItems, 'PaymentBalanceHeader');

    if (paymentInfo?.pendingNumberOfInstallments && paymentBalanceInfo !== '') {
      paymentBalanceInfo = paymentBalanceInfo?.replace('##Months##', paymentInfo?.pendingNumberOfInstallments);
    }

    console.log("pageContent", this.props.deviceHomeInfoSection);
    if (paymentInfo?.remainingBalance && paymentBalanceInfo !== '') {
      paymentBalanceInfo = paymentBalanceInfo?.replace('##balance##', `$${paymentInfo?.remainingBalance}`);
    }

    let selectedDualNum = (deviceList && deviceList.filter((singleDevice) => singleDevice.mtn == secondMtn)) || [];

    let allDevices = [];

    if (deviceList) {
      deviceList.forEach((singleDevice, index) => {
        if (!singleDevice?.isSecondNumber) {
          allDevices.push(singleDevice);
        }
      });
    }

    let deviceManagementArray = {};
    let preferencesArray = {};
    let troubleshootAndSupportArray = {};
    let deviceData = {};
    if (selectedDeviceDetail?.length && selectedDualNum.length && this.state.index && secondMtn !== '') {
      deviceManagementArray = { ...selectedDualNum[0]?.deviceManagement };
      preferencesArray = { ...selectedDualNum[0]?.preferences };
      troubleshootAndSupportArray = { ...selectedDualNum[0]?.troubleshootAndSupport };
      deviceData = { ...selectedDualNum[0] };
    } else {
      deviceManagementArray = { ...selectedDeviceDetail[0]?.deviceManagement };
      preferencesArray = { ...selectedDeviceDetail[0]?.preferences };
      troubleshootAndSupportArray = { ...selectedDeviceDetail[0]?.troubleshootAndSupport };
      deviceData = { ...selectedDeviceDetail[0] };
    }

    if (!this.props.isFetching) {
      return (
          <ErrorBoundary
            errorcode={this.props.statusCode}
            title={{text: this.props.errorMessage, size: 'small', width: '100%',margin:'24px 0px 10px 0px'}}
            message={ {text: this.props.errorDesc, size: 'small', width: '100%', margin:'5px 0px'}}
            action={ {name: this.props.actionName, value: () => this.handleClickForError(this.props.actionType, this.props.actionValue), margin:'50px 0px' } }
          >
          <Fragment>
            <div data-testid='DeviceDetailTestId'></div>
            {pendingLineChange && (
              <Notification
                type='warning'
                title={common.getItemValue(pageItems, 'pendingLineChangeNotificationTitle')}
                subtitle={common.getItemValue(pageItems, 'pendingLineChangeNotificationSubTitle')}
                fullBleed={true}
                inlineTreatment={false}
                disableFocus={false}
                layout='horizontal'
                buttonData={[
                  {
                    children: common.getItemValue(pageItems, 'reviewDetail'),
                    'data-testid': 'reviewDetailLinkTestId',
                    onClick: () => this.handleReviewDetailLink(),
                  },
                ]}
              />
            )}
            <TitleContainer className='grid main' id='deviceDetailsSection'>
              <Title size='large' primitive='h1'>
              {selectedDeviceDetail?.[0]?.pearlTrialFlow ? common.getItemValue(pageItems, 'pearlHeaderText'):common.getItemValue(pageItems, 'headerText')}
              </Title>
            </TitleContainer>
            {
              !selectedDeviceDetail?.[0]?.pearlTrialFlow &&
            <DropdownSelectContainer className='grid main'>
              <DropdownSelect
                id='deviceListSelectBox'
                label={common.getItemValue(pageItems, 'deviceListText')}
                error={false}
                disabled={false}
                readOnly={false}
                inlineLabel={false}
                value={this.state.selectedMdn}
                data-testid='deviceListTestId'
                data-track='my select generic name'
                onChange={(e) => {
                  this.handleSelectBoxChange(e);
                }}
              >
                {allDevices.length > 0 &&
                  allDevices.map((singleDevice, index) => (
                    <option
                      data-cs-mask
                      key={`${singleDevice?.networkExtender ? singleDevice?.deviceId : singleDevice.mtn}`}
                      value={`${singleDevice?.networkExtender ? singleDevice?.deviceId : singleDevice.mtn}`}
                    >{`${singleDevice.nickName} ${singleDevice?.networkExtender ? singleDevice?.deviceId : singleDevice.displayMtn}`}</option>
                  ))}
              </DropdownSelect>
              <TextLinkContainer>
                <TextLink
                  type='standAlone'
                  data-testid='showAllDeviceTestId'
                  onClick={() => {
                    this.handleShowAllDevices();
                  }}
                >
                  {common.getItemValue(pageItems, 'showAllDeviceTextlink')}
                </TextLink>
              </TextLinkContainer>
            </DropdownSelectContainer>
                }
            {selectedDeviceDetail.length !== 0 &&
              ((selectedDeviceDetail[0]?.secondMtn && selectedDeviceDetail[0]?.secondMtn !== '') || selectedDeviceDetail[0]?.isSecondNumber) && (
                <DeviceWrapper className='grid main'>
                  {' '}
                  <Tabs
                    orientation='horizontal'
                    indicatorPosition='bottom'
                    onTabChange={(event, tabindex) => {
                      console.log('event-tabindex', event, tabindex);
                      this.setState({ index: tabindex });
                    }}
                    selectedIndex={this.state.index}
                  >
                    <Tab label='First number'>{this.displayNumber(selectedDeviceDetail[0]?.mtn)}</Tab>
                    <Tab label='Second number'>{this.displayNumber(selectedDualNum[0]?.mtn)}</Tab>
                  </Tabs>
                </DeviceWrapper>
              )}

            <DeviceWrapper className='grid main'>
              {selectedDeviceDetail.length !== 0 && selectedDualNum.length == 0 && (
                <Wrapper>{this.displayNumber(selectedDeviceDetail[0]?.mtn)}</Wrapper>
              )}
            </DeviceWrapper>
            {(skuId != "FMTLK") ?
            <ListGroupContainer className='grid main'>
              <Grid bleed='full' rowGutter='10px'>
                <Row>
                  <Col
                    colSizes={{
                      desktop: 12,
                      tablet: 12,
                    }}
                  >
                    <MyDeviceHeaderContainer>
                      <Title size='small' primitive='h2'>
                        {common.getItemValue(pageItems, 'deviceManagementText')}
                      </Title>
                    </MyDeviceHeaderContainer>
                  </Col>
                </Row>
                <Row data-testid='DeviceManagementTestId'>{this.handleDeviceMangement(deviceManagementArray)}</Row>
                <Row>
                  <Col
                    colSizes={{
                      desktop: 12,
                      tablet: 12,
                    }}
                  >
                    <MyDeviceHeaderContainer>
                      <Title size='small' primitive='h2'>
                        {common.getItemValue(pageItems, 'preferencesText')}
                      </Title>
                    </MyDeviceHeaderContainer>
                  </Col>
                </Row>
                <Row>{this.handlePreferences(preferencesArray)}</Row>
                <Row>
                  <Col
                    colSizes={{
                      desktop: 12,
                      tablet: 12,
                    }}
                  >
                    <MyDeviceHeaderContainer>
                      <Title size='small' primitive='h2'>
                        {common.getItemValue(pageItems, 'troubleshootAndSupportText')}
                      </Title>
                    </MyDeviceHeaderContainer>
                  </Col>
                </Row>
                <Row>{this.handleTroubleshootAndSupport(troubleshootAndSupportArray)}</Row>
              </Grid>
            </ListGroupContainer>
            : (
              <ListGroupContainer className='grid main'>
                <Grid bleed='full' rowGutter='10px'>
                  <Row>
                    <Col
                      colSizes={{
                      desktop: 12,
                      tablet: 12,
                     }}
                    >
                    <MyDeviceHeaderContainer>
                     <Title size='small' primitive='h2'>
                  {common.getItemValue(pageItems, 'deviceManagementText')}
                  </Title>
                  </MyDeviceHeaderContainer>
                </Col>
              </Row>
              <Row data-testid='DeviceManagementTestId'>{this.handleDeviceMangement(deviceManagementArray)}</Row>
            </Grid>
            </ListGroupContainer>
            )
            }
            {this.state.showModal && (
              <UpgradePlanModal
                handleModalChange={this.handleModalChange}
                handleCancel={this.handleCancel}
                showModal={this.state.showModal}
                deviceDetailInfoSection={this.props.deviceDetailInfoSection}
              />
            )}
            
            {this.state.showSimFreezeModel && (
              <SimFreezeBlockModal
                handleModalChange={this.handleSimFreezeModalChange}
                handleCancel={this.handleSimFreezeCancel}
                showModal={this.state.showSimFreezeModel}
                deviceDetailInfoSection={this.props.deviceDetailInfoSection}
                simFreezeDuration={this.state.simFreezeDuration}
              />
            )}

            {this.state.changeOrReplaceModal && (
            <ChangeOrReplaceModal
                handleModalChange={this.handleChangeOrReplaceModalChange}
                handleCancel={this.handleChangeOrReplaceModalCancel}
                isChangeOrReplaceModal={this.state.changeOrReplaceModal}
                deviceDetailInfoSection={this.props.deviceDetailInfoSection}
              />
            )}

            {/* {this.props.isPendingLineChangeModalOpen && <PendingLineDetailModal />} */}
            {this.props.showPinAndPukModal && <PinUnblockModal selectedDeviceForPinPuk={deviceData} />}
          </Fragment>
        </ErrorBoundary>
      );
    } else {
      const loadingImg = <Loader />;
      return <div data-testid='DeviceDetailTestId'>{loadingImg}</div>;
    }
  }
}

const mapStateToProps = (store) => ({
  isFetching: store.Detail.isFetching,
  selectedDevice: store.Home.selectedDevice,
  statusCode: store.Detail.statusCode,
  statusMessage: store.Detail.statusMessage,
  errorMessage: store.Detail.errorMessage,
  errorObj: store.Detail.errorObj,
  errorDesc: store.Detail.errorDesc,
  actionName: store.Detail.actionName,
  actionValue: store.Detail.actionValue,
  actionType: store.Detail.actionType,
  isOpenNickNameModal: store.Detail.isOpenNickNameModal,
  showPinAndPukModal: store.Detail.showPinAndPukModal,
  productList: store.Detail.productList,
  recommendedDevice: store.Detail.recommendedDevice,
  recommendedTiles: store.Detail.recommendedTiles,
  // isPendingLineChangeModalOpen: store.Detail.isPendingLineChangeModalOpen,
  deviceDetailInfoSection:
    store.Detail.sectionContentMetaData && store.Detail.sectionContentMetaData.body
      ? store.Detail.sectionContentMetaData.body
      : store.Detail.sectionContentMetaData,
  deviceHomeInfoSection: store?.Detail?.sectionContentMetaData  ,
});

const mapDispatchToProps = (dispatch) => ({
  actions: bindActionCreators(deviceDetailActions, dispatch),
});

export default connect(mapStateToProps, mapDispatchToProps)(DeviceDetail);
