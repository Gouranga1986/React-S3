import React, { useEffect } from "react";
import { Modal, ModalTitle, ModalBody,ModalFooter } from '@vds/modals';
import { Button } from "@vds/buttons";
import common from '../../../../shared/utilities/util';
import { dispatchOpenView } from '../../../../shared/utilities/tagging';

const SimFreezeBlockModal = ({ handleCancel, handleModalChange, showModal, deviceDetailInfoSection, simFreezeDuration }) =>{

    let pageContent;
    if (deviceDetailInfoSection?.sections) {
        pageContent = common.getContentFromSection(deviceDetailInfoSection, 'devicesLandingMainSection');
        pageContent = pageContent.sections[0];
    }
    let pageItems = pageContent && pageContent.contents && pageContent.contents[0].items;
    let pageActions = pageContent && pageContent?.actions && pageContent?.actions;

    const actionBtn = common.getActionByKey(pageActions, 'SIMFreezeSettingBtnAction');

    useEffect(() => {
        dispatchOpenView("Can't Upgrade or change device with SIM protection", '#simprotection');
    }, [])

    return(<>
    <div data-testid="SIMFreezePopupTestId">
        <Modal
            surface="light"
            opened={showModal}
            disableOutsideClick={false}
            ariaLabel={common.getItemValue(pageItems, "SIMFreezePopupTitleText")}
            onOpenedChange={handleModalChange}
            width={"36rem"}
            id="simprotection"
        >
            <ModalTitle>
                {common.getItemValue(pageItems, "SIMFreezePopupTitleText")}
            </ModalTitle>
            <ModalBody>
                {common.getItemValue(pageItems, "SIMFreezePopupDescText1")}
            </ModalBody>
            <ModalBody>
                {common.getItemValue(pageItems, "SIMFreezePopupDescText2").replace('<thaw threshold>', simFreezeDuration)}
            </ModalBody>
            <ModalFooter>
                <Button 
                    ariaLabel={common.getItemValue(pageItems, "SIMFreezeSettingBtnText")} 
                    href={actionBtn?.actionValue}
                    width={"100%"}
                >
                    {common.getItemValue(pageItems, "SIMFreezeSettingBtnText")}
                </Button>
            </ModalFooter>
        </Modal>
        </div>
</>)

}

export default SimFreezeBlockModal;