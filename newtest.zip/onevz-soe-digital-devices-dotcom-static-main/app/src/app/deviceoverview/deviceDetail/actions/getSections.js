import { getHttpClientRequest, postHttpClientRequest } from '@vz/react-util';
import { setVzDLVaribale, dispatchPageView, dispatchVzdlData, dispatchVzdlFlow, } from '../../../../shared/utilities/tagging';
import apiUrl from '../../../../shared/utilities/apiUrl';
import { PURGE } from "redux-persist";
import common from '../../../../shared/utilities/util';

export const GET_DEVICE_DETAIL_BEGIN = "deviceDetail/GET_DEVICE_DETAIL_BEGIN";
export const GET_DEVICE_DETAIL_SUCCESS = "deviceDetail/GET_DEVICE_DETAIL_SUCCESS";
export const GET_DEVICE_DETAIL_ERROR = "deviceDetail/GET_DEVICE_DETAIL_ERROR";

export const SET_NICK_NAME_BEGIN = "deviceDetail/SET_NICK_NAME_BEGIN";
export const SET_NICK_NAME_SUCCESS = "deviceDetail/SET_NICK_NAME_SUCCESS";
export const SET_NICK_NAME_ERROR = "deviceDetail/SET_NICK_NAME_ERROR";

export const SET_PIN_AND_PUK_BEGIN = "deviceDetail/SET_PIN_AND_PUK_BEGIN";
export const SET_PIN_AND_PUK_SUCCESS = "deviceDetail/SET_PIN_AND_PUK_SUCCESS";
export const SET_PIN_AND_PUK_ERROR = "deviceDetail/SET_PIN_AND_PUK_ERROR";

export const OPEN_NICK_NAME_MODAL = "deviceDetail/OPEN_NICK_NAME_MODAL"
export const CLOSE_NICK_NAME_MODAL = "deviceDetail/CLOSE_NICK_NAME_MODAL"

export const OPEN_PIN_AND_PUK_MODAL = "deviceDetail/OPEN_PIN_AND_PUK_MODAL"
export const CLOSE_PIN_AND_PUK_MODAL = "deviceDetail/CLOSE_PIN_AND_PUK_MODAL"

export const SET_PENDING_LINE_CHANGE_DETAIL_BEGIN = "deviceDetail/SET_PENDING_LINE_CHANGE_DETAIL_BEGIN";
export const SET_PENDING_LINE_CHANGE_DETAIL_SUCCESS = "deviceDetail/SET_PENDING_LINE_CHANGE_DETAIL_SUCCESS";
export const SET_PENDING_LINE_CHANGE_DETAIL_ERROR = "deviceDetail/SET_PENDING_LINE_CHANGE_DETAIL_ERROR";

export const OPEN_PENDING_LINE_DETAIL_MODAL = "deviceDetail/OPEN_PENDING_LINE_DETAIL_MODAL";
export const CLOSE_PENDING_LINE_DETAIL_MODAL = "deviceDetail/CLOSE_PENDING_LINE_DETAIL_MODAL";

export const GET_TROUBLESHOOT_BEGIN = "deviceDetail/GET_TROUBLESHOOT_BEGIN";
export const GET_TROUBLESHOOT_SUCCESS = "deviceDetail/GET_TROUBLESHOOT_SUCCESS";
export const GET_TROUBLESHOOT_ERROR = "deviceDetail/GET_TROUBLESHOOT_ERROR";

//Smartphone api - canonical url
export const GET_SMART_PHONE_DETAILS_SUCESS = "deviceDetail/GET_SMART_PHONE_DETAILS_SUCESS";
export const GET_SMART_PHONE_DETAIL_BEGIN = "deviceDetail/GET_SMART_PHONE_DETAIL_BEGIN";
export const GET_SMART_PHONE_DETAIL_ERROR = "deviceDetail/GET_SMART_PHONE_DETAIL_ERROR";

//Recommended Device
export const GET_RECOMMENDED_DEVICE_SUCESS = "deviceDetail/GET_RECOMMENDED_DEVICE_SUCESS";
export const GET_RECOMMENDED_DEVICE_BEGIN = "deviceDetail/GET_RECOMMENDED_DEVICE_BEGIN";
export const GET_RECOMMENDED_DEVICE_ERROR = "deviceDetail/GET_RECOMMENDED_DEVICE_ERROR";

//RecommendedTiles Device
export const GET_RECOMMENDED_TILES_SUCESS = "deviceDetail/GET_RECOMMENDED_TILES_SUCESS";
export const GET_RECOMMENDED_TILES_BEGIN = "deviceDetail/GET_RECOMMENDED_TILES_BEGIN";
export const GET_RECOMMENDED_TILES_ERROR = "deviceDetail/GET_RECOMMENDED_TILES_ERROR";


export const getSections = (selectedMdn = '', encryptedMtn) => dispatch => {
  dispatch(getDeviceDetailBegin());

  const onSuccess = resp => {

    if (
      resp &&
      resp.data &&
      resp.data.responseInfo &&
      resp.data.responseInfo.responseCode == "00"
    ) {
      const body = resp.data.body;
      const pgAttributes = body.pageAttributes;
      const mainSection = common.getSection(body?.sections, "devicesLandingMainSection") || {};
      const deviceSetion = common.getSection(mainSection?.sections, "devicesSection") || {};
      let pageItems = deviceSetion && deviceSetion?.contents && deviceSetion?.contents[0]?.items;
      let isNewEndPoint = common.getItemValue(pageItems, 'newRecommendationTileEnabled') === 'true';
      const isPearlTrialFlow = deviceSetion?.data?.some(device => device?.pearlTrialFlow) || false;
      if (mainSection?.sections?.length > 0) {
        let pageContent = mainSection?.sections[0];
        let singleSelectedMdn = [];
        let allDevices = [];
        if (pageContent && pageContent?.data) {
          pageContent &&
            pageContent?.data &&
            pageContent?.data?.forEach((singleDevice, index) => {
              if (!singleDevice?.isSecondNumber) {
                allDevices.push(singleDevice);
              }
            });
        }
        if (encryptedMtn != undefined && encryptedMtn !== '') {
          singleSelectedMdn = pageContent?.data?.filter((singleMdnDetail) => singleMdnDetail?.encryptedMtnDES == encryptedMtn);
          selectedMdn = singleSelectedMdn[0]?.mtn || allDevices[0]?.mtn;
        }
        if (isNewEndPoint) {
          dispatch(getRecommendedTiles(selectedMdn));
        } else {
          let deviceList = pageContent && pageContent?.data;
          let mtnList =
            deviceList &&
            deviceList?.filter((mtn) => mtn?.isOneClickEligible).map((mtn) => mtn.mtn);
          if (mtnList?.length > 0) {
            let payload = { "eligibleMtns": mtnList };
            dispatch(getRecommendedDevice(payload));
            dispatch(getSmartPhoneDetails());
          }
        }
      }

      try {
        setVzDLVaribale(pgAttributes);
        setTimeout(() => {
          dispatchVzdlData('manage device', 'manage device');
          dispatchVzdlFlow('manage device');
          if (window.VZTAG_IS_READY) {
            dispatchPageView('manage device');
          } else {
            document.addEventListener('vztagReady', () => {
              dispatchPageView('manage device');
            });
          }

          if(isPearlTrialFlow && window.vztag?.api) {
            window.vztag.api.dispatch("impression", { "list": `L1|P1||||||Pearl Trial Tile^L1|P2||||||PlanUsage Tile` });
          }
          else if (window.vztag?.api) {
            window.vztag.api.dispatch("impression", { "list": `L1|P1||||||PaymentInfo Tile^L1|P2||||||PlanUsage Tile^L1|P3||||||Device Protect Tile` });
          }
        }, 2000);
      } catch (ex) { }
      dispatch(getDeviceDetailSuccess(resp.data));
    } else {
      dispatch(getDeviceDetailError(resp.data));
    }
  };

  const onError = error => {
    // below code is for redirecting to unauthorised screen for member account
    let msResp = error && error.response && error.response.data;
    let responseCode = msResp && msResp.responseInfo && msResp.responseInfo.responseCode;
    let responseMessage = msResp && msResp.responseInfo && msResp.responseInfo.responseMessage;
    if (responseCode == "401" && responseMessage.includes("mobileSecure")) {
      window.location.href = apiUrl().mvoLimitedAccessUrl;
    }
    else {
      dispatch(getDeviceDetailError(error));
    }
  };

  const callMS = () => {
    let axConfig = {
      headers: { pageName: "devicesDetailPage", flowName: "Devices" }
    };

    return getHttpClientRequest(
      apiUrl().deviceDetailUrl,
      axConfig
    )
  };

  callMS()
    .then(msResp => {
      if (msResp && msResp.status == 200) {
        onSuccess(msResp);
      }
    })
    .catch(onError);
};

export const getDeviceDetailBegin = urlParams => ({
  type: GET_DEVICE_DETAIL_BEGIN,
  urlParams
});

export const getDeviceDetailSuccess = msResp => ({
  type: GET_DEVICE_DETAIL_SUCCESS,
  msResp
});

export const getDeviceDetailError = err => ({
  type: GET_DEVICE_DETAIL_ERROR,
  err
});

export const setOpenPinAndPukModal = () => ({
  type: OPEN_PIN_AND_PUK_MODAL
})

export const closePinAndPukModal = () => dispatch => {
  dispatch(setClosePinAndPukModal());
}

export const setClosePinAndPukModal = () => ({
  type: CLOSE_PIN_AND_PUK_MODAL
})

export const setPinAndPukBegin = urlParams => ({
  type: SET_PIN_AND_PUK_BEGIN,
  urlParams
});

export const setPinAndPukSuccess = msResp => ({
  type: SET_PIN_AND_PUK_SUCCESS,
  msResp
});

export const setPinAndPukError = err => ({
  type: SET_PIN_AND_PUK_ERROR,
  err
});

export const getPinAndPukCode = (payload) => dispatch => {
  dispatch(setPinAndPukBegin());

  const onSuccess = res => {
    if (
      res &&
      res.data &&
      res.data.responseInfo &&
      res.data.responseInfo.responseCode == "00"
    ) {
      dispatch(setPinAndPukSuccess(res.data));
    }
  };

  const onError = error => {
    dispatch(setPinAndPukError(error));
  };

  const callMS = () => {

    let axConfig = {
      headers: { pageName: "devicesDetailPage", flowName: "Device" }
    };

    if (apiUrl().getPinAndPukApi?.indexOf('ApiData') > -1) {
      return getHttpClientRequest(
        apiUrl().getPinAndPukApi,
        axConfig
      )
    } else {
      return postHttpClientRequest(
        apiUrl().getPinAndPukApi,
        payload,
        axConfig
      );
    }
  };

  callMS()
    .then(msResp => {
      if (msResp && msResp?.status == 200) {
        onSuccess(msResp);
      }
    })
    .catch(onError);
};

export const openEditNickNameModal = () => dispatch => {
  dispatch(setOpenEditNickNameModal());
};

export const setOpenEditNickNameModal = () => ({
  type: OPEN_NICK_NAME_MODAL
});

export const closeEditNickNameModal = () => dispatch => {
  dispatch(setCloseEditNickNameModal());
};

export const setCloseEditNickNameModal = () => ({
  type: CLOSE_NICK_NAME_MODAL
});

export const updateNickName = (payload) => dispatch => {
  dispatch(setNickNameBegin());

  const onSuccess = resUpdateNickName => {
    if (
      resUpdateNickName &&
      resUpdateNickName.data &&
      resUpdateNickName.data.responseInfo &&
      resUpdateNickName.data.responseInfo.responseCode == "00"
    ) {
      dispatch(setNickNameSuccess(resUpdateNickName.data));
      if (resUpdateNickName?.data?.body?.statusCode == "200") {
        dispatch(getSections());
      }
    }
  };

  const onError = error => {
    dispatch(setNickNameError(error));
  };

  const callMS = () => {

    let axConfig = {
      headers: { pageName: "devicesDetailPage", flowName: "Device" }
    };
    if (apiUrl().updateNickNameUrl && apiUrl().updateNickNameUrl.indexOf('ApiData') > -1) {
      return getHttpClientRequest(
        apiUrl().updateNickNameUrl,
        axConfig
      )
    } else {
      return postHttpClientRequest(
        apiUrl().updateNickNameUrl,
        payload,
        axConfig
      );
    }
  };

  callMS()
    .then(msResp => {
      if (msResp && msResp.status == 200) {
        onSuccess(msResp);
      }
    })
    .catch(onError);
};

export const setNickNameBegin = urlParams => ({
  type: SET_NICK_NAME_BEGIN,
  urlParams
});

export const setNickNameSuccess = msResp => ({
  type: SET_NICK_NAME_SUCCESS,
  msResp
});

export const setNickNameError = err => ({
  type: SET_NICK_NAME_ERROR,
  err
});

export const openPendingLineChangeDetailModal = () => dispatch => {
  dispatch(setOpenPendingLineChangeDetailModal());
};

export const setOpenPendingLineChangeDetailModal = () => ({
  type: OPEN_PENDING_LINE_DETAIL_MODAL
});

export const closePendingLineChangeDetailModal = () => dispatch => {
  dispatch(setClosePendingLineChangeDetailModal());
};

export const setClosePendingLineChangeDetailModal = () => ({
  type: CLOSE_PENDING_LINE_DETAIL_MODAL
});

export const getTroubleshootUrlResp = (payload, defaultUrl) => dispatch => {
  dispatch(getTrobleshootBegin());

  const onSuccess = response => {
    if (
      response &&
      response.data &&
      response.data.responseInfo &&
      response.data.responseInfo.responseCode == "00"
    ) {
      dispatch(getTrobleshootSuccess(response.data, defaultUrl));
    }
  };

  const onError = error => {
    dispatch(getTrobleshootError(error));
  };

  const callMS = () => {

    let axConfig = {
      headers: { pageName: "devicesDetailPage", flowName: "Device" }
    };
    if (apiUrl().getTroubleshootUrl.indexOf('ApiData') > -1) {
      return getHttpClientRequest(
        apiUrl().getTroubleshootUrl,
        axConfig
      )
    } else {
      return postHttpClientRequest(
        apiUrl().getTroubleshootUrl,
        payload,
        axConfig
      );
    }
  };

  callMS()
    .then(msResp => {
      if (msResp && msResp.status == 200) {
        onSuccess(msResp);
      }
    })
    .catch(onError);
};

export const getTrobleshootBegin = urlParams => ({
  type: GET_TROUBLESHOOT_BEGIN,
  urlParams
});

export const getTrobleshootSuccess = (msResp, defaultUrl) => ({
  type: GET_TROUBLESHOOT_SUCCESS,
  msResp,
  defaultUrl
});

export const getTrobleshootError = err => ({
  type: GET_TROUBLESHOOT_ERROR,
  err
});

export const purgeStore = () => dispatch => {
  dispatch({
    type: PURGE,
    key: "clearSession",
    result: () => null
  });
};

//To get the product list details
export const getSmartPhoneDetails = () => (dispatch) => {
  dispatch(getSmartPhoneDeviceBegin());

  const onSuccess = (response) => {
    console.log(response?.status);
    if (response?.status == "200") {
      let productDetails = {};
      if (response.data?.productListById) {
        productDetails = response.data?.productListById;
      }
      dispatch(getSmartPhoneDetailsSucess(productDetails));
    } else {
      dispatch(getSmartPhoneDetailsError(productDetails));
    }
  };

  const onError = (error) => {
    dispatch(getSmartPhoneDetailsError(error));
  };

  const callMS = () => {
    let axConfig = {
      headers: { pageName: "devicesDetailPage", flowName: "Devices" }
    };
    return getHttpClientRequest(apiUrl().smartPhoneUrl, axConfig);
  };

  callMS()
    .then((msResp) => {
      if (msResp?.status == 200) {
        onSuccess(msResp);
      }
    })
    .catch(onError);
};


export const getSmartPhoneDeviceBegin = (urlParams) => ({
  type: GET_SMART_PHONE_DETAIL_BEGIN,
  urlParams,
});

export const getSmartPhoneDetailsSucess = (msResp) => ({
  type: GET_SMART_PHONE_DETAILS_SUCESS,
  msResp,
});

export const getSmartPhoneDetailsError = (err) => ({
  type: GET_SMART_PHONE_DETAIL_ERROR,
  err,
});



//Get the RecommendeDevice - Request - MTNList
export const getRecommendedDevice = (payload) => (dispatch) => {
 dispatch(getRecommendDeviceBegin());
  const onSuccess = (response) => {
    if (
      response &&
      response.data &&
      response.data.responseInfo &&
      response.data.responseInfo.responseCode == "00"
    ) {
      const body = response.data.body;
      dispatch(getRecommendedDeviceSucess(response.data));
    }
   }

  const onError = (error) => {
    dispatch(getRecommendedDeviceError(error));
  };

  const callMS = () => {
    let axConfig = {
      headers: { pageName: "devicesDetailPage", flowName: "Devices" }
    };
      if (apiUrl().recommendedDeviceUrl?.indexOf('ApiData') > -1) {
        return getHttpClientRequest(
          apiUrl().recommendedDeviceUrl,
          axConfig
        )
      } else {
        return postHttpClientRequest(
          apiUrl().recommendedDeviceUrl,
          payload,
          axConfig
        );
      } 
  };

  callMS()
    .then((msResp) => {
      if (msResp?.status == 200) {
        onSuccess(msResp);
      }
    })
    .catch(onError);
};


export const getRecommendDeviceBegin = (urlParams) => ({
  type: GET_RECOMMENDED_DEVICE_BEGIN,
  urlParams,
});

export const getRecommendedDeviceSucess = (msResp) => ({
  type: GET_RECOMMENDED_DEVICE_SUCESS,
  msResp,
});

export const getRecommendedDeviceError = (err) => ({
  type: GET_RECOMMENDED_DEVICE_ERROR,
  err,
});

export const getRecommendedTiles = (selectedMdn) => (dispatch) => {
  dispatch(getRecommendedTilesBegin());
  let payload = { flowIntent: "Singleline", pageContext: "DeviceDetails", selectedMtn : selectedMdn }
   const onSuccess = (response) => {
     if (
       response &&
       response.data
     ) {
       dispatch(getRecommendedTilesSucess(response?.data));
           }
    }
 
   const onError = (error) => {
     dispatch(getRecommendedTilesError(error));
   };
 
   const callMS = () => {
    let axConfig = {
      headers: { pageName: "DeviceDetails", flowName: "Singleline" }
    };
       if (apiUrl().recommendedDeviceNewUrl?.indexOf('ApiData') > -1) {
                 return getHttpClientRequest(
           apiUrl().recommendedDeviceNewUrl,
           axConfig
         )
       } else {
        return postHttpClientRequest(
          apiUrl().recommendedDeviceNewUrl,
          payload,
          axConfig
        );
       }
   };
 
   callMS()
     .then((msResp) => {
       if (msResp?.status == 200) {
         onSuccess(msResp);
       }
     })
     .catch(onError);
 };
 
 
 export const getRecommendedTilesBegin = (urlParams) => ({
   type: GET_RECOMMENDED_TILES_BEGIN,
   urlParams,
 });
 
 export const getRecommendedTilesSucess = (msResp) => ({
   type: GET_RECOMMENDED_TILES_SUCESS,
   msResp,
 });
 
 export const getRecommendedTilesError = (err) => ({
   type: GET_RECOMMENDED_TILES_ERROR,
   err,
 });