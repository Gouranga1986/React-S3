export {
  getSections,
  updateNickName,
  purgeStore,
  openEditNickNameModal,
  closeEditNickNameModal,
  getPinAndPukCode,
  closePinAndPukModal,
  openPendingLineChangeDetailModal,
  closePendingLineChangeDetailModal,
  getTroubleshootUrlResp,
  getSmartPhoneDetails,
  getRecommendedDevice,
  getRecommendedTiles,
} from './getSections';
export { setSelectedDevice, isRedirectedFromDetailPage } from './pageActions';
