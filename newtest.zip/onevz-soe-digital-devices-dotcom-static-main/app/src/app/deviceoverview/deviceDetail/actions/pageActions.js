export const SET_SELECTED_DEVICE = "deviceDetail/SET_SELECTED_DEVICE";
export const IS_REDIRECTED_FROM_DETAIL_PAGE = "deviceDetail/IS_REDIRECTED_FROM_DETAIL_PAGE";

export const setSelectedDevice = data => ({
	type: SET_SELECTED_DEVICE,
	data
});

export const isRedirectedFromDetailPage = data => ({
	type: IS_REDIRECTED_FROM_DETAIL_PAGE,
	data
});