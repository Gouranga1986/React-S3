import React from "react";
import "../../../../../config/jest/test-setup";
import { act, render, screen, fireEvent, cleanup } from "@testing-library/react";
import "@testing-library/jest-dom/extend-expect";
import { Provider } from "react-redux";
import { getHttpClientRequest } from '@vz/react-util';
import configureStore from "../../../../shared/store/configureStore";
import { persistStore } from 'redux-persist';
import { PersistGate } from 'redux-persist/integration/react';
import DeviceDetail from '../components/index';
import {deviceDetail2} from './mockResponse'
import { combineReducers } from "redux";
const APP = combineReducers({
    Detail:()=>({
        isFetching: false,
        statusCode:"00",
        statusMessage:"",
        errorMessage:"",
        errorObj: {},
        errorDesc: "",
        actionName: "",
        actionValue: "",
        actionType: "",
        isOpenNickNameModal: false,
        showPinAndPukModal: false,
        productList: {},
        recommendedDevice: [],
        recommendedTiles: {
            "recommendedDevices": [
                {
                    "sorId": "MU683LL/A",
                    "mtn": "2404445510",
                    "currentDeviceBrandName": "Apple",
                    "currentDeviceName": "iPhone 14 Plus",
                    "currentDeviceNickName": "BLOSSOM",
                    "offerId": "597967",
                    "deviceId": "dev21410696",
                    "offerAmount": 1000,
                    "simId": "UNIVESIM5G-SAB-S",
                    "imageUrl": "https://ss7.vzw.com/is/image/VerizonWireless/apple-iphone-15-pro-max-256gb-natural-titanium-mu683ll-a-a",
                    "productDisplayName": "iPhone 15 Pro Max",
                    "recommendedDeviceURL": "smartphones/apple-iphone-15-pro-max/",
                    "promotionId": "promo4372504",
                    "promoType": "TRADEIN_PROMO",
                    "restricted": "Y",
                    "startDateTime": "09-09-2022 07:58:00 AM",
                    "processingMTN": "7325402208",
                    "isQuickCartEnabled": false,
                    "showRecommendedPlan": false,
                    "isStrategicOffer": true
                },
                {
                    "sorId": "MU683LL/A",
                    "mtn": "2404445510",
                    "currentDeviceBrandName": "Apple",
                    "currentDeviceName": "iPhone 14 Plus",
                    "currentDeviceNickName": "BLOSSOM",
                    "offerId": "597967",
                    "deviceId": "dev21410696",
                    "offerAmount": 1000,
                    "simId": "UNIVESIM5G-SAB-S",
                    "imageUrl": "https://ss7.vzw.com/is/image/VerizonWireless/apple-iphone-15-pro-max-256gb-natural-titanium-mu683ll-a-a",
                    "productDisplayName": "iPhone 15 Pro Max",
                    "recommendedDeviceURL": "smartphones/apple-iphone-15-pro-max/",
                    "promotionId": "promo4372504",
                    "promoType": "TRADEIN_PROMO",
                    "restricted": "Y",
                    "startDateTime": "09-09-2022 07:58:00 AM",
                    "processingMTN": "7325402209",
                    "isQuickCartEnabled": true,
                    "showRecommendedPlan": false,
                    "isStrategicOffer": true
                }
            ]
        },
        sectionContentMetaData:{
            "sections": [
            {
                "sectionIndex": "0",
                "sectionId": "devicesLandingMainSection",
                "sectionType": "devicesLandingMainSection",
                "sectionComponentId": "GenericComponent",
                "sections": [
                    {
                        "sectionIndex": "1",
                        "sectionId": "devicesDetailsPageSection",
                        "sectionType": "devicesSection",
                        "actions": [
                            {
                                "actionType": "http",
                                "actionValue": "https://vzwqa2.verizonwireless.com/sales/nextgen/mdnselection.html?flow=EUP&MyvPage=true&amLogin=true&dc=phone&t=",
                                "actionKey": "returnAndUpgradeAction",
                                "clickStream": "return-and-upgrade"
                            },
                            {
                                "actionType": "http",
                                "actionValue": "https://vzwqa2.verizonwireless.com/sales/nextgen/mdnselection.html?flow=EUP&MyvPage=true&amLogin=true&dc=phone&t=",
                                "actionKey": "upgradeAction",
                                "clickStream": "upgrade"
                            },
                            {
                                "actionType": "http",
                                "actionValue": "https://vzwqa2.verizonwireless.com/digital/nsa/secure/ui/payment/device/buyout?g=d&t=e&param1=",
                                "actionKey": "payOffDeviceAction",
                                "clickStream": "pay-off-device-cta"
                            },
                            {
                                "actionType": "http",
                                "actionValue": "https://vzwqa2.verizonwireless.com/digital/nsa/secure/ui/myusage/?intcmp=vzwdom",
                                "actionKey": "reviewUsageAction",
                                "clickStream": "review-usage-cta"
                            },
                            {
                                "actionType": "http",
                                "actionValue": "https://vzwqa2.verizonwireless.com/digital/nsa/secure/ui/products/producthub/category/Security",
                                "actionKey": "enrollAction",
                                "clickStream": "enroll-cta"
                            },
                            {
                                "actionType": "http",
                                "actionValue": "https://vzwqa2.verizonwireless.com/sales/as/home.html",
                                "actionKey": "activateOrSwitchDeviceAction",
                                "clickStream": "Activate or switch device"
                            },
                            {
                                "actionType": "http",
                                "actionValue": "https://vzwqa2.verizonwireless.com/digital/nsa/secure/ui/cpc/#/",
                                "actionKey": "managePlanAction",
                                "clickStream": "manage-plan-cta"
                            },
                            {
                                "actionType": "http",
                                "actionValue": "https://vzwqa2.verizonwireless.com/support/troubleshooting/",
                                "actionKey": "troubleshootAction",
                                "clickStream": "Troubleshoot"
                            },
                            {
                                "actionType": "http",
                                "actionValue": "https://vzwqa2.verizonwireless.com/sales/digital/tradein.html?t=",
                                "actionKey": "tradeInAction",
                                "clickStream": "Trade in"
                            },
                            {
                                "actionType": "http",
                                "actionValue": "https://vzwqa2.verizonwireless.com/sales/nextgen/mdnselection.html?flow=EUP&MyvPage=true&amLogin=true&dc=phone&t=",
                                "actionKey": "upgradeDeviceAction",
                                "clickStream": "Upgrade device"
                            },
                            {
                                "actionType": "http",
                                "actionValue": "https://vzwqa2.verizonwireless.com/digital/nsa/secure/ui/products/producthub/home",
                                "actionKey": "viewAdd-onsAction",
                                "clickStream": "View add-ons"
                            },
                            {
                                "actionType": "http",
                                "actionValue": "https://vzwqa2.verizonwireless.com/digital/nsa/secure/ui/acct/changemdn/?selectedMdn=",
                                "actionKey": "changeMobileNumberAction",
                                "clickStream": "Change mobile number"
                            },
                            {
                                "actionType": "http",
                                "actionValue": "https://vzwqa2.verizonwireless.com/support/transfer-service/overview/",
                                "actionKey": "transferYourServiceAction",
                                "clickStream": "Transfer your service"
                            },
                            {
                                "actionType": "http",
                                "actionValue": "https://cloud.verizon.com/vzCloud/home/cloudOverview.action",
                                "actionKey": "backupContentToVerizonCloudAction",
                                "clickStream": "Backup content to Verizon Cloud"
                            },
                            {
                                "actionType": "http",
                                "actionValue": "https://vzwqa2.verizonwireless.com/digital/nsa/secure/ui/devices/numbershare",
                                "actionKey": "manageConnectedDevicesAction",
                                "clickStream": "Manage connected devices"
                            },
                            {
                                "actionType": "http",
                                "actionValue": "https://vzwqa2.verizonwireless.com/digital/nsa/secure/ui/devices/suspendreconnect/",
                                "actionKey": "suspendOrReconnectServiceAction",
                                "clickStream": "Suspend or reconnect service"
                            },
                            {
                                "actionType": "http",
                                "actionValue": "https://vzwqa2.verizonwireless.com/ui/acct/ao/shareName",
                                "actionKey": "shareNameIDAction",
                                "clickStream": "Share Name ID"
                            },
                            {
                                "actionType": "http",
                                "actionValue": "https://vzwqa2.verizonwireless.com/support/call-forwarding-faqs/#itemfour",
                                "actionKey": "manageCallForwardingAction",
                                "clickStream": "Manage call forwarding"
                            },
                            {
                                "actionType": "http",
                                "actionValue": "https://vzwqa2.verizonwireless.com/ui/acct/secure/blocks",
                                "actionKey": "blockSpecificServicesAction",
                                "clickStream": "Block specific services"
                            },
                            {
                                "actionType": "http",
                                "actionValue": "https://vzwqa2.verizonwireless.com/ui/acct/secure/blocks",
                                "actionKey": "blockCallsAndMessagesAction",
                                "clickStream": "Block calls and messages"
                            },
                            {
                                "actionType": "overlay",
                                "actionValue": "/",
                                "actionKey": "pinandPersonalUnblockingKeyAction",
                                "clickStream": "PIN and Personal Unblocking Key"
                            },
                            {
                                "actionType": "http",
                                "actionValue": "https://vzwqa2.verizonwireless.com/digital/nsa/secure/ui/devices/disconnect/",
                                "actionKey": "disconnectDeviceAction",
                                "clickStream": "Disconnect device"
                            },
                            {
                                "actionType": "http",
                                "actionValue": "https://vzwqa2.verizonwireless.com/digital/nsa/secure/ui/acct/voicemail/",
                                "actionKey": "manageVoicemailPasswordAction",
                                "clickStream": "Manage voicemail password"
                            },
                            {
                                "actionType": "http",
                                "actionValue": "https://vzwqa2.verizonwireless.com/digital/nsa/secure/ui/products/producthub/manage/",
                                "actionKey": "manageDeviceProtectionAction",
                                "clickStream": "Enroll-Manage-Device-Protection"
                            },
                            {
                                "actionType": "http",
                                "actionValue": "https://vzwqa2.verizonwireless.com/digital/nsa/secure/ui/products/producthub/pdp/sfo80072MS",
                                "actionKey": "techCoachSupportAction",
                                "clickStream": "Tech Coach Support"
                            },
                            {
                                "actionType": "http",
                                "actionValue": "https://vzwqa2.verizonwireless.com/digital/nsa/secure/ui/acct/profile/contactbilling/E911Address#/",
                                "actionKey": "manageE911AddressAction",
                                "clickStream": "Manage E911 Address"
                            },
                            {
                                "actionType": "http",
                                "actionValue": "https://vzwqa2.verizonwireless.com/ui/acct/secure/callFilterSettings",
                                "actionKey": "manageCallFilterAction",
                                "clickStream": "Manage Call Filter"
                            },
                            {
                                "actionType": "http",
                                "actionValue": "https://vzwqa2.verizonwireless.com/digital/nsa/secure/ui/acct/profile/security/portsecurity/",
                                "actionKey": "numberLockAction"
                            },
                            {
                                "actionType": "http",
                                "actionValue": "https://vzwqa2.verizonwireless.com/digital/nsa/secure/ui/acct/profile/security/portout/",
                                "actionKey": "numberTransferPinAction"
                            },
                            {
                                "actionType": "bridge",
                                "actionValue": "runHealthCheck",
                                "actionKey": "runHealthCheckAction"
                            },
                            {
                                "actionType": "bridge",
                                "actionValue": "transferContentBetweenPhones",
                                "actionKey": "transferContentBetweenPhonesAction"
                            },
                            {
                                "actionType": "bridge",
                                "actionValue": "launchSecurityDashboard",
                                "actionKey": "launchSecurityDashboardAction"
                            },
                            {
                                "actionType": "http",
                                "actionValue": "https://vzwqa2.verizonwireless.com/digital/nsa/secure/ui/support/networkcompatibility",
                                "actionKey": "checkNetworkCompatibiltyAction",
                                "clickStream": "Check Network Compatibility"
                            },
                            {
                                "actionType": "redirect",
                                "actionValue": "https://vzwqa2.verizonwireless.com/digital/nsa/secure/ui/devices/routermgmt/?t=",
                                "actionKey": "manageRouterAction",
                                "clickStream": "manage-router-cta"
                            },
                            {
                                "actionType": "native",
                                "actionValue": "DHCOverviewRtl",
                                "actionKey": "runHealthCheckAction_native",
                                "clickStream": "Device Health Check"
                            },
                            {
                                "actionType": "native",
                                "actionValue": "changeMobileNumber",
                                "actionKey": "changeMobileNumberAction_native",
                                "clickStream": "Change Phone Number"
                            },
                            {
                                "actionType": "native",
                                "actionValue": "adjServiceBlock",
                                "actionKey": "blockSpecificServicesAction_native",
                                "clickStream": "Block services"
                            },
                            {
                                "actionType": "native",
                                "actionValue": "ViewCMB",
                                "actionKey": "blockCallsAndMessagesAction_native",
                                "clickStream": "Block Calls & Messages"
                            },
                            {
                                "actionType": "redirect",
                                "actionValue": "https://vzwqa2.verizonwireless.com/digital/nsa/secure/ui/acct/pending-account#/",
                                "actionKey": "reviewDetailAction",
                                "clickStream": "review-detail-cta"
                            },
                            {
                                "actionType": "http",
                                "actionValue": "https://www.verizon.com/solutions-and-services/verizon-mobile-protect/",
                                "actionKey": "learnMoreAction",
                                "clickStream": "learn-more-cta"
                            },
                            {
                                "actionType": "http",
                                "actionValue": "https://vzwqa2.verizonwireless.com/ui/ntwk/ao/networkextender",
                                "actionKey": "manageNetworkExtender",
                                "clickStream": "manage-network-extender-cta"
                            },
                            {
                                "actionType": "upgrade",
                                "actionValue": "/",
                                "actionKey": "upgradeKeyAction",
                                "clickStream": "Upgrade Second Number"
                            },
                            {
                                "actionType": "http",
                                "actionValue": "https://www.asurion.com/claims/verizon/",
                                "actionKey": "fileClaimAction",
                                "clickStream": "file a claim"
                            },
                            {
                                "actionType": "redirect",
                                "actionValue": "https://vzwqa2.verizonwireless.com/sales/nextgen/secondnumber.html",
                                "actionKey": "getSecondNumberAction",
                                "clickStream": "get-second-number-cta"
                            },
                            {
                                "actionType": "http",
                                "actionValue": "https://vzwqa2.verizonwireless.com/digital/nsa/secure/ui/devices/sharenameid/",
                                "actionKey": "nsa_shareNameIDAction",
                                "clickStream": "Share Name ID"
                            },
                            {
                                "actionType": "http",
                                "actionValue": "https://vzwqa2.verizonwireless.com/sales/digital/dvm/conversion.html",
                                "actionKey": "pearlTrialAction",
                                "clickStream": "pearlTrial"
                            },
                            {
                                "actionType": "http",
                                "actionValue": "https://vzwqa2.verizonwireless.com/digital/nsa/secure/ui/cpc/#/",
                                "actionKey": "pearlTrialPlanAction",
                                "clickStream": "pearlTrialDashboard"
                            },
                            {
                                "actionType": "http",
                                "actionValue": "https://vzwqa2.verizonwireless.com/digital/nsa/secure/ui/devices/suspendreconnect/#/suspendoptions",
                                "actionKey": "trialMilitarySuspendBtnAction",
                                "clickStream": "pearlTrialMilitarySuspend"
                            },
                            {
                                "actionType": "http",
                                "actionValue": "https://vzwqa2.verizonwireless.com/digital/nsa/secure/ui/devices/disconnect/#/",
                                "actionKey": "trialCancelBtnAction",
                                "clickStream": "pearlTrialCancelButton"
                            },
                            {
                                "actionType": "http",
                                "actionValue": "https://vzwqa2.verizonwireless.com/digital/nsa/secure/ui/acct/profile/security/simfreeze#/",
                                "actionKey": "SIMFreezeSettingBtnAction",
                                "clickStream": "simFreeze-setting-redirect-cta"
                            },
                            {
                                "actionType": "http",
                                "actionValue": "https://vzwqa2.verizonwireless.com/digital/nsa/secure/ui/acct/changemdn/?selectedMdn=",
                                "actionKey": "changeMobileNumberAction_nsa",
                                "clickStream": "Change mobile number"
                            }
                        ],
                        "contents": [
                            {
                                "contentIndex": "0",
                                "items": [
                                    {
                                        "itemKey": "headerText",
                                        "itemType": "text",
                                        "itemValue": "Now, let’s manage all device details.",
                                        "itemAttributes": {}
                                    },
                                    {
                                        "itemKey": "subHeaderText",
                                        "itemType": "text",
                                        "itemValue": "You can view, track and make any changes right here.",
                                        "itemAttributes": {}
                                    },
                                    {
                                        "itemKey": "modelHeader",
                                        "itemType": "text",
                                        "itemValue": "Model",
                                        "itemAttributes": {}
                                    },
                                    {
                                        "itemKey": "deviceIdHeader",
                                        "itemType": "text",
                                        "itemValue": "Device ID / IMEI",
                                        "itemAttributes": {}
                                    },
                                    {
                                        "itemKey": "simIdHeader",
                                        "itemType": "text",
                                        "itemValue": "SIM ID / ICCID",
                                        "itemAttributes": {}
                                    },
                                    {
                                        "itemKey": "mobileNumberHeader",
                                        "itemType": "text",
                                        "itemValue": "Mobile Number",
                                        "itemAttributes": {},
                                        "actionKey": "manageDeviceAction"
                                    },
                                    {
                                        "itemKey": "eSIMCapableHeader",
                                        "itemType": "text",
                                        "itemValue": "eSIM capable",
                                        "itemAttributes": {}
                                    },
                                    {
                                        "itemKey": "upgradeEligibilityHeader",
                                        "itemType": "text",
                                        "itemValue": "Upgrade eligibility",
                                        "itemAttributes": {}
                                    },
                                    {
                                        "itemKey": "accountPlaneHeader",
                                        "itemType": "text",
                                        "itemValue": "Account plan",
                                        "itemAttributes": {}
                                    },
                                    {
                                        "itemKey": "paidHeader",
                                        "itemType": "text",
                                        "itemValue": "Paid",
                                        "itemAttributes": {}
                                    },
                                    {
                                        "itemKey": "totalHeader",
                                        "itemType": "text",
                                        "itemValue": "Total",
                                        "itemAttributes": {}
                                    },
                                    {
                                        "itemKey": "endDateHeader",
                                        "itemType": "text",
                                        "itemValue": "End date",
                                        "itemAttributes": {}
                                    },
                                    {
                                        "itemKey": "startDateHeader",
                                        "itemType": "text",
                                        "itemValue": "Start date",
                                        "itemAttributes": {}
                                    },
                                    {
                                        "itemKey": "deviceInformationHeader",
                                        "itemType": "text",
                                        "itemValue": "Device information",
                                        "itemAttributes": {}
                                    },
                                    {
                                        "itemKey": "manageDeviceHeader",
                                        "itemType": "text",
                                        "itemValue": "Manage Device",
                                        "itemAttributes": {}
                                    },
                                    {
                                        "itemKey": "returnAndUpgradeBtn",
                                        "itemType": "button",
                                        "itemValue": "Return and upgrade",
                                        "itemAttributes": {},
                                        "actionKey": "returnAndUpgradeAction"
                                    },
                                    {
                                        "itemKey": "upgradeBtn",
                                        "itemType": "button",
                                        "itemValue": "Upgrade now",
                                        "itemAttributes": {},
                                        "actionKey": "upgradeAction"
                                    },
                                    {
                                        "itemKey": "payOffDeviceBtn",
                                        "itemType": "button",
                                        "itemValue": "Pay off device",
                                        "itemAttributes": {},
                                        "actionKey": "payOffDeviceAction"
                                    },
                                    {
                                        "itemKey": "managePlanBtn",
                                        "itemType": "button",
                                        "itemValue": "Manage plan",
                                        "itemAttributes": {},
                                        "actionKey": "managePlanAction"
                                    },
                                    {
                                        "itemKey": "reviewUsageBtn",
                                        "itemType": "button",
                                        "itemValue": "Review usage",
                                        "itemAttributes": {},
                                        "actionKey": "reviewUsageAction"
                                    },
                                    {
                                        "itemKey": "activateOrSwitchDeviceBtn",
                                        "itemType": "button",
                                        "itemValue": "Activate or switch device",
                                        "itemAttributes": {},
                                        "actionKey": "activateOrSwitchDeviceAction"
                                    },
                                    {
                                        "itemKey": "troubleshootBtn",
                                        "itemType": "button",
                                        "itemValue": "Troubleshoot",
                                        "itemAttributes": {},
                                        "actionKey": "troubleshootAction"
                                    },
                                    {
                                        "itemKey": "tradeInBtn1",
                                        "itemType": "button",
                                        "itemValue": "Trade in",
                                        "itemAttributes": {},
                                        "actionKey": "tradeInAction"
                                    },
                                    {
                                        "itemKey": "upgradeDeviceBtn",
                                        "itemType": "button",
                                        "itemValue": "Upgrade device",
                                        "itemAttributes": {},
                                        "actionKey": "upgradeDeviceAction"
                                    },
                                    {
                                        "itemKey": "viewAddOnsBtn",
                                        "itemType": "button",
                                        "itemValue": "Services & perks",
                                        "itemAttributes": {},
                                        "actionKey": "viewAdd-onsAction"
                                    },
                                    {
                                        "itemKey": "changeMobileNumberBtn",
                                        "itemType": "button",
                                        "itemValue": "Change mobile number",
                                        "itemAttributes": {},
                                        "actionKey": "changeMobileNumberAction"
                                    },
                                    {
                                        "itemKey": "transferYourServiceBtn",
                                        "itemType": "button",
                                        "itemValue": "Transfer your service",
                                        "itemAttributes": {},
                                        "actionKey": "transferYourServiceAction"
                                    },
                                    {
                                        "itemKey": "backupContentToVerizonCloudBtn",
                                        "itemType": "button",
                                        "itemValue": "Verizon Cloud Backup",
                                        "itemAttributes": {},
                                        "actionKey": "backupContentToVerizonCloudAction"
                                    },
                                    {
                                        "itemKey": "manageConnectedDevicesBtn",
                                        "itemType": "button",
                                        "itemValue": "Manage connected devices",
                                        "itemAttributes": {},
                                        "actionKey": "manageConnectedDevicesAction"
                                    },
                                    {
                                        "itemKey": "suspendOrReconnectServiceBtn",
                                        "itemType": "button",
                                        "itemValue": "Suspend or reconnect service",
                                        "itemAttributes": {},
                                        "actionKey": "suspendOrReconnectServiceAction"
                                    },
                                    {
                                        "itemKey": "changeOrReplaceDeviceLineBtn",
                                        "itemType": "button",
                                        "itemValue": "change Or Replace DeviceLine",
                                        "itemAttributes": {},
                                        "actionKey": "changeOrReplaceDeviceLineBtn"
                                    },
                                    {
                                        "itemKey": "shareNameIDBtn",
                                        "itemType": "button",
                                        "itemValue": "Share Name ID",
                                        "itemAttributes": {},
                                        "actionKey": "shareNameIDAction"
                                    },
                                    {
                                        "itemKey": "manageCallForwardingBtn",
                                        "itemType": "button",
                                        "itemValue": "Call Forwarding",
                                        "itemAttributes": {},
                                        "actionKey": "manageCallForwardingAction"
                                    },
                                    {
                                        "itemKey": "blockSpecificServicesBtn",
                                        "itemType": "button",
                                        "itemValue": "Block specific services",
                                        "itemAttributes": {},
                                        "actionKey": "blockSpecificServicesAction"
                                    },
                                    {
                                        "itemKey": "blockCallsAndMessagesBtn",
                                        "itemType": "button",
                                        "itemValue": "Block calls and messages",
                                        "itemAttributes": {},
                                        "actionKey": "blockCallsAndMessagesAction"
                                    },
                                    {
                                        "itemKey": "pinandPersonalUnblockingKeyBtn1",
                                        "itemType": "button",
                                        "itemValue": "PIN and Personal Unblocking Key",
                                        "itemAttributes": {},
                                        "actionKey": "pinandPersonalUnblockingKeyAction"
                                    },
                                    
                                    {
                                        "itemKey": "disconnectDeviceBtn",
                                        "itemType": "button",
                                        "itemValue": "Disconnect device",
                                        "itemAttributes": {},
                                        "actionKey": "disconnectDeviceAction"
                                    },
                                    {
                                        "itemKey": "manageVoicemailPasswordBtn",
                                        "itemType": "button",
                                        "itemValue": "Manage voicemail password",
                                        "itemAttributes": {},
                                        "actionKey": "manageVoicemailPasswordAction"
                                    },
                                    {
                                        "itemKey": "manageDeviceProtectionBtn",
                                        "itemType": "button",
                                        "itemValue": "Manage Device Protection",
                                        "itemAttributes": {},
                                        "actionKey": "manageDeviceProtectionAction"
                                    },
                                    {
                                        "itemKey": "techCoachSupportBtn",
                                        "itemType": "button",
                                        "itemValue": "Tech Coach Support",
                                        "itemAttributes": {},
                                        "actionKey": "techCoachSupportAction"
                                    },
                                    {
                                        "itemKey": "manageCallFilterBtn",
                                        "itemType": "button",
                                        "itemValue": "Manage Call Filter",
                                        "itemAttributes": {},
                                        "actionKey": "manageCallFilterAction"
                                    },
                                    {
                                        "itemKey": "manageE911AddressBtn",
                                        "itemType": "button",
                                        "itemValue": "Manage E911 Address",
                                        "itemAttributes": {},
                                        "actionKey": "manageE911AddressAction"
                                    },
                                    {
                                        "itemKey": "toolsAndApplicationText",
                                        "itemType": "text",
                                        "itemValue": "Tools & applications",
                                        "itemAttributes": {}
                                    },
                                    {
                                        "itemKey": "preferencesText",
                                        "itemType": "text",
                                        "itemValue": "Settings & Preferences",
                                        "itemAttributes": {}
                                    },
                                    {
                                        "itemKey": "deviceProtectionText",
                                        "itemType": "text",
                                        "itemValue": "Device Protection",
                                        "itemAttributes": {}
                                    },
                                    {
                                        "itemKey": "deviceProtectionText",
                                        "itemType": "text",
                                        "itemValue": "Device Protection",
                                        "itemAttributes": {}
                                    },
                                    {
                                        "itemKey": "myPlanCardHeader",
                                        "itemType": "text",
                                        "itemValue": "My Plan",
                                        "itemAttributes": {}
                                    },
                                    {
                                        "itemKey": "changeDeviceLinktext",
                                        "itemType": "text",
                                        "itemValue": "Change device",
                                        "itemAttributes": {}
                                    },
                                    {
                                        "itemKey": "upgradeEligibilityText",
                                        "itemType": "text",
                                        "itemValue": "Upgrade eligible",
                                        "itemAttributes": {}
                                    },
                                    {
                                        "itemKey": "deviceListText",
                                        "itemType": "text",
                                        "itemValue": "Device List",
                                        "itemAttributes": {}
                                    },
                                    {
                                        "itemKey": "showAllDeviceTextlink",
                                        "itemType": "text",
                                        "itemValue": "Show all devices",
                                        "itemAttributes": {}
                                    },
                                    {
                                        "itemKey": "editDeviceNameTextlink",
                                        "itemType": "text",
                                        "itemValue": "Edit device nickname",
                                        "itemAttributes": {}
                                    },
                                    {
                                        "itemKey": "accountPlanUnlimitedDataText",
                                        "itemType": "text",
                                        "itemValue": "unlimited data used",
                                        "itemAttributes": {}
                                    },
                                    {
                                        "itemKey": "accountPlanUnlimitedMinutesText",
                                        "itemType": "text",
                                        "itemValue": "unlimited minutes used",
                                        "itemAttributes": {}
                                    },
                                    {
                                        "itemKey": "accountPlanUnlimitedMessageText",
                                        "itemType": "text",
                                        "itemValue": "unlimited message used",
                                        "itemAttributes": {}
                                    },
                                    {
                                        "itemKey": "manageNumberShareBtn",
                                        "itemType": "button",
                                        "itemValue": "Manage Number Share",
                                        "itemAttributes": {},
                                        "actionKey": "manageConnectedDevicesAction"
                                    },
                                    {
                                        "itemKey": "numberLockBtn",
                                        "itemType": "button",
                                        "itemValue": "Number Lock",
                                        "itemAttributes": {},
                                        "actionKey": "numberLockAction"
                                    },
                                    {
                                        "itemKey": "numberTransferPinBtn",
                                        "itemType": "button",
                                        "itemValue": "Number Transfer Pin",
                                        "itemAttributes": {},
                                        "actionKey": "numberTransferPinAction"
                                    },
                                    {
                                        "itemKey": "runHealthCheckBtn",
                                        "itemType": "button",
                                        "itemValue": "Run Health Check",
                                        "itemAttributes": {},
                                        "actionKey": "runHealthCheckAction"
                                    },
                                    {
                                        "itemKey": "transferContentBetweenPhonesBtn",
                                        "itemType": "button",
                                        "itemValue": "Transfer Content Between Phones",
                                        "itemAttributes": {},
                                        "actionKey": "transferContentBetweenPhonesAction"
                                    },
                                    {
                                        "itemKey": "launchSecurityDashboardBtn",
                                        "itemType": "button",
                                        "itemValue": "Launch Security Dashboard",
                                        "itemAttributes": {},
                                        "actionKey": "launchSecurityDashboardAction"
                                    },
                                    {
                                        "itemKey": "deviceManagementText",
                                        "itemType": "text",
                                        "itemValue": "Device Management",
                                        "itemAttributes": {}
                                    },
                                    {
                                        "itemKey": "troubleshootAndSupportText",
                                        "itemType": "text",
                                        "itemValue": "Troubleshoot & Support",
                                        "itemAttributes": {}
                                    },
                                    {
                                        "itemKey": "checkNetworkCompatibiltyBtn",
                                        "itemType": "button",
                                        "itemValue": "Check Network Compatibility",
                                        "itemAttributes": {},
                                        "actionKey": "checkNetworkCompatibiltyAction"
                                    },
                                    {
                                        "itemKey": "upgradeEligibilityHeaderText",
                                        "itemType": "text",
                                        "itemValue": "You're eligible for an upgrade.",
                                        "itemAttributes": {}
                                    },
                                    {
                                        "itemKey": "upgradeEligibilitySubtHeader",
                                        "itemType": "text",
                                        "itemValue": "Ready for an upgrade? Check out our latest devices.",
                                        "itemAttributes": {}
                                    },
                                    {
                                        "itemKey": "DevicePaymentAgreementHeader",
                                        "itemType": "text",
                                        "itemValue": "Device Payment Agreement",
                                        "itemAttributes": {}
                                    },
                                    {
                                        "itemKey": "DevicePaymentAgreementText",
                                        "itemType": "text",
                                        "itemValue": "You're eligible for an upgrade. Check out our latest devices.",
                                        "itemAttributes": {}
                                    },
                                    {
                                        "itemKey": "DevicePaymentAgreemenPromotiontText",
                                        "itemType": "text",
                                        "itemValue": "Ready for an upgrade? This device is currently on a promotion. Select to pay off the device to learn how to upgrade.",
                                        "itemAttributes": {}
                                    },
                                    {
                                        "itemKey": "PaymentBalanceHeader",
                                        "itemType": "text",
                                        "itemValue": "##Months## payments left with a remaining balance of ##balance##",
                                        "itemAttributes": {}
                                    },
                                    {
                                        "itemKey": "devicePaymentAggrementHeaderText",
                                        "itemType": "text",
                                        "itemValue": "Device Payment Aggrement",
                                        "itemAttributes": {}
                                    },
                                    {
                                        "itemKey": "devicePaymentAggrementSubHeaderText",
                                        "itemType": "text",
                                        "itemValue": "Ready for an upgrade? Check out our latest devices.",
                                        "itemAttributes": {}
                                    },
                                    {
                                        "itemKey": "devicePaymentAggrementSubHeaderText2",
                                        "itemType": "text",
                                        "itemValue": "You're eligible for an upgrade. Check out our latest devices.",
                                        "itemAttributes": {}
                                    },
                                    {
                                        "itemKey": "devicePaymentAggrementMessageText2",
                                        "itemType": "text",
                                        "itemValue": "##MONTHS## monthly bills left with remaining balance of ##BALANCE##",
                                        "itemAttributes": {}
                                    },
                                    {
                                        "itemKey": "devicePaymentAggrementPromotionMessageText",
                                        "itemType": "text",
                                        "itemValue": "Ready for an upgrade? This device is currently on a promotion. Select to pay off the device to learn how to upgrade.",
                                        "itemAttributes": {}
                                    },
                                    {
                                        "itemKey": "devicePaymentAggrementPromotionMessageText",
                                        "itemType": "text",
                                        "itemValue": "Ready for an upgrade? This device is currently on a promotion. Select to pay off the device to learn how to upgrade.",
                                        "itemAttributes": {}
                                    },
                                    {
                                        "itemKey": "checkNetworkCompatibiltyText",
                                        "itemType": "button",
                                        "itemValue": "Check Network Compatibility",
                                        "itemAttributes": {},
                                        "actionKey": "checkNetworkCompatibiltyAction"
                                    },
                                    {
                                        "itemKey": "deviceSuspended",
                                        "itemType": "text",
                                        "itemValue": "Suspended",
                                        "itemAttributes": {}
                                    },
                                    {
                                        "itemKey": "pendingLineChangeNotificationTitle",
                                        "itemType": "text",
                                        "itemValue": "You have pending account changes",
                                        "itemAttributes": {}
                                    },
                                    {
                                        "itemKey": "pendingLineChangeNotificationSubTitle",
                                        "itemType": "text",
                                        "itemValue": "In order to make certain changes to this line, you'll have to cancel the pending changes or wait until they're completed",
                                        "itemAttributes": {}
                                    },
                                    {
                                        "itemKey": "reviewDetail",
                                        "itemType": "button",
                                        "itemValue": "Review details",
                                        "itemAttributes": {},
                                        "actionKey": "reviewDetailAction"
                                    },
                                    {
                                        "itemKey": "deviceProtectionHeaderText",
                                        "itemType": "text",
                                        "itemValue": "Manage your device protection.",
                                        "itemAttributes": {}
                                    },
                                    {
                                        "itemKey": "deviceProtectionSubHeaderText",
                                        "itemType": "text",
                                        "itemValue": "Your device is protected. Need to report a lost, stolen or damaged device? You can start by filing a claim.",
                                        "itemAttributes": {}
                                    },
                                    {
                                        "itemKey": "manageDeviceProtection",
                                        "itemType": "button",
                                        "itemValue": "Review coverage",
                                        "itemAttributes": {},
                                        "actionKey": "manageDeviceProtectionAction"
                                    },
                                    {
                                        "itemKey": "learnMore",
                                        "itemType": "http",
                                        "itemValue": "Learn More",
                                        "itemAttributes": {},
                                        "actionKey": "learnMoreAction"
                                    },
                                    {
                                        "itemKey": "deviceProtectionNotEligibleHeaderText",
                                        "itemType": "text",
                                        "itemValue": "Learn how to protect your device.",
                                        "itemAttributes": {}
                                    },
                                    {
                                        "itemKey": "deviceProtectionNotEligibleSubHeaderText",
                                        "itemType": "text",
                                        "itemValue": "We offer device protection with 24/7 Tech Coach expert support, digital security and privacy tools. It also comes with same-day delivery and setup for replacement smartphones and new devices purchased from Verizon.",
                                        "itemAttributes": {}
                                    },
                                    {
                                        "itemKey": "cardHeaderText",
                                        "itemType": "text",
                                        "itemValue": "Enroll in device protection.",
                                        "itemAttributes": {}
                                    },
                                    {
                                        "itemKey": "cardSubHeaderText",
                                        "itemType": "text",
                                        "itemValue": "Protect your device with 24/7 Tech Coach expert support, digital security and privacy tools. It also comes with same-day delivery and setup for replacement smartphones and new devices purchased from Verizon. You're eligible to enroll within 30 days of device activation for a new line or an upgraded line. You can cancel your coverage at any time.",
                                        "itemAttributes": {},
                                        "actionKey": "learnMoreAction"
                                    },
                                    {
                                        "itemKey": "enrollBtn",
                                        "itemType": "button",
                                        "itemValue": "Get it now",
                                        "itemAttributes": {},
                                        "actionKey": "enrollAction"
                                    },
                                    {
                                        "itemKey": "reconnectServiceBtn",
                                        "itemType": "button",
                                        "itemValue": "Re-connect",
                                        "itemAttributes": {},
                                        "actionKey": "suspendOrReconnectServiceAction"
                                    },
                                    {
                                        "itemKey": "eSIMText",
                                        "itemType": "text",
                                        "itemValue": "(eSIM)",
                                        "itemAttributes": {}
                                    },
                                    {
                                        "itemKey": "pSIMText",
                                        "itemType": "text",
                                        "itemValue": "(pSIM)",
                                        "itemAttributes": {}
                                    },
                                    {
                                        "itemKey": "firstNumberHeader",
                                        "itemType": "text",
                                        "itemValue": "First number",
                                        "itemAttributes": {}
                                    },
                                    {
                                        "itemKey": "secondNumberHeader",
                                        "itemType": "text",
                                        "itemValue": "Second number",
                                        "itemAttributes": {}
                                    },
                                    {
                                        "itemKey": "nosecondNumberText",
                                        "itemType": "text",
                                        "itemValue": "You don’t have a second number yet",
                                        "itemAttributes": {}
                                    },
                                    {
                                        "itemKey": "manageText",
                                        "itemType": "text",
                                        "itemValue": "Manage",
                                        "itemAttributes": {}
                                    },
                                    {
                                        "itemKey": "upgradeToPlanText",
                                        "itemType": "text",
                                        "itemValue": "Would you like to upgrade your Second Number?",
                                        "itemAttributes": {}
                                    },
                                    {
                                        "itemKey": "upgradeToPlanText2",
                                        "itemType": "text",
                                        "itemValue": "If you'd like the full myPlan experience for your second line, call us at 800-922-0204.",
                                        "itemAttributes": {}
                                    },
                                    {
                                        "itemKey": "upgradePlanBtn",
                                        "itemType": "button",
                                        "itemValue": "Upgrade to full plan",
                                        "itemAttributes": {},
                                        "actionKey": "upgradeKeyAction"
                                    },
                                    {
                                        "itemKey": "fileClaimbtn",
                                        "itemType": "button",
                                        "itemValue": "File a claim",
                                        "itemAttributes": {},
                                        "actionKey": "fileClaimAction"
                                    },
                                    {
                                        "itemKey": "getSeconNumberSubHeaderText",
                                        "itemType": "text",
                                        "itemValue": "You don't have a second number yet",
                                        "itemAttributes": {}
                                    },
                                    {
                                        "itemKey": "ChangeDeviceModalBtn",
                                        "itemType": "button",
                                        "itemValue": "Got it",
                                        "itemAttributes": {}
                                    },
                                    {
                                        "itemKey": "ChangeDeviceModalHeader",
                                        "itemType": "text",
                                        "itemValue": "Update your device",
                                        "itemAttributes": {}
                                    },
                                    {
                                        "itemKey": "ChangeDeviceModalSubHeader",
                                        "itemType": "text",
                                        "itemValue": "We're here to help. We'll walk you through how to transfer your line that's on the Discover Verizon Mobile trial to a different device. Please give us a call at 800.922.0204 at your convenience.",
                                        "itemAttributes": {}
                                    },
                                    {
                                        "itemKey": "getSecondNumberLinkText",
                                        "itemType": "text",
                                        "itemValue": "Get a second number",
                                        "itemAttributes": {}
                                    },
                                    {
                                        "itemKey": "pearlTrialBtn",
                                        "itemType": "button",
                                        "itemValue": "Join now",
                                        "itemAttributes": {},
                                        "actionKey": "pearlTrialAction"
                                    },
                                    {
                                        "itemKey": "pearlTrialPlanBtn",
                                        "itemType": "button",
                                        "itemValue": "Review Plan",
                                        "itemAttributes": {},
                                        "actionKey": "pearlTrialPlanAction"
                                    },
                                    {
                                        "itemKey": "pearlEligibleHeaderText",
                                        "itemType": "text",
                                        "itemValue": "Enjoying your trial membership?",
                                        "itemAttributes": {}
                                    },
                                    {
                                        "itemKey": "pearlEligibleSubHeader",
                                        "itemType": "text",
                                        "itemValue": "Join verizon now to take advantage of special offers and personalized plans.",
                                        "itemAttributes": {}
                                    },
                                    {
                                        "itemKey": "trialMilitarySuspendBtn",
                                        "itemType": "button",
                                        "itemValue": "Suspend or reconnect service",
                                        "itemAttributes": {},
                                        "actionKey": "trialMilitarySuspendBtnAction"
                                    },
                                    {
                                        "itemKey": "trialCancelBtn",
                                        "itemType": "button",
                                        "itemValue": "Cancel trial",
                                        "itemAttributes": {},
                                        "actionKey": "trialCancelBtnAction"
                                    },
                                    {
                                        "itemKey": "upgradeEligibilityOneclickSubtHeader",
                                        "itemType": "text",
                                        "itemValue": "Trade in your phone and get our best deal.",
                                        "itemAttributes": {}
                                    },
                                    {
                                        "itemKey": "pearlTrialEditDeviceNameTextlink",
                                        "itemType": "text",
                                        "itemValue": "Edit",
                                        "itemAttributes": {}
                                    },
                                    {
                                        "itemKey": "pearlHeaderText",
                                        "itemType": "text",
                                        "itemValue": "Manage your device details.",
                                        "itemAttributes": {}
                                    },
                                    {
                                        "itemKey": "SIMFreezeNotificationTitle",
                                        "itemType": "text",
                                        "itemValue": "Upgrades are blocked until <unfreeze timestamp>.",
                                        "itemAttributes": {}
                                    },
                                    {
                                        "itemKey": "SIMFreezeNotificationDesc",
                                        "itemType": "text",
                                        "itemValue": "For your security, disabling SIM Protection may take up to <thaw threshold> minutes and is still in progress.",
                                        "itemAttributes": {}
                                    },
                                    {
                                        "itemKey": "SIMFreezePopupTitleText",
                                        "itemType": "text",
                                        "itemValue": "You cannot upgrade or change device with SIM Protection on.",
                                        "itemAttributes": {}
                                    },
                                    {
                                        "itemKey": "SIMFreezePopupDescText1",
                                        "itemType": "text",
                                        "itemValue": "SIM Protection is currently enabled on this mobile number. Please disable SIM Protection before you activate another device.",
                                        "itemAttributes": {}
                                    },
                                    {
                                        "itemKey": "SIMFreezePopupDescText2",
                                        "itemType": "text",
                                        "itemValue": "For your security, disabling SIM Protection will take <thaw threshold> minutes. During this time, upgrades and device changes will still be blocked.",
                                        "itemAttributes": {}
                                    },
                                    {
                                        "itemKey": "SIMFreezeSettingBtnText",
                                        "itemType": "button",
                                        "itemValue": "Go to SIM Protection settings",
                                        "itemAttributes": {},
                                        "actionKey": "SIMFreezeSettingBtnAction"
                                    },
                                    {
                                        "itemKey": "checkUsageBtn",
                                        "itemType": "button",
                                        "itemValue": "Check usage",
                                        "itemAttributes": {},
                                        "actionKey": "reviewUsageAction"
                                    },
                                    {
                                        "itemKey": "earlyUpgradepaidlessSubHeaderText",
                                        "itemType": "text",
                                        "itemValue": "To upgrade early, pay ##balance## and return the device in good condition to get the remaining balance waived.",
                                        "itemAttributes": {}
                                    },
                                    {
                                        "itemKey": "earlyUpgradepaidhighSubHeaderText",
                                        "itemType": "text",
                                        "itemValue": "To upgrade early, return the device to get the balance waived or pay it off to keep the device.",
                                        "itemAttributes": {}
                                    },
                                    {
                                        "itemKey": "BeforeThirtyDaysSubtext",
                                        "itemType": "text",
                                        "itemValue": "To upgrade now, you can pay off your device at a store.  After 30 days  from purchase, you can pay it off online.",
                                        "itemAttributes": {}
                                    },
                                    {
                                        "itemKey": "changeMobileNumberThrottle",
                                        "itemType": "button",
                                        "itemValue": "Change mobile number",
                                        "itemAttributes": {},
                                        "actionKey": "changeMobileNumberAction_nsa"
                                    },
                                    {
                                        "itemKey": "newRecommendationTileEnabled",
                                        "itemType": "text",
                                        "itemValue": "true",
                                        "itemAttributes": {}
                                    }
                                ]
                            }
                        ],
                        "data": [
                            {
                                "mtn": "6176317641",
                                "pearlTrialFlow": true,
                                "displayMtn": "617-631-7641",
                                "encryptedMtnAES": "YF/7vlSz+H8kvZINPe+GL0Igdsa/8YuOIQx2bKOw/tM=",
                                "encryptedMtnDES": "KQtGtWnGORllWXjrFUdkqg%3D%3D",
                                "modelName": "Apple iPhone 14 Pro Max 128GB in Silver",
                                "nickName": "KIRANKUMAR BHAR DANGAR",
                                "simId": "89148000008064874997",
                                "encryptedSimId": "ZAEiJc%2B0MTm%2FNMgJ3s3EUVMgwgm98xEC",
                                "deviceDetailsFeatureFlags":{
                                    "deviceDetailBtnFFlag":true
                                },
                                "simType": "ICC",
                                "upgradeEligible": true,
                                "userRole": "Member",
                                "device4G": false,
                                "device5GE": true,
                                "device5GA": false,
                                "smartPhone": true,
                                "basicPhone": false,
                                "deviceId": "355822268965652",
                                "paymentInfo": {
                                    "hasPayOffBalance": false,
                                    "displayReturnOption": false,
                                    "payOffEligible": false,
                                    "lessThan30Days": false,
                                    "promoDevice": false,
                                    "upgradeEligible": false
                                },
                                "preferences": {
                                    "shareNameIDBtn": false,
                                    "shareNameIDBtnThrottle": true,
                                    "manageCallForwardingBtn": true,
                                    "blockSpecificServicesBtn": false,
                                    "blockCallsAndMessagesBtn": false,
                                    "manageCallFilterBtn": true,
                                    "manageVoicemailPasswordBtn": true,
                                    "backupContentToVerizonCloudBtn": false
                                },
                                "planUsageInfo": {
                                    "planName": "Discover Verizon Mobile Plan"
                                },
                                "deviceManagement": {
                                    "tradeInBtn": false,
                                    "changeOrReplaceDeviceBtn": false,
                                    "activateOrGetSimBtn": false,
                                    "activateOrSwitchDeviceBtn": false,
                                    "checkNetworkCompatibiltyText": true,
                                    "changeOrReplaceDeviceLineBtn":true,
                                    "upgradeDeviceBtn": false,
                                    "changeMobileNumberBtn": true,
                                    "changeMobileNumberThrottle": false,
                                    "transferYourServiceBtn": false,
                                    "manageConnectedDevicesBtn": false,
                                    "suspendOrReconnectServiceBtn": true,
                                    "numberLockBtn": false,
                                    "numberTransferPinBtn": false,
                                    "disconnectDeviceBtn": false,
                                    "pinandPersonalUnblockingKeyBtn": true,
                                    "manageNumberShareBtn": false,
                                    "viewAddOnsBtn": false,
                                    "trialCancelBtn": true,
                                    "trialMilitarySuspendBtn": false
                                },
                                "troubleshootAndSupport": {
                                    "networkStatusBtn": false,
                                    "troubleshootBtn": true,
                                    "techCoachSupportBtn": true,
                                    "runHealthCheckBtn": false,
                                    "transferContentBetweenPhonesBtn": false,
                                    "launchSecurityDashboardBtn": false
                                },
                                "images": {
                                    "defaultImage": "https://ss7.vzw.com/is/image/VerizonWireless/iphone-14-pro-max-silver-fall22-a",
                                    "largeImage": "https://ss7.vzw.com/is/image/VerizonWireless/iphone-14-pro-max-silver-fall22-a?$device-lg$",
                                    "mediumImage": "https://ss7.vzw.com/is/image/VerizonWireless/iphone-14-pro-max-silver-fall22-a?$device-med$",
                                    "miniImage": "https://ss7.vzw.com/is/image/VerizonWireless/iphone-14-pro-max-silver-fall22-a?$device-mini$",
                                    "thumbImage": "https://ss7.vzw.com/is/image/VerizonWireless/iphone-14-pro-max-silver-fall22-a?$device-thumb$"
                                },
                                "displayDeviceCategory": "5G Smartphone",
                                "esim": true,
                                "psim": false,
                                "router": false,
                                "accountPlan": {
                                    "mtn": "6176317641",
                                    "unlimitedDataPlan": false,
                                    "unlimitedMessagePlan": false,
                                    "unlimitedMinutesPlan": false
                                },
                                "dynamicData": {
                                    "deviceName": "Apple iPhone 14 Pro Max 128GB in Silver",
                                    "encMdn": "KQtGtWnGORllWXjrFUdkqg%3D%3D",
                                    "nsaHost": "https://vzwqa2.verizonwireless.com"
                                },
                                "pendingLineChange": false,
                                "deviceCategory": "phone",
                                "isOneClickEligible": false,
                                "mtnStatus": "A",
                                "isMtnSuspended": false,
                                "openEnrollmentPeriod": "N",
                                "deviceProtectionEnrolled": "N",
                                "skuId": "MQ8P3LL/A",
                                "productDisplayName": "iPhone 14 Pro Max",
                                "networkExtender": false,
                                "secondMtn": "6176317641",
                                "isSecondNumber": false,
                                "eSimActive": true,
                                "pSimActive": false,
                                "fileAClaim": "N",
                                "hasSecondNumberEligible": false,
                                "wififlow": true,
                                "simFreezeInfo": {
                                    "simFreezeCode": "N",
                                    "simUnfreezeTimeStamp": "",
                                    "simFreezeDuration": "15",
                                    "isBlocked": "N",
                                    "simFreezeDetails": "QQ"
                                }
                            }
                        ]
                    }
                ]
            }
        ]
        }
    }),
    Home:()=>({
        selectedDevice:{}
    }),
})

let store = configureStore(APP);
const persistor = persistStore(store);
jest.mock("@vz/react-util", () => ({
    ...jest.requireActual("@vz/react-util"),
    getHttpClientRequest: jest.fn(),
    postHttpClientRequest: jest.fn()
}));


jest.mock("../../../../shared/services/httpClient", () => ({
    ...jest.requireActual("../../../../shared/services/httpClient"),
}));
const DeviceDetailTestSuite = () => {
    describe("<DeviceDetail />", () => {
      beforeEach(async () => {
        cleanup();
        window.history.pushState=jest.fn()
        getHttpClientRequest.mockImplementation((url) => {
            return Promise.resolve({ status: 200, data: { ...deviceDetail2 } });
          });
        window.enableDualNumExp = false;  
            await act(async () => render(
            <Provider store={store}>
                <PersistGate loading={null} persistor={persistor}>
                <DeviceDetail />
                </PersistGate>
            </Provider>
            ));
        });
        test("Test",()=>{
            const btn1 = document.querySelector('[aria-label="change Or Replace DeviceLine"]')
            fireEvent.click(btn1);
            const closeBtn = screen.getByTestId('ChangeOrReplaceModalTestId');
            expect(closeBtn).toBeInTheDocument();
            // screen.debug(closeBtn);
            // const GotItModalBtn = screen.getByTestId('ChangeOrReplaceModal1TestId');
            // expect(GotItModalBtn).toBeInTheDocument();
            // fireEvent.click(GotItModalBtn);
            
                // const closeBtn = screen.getAllByText('Update your device')//document.querySelector('[aria-label="Got it"]')//screen.getByTestId("ChangeOrReplaceModalTestId")
                // console.log("hello1",closeBtn)
                // expect('Update your device').toBe(closeBtn)
            //     fireEvent.click(closeBtn)
             expect(true).toBe(true)
        })
        // test("Test",()=>{
        //     //  const closeBtn = document.querySelector('button[aria-label="Got it"]');
        //     //  fireEvent.click(closeBtn)
        //     const btn =screen.getByRole('button',{name:/Got it/i})
        //     expect(btn).toBeInTheDocument()
        //      expect(true).toBe(true)
        // })
    });
}
DeviceDetailTestSuite();