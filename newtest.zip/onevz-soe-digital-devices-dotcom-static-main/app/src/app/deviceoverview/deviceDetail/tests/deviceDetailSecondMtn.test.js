import React from "react";
import "../../../../../config/jest/test-setup";
import { act, render, screen, fireEvent } from "@testing-library/react";
import "@testing-library/jest-dom/extend-expect";
import { Provider } from "react-redux";
import  { getHttpClientRequest } from '@vz/react-util';
import configureStore from "../../../../shared/store/configureStore";
import rootReducer from "../../reducers";
import { persistStore } from 'redux-persist';
import { PersistGate } from 'redux-persist/integration/react';
import DeviceDetail from "../components/index";
import { deviceDetail7 } from "./mockResponse";
import * as pageActions from '../actions/pageActions';

const store = configureStore(rootReducer);
const persistor = persistStore(store);

jest.mock('@vz/react-util', () => ({
    ...jest.requireActual('@vz/react-util'),
    getHttpClientRequest: jest.fn()
}));

const data = {
    "mtn": "3152721111",
    "displayMtn": "315-272-1111",
    "secondMtn": "",
    "isSecondNumber": true,
    "encryptedMtnAES": "c/hjJph7S0I9+ShOR9odHCnNrASzLr83UYeWgTCkjLU=",
    "encryptedMtnDES": "DEdPlyZHgN2FUgwlk4%2Bq7A%3D%3D",
    "modelName": "Samsung Galaxy S22 Ultra 128GB in Green",
    "nickName": "LUCY LEGER",
    "simId": "89148000004602471600",
    "encryptedSimId": "ZAEiJc%2B0MTkkWf7bcCqcYI4stEKPgaOm",
    "simType": "ICC",
    "upgradeEligible": true,
    "userRole": "Non Registered",
    "device4G": false,
    "device5GE": false,
    "device5GA": false,
    "smartPhone": false,
    "basicPhone": false,
    "deviceId": "990006359378287",
    "paymentInfo": {
        "hasPayOffBalance": false,
        "displayReturnOption": false,
        "payOffEligible": false,
        "upgradeEligible": false,
        "promoDevice": false
    },
    "preferences": {
        "shareNameIDBtn": true,
        "shareNameIDBtnThrottle": false,
        "manageCallForwardingBtn": true,
        "blockSpecificServicesBtn": true,
        "blockCallsAndMessagesBtn": true,
        "manageCallFilterBtn": true,
        "manageVoicemailPasswordBtn": true,
        "backupContentToVerizonCloudBtn": true
    },
    "planUsageInfo": {
        "planName": "Unlimited Plan"
    },
    "deviceManagement": {
        "tradeInBtn": true,
        "activateOrSwitchDeviceBtn": true,
        "checkNetworkCompatibiltyText": false,
        "upgradeDeviceBtn": true,
        "changeMobileNumberBtn": true,
        "changeMobileNumberThrottle": false,
        "transferYourServiceBtn": true,
        "manageConnectedDevicesBtn": false,
        "suspendOrReconnectServiceBtn": true,
        "numberLockBtn": true,
        "numberTransferPinBtn": true,
        "disconnectDeviceBtn": true,
        "pinandPersonalUnblockingKeyBtn": true,
        "manageNumberShareBtn": true,
        "viewAddOnsBtn": true
    },
    "troubleshootAndSupport": {
        "networkStatusBtn": true,
        "troubleshootBtn": false,
        "techCoachSupportBtn": true,
        "runHealthCheckBtn": true,
        "transferContentBetweenPhonesBtn": true,
        "launchSecurityDashboardBtn": false
    },
    "images": {
        "defaultImage": "https://ss7.vzw.com/is/image/VerizonWireless/apple-iphone-12-pro-max-pacificblue-10132020",
        "largeImage": "https://ss7.vzw.com/is/image/VerizonWireless/apple-iphone-12-pro-max-pacificblue-10132020?$device-lg$",
        "mediumImage": "https://ss7.vzw.com/is/image/VerizonWireless/apple-iphone-12-pro-max-pacificblue-10132020?$device-med$",
        "miniImage": "https://ss7.vzw.com/is/image/VerizonWireless/apple-iphone-12-pro-max-pacificblue-10132020?$device-mini$",
        "thumbImage": "https://ss7.vzw.com/is/image/VerizonWireless/apple-iphone-12-pro-max-pacificblue-10132020?$device-thumb$"
    },
    "displayDeviceCategory": "4G Internet",
    "esim": false,
    "psim": true,
    "router": false,
    "accountPlan": {
        "mtn": "3152721111",
        "unlimitedDataPlan": true,
        "dataPlan": "9999",
        "dataUsed": "0",
        "unlimitedMessagePlan": true,
        "messagePlan": "9999",
        "messageUsed": "0",
        "unlimitedMinutesPlan": true,
        "minutesPlan": "0",
        "minutesUsed": "0",
        "unitOfMeasureCDForData": "GB"
    },
    "dynamicData": {
        "deviceName": "Samsung Galaxy S22 Ultra 128GB in Green",
        "encMdn": "m%2FYt8XCPnURdRNDx7u8IRQ%3D%3D",
        "nsaHost": "https://www.verizon.com"
    },
    "pendingLineChange": false,
    "deviceCategory": "connecteddevice",
    "mtnStatus": "A",
    "isMtnSuspended": false,
    "openEnrollmentPeriod": "N",
    "deviceProtectionEnrolled": "Y",
    "skuId": "MIFI6620L",
    "productDisplayName": "Galaxy S22 Ultra",
    "networkExtender": false
}

describe("<DeviceDetail />", () => {
    window.enableDualNumExp = false;
    beforeEach(async () => {
        getHttpClientRequest.mockImplementation((url) => {
            return Promise.resolve({ status: 200, data: { ...deviceDetail7 } });
        });

        await act(async () => render(
            <Provider store={store}>
                <PersistGate loading={null} persistor={persistor}>
                    <DeviceDetail />
                </PersistGate>
            </Provider>
        ));
        store.dispatch(pageActions.setSelectedDevice(data));

    })

    test("render tabs", () => {
        const tabs = screen.getByRole("tablist");
        expect(tabs).toBeInTheDocument();
    })

    test("selects second tab", () => {
        const displayNumber = jest.fn().mockResolvedValue(data.mtn);
        const tab = screen.getByRole("tab", { name: "Second number" })
        fireEvent.click(tab);
        expect(tab).toBeInTheDocument();
        expect(displayNumber).toBeDefined();
    })

    test("selects First tab", () => {
        const displayNumber = jest.fn().mockResolvedValue(data.mtn);
        const tab = screen.getByRole("tab", { name: "First number" })
        expect(tab).toBeInTheDocument();
        expect(displayNumber).toBeDefined()
    })

    test("render Manage link for first number", async () => {
        const manageLink = screen.getByRole("link", { name: "Manage" })
        const tab = screen.getByRole("tab", { name: "Second number" })
        const tab2 = screen.getByRole("tab", { name: "First number" })
        expect(manageLink).toBeInTheDocument();
        fireEvent.click(manageLink);
        await expect(tab.getAttribute("aria-selected")).toBe("true");
        expect(tab2.getAttribute("aria-selected")).toBe("false");
    })

    test("render Manage link for second number", async () => {

        const tab = screen.getByRole("tab", { name: "Second number" })
        fireEvent.click(tab);
        const manageLink = screen.getByRole("link", { name: "Manage" })
        const tab2 = screen.getByRole("tab", { name: "First number" })
        fireEvent.click(manageLink);
        await expect(tab2.getAttribute("aria-selected")).toBe("true");
        expect(tab.getAttribute("aria-selected")).toBe("false");
    })


});

describe("<DeviceDetail />", () => {
    window.enableDualNumExp = true;
    beforeEach(async () => {
        getHttpClientRequest.mockImplementation((url) => {
            return Promise.resolve({ status: 200, data: { ...deviceDetail7 } });
        });

        await act(async () => render(
            <Provider store={store}>
                <PersistGate loading={null} persistor={persistor}>
                    <DeviceDetail />
                </PersistGate>
            </Provider>
        ));
        store.dispatch(pageActions.setSelectedDevice(data));

    })

    test("render Manage link for second number", async () => {
        window.enableDualNumExp = true;
        const tab = screen.getByRole("tab", { name: "Second number" })
        fireEvent.click(tab);
        const manageLink = screen.getByRole("link", { name: "Manage" })
        const tab2 = screen.getByRole("tab", { name: "First number" })
        fireEvent.click(manageLink);
        await expect(tab2.getAttribute("aria-selected")).toBe("true");
        expect(tab.getAttribute("aria-selected")).toBe("false");
    })

    test("render Manage link for first number", async () => {
        window.enableDualNumExp = true;

        const manageLink = screen.getByRole("link", { name: "Manage" })
        const tab = screen.getByRole("tab", { name: "Second number" })
        const tab2 = screen.getByRole("tab", { name: "First number" })
        expect(manageLink).toBeInTheDocument();
        fireEvent.click(manageLink);
        await expect(tab.getAttribute("aria-selected")).toBe("true");
        expect(tab2.getAttribute("aria-selected")).toBe("false");
        const upgradePlan = screen.getByTestId("upgradePlanBtnTestId")
        expect(upgradePlan).toBeInTheDocument();
        fireEvent.click(upgradePlan)
        // const gotit = screen.getByRole("button", { name: "Got it" });
        // fireEvent.click(gotit)
    })

});