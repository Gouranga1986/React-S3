import React from "react";
import "../../../../../config/jest/test-setup";
import { act, render, screen, fireEvent } from "@testing-library/react";
import "@testing-library/jest-dom/extend-expect";
import { Provider } from "react-redux";
import { getHttpClientRequest } from '@vz/react-util';
import configureStore from "../../../../shared/store/configureStore";
import rootReducer from "../../reducers";
import { persistStore } from 'redux-persist';
import { PersistGate } from 'redux-persist/integration/react';
import DeviceDetail from "../components/index";
import { deviceDetail5 } from "./mockResponse";
import * as getSections from '../actions/getSections';
import * as pageActions from '../actions/pageActions';

const store = configureStore(rootReducer);
const persistor = persistStore(store);

jest.mock('@vz/react-util', () => ({
  ...jest.requireActual('@vz/react-util'),
  getHttpClientRequest: jest.fn()
}));

describe("<DeviceDetail />", () => {
  beforeEach(async () => {
    getHttpClientRequest.mockImplementation((url) => {
      return Promise.resolve({ status: 200, data: { ...deviceDetail5 } });
    });

    await act(async () => render(
      <Provider store={store}>
        <PersistGate loading={null} persistor={persistor}>
          <DeviceDetail />
        </PersistGate>
      </Provider>
    ));

  })

  test("it should mount", () => {
    const doc = screen.getByTestId("DeviceDetailTestId");
    expect(doc).toBeInTheDocument();
  });
  test("payOffDeviceBtnTestId test", () => {
    jest.setTimeout('10000');
    const dropDown = screen.getByTestId(`deviceListTestId`)
    expect(dropDown).toBeInTheDocument();
    // fireEvent.click(screen.getByTestId(`deviceListTestId`));
  })
  test("device details api error", () => {
    
    getHttpClientRequest.mockImplementation((url) => {
      return Promise.reject({ data: 'error' });
    });

    store.dispatch(getSections.getSections('getSection'))
      // .then((res) => {
      // }, (error) => {
      //   expect(error.data).toEqual('error');
      // });

  });
  test("pin and pick api error", () => {
    
    getHttpClientRequest.mockImplementation((url) => {
      return Promise.reject({ data: 'error' });
    });

    store.dispatch(getSections.getPinAndPukCode('getSection'))
      // .then((res) => {
      // }, (error) => {
      //   expect(error.data).toEqual('error');
      // }).catch((err) => console.log(err));;

  });
  test("openPendingLineChangeDetailModal api error", () => {
    
    getHttpClientRequest.mockImplementation((url) => {
      return Promise.reject({ data: 'error' });
    });

    store.dispatch(getSections.openPendingLineChangeDetailModal('getSection'));


  });
  test("closePendingLineChangeDetailModal api error", () => {
    
    getHttpClientRequest.mockImplementation((url) => {
      return Promise.reject({ data: 'error' });
    });

    store.dispatch(getSections.closePendingLineChangeDetailModal('getSection'));


  });
  test("setClosePendingLineChangeDetailModal api error", () => {
    
    getHttpClientRequest.mockImplementation((url) => {
      return Promise.reject({ data: 'error' });
    });

    store.dispatch(getSections.setClosePendingLineChangeDetailModal('getSection'));


  });

  test("setOpenPinAndPukModal api error", () => {
    
    getHttpClientRequest.mockImplementation((url) => {
      return Promise.reject({ data: 'error' });
    });

    store.dispatch(getSections.setOpenPinAndPukModal('getSection'));


  });
  test("closePinAndPukModal api error", () => {
    
    getHttpClientRequest.mockImplementation((url) => {
      return Promise.reject({ data: 'error' });
    });

    store.dispatch(getSections.closePinAndPukModal('getSection'));


  });
  test("closeEditNickNameModal api error", () => {
    
    getHttpClientRequest.mockImplementation((url) => {
      return Promise.reject({ data: 'error' });
    });
    store.dispatch(getSections.closeEditNickNameModal('getSection'));
  });

  test("getTrobleshootBegin api error", () => {
    
    getHttpClientRequest.mockImplementation((url) => {
      return Promise.reject({ data: 'error' });
    });
    store.dispatch(getSections.getTrobleshootBegin('getSection'));
  });

  test("getTrobleshootSuccess api error", () => {
    
    getHttpClientRequest.mockImplementation((url) => {
      return Promise.reject({ data: 'error' });
    });
    store.dispatch(getSections.getTrobleshootSuccess('getSection'));
  });

  test("getTrobleshootError api error", () => {
    
    getHttpClientRequest.mockImplementation((url) => {
      return Promise.reject({ data: 'error' });
    });
    store.dispatch(getSections.getTrobleshootError('getSection'));
  });

  test("setPinAndPukSuccess api error", () => {
    
    getHttpClientRequest.mockImplementation((url) => {
      return Promise.reject({ data: 'error' });
    });
    store.dispatch(getSections.setPinAndPukSuccess('getSection'));
  });

  test("setPinAndPukError api error", () => {
    
    getHttpClientRequest.mockImplementation((url) => {
      return Promise.reject({ data: 'error' });
    });
    store.dispatch(getSections.setPinAndPukError('getSection'));
  });

  test("setNickNameError api error", () => {
    
    getHttpClientRequest.mockImplementation((url) => {
      return Promise.reject({ data: 'error' });
    });
    store.dispatch(getSections.setNickNameError('getSection'));
  });

  test("setNickNameSuccess api error", () => {
    
    getHttpClientRequest.mockImplementation((url) => {
      return Promise.reject({ data: 'error' });
    });
    store.dispatch(getSections.setNickNameSuccess('getSection'));
  });

  test("setSelectedDevice api error", () => {
    
    getHttpClientRequest.mockImplementation((url) => {
      return Promise.reject({ data: 'error' });
    });
    store.dispatch(pageActions.setSelectedDevice('getSection'));
  });

});