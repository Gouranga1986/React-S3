import React from "react";
import "../../../../../config/jest/test-setup";
import { act, render, screen } from "@testing-library/react";
import "@testing-library/jest-dom/extend-expect";
import { Provider } from "react-redux";
import configureStore from "../../../../shared/store/configureStore";
import rootReducer from "../../reducers";
import { persistStore } from 'redux-persist';
import { PersistGate } from 'redux-persist/integration/react';
import { deviceDetailInfoSection } from "./mockResponse";
import ChangeOrReplaceModal from "../components/ChangeOrReplaceModal";

const store = configureStore(rootReducer);
const persistor = persistStore(store);
jest.mock("@vz/react-util", () => ({
    ...jest.requireActual("@vz/react-util"),
    getHttpClientRequest: jest.fn()
}));

jest.mock("../../../../shared/services/httpClient", () => ({
    ...jest.requireActual("../../../../shared/services/httpClient"),
    // getHttpClientRequest: jest.fn()
}));


describe("<DeviceDetail />", () => {
    beforeEach(async () => {
       
        await act(async () => render(
            <Provider store={store}>
                <PersistGate loading={null} persistor={persistor}>
                    <ChangeOrReplaceModal handleModalChange={jest.fn()} changeOrReplaceModal={true} handleCancel={jest.fn()} deviceDetailInfoSection={deviceDetailInfoSection}/>
                </PersistGate>
            </Provider>
        ));
    })

    test("it should mount", () => {
        const doc = screen.getByTestId("ChangeOrReplaceModalTestId");
        expect(doc).toBeInTheDocument();
        screen.debug(undefined, Infinity)
    });
});