import React from "react";
import "../../../../../config/jest/test-setup";
import { act, render, screen, fireEvent } from "@testing-library/react";
import "@testing-library/jest-dom/extend-expect";
import { Provider } from "react-redux";
import configureStore, { history } from "../../../../shared/store/configureStore";
import rootReducer from "../../reducers";
import { persistStore } from 'redux-persist';
import { PersistGate } from 'redux-persist/integration/react';
import EditNickNameModal from "../components/editNickNameModal";
import { deviceDetail , data} from "./mockResponse";
import { getHttpClientRequest } from "@vz/react-util";
import * as deviceDetailActions from '../actions';


const store = configureStore(rootReducer);
const persistor = persistStore(store);
jest.mock("@vz/react-util", () => ({
    ...jest.requireActual("@vz/react-util"),
    getHttpClientRequest: jest.fn()
  }));

jest.mock("../../../../shared/services/httpClient", () => ({
    ...jest.requireActual("../../../../shared/services/httpClient"),
    // getHttpClientRequest: jest.fn()
}));

const deviceDetailCharText = deviceDetail.body.sections[0].sections[0].contents[0];


describe("<DeviceDetail />", () => {
    window.VZTAG_IS_READY = 'true';
    beforeEach(async () => {
      getHttpClientRequest.mockImplementation((url) => {
            return Promise.resolve({ status: 200, data: { ...deviceDetail } });
        });

        await act(async () => render(
            <Provider store={store}>
                <PersistGate loading={null} persistor={persistor}>
                    <EditNickNameModal selectedDevice={data}/>
                </PersistGate>
            </Provider>
        ));
    })

    test("it should mount", () => {
        const doc = screen.getByTestId("editNicknameTestID");
        expect(doc).toBeInTheDocument();
        store.dispatch(deviceDetailActions.updateNickName({mdn:'2144707276',mdnNickName: 'rita'}))
    });
});
describe("<DeviceDetail />", () => {
    window.VZTAG_IS_READY = 'true';
    reactGlobals.deviceNickNameSpecialCharFFlag = true;
    beforeEach(async () => {
      getHttpClientRequest.mockImplementation((url) => {
            return Promise.resolve({ status: 200, data: { ...deviceDetail } });
        });

        await act(async () => render(
            <Provider store={store}>
                <PersistGate loading={null} persistor={persistor}>
                    <EditNickNameModal selectedDevice={data} pageItems={deviceDetailCharText}/>
                </PersistGate>
            </Provider>
        ));
    })

    test("it should mount", () => {
        const doc = screen.getByTestId("editNicknameTestID");
        expect(doc).toBeInTheDocument();
        store.dispatch(deviceDetailActions.updateNickName({mdn:'2144707276',mdnNickName: 'rita"'}))
    });
    test("it should mount", () => {
        const doc = screen.getByTestId("editNicknameTestID");
        expect(doc).toBeInTheDocument();
        store.dispatch(deviceDetailActions.updateNickName({mdn:'2144707276',mdnNickName: 'rita*'}))
        const txt = screen.getByText("This special character is not allowed");
        expect(txt).toBeInTheDocument();
    });
});