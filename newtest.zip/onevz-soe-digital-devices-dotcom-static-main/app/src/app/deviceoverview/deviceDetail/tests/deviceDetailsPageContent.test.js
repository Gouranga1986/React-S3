import React from "react";
import "../../../../../config/jest/test-setup";
import { act, render, screen, fireEvent } from "@testing-library/react";
import "@testing-library/jest-dom/extend-expect";
import { Provider } from "react-redux";
import { getHttpClientRequest } from '@vz/react-util';
import configureStore from "../../../../shared/store/configureStore";
import rootReducer from "../../reducers";
import { persistStore } from 'redux-persist';
import { PersistGate } from 'redux-persist/integration/react';
import DeviceDetail from "../components/index";
import { deviceDetail3, deviceDetailPageContentData } from "./mockResponse";
import * as actions from "../../home/actions";

const store = configureStore(rootReducer);
const persistor = persistStore(store);

const dummyProps = {
    "match": {
        "path": "/",
        "url": "/",
        "isExact": true,
        "params": {
        }
    }
}



jest.mock('@vz/react-util', () => ({
    ...jest.requireActual('@vz/react-util'),
    getHttpClientRequest: jest.fn()
}));

describe("<DeviceDetail />", () => {
    window.VZTAG_IS_READY = 'true';
    beforeEach(async () => {
        getHttpClientRequest.mockImplementation((url) => {
            return Promise.resolve({ status: 200, data: { ...deviceDetail3 } });
        });

        await act(async () => render(
            <Provider store={store}>
                <PersistGate loading={null} persistor={persistor}>
                    <DeviceDetail {...dummyProps}/>
                </PersistGate>
            </Provider>
        ));
        store.dispatch(actions.setSelectedDevice(deviceDetailPageContentData));
    })

    test("it should mount", () => {
        const doc = screen.getByTestId("DeviceDetailTestId");
        expect(doc).toBeInTheDocument();
    });
});

describe("<DeviceDetail />", () => {
    window.VZTAG_IS_READY = 'true';
    reactGlobals = {
        featureFlag:{
            deviceImeiFFlag :"true" 
        }
          
    }
    beforeEach(async () => {
        getHttpClientRequest.mockImplementation((url) => {
            return Promise.resolve({ status: 200, data: { ...deviceDetail3 } });
        });

        await act(async () => render(
            <Provider store={store}>
                <PersistGate loading={null} persistor={persistor}>
                    <DeviceDetail {...dummyProps}/>
                </PersistGate>
            </Provider>
        ));
        store.dispatch(actions.setSelectedDevice(deviceDetailPageContentData));
    })

    test("it should mount",async () => {
        const doc = screen.getByTestId("DeviceDetailTestId");
        expect(doc).toBeInTheDocument();
    });
    test("it should mount", () => {
        deviceDetail3.body.sections[0].sections[0].data[0].deviceImeiFlag = "S";
        const doc = screen.getByTestId("DeviceDetailTestId");
        expect(doc).toBeInTheDocument();
    });
});