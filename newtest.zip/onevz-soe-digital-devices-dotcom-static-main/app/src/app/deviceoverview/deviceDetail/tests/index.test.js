import React from "react";
import "../../../../../config/jest/test-setup";
import { act, render, screen, fireEvent, waitFor } from "@testing-library/react";
import "@testing-library/jest-dom/extend-expect";
import { Provider } from "react-redux";
import { getHttpClientRequest } from '@vz/react-util';
import configureStore from "../../../../shared/store/configureStore";
import rootReducer from "../../reducers";
import { persistStore } from 'redux-persist';
import { PersistGate } from 'redux-persist/integration/react';
import DeviceDetail from "../components/index";
import { deviceDetail, deviceDetailNew } from "./mockResponse";

const store = configureStore(rootReducer);
const persistor = persistStore(store);

jest.mock('@vz/react-util', () => ({
    ...jest.requireActual('@vz/react-util'),
    getHttpClientRequest: jest.fn()
}));


describe("<DeviceDetail />", () => {
    window.VZTAG_IS_READY = 'true';
    beforeEach(async () => {
        getHttpClientRequest.mockImplementation((url) => {
            return Promise.resolve({ status: 200, data: { ...deviceDetailNew } });
        });

        await act(async () => render(
            <Provider store={store}>
                <PersistGate loading={null} persistor={persistor}>
                    <DeviceDetail />
                </PersistGate>
            </Provider>
        ));
    })

    test("pearlTrialBtnTestId test", async() => {
        jest.setTimeout('10000');
        const manageBtn = screen.getByTestId(`pearlTrialBtnTestId`);
        expect(manageBtn).toBeInTheDocument();
        fireEvent.click(manageBtn);
        await waitFor(() => {
          jest.setTimeout("10000")
          const sonToggle = screen.getAllByTestId("buttonIcon")[0]
          expect(sonToggle).toBeInTheDocument()
          fireEvent.click(sonToggle)
          const sonToggle2 = screen.getAllByTestId("buttonIcon")[1]
          expect(sonToggle2).toBeInTheDocument()
          fireEvent.click(sonToggle2)
          const sonToggle3 = screen.getAllByTestId("buttonIcon")[2]
          expect(sonToggle3).toBeInTheDocument()
          fireEvent.click(sonToggle3)
          const sonToggle4 = screen.getAllByTestId("buttonIcon")[3]
          expect(sonToggle4).toBeInTheDocument()
          fireEvent.click(sonToggle4)
          const sonToggle5 = screen.getAllByTestId("buttonIcon")[4]
          expect(sonToggle5).toBeInTheDocument()
          fireEvent.click(sonToggle5)
          const sonToggle6 = screen.getAllByTestId("buttonIcon")[5]
          expect(sonToggle6).toBeInTheDocument()
          fireEvent.click(sonToggle6)
          const sonToggle7 = screen.getAllByTestId("buttonIcon")[6]
          expect(sonToggle7).toBeInTheDocument()
          fireEvent.click(sonToggle7)
          const sonToggle8 = screen.getAllByTestId("buttonIcon")[7]
          expect(sonToggle8).toBeInTheDocument()
          fireEvent.click(sonToggle8)
          const sonToggle9 = screen.getAllByTestId("buttonIcon")[8]
          expect(sonToggle9).toBeInTheDocument()
          fireEvent.click(sonToggle9)
          const sonToggle10 = screen.getAllByTestId("buttonIcon")[9]
          expect(sonToggle10).toBeInTheDocument()
          fireEvent.click(sonToggle10)
          const sonToggle11 = screen.getAllByTestId("buttonIcon")[10]
          expect(sonToggle11).toBeInTheDocument()
          fireEvent.click(sonToggle11)
          const sonToggle12 = screen.getAllByTestId("buttonIcon")[11]
          expect(sonToggle12).toBeInTheDocument()
          fireEvent.click(sonToggle12)
          const sonToggle13 = screen.getAllByTestId("buttonIcon")[12]
          expect(sonToggle13).toBeInTheDocument()
          fireEvent.click(sonToggle13)
          const sonToggle14 = screen.getAllByTestId("buttonIcon")[13]
          expect(sonToggle14).toBeInTheDocument()
          fireEvent.click(sonToggle14)
          const sonToggle15 = screen.getAllByTestId("buttonIcon")[14]
          expect(sonToggle15).toBeInTheDocument()
          fireEvent.click(sonToggle15)
          const sonToggle16 = screen.getAllByTestId("buttonIcon")[15]
          expect(sonToggle16).toBeInTheDocument()
          fireEvent.click(sonToggle16)
          const sonToggle17 = screen.getAllByTestId("buttonIcon")[16]
          expect(sonToggle17).toBeInTheDocument()
          fireEvent.click(sonToggle17)
          const sonToggle18 = screen.getAllByTestId("buttonIcon")[17]
          expect(sonToggle18).toBeInTheDocument()
          fireEvent.click(sonToggle18)
          const sonToggle19 = screen.getAllByTestId("buttonIcon")[18]
          expect(sonToggle19).toBeInTheDocument()
          fireEvent.click(sonToggle19)  
        })  
    });
    test("pearlTrialPlanBtn test", () => {
        jest.setTimeout('10000');
        const manageBtn = screen.getByTestId(`pearlTrialPlanBtn`);
        expect(manageBtn).toBeInTheDocument();
        fireEvent.click(manageBtn);
    });
});

describe("<DeviceDetail />", () => {
    window.VZTAG_IS_READY = 'true';
    global.dotcomConfig = JSON.parse("{\"reactStaticFilePath\":\"\/digital\/nsa\/nos\/devices\/dotcom\/\",\"statusApiUrl\":\"\/digital\/nsa\/secure\/ui\/devices\/suspendreconnect\/status\",\"landingApiUrl\":\"\/digital\/nsa\/secure\/gw\/devices\/suspendreconnect\/landing\",\"networkOutageUrl\":\"\/digital\/nsa\/secure\/gw\/devices\/notification\/network_outage\",\"pendingAcctChangesURL\":\"\/digital\/nsa\/secure\/ui\/acct\/pending-account\",\"pendingAcctChangesCancelOrder\":\"\/digital\/nsa\/secure\/gw\/acct\/pending-account\/pendingAccChangesCancelOrder\",\"pendingAccChanges\":\"\/digital\/nsa\/secure\/gw\/acct\/pending-account\/pendingAccChanges\",\"isPendingDisconnectLink\":\"true\",\"pendingAccChangesFilterByLine\":\"\",\"deviceDetailUrl\":\"\/digital\/nsa\/secure\/gw\/devices\/deviceDetail\",\"getTroubleshootUrl\":\"\/digital\/nsa\/secure\/gw\/troubleshooting\/get-recent-pending-case\",\"getPinAndPukApi\":\"\/digital\/nsa\/secure\/gw\/devices\/pinpuk_details\",\"deviceLandingPageUrl\":\"\/digital\/nsa\/secure\/gw\/devices\/landing\",\"updateNickNameUrl\":\"\/digital\/nsa\/secure\/gw\/devices\/updateNickName\",\"deviceLandingPageRecommendationUrl\":\"\/digital\/nsa\/secure\/gw\/devices\/recommdation\",\"suspendOptionsApiUrl\":\"\/digital\/nsa\/secure\/gw\/devices\/suspendreconnect\/suspend_options\",\"validateSuspendApiUrl\":\"\/digital\/nsa\/secure\/gw\/devices\/suspendreconnect\/validate_suspend\",\"militaryVerificationApiUrl\":\"\/digital\/nsa\/secure\/gw\/devices\/suspendreconnect\/military_verification\",\"saveSuspendApiUrl\":\"\/digital\/nsa\/secure\/gw\/devices\/suspendreconnect\/save_suspend\",\"reconnectOptionsApiUrl\":\"\/digital\/nsa\/secure\/gw\/devices\/suspendreconnect\/reconnect_options\",\"saveReconnectApiUrl\":\"\/digital\/nsa\/secure\/gw\/devices\/suspendreconnect\/save_reconnect\",\"updateReconnectIntentApiUrl\":\"\/digital\/nsa\/secure\/gw\/devices\/suspendreconnect\/update_reconnect_intent\",\"uiLogging\":\"\/digital\/nsa\/nos\/gw\/devices\/suspendreconnect\/clickstream\",\"clickStreamLogging\":\"\/digital\/nsa\/secure\/gw\/devices\/suspendreconnect\/clickstream\",\"suspendFAQsApiUrl\":\"\/support\/spot\/?tag=pause-service-faqs\u0026count=4\u0026intcmp=vzwdom\",\"reconnectFAQsApiUrl\":\"\/support\/spot\/?tag=resume-service-faqs\u0026count=4\u0026intcmp=vzwdom\",\"aemContentApiUrl\":\"\/digital\/nsa\/secure\/gw\/devices\/suspendreconnect\/refresh_aem_content\",\"testApiUrl\":\"\/digital\/nsa\/secure\/gw\/devices\/disconnect\/landing\",\"disconnectLandingApiUrl\":\"\/digital\/nsa\/secure\/gw\/devices\/disconnect\/landing\",\"reviewApiUrl\":\"\/digital\/nsa\/secure\/gw\/devices\/disconnect\/review\",\"cancelReviewApiUrl\":\"\/digital\/nsa\/secure\/gw\/devices\/disconnect\/cancel_review\",\"offerDetailsApiUrl\":\"\/digital\/nsa\/secure\/gw\/devices\/disconnect\/offer_details\",\"offerSelectionApiUrl\":\"\/digital\/nsa\/secure\/gw\/devices\/disconnect\/offer_selection\",\"saveDisconnectApiUrl\":\"\/digital\/nsa\/secure\/gw\/devices\/disconnect\/save_disconnect\",\"mvoLimitedAccessUrl\":\"https:\/\/vzwqa3.verizonwireless.com\/ui\/acct\/unauthorized#\/landing\",\"myVzPage\":\"\",\"suspendLanding\":\"\/digital\/nsa\/secure\/ui\/devices\/suspendreconnect\/#\/\",\"disconnectLanding\":\"\/digital\/nsa\/secure\/ui\/devices\/disconnect\/#\/\",\"zipValidationApiUrl\":\"\/digital\/nsa\/secure\/gw\/devices\/suspendreconnect\/zipcode_validation\",\"validateDeploymentApiUrl\":\"\/digital\/nsa\/secure\/gw\/devices\/suspendreconnect\/validate_deployment\",\"idmeCodeValidationApiUrl\":\"\/digital\/nsa\/secure\/gw\/devices\/suspendreconnect\/idme_code_validation\",\"idMeDenyApiUrl\":\"\/digital\/nsa\/secure\/gw\/devices\/suspendreconnect\/idme_deny\",\"idMeAuthorizationUrl\":\"https:\/\/api.id.me\/oauth\/authorize?client_id=1c69dce1a5bb5c695d7c1b8e43daa811\u0026redirect_uri=https:\/\/vzwqa3.verizonwireless.com\/digital\/nsa\/secure\/ui\/devices\/suspendreconnect\/validate\u0026response_type=code\u0026scope=military_suspend\",\"fiveGBadge\":\"https:\/\/ss7.vzw.com\/is\/image\/VerizonWireless\/5g-logo-d-072822?$pngalpha$\u0026scl=2\",\"cdmaUpgradeUrl\":\"https:\/\/vzwqa3.verizonwireless.com\/shop\/online\/phone-upgrade\/\",\"proActiveNotificationUrl\":\"\/digital\/nsa\/secure\/gw\/devices\/proactive\/notification\",\"callNetworkOutage\":\"true\",\"callProActiveNotifications\":\"true\",\"callRecommendations\":\"true\",\"enableUILogging\":\"true\",\"enableClickStream\":\"true\"}");
    beforeEach(async () => {
        getHttpClientRequest.mockImplementation((url) => {
            return Promise.resolve({ status: 200, data: { ...deviceDetail } });
        });

        await act(async () => render(
            <Provider store={store}>
                <PersistGate loading={null} persistor={persistor}>
                    <DeviceDetail />
                </PersistGate>
            </Provider>
        ));

    })

    test("it should mount", () => {
        const doc = screen.getByTestId("DeviceDetailTestId");
        expect(doc).toBeInTheDocument();
    });

    test("deviceListTestId test", () => {
        jest.setTimeout('10000');
        fireEvent.change(screen.getByTestId(`deviceListTestId`));
    })
    test("showAllDeviceTestId test", () => {
        jest.setTimeout('10000');
        fireEvent.click(screen.getByTestId(`showAllDeviceTestId`));
    })
    // test("editNickNameTestId test", () => {
    //     jest.setTimeout('10000');
    //     fireEvent.click(screen.getByTestId(`editNickNameTestId`));
    // })
    // test("returnAndUpgradeBtnTestId test", () => {
    //     jest.setTimeout('10000');
    //     fireEvent.click(screen.getByTestId(`returnAndUpgradeBtnTestId`));
    // })
    test("payOffDeviceBtnNotPromoDevTestId test", () => {
        jest.setTimeout('10000');
        fireEvent.click(screen.getByTestId(`payOffDeviceBtnNotPromoDevTestId`));
    })
    test("managePlanBtnTestId test", () => {
        jest.setTimeout('10000');
        fireEvent.click(screen.getByTestId(`managePlanBtnTestId`));
    })
    test("reviewUsageBtnTestId test", () => {
        jest.setTimeout('10000');
        fireEvent.click(screen.getByTestId(`reviewUsageBtnTestId`));
    })
    test("reviewDetailLinkTestId test", () => {
        jest.setTimeout('10000');
        fireEvent.click(screen.getByTestId(`reviewDetailLinkTestId`));
    })

    test("learnMoreTestId test", () => {
        jest.setTimeout('10000');
        fireEvent.click(screen.getByTestId(`learnMoreTestId`));
    })
});