import React from "react";
import "../../../../../config/jest/test-setup";
import { act, render, screen,  fireEvent } from "@testing-library/react";
import "@testing-library/jest-dom/extend-expect";
import { Provider } from "react-redux";
import { getHttpClientRequest } from '@vz/react-util';
import configureStore from "../../../../shared/store/configureStore";
import rootReducer from "../../reducers";
import { persistStore } from 'redux-persist';
import { PersistGate } from 'redux-persist/integration/react';
import DeviceDetail from "../components/index";
import { deviceDetail3 } from "./mockResponse";
import * as actions from "../../home/actions";
import {shallow, configure} from 'enzyme'
import Adapter from 'enzyme-adapter-react-16';

configure({ adapter: new Adapter() });

const store = configureStore(rootReducer);
const persistor = persistStore(store);

const dummyProps = {
  "match": {
    "path": "/",
    "url": "/",
    "isExact": true,
    "params": {
      "mtn": "85cvM9q9i1BikUE8vbkqLA%3D%3D"
    }
  }
}

const data = {
  "mtn": "4042259805",
  "displayMtn": "404-225-9805",
  "encryptedMtn": "85cvM9q9i1BikUE8vbkqLA%3D%3D",
  "nickName": "VZC/ NBX PLATFORM AND PROCESSE",
  "simId": "89148000009275893420",
  "encryptedSimId": "ZAEiJc%2B0MTkfbCHgJbPfZlyzd5UJxDmy",
  "simType": "ICC",
  "upgradeEligible": false,
  "userRole": "Non Registered",
  "device4G": false,
  "device5GE": false,
  "device5GA": false,
  "smartPhone": false,
  "basicPhone": false,
  "deviceId": "89148000009275893420",
  "paymentInfo": {
    "hasPayOffBalance": false,
    "promoDevice": false,
    "upgradeEligible": false
  },
  "preferences": {
    "shareNameIDBtn": true,
    "manageCallForwardingBtn": true,
    "blockSpecificServicesBtn": true,
    "blockCallsAndMessagesBtn": true,
    "manageCallFilterBtn": true,
    "manageVoicemailPasswordBtn": true,
    "backupContentToVerizonCloudBtn": true
  },
  "planUsageInfo": {
    "planName": "10GB"
  },
  "deviceManagement": {
    "tradeInBtn": true,
    "activateOrSwitchDeviceBtn": true,
    "upgradeDeviceBtn": true,
    "changeMobileNumberBtn": true,
    "transferYourServiceBtn": true,
    "manageConnectedDevicesBtn": false,
    "suspendOrReconnectServiceBtn": true,
    "numberLockBtn": true,
    "numberTransferPinBtn": true,
    "disconnectDeviceBtn": true,
    "pinandPersonalUnblockingKeyBtn": true,
    "manageNumberShareBtn": true,
    "checkNetworkCompatibiltyText": false,
    "viewAddOnsBtn": true
  },
  "troubleshootAndSupport": {
    "troubleshootBtn": true,
    "techCoachSupportBtn": true,
    "runHealthCheckBtn": false,
    "transferContentBetweenPhonesBtn": false,
    "launchSecurityDashboardBtn": false
  },
  "images": {},
  "displayDeviceCategory": "5G Internet",
  "esim": false,
  "psim": true,
  "router": true,
  "dynamicData": {
    "encMdn": "85cvM9q9i1BikUE8vbkqLA==",
    "nsaHost": "https://www.verizon.com"
  },
  "pendingLineChange": false,
  "deviceCategory": "connecteddevice",
  "mtnStatus": "A",
  "isMtnSuspended": false,
  "openEnrollmentPeriod": "Y",
  "deviceProtectionEnrolled": "N"
}

jest.mock('@vz/react-util', () => ({
  ...jest.requireActual('@vz/react-util'),
  getHttpClientRequest: jest.fn()
}));

describe("<DeviceDetail />", () => {
  window.VZTAG_IS_READY = 'true';
     global.dotcomConfig = JSON.parse("{\"reactStaticFilePath\":\"\/digital\/nsa\/nos\/devices\/dotcom\/\",\"statusApiUrl\":\"\/digital\/nsa\/secure\/ui\/devices\/suspendreconnect\/status\",\"landingApiUrl\":\"\/digital\/nsa\/secure\/gw\/devices\/suspendreconnect\/landing\",\"networkOutageUrl\":\"\/digital\/nsa\/secure\/gw\/devices\/notification\/network_outage\",\"pendingAcctChangesURL\":\"\/digital\/nsa\/secure\/ui\/acct\/pending-account\",\"pendingAcctChangesCancelOrder\":\"\/digital\/nsa\/secure\/gw\/acct\/pending-account\/pendingAccChangesCancelOrder\",\"pendingAccChanges\":\"\/digital\/nsa\/secure\/gw\/acct\/pending-account\/pendingAccChanges\",\"isPendingDisconnectLink\":\"true\",\"pendingAccChangesFilterByLine\":\"\",\"deviceDetailUrl\":\"\/digital\/nsa\/secure\/gw\/devices\/deviceDetail\",\"getTroubleshootUrl\":\"\/digital\/nsa\/secure\/gw\/troubleshooting\/get-recent-pending-case\",\"getPinAndPukApi\":\"\/digital\/nsa\/secure\/gw\/devices\/pinpuk_details\",\"deviceLandingPageUrl\":\"\/digital\/nsa\/secure\/gw\/devices\/landing\",\"updateNickNameUrl\":\"\/digital\/nsa\/secure\/gw\/devices\/updateNickName\",\"deviceLandingPageRecommendationUrl\":\"\/digital\/nsa\/secure\/gw\/devices\/recommdation\",\"suspendOptionsApiUrl\":\"\/digital\/nsa\/secure\/gw\/devices\/suspendreconnect\/suspend_options\",\"validateSuspendApiUrl\":\"\/digital\/nsa\/secure\/gw\/devices\/suspendreconnect\/validate_suspend\",\"militaryVerificationApiUrl\":\"\/digital\/nsa\/secure\/gw\/devices\/suspendreconnect\/military_verification\",\"saveSuspendApiUrl\":\"\/digital\/nsa\/secure\/gw\/devices\/suspendreconnect\/save_suspend\",\"reconnectOptionsApiUrl\":\"\/digital\/nsa\/secure\/gw\/devices\/suspendreconnect\/reconnect_options\",\"saveReconnectApiUrl\":\"\/digital\/nsa\/secure\/gw\/devices\/suspendreconnect\/save_reconnect\",\"updateReconnectIntentApiUrl\":\"\/digital\/nsa\/secure\/gw\/devices\/suspendreconnect\/update_reconnect_intent\",\"uiLogging\":\"\/digital\/nsa\/nos\/gw\/devices\/suspendreconnect\/clickstream\",\"clickStreamLogging\":\"\/digital\/nsa\/secure\/gw\/devices\/suspendreconnect\/clickstream\",\"suspendFAQsApiUrl\":\"\/support\/spot\/?tag=pause-service-faqs\u0026count=4\u0026intcmp=vzwdom\",\"reconnectFAQsApiUrl\":\"\/support\/spot\/?tag=resume-service-faqs\u0026count=4\u0026intcmp=vzwdom\",\"aemContentApiUrl\":\"\/digital\/nsa\/secure\/gw\/devices\/suspendreconnect\/refresh_aem_content\",\"testApiUrl\":\"\/digital\/nsa\/secure\/gw\/devices\/disconnect\/landing\",\"disconnectLandingApiUrl\":\"\/digital\/nsa\/secure\/gw\/devices\/disconnect\/landing\",\"reviewApiUrl\":\"\/digital\/nsa\/secure\/gw\/devices\/disconnect\/review\",\"cancelReviewApiUrl\":\"\/digital\/nsa\/secure\/gw\/devices\/disconnect\/cancel_review\",\"offerDetailsApiUrl\":\"\/digital\/nsa\/secure\/gw\/devices\/disconnect\/offer_details\",\"offerSelectionApiUrl\":\"\/digital\/nsa\/secure\/gw\/devices\/disconnect\/offer_selection\",\"saveDisconnectApiUrl\":\"\/digital\/nsa\/secure\/gw\/devices\/disconnect\/save_disconnect\",\"mvoLimitedAccessUrl\":\"https:\/\/vzwqa3.verizonwireless.com\/ui\/acct\/unauthorized#\/landing\",\"myVzPage\":\"\",\"suspendLanding\":\"\/digital\/nsa\/secure\/ui\/devices\/suspendreconnect\/#\/\",\"disconnectLanding\":\"\/digital\/nsa\/secure\/ui\/devices\/disconnect\/#\/\",\"zipValidationApiUrl\":\"\/digital\/nsa\/secure\/gw\/devices\/suspendreconnect\/zipcode_validation\",\"validateDeploymentApiUrl\":\"\/digital\/nsa\/secure\/gw\/devices\/suspendreconnect\/validate_deployment\",\"idmeCodeValidationApiUrl\":\"\/digital\/nsa\/secure\/gw\/devices\/suspendreconnect\/idme_code_validation\",\"idMeDenyApiUrl\":\"\/digital\/nsa\/secure\/gw\/devices\/suspendreconnect\/idme_deny\",\"idMeAuthorizationUrl\":\"https:\/\/api.id.me\/oauth\/authorize?client_id=1c69dce1a5bb5c695d7c1b8e43daa811\u0026redirect_uri=https:\/\/vzwqa3.verizonwireless.com\/digital\/nsa\/secure\/ui\/devices\/suspendreconnect\/validate\u0026response_type=code\u0026scope=military_suspend\",\"fiveGBadge\":\"https:\/\/ss7.vzw.com\/is\/image\/VerizonWireless\/5g-logo-d-072822?$pngalpha$\u0026scl=2\",\"cdmaUpgradeUrl\":\"https:\/\/vzwqa3.verizonwireless.com\/shop\/online\/phone-upgrade\/\",\"proActiveNotificationUrl\":\"\/digital\/nsa\/secure\/gw\/devices\/proactive\/notification\",\"callNetworkOutage\":\"true\",\"callProActiveNotifications\":\"true\",\"callRecommendations\":\"true\",\"enableUILogging\":\"true\",\"enableClickStream\":\"true\"}");
    let assignMock = jest.fn();

    delete window.location;
    window.location = { assign: assignMock };
  beforeEach(async () => {
    getHttpClientRequest.mockImplementation((url) => {
      return Promise.resolve({ status: 200, data: { ...deviceDetail3 } });
    });

    await act(async () => render(
      <Provider store={store}>
        <PersistGate loading={null} persistor={persistor}>
          <DeviceDetail {...dummyProps} />
        </PersistGate>
      </Provider>
    ));
    store.dispatch(actions.setSelectedDevice(data));
  })

  test("it should mount", () => {
    const doc = screen.getByTestId("DeviceDetailTestId");
    expect(doc).toBeInTheDocument();
  });
  test("deviceListTestId test", () => {
    jest.setTimeout('10000');
    fireEvent.change(screen.getByTestId(`deviceListTestId`));
    store.dispatch(actions.setSelectedDevice(data));
  })

  test("manageDeviceProtectionTestId test", () => {
    jest.setTimeout('10000');
    fireEvent.click(screen.getByTestId(`manageDeviceProtectionTestId`));
  })

  test("it should have radio option and clickable", () => {
    fireEvent.click(screen.getAllByText("right-arrow icon")[0]);
    expect(screen.getAllByText("right-arrow icon")[0]).toBeInTheDocument();
    fireEvent.click(screen.getAllByText("right-arrow icon")[1]);
    expect(screen.getAllByText("right-arrow icon")[1]).toBeInTheDocument();
    fireEvent.click(screen.getAllByText("right-arrow icon")[2]);
    expect(screen.getAllByText("right-arrow icon")[2]).toBeInTheDocument();
    fireEvent.click(screen.getAllByText("right-arrow icon")[9]);
    // expect(screen.getAllByText("right-arrow icon")[9]).toBeInTheDocument();
});

test("it should have radio option and clickable", () => {

  fireEvent.click(screen.getAllByText("right-arrow icon")[13]);
  expect(screen.getAllByText("right-arrow icon")[13]).toBeInTheDocument();
  fireEvent.click(screen.getAllByText("right-arrow icon")[14]);
  expect(screen.getAllByText("right-arrow icon")[14]).toBeInTheDocument();
  fireEvent.click(screen.getAllByText("right-arrow icon")[15]);
  expect(screen.getAllByText("right-arrow icon")[15]).toBeInTheDocument();
  fireEvent.click(screen.getAllByText("right-arrow icon")[16]);
  expect(screen.getAllByText("right-arrow icon")[16]).toBeInTheDocument();
  fireEvent.click(screen.getAllByText("right-arrow icon")[19]);
  expect(screen.getAllByText("right-arrow icon")[19]).toBeInTheDocument();
  fireEvent.click(screen.getAllByText("right-arrow icon")[20]);
  expect(screen.getAllByText("right-arrow icon")[20]).toBeInTheDocument();

})


});