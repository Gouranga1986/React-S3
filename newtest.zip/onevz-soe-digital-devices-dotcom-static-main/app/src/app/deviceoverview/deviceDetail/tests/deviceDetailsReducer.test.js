import deviceLandingReducer from "../reducers/index";

describe('deviceLandingReducer Reducer ', () => {
    it('deviceLandingReducer reducers',() => {
        let beginData ={isFetching:true}   
        let successData ="success";
        let errData ="error"
          
        //    expect(deviceLandingReducer({}, { type: "GET_DEVICE_DETAIL_BEGIN", value: beginData }).isFetching).toBe(true);
            // expect(deviceLandingReducer({}, { type: "GET_DEVICE_DETAIL_SUCCESS", msResp: successData }).sectionContentMetaData).toBe('success');
            // expect(deviceLandingReducer({}, { type: "GET_DEVICE_DETAIL_ERROR", msResp: errData }).errorObj).toBe('error');

     
            // expect(deviceLandingReducer({}, { type: "SET_NICK_NAME_BEGIN", value: beginData }).isUpdatingNickName).toBe(true);
            // expect(deviceLandingReducer({}, { type: "SET_NICK_NAME_SUCCESS", msResp: successData }).isNickNameUpdated).toBe(true);
            // expect(deviceLandingReducer({}, { type: "SET_NICK_NAME_ERROR", msResp: errData }).isNickNameError).toBe(true);

        
        })
});