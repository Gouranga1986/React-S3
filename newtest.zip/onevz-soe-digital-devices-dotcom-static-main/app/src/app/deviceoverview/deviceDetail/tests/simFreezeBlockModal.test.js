import React from "react";
import "../../../../../config/jest/test-setup";
import { act, render, screen, fireEvent } from "@testing-library/react";
import "@testing-library/jest-dom/extend-expect";
import { Provider } from "react-redux";
import configureStore, { history } from "../../../../shared/store/configureStore";
import rootReducer from "../../reducers";
import { persistStore } from 'redux-persist';
import { PersistGate } from 'redux-persist/integration/react';
import SimFreezeBlockModal from "../components/SimFreezeBlockModal";
import { deviceDetailInfoSection } from "./mockResponse";
import { getHttpClientRequest } from "@vz/react-util";


const store = configureStore(rootReducer);
const persistor = persistStore(store);
jest.mock("@vz/react-util", () => ({
    ...jest.requireActual("@vz/react-util"),
    getHttpClientRequest: jest.fn()
}));

jest.mock("../../../../shared/services/httpClient", () => ({
    ...jest.requireActual("../../../../shared/services/httpClient"),
    getHttpClientRequest: jest.fn()
}));


describe("<DeviceDetail />", () => {
    beforeEach(async () => {
        getHttpClientRequest.mockImplementation((url) => {
            return Promise.resolve({ status: 200, data: { ...deviceDetailInfoSection } });
        });
        await act(async () => render(
            <Provider store={store}>
                <PersistGate loading={null} persistor={persistor}>
                    <SimFreezeBlockModal handleModalChange={jest.fn()} showModal={false} handleCancel={jest.fn()} deviceDetailInfoSection={deviceDetailInfoSection}/>
                </PersistGate>
            </Provider>
        ));
    })

    test("it should mount SIMFreezePopup Modal", () => {
        const doc = screen.getByTestId("SIMFreezePopupTestId");
        expect(doc).toBeInTheDocument();
        screen.debug(undefined, Infinity);
    });
});