import React from "react";
import "../../../../../config/jest/test-setup";
import { act, render, screen, fireEvent } from "@testing-library/react";
import "@testing-library/jest-dom/extend-expect";
import { Provider } from "react-redux";
import { getHttpClientRequest } from '@vz/react-util';
import configureStore, { history } from "../../../../shared/store/configureStore";
import rootReducer from "../../reducers";
import { persistStore } from 'redux-persist';
import { PersistGate } from 'redux-persist/integration/react';
import DeviceDetail from "../components/index";
import { nosectionData, deviceDetail4 } from "./mockResponse";
import * as getOptionsAction from "../actions";

const store = configureStore(rootReducer);
const persistor = persistStore(store);

jest.mock('@vz/react-util', () => ({
    ...jest.requireActual('@vz/react-util'),
    getHttpClientRequest: jest.fn()
}));



describe("<DeviceDetail />", () => {
    beforeEach(async () => {
        getHttpClientRequest.mockImplementation((url) => {
            return Promise.resolve({ status: 200, data: { ...deviceDetail4 } });
        });

        await act(async () => render(
            <Provider store={store}>
                <PersistGate loading={null} persistor={persistor}>
                    <DeviceDetail />
                </PersistGate>
            </Provider>
        ));

    })

    test("it should mount", () => {
        const doc = screen.getByTestId("DeviceDetailTestId");
        expect(doc).toBeInTheDocument();
    });
    test("deviceListTestId test", () => {
        jest.setTimeout('10000');
        fireEvent.change(screen.getByTestId(`deviceListTestId`));
        store.dispatch(getOptionsAction.setSelectedDevice(nosectionData));
    })
});