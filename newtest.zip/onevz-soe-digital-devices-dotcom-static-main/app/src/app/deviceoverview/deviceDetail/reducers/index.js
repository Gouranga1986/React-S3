import {
  GET_DEVICE_DETAIL_BEGIN,
  GET_DEVICE_DETAIL_SUCCESS,
  GET_DEVICE_DETAIL_ERROR,
  SET_NICK_NAME_BEGIN,
  SET_NICK_NAME_SUCCESS,
  SET_NICK_NAME_ERROR,
  OPEN_NICK_NAME_MODAL,
  CLOSE_NICK_NAME_MODAL,
  SET_PIN_AND_PUK_BEGIN,
  SET_PIN_AND_PUK_SUCCESS,
  SET_PIN_AND_PUK_ERROR,
  OPEN_PIN_AND_PUK_MODAL,
  CLOSE_PIN_AND_PUK_MODAL,
  OPEN_PENDING_LINE_DETAIL_MODAL,
  CLOSE_PENDING_LINE_DETAIL_MODAL,
  GET_TROUBLESHOOT_BEGIN,
  GET_TROUBLESHOOT_SUCCESS,
  GET_TROUBLESHOOT_ERROR,
  GET_SMART_PHONE_DETAILS_SUCESS,
  GET_RECOMMENDED_DEVICE_BEGIN,
  GET_RECOMMENDED_DEVICE_SUCESS,
  GET_RECOMMENDED_DEVICE_ERROR,
  GET_RECOMMENDED_TILES_BEGIN,
  GET_RECOMMENDED_TILES_SUCESS,
  GET_RECOMMENDED_TILES_ERROR,
} from "../actions/getSections";

import {
  SET_SELECTED_DEVICE,
  IS_REDIRECTED_FROM_DETAIL_PAGE
} from "../actions/pageActions";

import { updateObject } from '../../../../shared/utilities/reducer';
import common from '../../../../shared/utilities/util';

const initialState = {
  isFetching: true,
  isOpenNickNameModal: false,
  isUpdatingNickName: false,
  statusCode: "",
  statusMessage: "",
  errorMessage: '',
  errorDesc: '',
  actionName: '',
  actionValue: '',
  actionType: '',
  errorObj: {},
  sectionContentMetaData: {},
  selectedDevice: {},
  isRedirectedFromDetailPage: false,
  isNickNameError: false,
  isNickNameUpdated: false,
  showPinAndPukModal: false,
  pinAndPukDetail: {},
  pinAndPukDetailError: false,
  isPendingLineChangeModalOpen: false,
  productList : {},
  recommendedDevice :[],
  recommendedTiles :[],
};

export const getDeviceDetailBegin = (state, action) => {
  return updateObject(state, {
    isRedirectedFromDetailPage: false,
    isFetching: true
  });
};

export const getDeviceDetailSuccess = (state, action) => {
  return updateObject(state, {
    isFetching: false,
    statusCode: action.msResp.responseInfo.responseCode,
    statusMessage: action.msResp.responseInfo.responseMessage,
    errorMessage: common.isError(action.msResp.responseInfo.responseCode, action.msResp.responseInfo.responseMessage, action.msResp.body),
    errorDesc: common.isErrorDesc(action.msResp.responseInfo.responseCode, action.msResp.responseInfo.responseMessage, action.msResp.body),
    actionName: common.isActionName(action.msResp.responseInfo.responseCode, action.msResp.responseInfo.responseMessage, action.msResp.body),
    actionValue: common.isActionValue(action.msResp.responseInfo.responseCode, action.msResp.responseInfo.responseMessage, action.msResp.body),
    actionType: common.isActionType(action.msResp.responseInfo.responseCode, action.msResp.responseInfo.responseMessage, action.msResp.body),
    errorObj: action.msResp.responseInfo.responseCode !== "00" && action.msResp.responseInfo ? action.msResp.responseInfo.sectionErrors : null,
    sectionContentMetaData: action.msResp.body,
    selectedDevice: {}
  });
};

export const getDeviceDetailError = (state, action) => {
  let msResp = action && action.err && action.err.response && action.err.response.data;
  let responseCode = msResp && msResp.responseInfo && msResp.responseInfo.responseCode;
  let responseMessage = msResp && msResp.responseInfo && msResp.responseInfo.responseMessage;
  let body = msResp && msResp.body;
  return updateObject(state, {
    isFetching: false,
    sectionContentMetaData: {},
    selectedDevice: {},
    statusCode: responseCode ? responseCode : '',
    statusMessage: common.isError(responseCode, responseMessage, body),
    errorMessage: common.isError(responseCode, responseMessage, body),
    errorDesc: common.isErrorDesc(responseCode, responseMessage, body),
    actionName: common.isActionName(responseCode, responseMessage, body),
    actionValue: common.isActionValue(responseCode, responseMessage, body),
    actionType: common.isActionType(responseCode, responseMessage, body),
    errorObj: responseCode !== "00" && msResp && msResp.responseInfo ? msResp.responseInfo.sectionErrors : action.err,
  });
};

export const openNickName = (state, action) => {
  return updateObject(state, {
    isOpenNickNameModal: true,
    isUpdatingNickName: false,
    isNickNameError: false
  });
};

export const closeNickName = (state, action) => {
  return updateObject(state, {
    isOpenNickNameModal: false,
    isUpdatingNickName: false,
    isNickNameError: false
  });
};

export const setNickNameBegin = (state, action) => {
  return updateObject(state, {
    isUpdatingNickName: true,
    isNickNameError: false,
    isNickNameUpdated: false
  });
};

export const setNickNameSuccess = (state, action) => {
  return updateObject(state, {
    isUpdatingNickName: false,
    isNickNameUpdated: action?.msResp?.body?.statusCode == "200" ? true : false,
    isOpenNickNameModal: action?.msResp?.body?.statusCode == "99" ? true : false,
    isNickNameError: action?.msResp?.body?.statusCode == "200" ? false : true
  });
};

export const setNickNameError = (state, action) => {
  return updateObject(state, {
    isUpdatingNickName: false,
    isNickNameError: true,
    isNickNameUpdated: false
  });
};

export const setSelectedDeviceValue = (state, action) => {
  return updateObject(state, {
    selectedDevice: action.data
  });
}

export const setHandleShowAllDevices = (state, action) => {
  return updateObject(state, {
    isRedirectedFromDetailPage: action.data,
    isNickNameUpdated: action.data ? true : false
  });
}

export const openPendingLineDetailModal = (state, action) => {
  return updateObject(state, {
    isPendingLineChangeModalOpen: true
  });
};

export const closePendingLineDetailModal = (state, action) => {
  return updateObject(state, {
    isPendingLineChangeModalOpen: false
  });
};

export const openPinAndPukModal = (state, action) => {
  return updateObject(state, {
    showPinAndPukModal: true
  });
};

export const closePinAndPukModal = (state, action) => {
  return updateObject(state, {
    showPinAndPukModal: false,
    pinAndPukDetail: {},
    pinAndPukDetailError: false
  });
};

export const getPinAndPukBegin = (state, action) => {
  return updateObject(state, {
    isFetching: true,
    showPinAndPukModal: false,
    pinAndPukDetail: {},
    pinAndPukDetailError: false
  });
};

export const getPinAndPukSuccess = (state, action) => {
  return updateObject(state, {
    isFetching: false,
    showPinAndPukModal: action.msResp?.responseInfo?.responseCode == "00" ? true : false,
    pinAndPukDetail: action?.msResp?.body,
    pinAndPukDetailError: action.msResp?.responseInfo?.responseCode == "00" ? false : true,
  });
};

export const getPinAndPukError = (state, action) => {
  return updateObject(state, {
    isFetching: false,
    showPinAndPukModal: false,
    pinAndPukDetail: {},
    pinAndPukDetailError: true
  });
};

export const getTroubleshootBegin = (state, action) => {
  return updateObject(state, {
    isFetching: true
  });
};

export const getTroubleshootSuccess = (state, action) => {
  let issueSelectorUrl = action?.msResp?.body?.issueSelectorUrl;
  if (issueSelectorUrl) {
    if (issueSelectorUrl.includes('http')) {
      window.location.href = issueSelectorUrl;
    } else {
      window.location.href = `https://${window.location.hostname}${issueSelectorUrl}`;
    }
  } else {
    if (action?.defaultUrl?.includes('http')) {
      window.location.href = action?.defaultUrl;
    } else {
      window.location.href = `https://${window.location.hostname}${action?.defaultUrl}`;
    }
  }
  return updateObject(state, {
    isFetching: false,
  });
};

export const getTroubleshootError = (state, action) => {
  return updateObject(state, {
    isFetching: false
  });
};

export const getSmartPhoneDetails = (state, action) => {
  return updateObject(state, {
   productList: action.msResp
  });
};
export const getRecommendDeviceBegin = (state, action) => {
  return updateObject(state, {
    isRedirectedFromDetailPage: false,
    isFetching: true
  });
};

export const getRecommendedDeviceSucess = (state, action) => {
  return updateObject(state, {
    isFetching: false,
    statusCode: action.msResp.responseInfo.responseCode,
    recommendedDevice: action.msResp.body,
  });
};

export const getRecommendTilesBegin = (state, action) => {
  return updateObject(state, {
    isRedirectedFromDetailPage: false,
    isFetching: false
  });
};

export const getRecommendedTilesSucess = (state, action) => {
  return updateObject(state, {
    isFetching: false,
    recommendedTiles: action.msResp,
  });
};

export const getRecommendedTilesError = (state, action) => {
  return updateObject(state, {
    isFetching: false,
    statusMessage: action.msResp,
  });
};

export const getRecommendedDeviceError = (state, action) => {
  let msResp = action && action.err && action.err.response && action.err.response.data;
  let responseCode = msResp && msResp.responseInfo && msResp.responseInfo.responseCode;
  let responseMessage = msResp && msResp.responseInfo && msResp.responseInfo.responseMessage;
  let body = msResp && msResp.body;
  return updateObject(state, {
    isFetching: false,
    recommendedDevice: [],
    statusCode: responseCode ? responseCode : '',
    statusMessage: common.isError(responseCode, responseMessage, body),
    errorMessage: common.isError(responseCode, responseMessage, body),
    errorDesc: common.isErrorDesc(responseCode, responseMessage, body),
    errorObj: responseCode !== "00" && msResp && msResp.responseInfo ? msResp.responseInfo.sectionErrors : action.err,
  });
};

const deviceLandingReducer = (state = initialState, action) => {
  const { type } = action;
  switch (type) {
    case GET_DEVICE_DETAIL_BEGIN:
      return getDeviceDetailBegin(state, action);
    case GET_DEVICE_DETAIL_SUCCESS:
      return getDeviceDetailSuccess(state, action);
    case GET_DEVICE_DETAIL_ERROR:
      return getDeviceDetailError(state, action);
    case OPEN_NICK_NAME_MODAL:
      return openNickName(state, action);
    case CLOSE_NICK_NAME_MODAL:
      return closeNickName(state, action);
    case SET_NICK_NAME_BEGIN:
      return setNickNameBegin(state, action);
    case SET_NICK_NAME_SUCCESS:
      return setNickNameSuccess(state, action);
    case SET_NICK_NAME_ERROR:
      return setNickNameError(state, action);
    case SET_SELECTED_DEVICE:
      return setSelectedDeviceValue(state, action);
    case IS_REDIRECTED_FROM_DETAIL_PAGE:
      return setHandleShowAllDevices(state, action);
    case OPEN_PIN_AND_PUK_MODAL:
      return openPinAndPukModal(state, action);
    case CLOSE_PIN_AND_PUK_MODAL:
      return closePinAndPukModal(state, action);
    case SET_PIN_AND_PUK_BEGIN:
      return getPinAndPukBegin(state, action);
    case SET_PIN_AND_PUK_SUCCESS:
      return getPinAndPukSuccess(state, action);
    case SET_PIN_AND_PUK_ERROR:
      return getPinAndPukError(state, action);
    case OPEN_PENDING_LINE_DETAIL_MODAL:
      return openPendingLineDetailModal(state, action);
    case CLOSE_PENDING_LINE_DETAIL_MODAL:
      return closePendingLineDetailModal(state, action);
    case GET_TROUBLESHOOT_BEGIN:
      return getTroubleshootBegin(state, action);
    case GET_TROUBLESHOOT_SUCCESS:
      return getTroubleshootSuccess(state, action);
    case GET_TROUBLESHOOT_ERROR:
      return getTroubleshootError(state, action);
    case GET_SMART_PHONE_DETAILS_SUCESS:
      return getSmartPhoneDetails(state, action);
    case GET_RECOMMENDED_DEVICE_BEGIN:
      return getRecommendDeviceBegin(state, action);
    case GET_RECOMMENDED_DEVICE_SUCESS:
      return getRecommendedDeviceSucess(state, action);
    case GET_RECOMMENDED_DEVICE_ERROR:
      return getRecommendedDeviceError(state, action);
    case GET_RECOMMENDED_TILES_BEGIN:
        return getRecommendTilesBegin(state, action);
    case GET_RECOMMENDED_TILES_SUCESS:
        return getRecommendedTilesSucess(state, action);
    case GET_RECOMMENDED_TILES_ERROR:
        return getRecommendedTilesError(state, action);
    default:
      return state;
  }
};

export default deviceLandingReducer;
