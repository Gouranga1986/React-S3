import Spy, {GlobalHistory, getHistory}  from './history'
import { render } from '@testing-library/react'
import { BrowserRouter as Router } from 'react-router-dom';
const props = {
    history:'GlobalHistory',

}
describe("checking", () => {
    test("testing Spy render", () => {
        const res = render(<Spy {...props}/>)
        expect(res).toBeDefined()
        expect(GlobalHistory).toBeTruthy()
     
    }
    )
})
describe("checking GlobalHistory render", () => {
    test("testing", () => {
        const res = render( <Router>  <GlobalHistory {...props}/></Router>)
        expect(res).toBeDefined();
        expect(GlobalHistory).toBeTruthy()
     
    }
    )
})