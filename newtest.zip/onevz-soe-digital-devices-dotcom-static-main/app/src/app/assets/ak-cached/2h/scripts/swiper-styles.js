export const SwipperCustomStyles = `
    .slider-control-centerleft {
        display: none;
    }

    .slider-control-centerright {
       display: none;
    }

    .slider-control-bottomcenter {
        display: flex;
        align-items: center;
        justify-content: space-evenly;
        min-width: 180px;
        width:60% !important;
        bottom: -10px !important;

        ul {
            .paging-item {
                margin: 0;
                padding: 0 3px;

                button {
                    padding: 0;
                    opacity: 1 !important;
                    outline: 0;
        
                    .paging-dot {
                        width: 24px !important;
                        height: 8px !important;
                        border-radius: 0 !important;
                        background-color: transparent !important;
                        position: relative;
            
                        &::after {
                            content: '';
                            position: absolute;
                            height: 1.5px;
                            width: 100%;
                            bottom: 0;
                            left: 0;
                            right: 0;
                            background-color: #333333;
                            transition: height 250ms, background-color 250ms;
                        }
                    
                    }
                    }

                    &.active {
                    .paging-dot {
                        &::after {
                            height: 5px;
                            background-color: #000000;
                            transition: height 250ms, background-color 250ms;
                        }
                    }
                }
            }
        }

    }
`;

export const LlpSwipperCustomStyles = `
${SwipperCustomStyles}

    
      
`;
