
const DOMEvents = {
  MouseEvent: 'click',
  // Above ONLY the MouseEvent monitor and the "click" handler as been implemented

  // BELOW ARE ALL EVENT MONITORS & HANDLERS WHICH CAN BE CAPTURED.
  // --Simply add any monitor and its respective handler/s which you wish to capture to the above DOMEvents object
  /* UIEvent: "abort DOMActivate error load resize scroll select unload",
  ProgressEvent: "abort error load loadend loadstart progress progress timeout",
  Event: "abort afterprint beforeprint cached canplay canplaythrough change chargingchange chargingtimechange checking close dischargingtimechange DOMContentLoaded downloading durationchange emptied ended ended error error error error fullscreenchange fullscreenerror input invalid languagechange levelchange loadeddata loadedmetadata noupdate obsolete offline online open open orientationchange pause pointerlockchange pointerlockerror play playing ratechange readystatechange reset seeked seeking stalled submit success suspend timeupdate updateready visibilitychange volumechange waiting",
  AnimationEvent: "animationend animationiteration animationstart",
  AudioProcessingEvent: "audioprocess",
  BeforeUnloadEvent: "beforeunload",
  TimeEvent: "beginEvent endEvent repeatEvent",
  OtherEvent: "blocked complete upgradeneeded versionchange",
  FocusEvent: "blur DOMFocusIn  Unimplemented DOMFocusOut  Unimplemented focus focusin focusout",
  MouseEvent: "click contextmenu dblclick mousedown mouseenter mouseleave mousemove mouseout mouseover mouseup show",
  SensorEvent: "compassneedscalibration Unimplemented userproximity",
  OfflineAudioCompletionEvent: "complete",
  CompositionEvent: "compositionend compositionstart compositionupdate",
  ClipboardEvent: "copy cut paste",
  DeviceLightEvent: "devicelight",
  DeviceMotionEvent: "devicemotion",
  DeviceOrientationEvent: "deviceorientation",
  DeviceProximityEvent: "deviceproximity",
  MutationNameEvent: "DOMAttributeNameChanged DOMElementNameChanged",
  MutationEvent: "DOMAttrModified DOMCharacterDataModified DOMNodeInserted DOMNodeInsertedIntoDocument DOMNodeRemoved DOMNodeRemovedFromDocument DOMSubtreeModified",
  DragEvent: "drag dragend dragenter dragleave dragover dragstart drop",
  GamepadEvent: "gamepadconnected gamepaddisconnected",
  HashChangeEvent: "hashchange",
  KeyboardEvent: "keydown keypress keyup",
  MessageEvent: "message message message message",
  PageTransitionEvent: "pagehide pageshow",
  PopStateEvent: "popstate",
  StorageEvent: "storage",
  SVGEvent: "SVGAbort SVGError SVGLoad SVGResize SVGScroll SVGUnload",
  SVGZoomEvent: "SVGZoom",
  TouchEvent: "touchcancel touchend touchenter touchleave touchmove touchstart",
  TransitionEvent: "transitionend",
  WheelEvent: "wheel" */
};

const RecentlyLoggedDOMEventTypes = {};

for (DOMEvent in DOMEvents) {
  const DOMEventTypes = DOMEvents[DOMEvent].split(' ');

  DOMEventTypes.filter((DOMEventType) => {
    const DOMEventCategory = DOMEvent + '.' + DOMEventType;
    document.addEventListener(DOMEventType, (e) => {
      if (RecentlyLoggedDOMEventTypes[DOMEventCategory]) return;
      RecentlyLoggedDOMEventTypes[DOMEventCategory] = true;
      setTimeout(() => { RecentlyLoggedDOMEventTypes[DOMEventCategory] = false; }, 5000);
      let clickstream = '';
      let DOMSource = '';
      if (e.target.dataset && e.target.dataset.clickstream) {
        clickstream = e.target.dataset.clickstream;
        DOMSource = e.target.id ? e.target.id : e.target.name ? e.target.name : e.target.localName + '.' + e.target.className;
      } else if (e.target.parentNode && e.target.parentNode.dataset && e.target.parentNode.dataset.clickstream) {
        clickstream = e.target.parentNode.dataset.clickstream;
        DOMSource = e.target.parentNode.id ? e.target.parentNode.id : e.target.parentNode.name ? e.target.parentNode.name : e.target.parentNode.localName + '.' + e.target.parentNode.className;
      } else if (e.target.offsetParent && e.target.offsetParent.dataset && e.target.offsetParent.dataset.clickstream) {
        clickstream = e.target.offsetParent.dataset.clickstream;
        DOMSource = e.target.offsetParent.id ? e.target.offsetParent.id : e.target.offsetParent.name ? e.target.offsetParent.name : e.target.offsetParent.localName + '.' + e.target.offsetParent.className;
      } else if (e.target.nextSibling && e.target.nextSibling.dataset && e.target.nextSibling.dataset.clickstream) {
        clickstream = e.target.nextSibling.dataset.clickstream;
        DOMSource = e.target.nextSibling.id ? e.target.nextSibling.id : e.target.nextSibling.name ? e.target.nextSibling.name : e.target.nextSibling.localName + '.' + e.target.nextSibling.className;
      } else if (e.target.nextSibling && e.target.nextSibling.nextSibling && e.target.nextSibling.nextSibling.dataset && e.target.nextSibling.nextSibling.dataset.clickstream) {
        clickstream = e.target.nextSibling.nextSibling.dataset.clickstream;
        DOMSource = e.target.nextSibling.nextSibling.id ? e.target.nextSibling.nextSibling.id : e.target.nextSibling.nextSibling.name
          ? e.target.nextSibling.nextSibling.name : e.target.nextSibling.nextSibling.localName + '.' + e.target.nextSibling.nextSibling.className;
      } else {
        clickstream = 'CS Not Found'; // clicking outside
        DOMSource = e.target.id ? e.target.id : e.target.name ? e.target.name : e.target.localName + '.' + e.target.className;
        if (e.target.className && e.target.className.toString().indexOf('tab') > -1) {
          clickstream = e.target.children[0].children[0].dataset.clickstream;
          DOMSource = e.target.children[0].children[0].id ? e.target.children[0].children[0].id : e.target.children[0].children[0].name
            ? e.target.children[0].children[0].name : e.target.children[0].children[0].localName + '.' + e.target.children[0].children[0].className;
        }

        if (e.target.textContent === 'Sign Out' || e.target.innerText === 'Sign Out') {
          sessionStorage.clear();
        }
      }

      if (clickstream && clickstream != 'CS Not Found') ULC.logClickStream(DOMSource, DOMEventCategory, clickstream);
    }, true);
  });
}
