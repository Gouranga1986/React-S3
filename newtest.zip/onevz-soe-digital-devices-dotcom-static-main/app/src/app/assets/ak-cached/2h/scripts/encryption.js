// (c) Copyright 2018 Micro Focus or one of its affiliates.
const SDW = {}; SDW.base10 = '0123456789'; SDW.base62 = '0123456789ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz'; SDW.luhn = function (a) { let e = a.length - 1; let b = 0; while (e >= 0) { b += parseInt(a.substr(e, 1), 10); e -= 2; }e = a.length - 2; while (e >= 0) { const c = 2 * parseInt(a.substr(e, 1), 10); if (c < 10) { b += c; } else { b += c - 9; }e -= 2; } return b % 10; }; SDW.fixluhn = function (b, d, c) {
  let a = SDW.luhn(b); if (a < c) { a += 10 - c; } else { a -= c; } if (a != 0) { if ((b.length - d) % 2 != 0) { a = 10 - a; } else if (a % 2 == 0) { a = 5 - (a / 2); } else { a = (9 - a) / 2 + 5; } return b.substr(0, d) + a + b.substr(d + 1); } return b;
}; SDW.distill = function (b) { let c = ''; for (let a = 0; a < b.length; ++a) { if (SDW.base10.indexOf(b.charAt(a)) >= 0) { c += b.substr(a, 1); } } return c; }; SDW.reformat = function (d, c) { let e = ''; let a = 0; for (let b = 0; b < c.length; ++b) { if (a < d.length && SDW.base10.indexOf(c.charAt(b)) >= 0) { e += d.substr(a, 1); ++a; } else { e += c.substr(b, 1); } } return e; }; SDW.integrity = function (a, e, c) {
  const b = String.fromCharCode(0) + String.fromCharCode(e.length) + e + String.fromCharCode(0) + String.fromCharCode(c.length) + c; const d = AES.HexToWords(a); d[3] ^= 1; const f = new sjcl.cipher.aes(d);
  const g = CMAC.compute(f, b); return AES.WordToHex(g[0]) + AES.WordToHex(g[1]);
}; function ProtectPANandCVV(t, o, k) {
  const l = SDW.distill(t); const r = SDW.distill(o); if (l.length < 13 || l.length > 19 || r.length > 4 || r.length == 1 || r.length == 2) { return null; } const g = l.substr(0, PIE.L) + l.substring(l.length - PIE.E); if (k == true) {
    const p = SDW.luhn(l); var j = l.substring(PIE.L + 1, l.length - PIE.E); var f = FFX.encrypt(j + r, g, PIE.K, 10); const b = l.substr(0, PIE.L) + '0' + f.substr(0, f.length - r.length) + l.substring(l.length - PIE.E); var s = SDW.reformat(SDW.fixluhn(b, PIE.L, p), t);
    var q = SDW.reformat(f.substring(f.length - r.length), o); return [s, q, SDW.integrity(PIE.K, s, q)];
  } if (SDW.luhn(l) != 0) { return null; } var j = l.substring(PIE.L + 1, l.length - PIE.E); const v = 23 - PIE.L - PIE.E; const h = j + r; const u = Math.floor((v * Math.log(62) - 34 * Math.log(2)) / Math.log(10)) - h.length - 1; const x = '11111111111111111111111111111'.substr(0, u) + (2 * r.length); var f = '1' + FFX.encrypt(x + h, g, PIE.K, 10); const e = parseInt(PIE.key_id, 16); const a = new Array(f.length); let w; for (w = 0; w < f.length; ++w) { a[w] = parseInt(f.substr(w, 1), 10); } const d = FFX.convertRadix(a, f.length, 10, v, 62);
  FFX.bnMultiply(d, 62, 131072); FFX.bnMultiply(d, 62, 65536); FFX.bnAdd(d, 62, e); if (PIE.phase == 1) { FFX.bnAdd(d, 62, 4294967296); } let c = ''; for (w = 0; w < v; ++w) { c += SDW.base62.substr(d[w], 1); } var s = l.substr(0, PIE.L) + c.substr(0, v - 4) + l.substring(l.length - PIE.E); var q = c.substring(v - 4); return [s, q, SDW.integrity(PIE.K, s, q)];
} function ValidatePANChecksum(b) { const a = SDW.distill(b); return (a.length >= 13 && a.length <= 19 && SDW.luhn(a) == 0); } function ProtectString(g, h) {
  const f = SDW_UTF8.encode(g); if (f.length < 2 || f.length > 256) { return null; } let b;
  if (h == null) { b = ''; } else { b = SDW_UTF8.encode(h); if (b.length > 256) { return null; } } const c = AES.HexToWords(PIE.K); c[3] ^= 2; const e = new sjcl.cipher.aes(c); const a = FFX.encryptWithCipher(f, b, e, 256); const d = SDW_Base64.encode(a); return [d];
}'use strict'; var sjcl = {
  cipher: {},
  hash: {},
  mode: {},
  misc: {},
  codec: {},
  exception: {
    corrupt(a) { this.toString = function () { return 'CORRUPT: ' + this.message; }; this.message = a; },
    invalid(a) { this.toString = function () { return 'INVALID: ' + this.message; }; this.message = a; },
    bug(a) {
      this.toString = function () {
        return 'BUG: ' + this.message;
      }; this.message = a;
    },
  },
}; sjcl.cipher.aes = function (h) {
  if (!this._tables[0][0][0]) { this._precompute(); } let d; let c; let e; let g; let l; const f = this._tables[0][4]; const k = this._tables[1]; const a = h.length; let b = 1; if (a !== 4 && a !== 6 && a !== 8) { throw new sjcl.exception.invalid('invalid aes key size'); } this._key = [g = h.slice(0), l = []]; for (d = a; d < 4 * a + 28; d++) { e = g[d - 1]; if (d % a === 0 || (a === 8 && d % a === 4)) { e = f[e >>> 24] << 24 ^ f[e >> 16 & 255] << 16 ^ f[e >> 8 & 255] << 8 ^ f[e & 255]; if (d % a === 0) { e = e << 8 ^ e >>> 24 ^ b << 24; b = b << 1 ^ (b >> 7) * 283; } }g[d] = g[d - a] ^ e; } for (c = 0; d; c++, d--) {
    e = g[c & 3 ? d : d - 4]; if (d <= 4 || c < 4) {
      l[c] = e;
    } else { l[c] = k[0][f[e >>> 24]] ^ k[1][f[e >> 16 & 255]] ^ k[2][f[e >> 8 & 255]] ^ k[3][f[e & 255]]; }
  }
}; sjcl.cipher.aes.prototype = {
  encrypt(a) { return this._crypt(a, 0); },
  decrypt(a) { return this._crypt(a, 1); },
  _tables: [[[], [], [], [], []], [[], [], [], [], []]],
  _precompute() {
    const j = this._tables[0]; const q = this._tables[1]; const h = j[4]; const n = q[4]; let g; let l; let f; const k = []; const c = []; let b; let p; let m; let o; let e; let a; for (g = 0; g < 256; g++) { c[(k[g] = g << 1 ^ (g >> 7) * 283) ^ g] = g; } for (l = f = 0; !h[l]; l ^= (b == 0) ? 1 : b, f = (c[f] == 0) ? 1 : c[f]) {
      o = f ^ f << 1 ^ f << 2 ^ f << 3 ^ f << 4; o = o >> 8 ^ o & 255 ^ 99; h[l] = o; n[o] = l;
      m = k[p = k[b = k[l]]]; a = m * 16843009 ^ p * 65537 ^ b * 257 ^ l * 16843008; e = k[o] * 257 ^ o * 16843008; for (g = 0; g < 4; g++) { j[g][l] = e = e << 24 ^ e >>> 8; q[g][o] = a = a << 24 ^ a >>> 8; }
    } for (g = 0; g < 5; g++) { j[g] = j[g].slice(0); q[g] = q[g].slice(0); }
  },
  _crypt(k, n) {
    if (k.length !== 4) { throw new sjcl.exception.invalid('invalid aes block size'); } const y = this._key[n]; let v = k[0] ^ y[0]; let u = k[n ? 3 : 1] ^ y[1]; let t = k[2] ^ y[2]; let s = k[n ? 1 : 3] ^ y[3]; let w; let e; let m; const x = y.length / 4 - 2; let p; let o = 4; const q = [0, 0, 0, 0]; const r = this._tables[n]; const j = r[0]; const h = r[1]; const g = r[2]; const f = r[3]; const l = r[4]; for (p = 0; p < x; p++) {
      w = j[v >>> 24] ^ h[u >> 16 & 255] ^ g[t >> 8 & 255] ^ f[s & 255] ^ y[o];
      e = j[u >>> 24] ^ h[t >> 16 & 255] ^ g[s >> 8 & 255] ^ f[v & 255] ^ y[o + 1]; m = j[t >>> 24] ^ h[s >> 16 & 255] ^ g[v >> 8 & 255] ^ f[u & 255] ^ y[o + 2]; s = j[s >>> 24] ^ h[v >> 16 & 255] ^ g[u >> 8 & 255] ^ f[t & 255] ^ y[o + 3]; o += 4; v = w; u = e; t = m;
    } for (p = 0; p < 4; p++) { q[n ? 3 & -p : p] = l[v >>> 24] << 24 ^ l[u >> 16 & 255] << 16 ^ l[t >> 8 & 255] << 8 ^ l[s & 255] ^ y[o++]; w = v; v = u; u = t; t = s; s = w; } return q;
  },
}; var AES = {}; AES.HexToKey = function (a) { return new sjcl.cipher.aes(AES.HexToWords(a)); }; AES.HexToWords = function (a) {
  const d = 4; const c = new Array(d); if (a.length != d * 8) { return null; } for (let b = 0; b < d; b++) {
    c[b] = parseInt(a.substr(b * 8, 8), 16);
  } return c;
}; AES.Hex = '0123456789abcdef'; AES.WordToHex = function (a) { let c = 32; let b = ''; while (c > 0) { c -= 4; b += AES.Hex.substr((a >>> c) & 15, 1); } return b; }; var SDW_Base64 = {
  _chars: 'ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789-_',
  encode(d) {
    let b = 0; let e = ''; let f; let a; while (b < d.length) {
      f = d.charCodeAt(b) & 255; e += SDW_Base64._chars.charAt(f >> 2); a = (f & 3) << 4; if (++b < d.length) { f = d.charCodeAt(b) & 255; a |= f >> 4; }e += SDW_Base64._chars.charAt(a); if (b >= d.length) { break; }a = (f & 15) << 2; if (++b < d.length) {
        f = d.charCodeAt(b) & 255;
        a |= f >> 6;
      }e += SDW_Base64._chars.charAt(a); if (b >= d.length) { break; }e += SDW_Base64._chars.charAt(f & 63); ++b;
    } return e;
  },
}; var SDW_UTF8 = { encode(b) { let d = ''; let a = 0; while (a < b.length) { const e = b.charCodeAt(a); if (e < 128) { d += String.fromCharCode(e); } else if (e >= 2048) { d += String.fromCharCode((e >> 12) | 224) + String.fromCharCode(((e >> 6) & 63) | 128) + String.fromCharCode((e & 63) | 128); } else { d += String.fromCharCode((e >> 6) | 192) + String.fromCharCode((e & 63) | 128); }++a; } return d; } }; var CMAC = {}; CMAC.MSBnotZero = function (a) {
  if ((a | 2147483647) == 2147483647) {
    return false;
  } return true;
}; CMAC.leftShift = function (b) { b[0] = ((b[0] & 2147483647) << 1) | (b[1] >>> 31); b[1] = ((b[1] & 2147483647) << 1) | (b[2] >>> 31); b[2] = ((b[2] & 2147483647) << 1) | (b[3] >>> 31); b[3] = ((b[3] & 2147483647) << 1); }; CMAC.const_Rb = 135; CMAC.compute = function (a, d) {
  let f = [0, 0, 0, 0]; const b = a.encrypt(f); let c = b[0]; CMAC.leftShift(b); if (CMAC.MSBnotZero(c)) { b[3] ^= CMAC.const_Rb; } let e = 0; while (e < d.length) { f[(e >> 2) & 3] ^= (d.charCodeAt(e) & 255) << (8 * (3 - (e & 3))); ++e; if ((e & 15) == 0 && e < d.length) { f = a.encrypt(f); } } if (e == 0 || (e & 15) != 0) {
    c = b[0]; CMAC.leftShift(b);
    if (CMAC.MSBnotZero(c)) { b[3] ^= CMAC.const_Rb; }f[(e >> 2) & 3] ^= 128 << (8 * (3 - (e & 3)));
  }f[0] ^= b[0]; f[1] ^= b[1]; f[2] ^= b[2]; f[3] ^= b[3]; return a.encrypt(f);
}; function CMAC_AES128(b, a) { return CMAC.compute(AES.HexToKey(b), a); } var FFX = {}; FFX.alphabet = ['0', '1', '2', '3', '4', '5', '6', '7', '8', '9', 'A', 'B', 'C', 'D', 'E', 'F', 'G', 'H', 'I', 'J', 'K', 'L', 'M', 'N', 'O', 'P', 'Q', 'R', 'S', 'T', 'U', 'V', 'W', 'X', 'Y', 'Z']; FFX.precompF = function (a, h, g, e) {
  const d = 4; const f = new Array(d); const c = g.length; const b = 10; f[0] = 16908544 | ((e >> 16) & 255); f[1] = (((e >> 8) & 255) << 24) | ((e & 255) << 16) | (b << 8) | (Math.floor(h / 2) & 255);
  f[2] = h; f[3] = c; return a.encrypt(f);
}; FFX.precompb = function (c, g) { let e = Math.ceil(g / 2); let a = 0; let d = 1; while (e > 0) { d *= c; --e; if (d >= 256) { d /= 256; ++a; } } if (d > 1) { ++a; } return a; }; FFX.bnMultiply = function (b, d, g) { let c; let e = 0; for (c = b.length - 1; c >= 0; --c) { const f = b[c] * g + e; b[c] = f % d; e = (f - b[c]) / d; } }; FFX.bnAdd = function (b, d, g) { let c = b.length - 1; let e = g; while (c >= 0 && e > 0) { const f = b[c] + e; b[c] = f % d; e = (f - b[c]) / d; --c; } }; FFX.convertRadix = function (f, g, e, d, h) {
  const a = new Array(d); let c; for (c = 0; c < d; ++c) { a[c] = 0; } for (let b = 0; b < g; ++b) {
    FFX.bnMultiply(a, h, e);
    FFX.bnAdd(a, h, f[b]);
  } return a;
}; FFX.cbcmacq = function (e, f, b, a) { const d = 4; let h = new Array(d); for (var c = 0; c < d; ++c) { h[c] = e[c]; } let g = 0; while (4 * g < b) { for (var c = 0; c < d; ++c) { h[c] = h[c] ^ ((f[4 * (g + c)] << 24) | (f[4 * (g + c) + 1] << 16) | (f[4 * (g + c) + 2] << 8) | f[4 * (g + c) + 3]); }h = a.encrypt(h); g += d; } return h; }; FFX.F = function (c, u, w, o, g, x, a, l, v) {
  const m = 16; const t = Math.ceil(v / 4) + 1; let p = (w.length + v + 1) & 15; if (p > 0) { p = 16 - p; } const k = new Array(w.length + p + v + 1); let s; for (s = 0; s < w.length; s++) { k[s] = w.charCodeAt(s); } for (;s < p + w.length; s++) { k[s] = 0; }k[k.length - v - 1] = u;
  const h = FFX.convertRadix(o, g, l, v, 256); for (let q = 0; q < v; q++) { k[k.length - v + q] = h[q]; } const e = FFX.cbcmacq(a, k, k.length, c); let n = e; let r; const f = new Array(2 * t); for (s = 0; s < t; ++s) { if (s > 0 && (s & 3) == 0) { r = s >> 2; n = c.encrypt([e[0], e[1], e[2], e[3] ^ r]); }f[2 * s] = n[s & 3] >>> 16; f[2 * s + 1] = n[s & 3] & 65535; } return FFX.convertRadix(f, 2 * t, 65536, x, l);
}; FFX.DigitToVal = function (c, a, e) {
  const f = new Array(a); if (e == 256) { for (let b = 0; b < a; b++) { f[b] = c.charCodeAt(b); } return f; } for (let d = 0; d < a; d++) {
    const g = parseInt(c.charAt(d), e); if ((g == isNaN) || !(g < e)) {
      return '';
    }f[d] = g;
  } return f;
}; FFX.ValToDigit = function (d, c) { let a = ''; let b; if (c == 256) { for (b = 0; b < d.length; b++) { a += String.fromCharCode(d[b]); } } else { for (b = 0; b < d.length; b++) { a += FFX.alphabet[d[b]]; } } return a; }; FFX.encryptWithCipher = function (d, m, p, s) {
  const f = d.length; const g = Math.floor(f / 2); const a = 5; const t = FFX.precompF(p, f, m, s); const q = FFX.precompb(s, f); const e = FFX.DigitToVal(d, g, s); const c = FFX.DigitToVal(d.substr(g), (f - g), s); if ((e == '') || (c == '')) { return ''; } for (let k = 0; k < a; k++) {
    var v; var u = FFX.F(p, k * 2, m, c, c.length, e.length, t, s, q); v = 0;
    for (var h = e.length - 1; h >= 0; --h) { var o = e[h] + u[h] + v; if (o < s) { e[h] = o; v = 0; } else { e[h] = o - s; v = 1; } } var u = FFX.F(p, (k * 2) + 1, m, e, e.length, c.length, t, s, q); v = 0; for (var h = c.length - 1; h >= 0; --h) { var o = c[h] + u[h] + v; if (o < s) { c[h] = o; v = 0; } else { c[h] = o - s; v = 1; } }
  } return FFX.ValToDigit(e, s) + FFX.ValToDigit(c, s);
}; FFX.encrypt = function (d, e, b, c) { const a = AES.HexToKey(b); if (a == null) { return ''; } return FFX.encryptWithCipher(d, e, a, c); };
