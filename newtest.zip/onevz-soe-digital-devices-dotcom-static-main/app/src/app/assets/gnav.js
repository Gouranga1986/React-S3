"use strict";
var _typeof = "function" == typeof Symbol && "symbol" == typeof Symbol.iterator ? function(e) {
    return typeof e
}
: function(e) {
    return e && "function" == typeof Symbol && e.constructor === Symbol && e !== Symbol.prototype ? "symbol" : typeof e
}
;
/*!
 * @overview es6-promise - a tiny implementation of Promises/A+.
 * @copyright Copyright (c) 2014 Yehuda Katz, Tom Dale, Stefan Penner and contributors (Conversion to ES6 API by Jake Archibald)
 * @license   Licensed under MIT license
 *            See https://raw.githubusercontent.com/stefanpenner/es6-promise/master/LICENSE
 * @version   4.1.0+f046478d
 */
/*!
 * @overview es6-promise - a tiny implementation of Promises/A+.
 * @copyright Copyright (c) 2014 Yehuda Katz, Tom Dale, Stefan Penner and contributors (Conversion to ES6 API by Jake Archibald)
 * @license   Licensed under MIT license
 *            See https://raw.githubusercontent.com/stefanpenner/es6-promise/master/LICENSE
 * @version   4.1.0+f046478d
 */
!function() {
    var e = arguments.length > 0 && void 0 !== arguments[0] ? arguments[0] : window
      , t = arguments[1];
    "object" === ("undefined" == typeof exports ? "undefined" : _typeof(exports)) && "undefined" != typeof module ? module.exports = t() : "function" == typeof define && define.amd ? define(t) : e.ES6Promise = t()
}(void 0, function() {
    function e(e) {
        return "function" == typeof e
    }
    var t = Array.isArray ? Array.isArray : function(e) {
        return "[object Array]" === Object.prototype.toString.call(e)
    }
      , n = 0
      , a = void 0
      , o = void 0
      , r = function(e, t) {
        d[n] = e,
        d[n + 1] = t,
        2 === (n += 2) && (o ? o(p) : b())
    };
    var s = "undefined" != typeof window ? window : void 0
      , i = s || {}
      , l = i.MutationObserver || i.WebKitMutationObserver
      , c = "undefined" == typeof self && "undefined" != typeof process && "[object process]" === {}.toString.call(process)
      , u = "undefined" != typeof Uint8ClampedArray && "undefined" != typeof importScripts && "undefined" != typeof MessageChannel;
    function h() {
        var e = setTimeout;
        return function() {
            return e(p, 1)
        }
    }
    var d = new Array(1e3);
    function p() {
        for (var e = 0; e < n; e += 2) {
            (0,
            d[e])(d[e + 1]),
            d[e] = void 0,
            d[e + 1] = void 0
        }
        n = 0
    }
    var m, g, v, f, b = void 0;
    function w(e, t) {
        var n = arguments
          , a = this
          , o = new this.constructor(k);
        void 0 === o[_] && F(o);
        var s, i = a._state;
        return i ? (s = n[i - 1],
        r(function() {
            return A(i, o, s, a._result)
        })) : E(a, o, e, t),
        o
    }
    function y(e) {
        if (e && "object" === (void 0 === e ? "undefined" : _typeof(e)) && e.constructor === this)
            return e;
        var t = new this(k);
        return L(t, e),
        t
    }
    c ? b = function() {
        return process.nextTick(p)
    }
    : l ? (g = 0,
    v = new l(p),
    f = document.createTextNode(""),
    v.observe(f, {
        characterData: !0
    }),
    b = function() {
        f.data = g = ++g % 2
    }
    ) : u ? ((m = new MessageChannel).port1.onmessage = p,
    b = function() {
        return m.port2.postMessage(0)
    }
    ) : b = void 0 === s && "function" == typeof require ? function() {
        try {
            var e = require("vertx");
            return void 0 !== (a = e.runOnLoop || e.runOnContext) ? function() {
                a(p)
            }
            : h()
        } catch (e) {
            return h()
        }
    }() : h();
    var _ = Math.random().toString(36).substring(16);
    function k() {}
    var S = void 0
      , C = 1
      , N = 2
      , R = new P;
    function O(e) {
        try {
            return e.then
        } catch (e) {
            return R.error = e,
            R
        }
    }
    function T(t, n, a) {
        var o, s, i, l;
        n.constructor === t.constructor && a === w && n.constructor.resolve === y ? (i = t,
        (l = n)._state === C ? x(i, l._result) : l._state === N ? D(i, l._result) : E(l, void 0, function(e) {
            return L(i, e)
        }, function(e) {
            return D(i, e)
        })) : a === R ? (D(t, R.error),
        R.error = null) : void 0 === a ? x(t, n) : e(a) ? (o = n,
        s = a,
        r(function(e) {
            var t = !1
              , n = function(e, t, n, a) {
                try {
                    e.call(t, n, a)
                } catch (e) {
                    return e
                }
            }(s, o, function(n) {
                t || (t = !0,
                o !== n ? L(e, n) : x(e, n))
            }, function(n) {
                t || (t = !0,
                D(e, n))
            }, e._label);
            !t && n && (t = !0,
            D(e, n))
        }, t)) : x(t, n)
    }
    function L(e, t) {
        var n, a;
        e === t ? D(e, new TypeError("You cannot resolve a promise with itself")) : (a = void 0 === (n = t) ? "undefined" : _typeof(n),
        null === n || "object" !== a && "function" !== a ? x(e, t) : T(e, t, O(t)))
    }
    function M(e) {
        e._onerror && e._onerror(e._result),
        U(e)
    }
    function x(e, t) {
        e._state === S && (e._result = t,
        e._state = C,
        0 !== e._subscribers.length && r(U, e))
    }
    function D(e, t) {
        e._state === S && (e._state = N,
        e._result = t,
        r(M, e))
    }
    function E(e, t, n, a) {
        var o = e._subscribers
          , s = o.length;
        e._onerror = null,
        o[s] = t,
        o[s + C] = n,
        o[s + N] = a,
        0 === s && e._state && r(U, e)
    }
    function U(e) {
        var t = e._subscribers
          , n = e._state;
        if (0 !== t.length) {
            for (var a = void 0, o = void 0, r = e._result, s = 0; s < t.length; s += 3)
                a = t[s],
                o = t[s + n],
                a ? A(n, a, o, r) : o(r);
            e._subscribers.length = 0
        }
    }
    function P() {
        this.error = null
    }
    var z = new P;
    function A(t, n, a, o) {
        var r = e(a)
          , s = void 0
          , i = void 0
          , l = void 0
          , c = void 0;
        if (r) {
            if ((s = function(e, t) {
                try {
                    return e(t)
                } catch (e) {
                    return z.error = e,
                    z
                }
            }(a, o)) === z ? (c = !0,
            i = s.error,
            s.error = null) : l = !0,
            n === s)
                return void D(n, new TypeError("A promises callback cannot return that same promise."))
        } else
            s = o,
            l = !0;
        n._state !== S || (r && l ? L(n, s) : c ? D(n, i) : t === C ? x(n, s) : t === N && D(n, s))
    }
    var I = 0;
    function F(e) {
        e[_] = I++,
        e._state = void 0,
        e._result = void 0,
        e._subscribers = []
    }
    function j(e, n) {
        this._instanceConstructor = e,
        this.promise = new e(k),
        this.promise[_] || F(this.promise),
        t(n) ? (this.length = n.length,
        this._remaining = n.length,
        this._result = new Array(this.length),
        0 === this.length ? x(this.promise, this._result) : (this.length = this.length || 0,
        this._enumerate(n),
        0 === this._remaining && x(this.promise, this._result))) : D(this.promise, new Error("Array Methods must be provided an Array"))
    }
    function B(e) {
        this[_] = I++,
        this._result = this._state = void 0,
        this._subscribers = [],
        k !== e && ("function" != typeof e && function() {
            throw new TypeError("You must pass a resolver function as the first argument to the promise constructor")
        }(),
        this instanceof B ? function(e, t) {
            try {
                t(function(t) {
                    L(e, t)
                }, function(t) {
                    D(e, t)
                })
            } catch (t) {
                D(e, t)
            }
        }(this, e) : function() {
            throw new TypeError("Failed to construct 'Promise': Please use the 'new' operator, this object constructor cannot be called as a function.")
        }())
    }
    return j.prototype._enumerate = function(e) {
        for (var t = 0; this._state === S && t < e.length; t++)
            this._eachEntry(e[t], t)
    }
    ,
    j.prototype._eachEntry = function(e, t) {
        var n = this._instanceConstructor
          , a = n.resolve;
        if (a === y) {
            var o = O(e);
            if (o === w && e._state !== S)
                this._settledAt(e._state, t, e._result);
            else if ("function" != typeof o)
                this._remaining--,
                this._result[t] = e;
            else if (n === B) {
                var r = new n(k);
                T(r, e, o),
                this._willSettleAt(r, t)
            } else
                this._willSettleAt(new n(function(t) {
                    return t(e)
                }
                ), t)
        } else
            this._willSettleAt(a(e), t)
    }
    ,
    j.prototype._settledAt = function(e, t, n) {
        var a = this.promise;
        a._state === S && (this._remaining--,
        e === N ? D(a, n) : this._result[t] = n),
        0 === this._remaining && x(a, this._result)
    }
    ,
    j.prototype._willSettleAt = function(e, t) {
        var n = this;
        E(e, void 0, function(e) {
            return n._settledAt(C, t, e)
        }, function(e) {
            return n._settledAt(N, t, e)
        })
    }
    ,
    B.all = function(e) {
        return new j(this,e).promise
    }
    ,
    B.race = function(e) {
        var n = this;
        return t(e) ? new n(function(t, a) {
            for (var o = e.length, r = 0; r < o; r++)
                n.resolve(e[r]).then(t, a)
        }
        ) : new n(function(e, t) {
            return t(new TypeError("You must pass an array to race."))
        }
        )
    }
    ,
    B.resolve = y,
    B.reject = function(e) {
        var t = new this(k);
        return D(t, e),
        t
    }
    ,
    B._setScheduler = function(e) {
        o = e
    }
    ,
    B._setAsap = function(e) {
        r = e
    }
    ,
    B._asap = r,
    B.prototype = {
        constructor: B,
        then: w,
        catch: function(e) {
            return this.then(null, e)
        }
    },
    B.polyfill = function() {
        var e = void 0;
        if ("undefined" != typeof global)
            e = global;
        else if ("undefined" != typeof self)
            e = self;
        else
            try {
                e = Function("return this")()
            } catch (e) {
                throw new Error("polyfill failed because global object is unavailable in this environment")
            }
        var t = e.Promise;
        if (t) {
            var n = null;
            try {
                n = Object.prototype.toString.call(t.resolve())
            } catch (e) {}
            if ("[object Promise]" === n && !t.cast)
                return
        }
        e.Promise = B
    }
    ,
    B.Promise = B,
    B
});
_typeof = "function" == typeof Symbol && "symbol" == typeof Symbol.iterator ? function(e) {
    return typeof e
}
: function(e) {
    return e && "function" == typeof Symbol && e.constructor === Symbol && e !== Symbol.prototype ? "symbol" : typeof e
}
;
!function() {
    function e(e, t) {
        var n, a, o, r, s = k;
        for (r = arguments.length; r-- > 2; )
            _.push(arguments[r]);
        for (t && null != t.children && (_.length || _.push(t.children),
        delete t.children); _.length; )
            if ((a = _.pop()) && void 0 !== a.pop)
                for (r = a.length; r--; )
                    _.push(a[r]);
            else
                "boolean" == typeof a && (a = null),
                (o = "function" != typeof e) && (null == a ? a = "" : "number" == typeof a ? a += "" : "string" != typeof a && (o = !1)),
                o && n ? s[s.length - 1] += a : s === k ? s = [a] : s.push(a),
                n = o;
        var i = new function() {}
        ;
        return i.nodeName = e,
        i.children = s,
        i.attributes = null == t ? void 0 : t,
        i.key = null == t ? void 0 : t.key,
        void 0 !== y.vnode && y.vnode(i),
        i
    }
    function t(e, t) {
        for (var n in t)
            e[n] = t[n];
        return e
    }
    function n(e) {
        !e.__d && (e.__d = !0) && 1 == N.push(e) && (y.debounceRendering || S)(a)
    }
    function a() {
        var e, t = N;
        for (N = []; e = t.pop(); )
            e.__d && f(e)
    }
    function o(e, t) {
        return e.__n === t || e.nodeName.toLowerCase() === t.toLowerCase()
    }
    function r(e) {
        var n = t({}, e.attributes);
        n.children = e.children;
        var a = e.nodeName.defaultProps;
        if (void 0 !== a)
            for (var o in a)
                void 0 === n[o] && (n[o] = a[o]);
        return n
    }
    function s(e) {
        var t = e.parentNode;
        t && t.removeChild(e)
    }
    function i(e, t, n, a, o) {
        if ("className" === t && (t = "class"),
        "key" === t)
            ;
        else if ("ref" === t)
            n && n(null),
            a && a(e);
        else if ("class" !== t || o)
            if ("style" === t) {
                if (a && "string" != typeof a && "string" != typeof n || (e.style.cssText = a || ""),
                a && "object" == (void 0 === a ? "undefined" : _typeof(a))) {
                    if ("string" != typeof n)
                        for (var r in n)
                            r in a || (e.style[r] = "");
                    for (var r in a)
                        e.style[r] = "number" == typeof a[r] && !1 === C.test(r) ? a[r] + "px" : a[r]
                }
            } else if ("dangerouslySetInnerHTML" === t)
                a && (e.innerHTML = a.__html || "");
            else if ("o" == t[0] && "n" == t[1]) {
                var s = t !== (t = t.replace(/Capture$/, ""));
                t = t.toLowerCase().substring(2),
                a ? n || e.addEventListener(t, l, s) : e.removeEventListener(t, l, s),
                (e.__l || (e.__l = {}))[t] = a
            } else if ("list" !== t && "type" !== t && !o && t in e)
                (function(e, t, n) {
                    try {
                        e[t] = n
                    } catch (e) {}
                }
                )(e, t, null == a ? "" : a),
                null != a && !1 !== a || e.removeAttribute(t);
            else {
                var i = o && t !== (t = t.replace(/^xlink\:?/, ""));
                null == a || !1 === a ? i ? e.removeAttributeNS("http://www.w3.org/1999/xlink", t.toLowerCase()) : e.removeAttribute(t) : "function" != typeof a && (i ? e.setAttributeNS("http://www.w3.org/1999/xlink", t.toLowerCase(), a) : e.setAttribute(t, a))
            }
        else
            e.className = a || ""
    }
    function l(e) {
        return this.__l[e.type](y.event && y.event(e) || e)
    }
    function c() {
        for (var e; e = R.pop(); )
            y.afterMount && y.afterMount(e),
            e.componentDidMount && e.componentDidMount()
    }
    function u(e, t, n, a, o, r) {
        O++ || (T = null != o && void 0 !== o.ownerSVGElement,
        L = null != e && !("__preactattr_"in e));
        var s = h(e, t, n, a, r);
        return o && s.parentNode !== o && o.appendChild(s),
        --O || (L = !1,
        r || c()),
        s
    }
    function h(e, t, n, a, l) {
        var c = e
          , u = T;
        if (null != t && "boolean" != typeof t || (t = ""),
        "string" == typeof t || "number" == typeof t)
            return e && void 0 !== e.splitText && e.parentNode && (!e._component || l) ? e.nodeValue != t && (e.nodeValue = t) : (c = document.createTextNode(t),
            e && (e.parentNode && e.parentNode.replaceChild(c, e),
            d(e, !0))),
            c.__preactattr_ = !0,
            c;
        var p, g, f = t.nodeName;
        if ("function" == typeof f)
            return function(e, t, n, a) {
                var o = e && e._component
                  , s = o
                  , i = e
                  , l = o && e._componentConstructor === t.nodeName
                  , c = l
                  , u = r(t);
                for (; o && !c && (o = o.__u); )
                    c = o.constructor === t.nodeName;
                return o && c && (!a || o._component) ? (v(o, u, 3, n, a),
                e = o.base) : (s && !l && (b(s),
                e = i = null),
                o = m(t.nodeName, u, n),
                e && !o.__b && (o.__b = e,
                i = null),
                v(o, u, 1, n, a),
                e = o.base,
                i && e !== i && (i._component = null,
                d(i, !1))),
                e
            }(e, t, n, a);
        if (T = "svg" === f || "foreignObject" !== f && T,
        f += "",
        (!e || !o(e, f)) && (p = f,
        (g = T ? document.createElementNS("http://www.w3.org/2000/svg", p) : document.createElement(p)).__n = p,
        c = g,
        e)) {
            for (; e.firstChild; )
                c.appendChild(e.firstChild);
            e.parentNode && e.parentNode.replaceChild(c, e),
            d(e, !0)
        }
        var w = c.firstChild
          , y = c.__preactattr_
          , _ = t.children;
        if (null == y) {
            y = c.__preactattr_ = {};
            for (var k = c.attributes, S = k.length; S--; )
                y[k[S].name] = k[S].value
        }
        return !L && _ && 1 === _.length && "string" == typeof _[0] && null != w && void 0 !== w.splitText && null == w.nextSibling ? w.nodeValue != _[0] && (w.nodeValue = _[0]) : (_ && _.length || null != w) && function(e, t, n, a, r) {
            var i, l, c, u, p, m = e.childNodes, g = [], v = {}, f = 0, b = 0, w = m.length, y = 0, _ = t ? t.length : 0;
            if (0 !== w)
                for (var k = 0; k < w; k++) {
                    var S = m[k]
                      , C = S.__preactattr_
                      , N = _ && C ? S._component ? S._component.__k : C.key : null;
                    null != N ? (f++,
                    v[N] = S) : (C || (void 0 !== S.splitText ? !r || S.nodeValue.trim() : r)) && (g[y++] = S)
                }
            if (0 !== _)
                for (var k = 0; k < _; k++) {
                    u = t[k],
                    p = null;
                    var N = u.key;
                    if (null != N)
                        f && void 0 !== v[N] && (p = v[N],
                        v[N] = void 0,
                        f--);
                    else if (!p && b < y)
                        for (i = b; i < y; i++)
                            if (void 0 !== g[i] && (R = l = g[i],
                            T = r,
                            "string" == typeof (O = u) || "number" == typeof O ? void 0 !== R.splitText : "string" == typeof O.nodeName ? !R._componentConstructor && o(R, O.nodeName) : T || R._componentConstructor === O.nodeName)) {
                                p = l,
                                g[i] = void 0,
                                i === y - 1 && y--,
                                i === b && b++;
                                break
                            }
                    p = h(p, u, n, a),
                    c = m[k],
                    p && p !== e && p !== c && (null == c ? e.appendChild(p) : p === c.nextSibling ? s(c) : e.insertBefore(p, c))
                }
            var R, O, T;
            if (f)
                for (var k in v)
                    void 0 !== v[k] && d(v[k], !1);
            for (; b <= y; )
                void 0 !== (p = g[y--]) && d(p, !1)
        }(c, _, n, a, L || null != y.dangerouslySetInnerHTML),
        function(e, t, n) {
            var a;
            for (a in n)
                t && null != t[a] || null == n[a] || i(e, a, n[a], n[a] = void 0, T);
            for (a in t)
                "children" === a || "innerHTML" === a || a in n && t[a] === ("value" === a || "checked" === a ? e[a] : n[a]) || i(e, a, n[a], n[a] = t[a], T)
        }(c, t.attributes, y),
        T = u,
        c
    }
    function d(e, t) {
        var n = e._component;
        n ? b(n) : (null != e.__preactattr_ && e.__preactattr_.ref && e.__preactattr_.ref(null),
        !1 !== t && null != e.__preactattr_ || s(e),
        p(e))
    }
    function p(e) {
        for (e = e.lastChild; e; ) {
            var t = e.previousSibling;
            d(e, !0),
            e = t
        }
    }
    function m(e, t, n) {
        var a, o = M[e.name];
        if (e.prototype && e.prototype.render ? (a = new e(t,n),
        w.call(a, t, n)) : ((a = new w(t,n)).constructor = e,
        a.render = g),
        o)
            for (var r = o.length; r--; )
                if (o[r].constructor === e) {
                    a.__b = o[r].__b,
                    o.splice(r, 1);
                    break
                }
        return a
    }
    function g(e, t, n) {
        return this.constructor(e, n)
    }
    function v(e, t, a, o, r) {
        e.__x || (e.__x = !0,
        (e.__r = t.ref) && delete t.ref,
        (e.__k = t.key) && delete t.key,
        !e.base || r ? e.componentWillMount && e.componentWillMount() : e.componentWillReceiveProps && e.componentWillReceiveProps(t, o),
        o && o !== e.context && (e.__c || (e.__c = e.context),
        e.context = o),
        e.__p || (e.__p = e.props),
        e.props = t,
        e.__x = !1,
        0 !== a && (1 !== a && !1 === y.syncComponentUpdates && e.base ? n(e) : f(e, 1, r)),
        e.__r && e.__r(e))
    }
    function f(e, n, a, o) {
        if (!e.__x) {
            var s, i, l, h = e.props, p = e.state, g = e.context, w = e.__p || h, _ = e.__s || p, k = e.__c || g, S = e.base, C = e.__b, N = S || C, T = e._component, L = !1;
            if (S && (e.props = w,
            e.state = _,
            e.context = k,
            2 !== n && e.shouldComponentUpdate && !1 === e.shouldComponentUpdate(h, p, g) ? L = !0 : e.componentWillUpdate && e.componentWillUpdate(h, p, g),
            e.props = h,
            e.state = p,
            e.context = g),
            e.__p = e.__s = e.__c = e.__b = null,
            e.__d = !1,
            !L) {
                s = e.render(h, p, g),
                e.getChildContext && (g = t(t({}, g), e.getChildContext()));
                var M, x, D = s && s.nodeName;
                if ("function" == typeof D) {
                    var E = r(s);
                    (i = T) && i.constructor === D && E.key == i.__k ? v(i, E, 1, g, !1) : (M = i,
                    e._component = i = m(D, E, g),
                    i.__b = i.__b || C,
                    i.__u = e,
                    v(i, E, 0, g, !1),
                    f(i, 1, a, !0)),
                    x = i.base
                } else
                    l = N,
                    (M = T) && (l = e._component = null),
                    (N || 1 === n) && (l && (l._component = null),
                    x = u(l, s, g, a || !S, N && N.parentNode, !0));
                if (N && x !== N && i !== T) {
                    var U = N.parentNode;
                    U && x !== U && (U.replaceChild(x, N),
                    M || (N._component = null,
                    d(N, !1)))
                }
                if (M && b(M),
                e.base = x,
                x && !o) {
                    for (var P = e, z = e; z = z.__u; )
                        (P = z).base = x;
                    x._component = P,
                    x._componentConstructor = P.constructor
                }
            }
            if (!S || a ? R.unshift(e) : L || (e.componentDidUpdate && e.componentDidUpdate(w, _, k),
            y.afterUpdate && y.afterUpdate(e)),
            null != e.__h)
                for (; e.__h.length; )
                    e.__h.pop().call(e);
            O || o || c()
        }
    }
    function b(e) {
        y.beforeUnmount && y.beforeUnmount(e);
        var t = e.base;
        e.__x = !0,
        e.componentWillUnmount && e.componentWillUnmount(),
        e.base = null;
        var n, a, o = e._component;
        o ? b(o) : t && (t.__preactattr_ && t.__preactattr_.ref && t.__preactattr_.ref(null),
        e.__b = t,
        s(t),
        a = (n = e).constructor.name,
        (M[a] || (M[a] = [])).push(n),
        p(t)),
        e.__r && e.__r(null)
    }
    function w(e, t) {
        this.__d = !0,
        this.context = t,
        this.props = e,
        this.state = this.state || {}
    }
    var y = {}
      , _ = []
      , k = []
      , S = "function" == typeof Promise ? Promise.resolve().then.bind(Promise.resolve()) : setTimeout
      , C = /acit|ex(?:s|g|n|p|$)|rph|ows|mnc|ntw|ine[ch]|zoo|^ord/i
      , N = []
      , R = []
      , O = 0
      , T = !1
      , L = !1
      , M = {};
    t(w.prototype, {
        setState: function(e, a) {
            var o = this.state;
            this.__s || (this.__s = t({}, o)),
            t(o, "function" == typeof e ? e(o, this.props) : e),
            a && (this.__h = this.__h || []).push(a),
            n(this)
        },
        forceUpdate: function(e) {
            e && (this.__h = this.__h || []).push(e),
            f(this, 2)
        },
        render: function() {}
    });
    var x = {
        h: e,
        createElement: e,
        cloneElement: function(n, a) {
            return e(n.nodeName, t(t({}, n.attributes), a), arguments.length > 2 ? [].slice.call(arguments, 2) : n.children)
        },
        Component: w,
        render: function(e, t, n) {
            return u(n, e, {}, !1, t, !1)
        },
        rerender: a,
        options: y
    };
    "undefined" != typeof module ? module.exports = x : self.preact = x
}();
var gnav = {};
"https://testman.verizonwireless.com" === window.location.origin ? (gnav.HEADER_JSON_URL_BIZ = "https://stcache.vzw.com/ui-one-digital/global-header/business.globalheader.json",
gnav.FOOTER_JSON_URL_BIZ = "https://stcache.vzw.com/ui-one-digital/global-footer/business.globalfooter.json",
gnav.HEADER_JSON_URL_CUSTOMER = "https://stcache.vzw.com/ui-one-digital/global-header/customer.globalheader.json",
gnav.FOOTER_JSON_URL_CUSTOMER = "https://stcache.vzw.com/ui-one-digital/global-footer/customer.globalfooter.json",
gnav.HEADER_JSON_URL_PROSPECT = "https://stcache.vzw.com/ui-one-digital/global-header/prospect.globalheader.json",
gnav.FOOTER_JSON_URL_PROSPECT = "https://stcache.vzw.com/ui-one-digital/global-footer/prospect.globalfooter.json",
gnav.SIGNOUT_URL = "https://tlogin.verizonwireless.com/amserver/UI/Logout?next=" + encodeURI(location.href)) : "https://www.verizonwireless.com" === window.location.origin || "https://es.verizonwireless.com" === window.location.origin ? (gnav.HEADER_JSON_URL_BIZ = "https://scache.vzw.com/ui-one-digital/global-header/business.globalheader.json",
gnav.FOOTER_JSON_URL_BIZ = "https://scache.vzw.com/ui-one-digital/global-footer/business.globalfooter.json",
gnav.HEADER_JSON_URL_CUSTOMER = "https://scache.vzw.com/ui-one-digital/global-header/customer.globalheader.json",
gnav.FOOTER_JSON_URL_CUSTOMER = "https://scache.vzw.com/ui-one-digital/global-footer/customer.globalfooter.json",
gnav.HEADER_JSON_URL_PROSPECT = "https://scache.vzw.com/ui-one-digital/global-header/prospect.globalheader.json",
gnav.FOOTER_JSON_URL_PROSPECT = "https://scache.vzw.com/ui-one-digital/global-footer/prospect.globalfooter.json",
gnav.SIGNOUT_URL = "https://login.verizonwireless.com/amserver/UI/Logout?next=" + encodeURI(location.href)) : (gnav.HEADER_JSON_URL_BIZ = "/content/wcms/one-digital/global-header/business.globalheader.json",
gnav.FOOTER_JSON_URL_BIZ = "https://scache.vzw.com/ui-one-digital/global-footer/business.globalfooter.json",
gnav.HEADER_JSON_URL_CUSTOMER = "https://scache.vzw.com/ui-one-digital/global-header/customer.globalheader.json",
gnav.FOOTER_JSON_URL_CUSTOMER = "https://scache.vzw.com/ui-one-digital/global-footer/customer.globalfooter.json",
gnav.HEADER_JSON_URL_PROSPECT = "https://scache.vzw.com/ui-one-digital/global-header/prospect.globalheader.json",
gnav.FOOTER_JSON_URL_PROSPECT = "https://scache.vzw.com/ui-one-digital/global-footer/prospect.globalfooter.json",
gnav.SIGNOUT_URL = "/clp/login?redirect=/myv/nda/amLogoutRedirect.jsp&next=" + encodeURI(location.href)),
gnav.mobilecheck = function() {
    var e, t = !1;
    return e = navigator.userAgent || navigator.vendor || window.opera,
    (/(android|bb\d+|meego).+mobile|avantgo|bada\/|blackberry|blazer|compal|elaine|fennec|hiptop|iemobile|ip(hone|od)|iris|kindle|lge |maemo|midp|mmp|mobile.+firefox|netfront|opera m(ob|in)i|palm( os)?|phone|p(ixi|re)\/|plucker|pocket|psp|series(4|6)0|symbian|treo|up\.(browser|link)|vodafone|wap|windows ce|xda|xiino|android|ipad|playbook|silk/i.test(e) || /1207|6310|6590|3gso|4thp|50[1-6]i|770s|802s|a wa|abac|ac(er|oo|s\-)|ai(ko|rn)|al(av|ca|co)|amoi|an(ex|ny|yw)|aptu|ar(ch|go)|as(te|us)|attw|au(di|\-m|r |s )|avan|be(ck|ll|nq)|bi(lb|rd)|bl(ac|az)|br(e|v)w|bumb|bw\-(n|u)|c55\/|capi|ccwa|cdm\-|cell|chtm|cldc|cmd\-|co(mp|nd)|craw|da(it|ll|ng)|dbte|dc\-s|devi|dica|dmob|do(c|p)o|ds(12|\-d)|el(49|ai)|em(l2|ul)|er(ic|k0)|esl8|ez([4-7]0|os|wa|ze)|fetc|fly(\-|_)|g1 u|g560|gene|gf\-5|g\-mo|go(\.w|od)|gr(ad|un)|haie|hcit|hd\-(m|p|t)|hei\-|hi(pt|ta)|hp( i|ip)|hs\-c|ht(c(\-| |_|a|g|p|s|t)|tp)|hu(aw|tc)|i\-(20|go|ma)|i230|iac( |\-|\/)|ibro|idea|ig01|ikom|im1k|inno|ipaq|iris|ja(t|v)a|jbro|jemu|jigs|kddi|keji|kgt( |\/)|klon|kpt |kwc\-|kyo(c|k)|le(no|xi)|lg( g|\/(k|l|u)|50|54|\-[a-w])|libw|lynx|m1\-w|m3ga|m50\/|ma(te|ui|xo)|mc(01|21|ca)|m\-cr|me(rc|ri)|mi(o8|oa|ts)|mmef|mo(01|02|bi|de|do|t(\-| |o|v)|zz)|mt(50|p1|v )|mwbp|mywa|n10[0-2]|n20[2-3]|n30(0|2)|n50(0|2|5)|n7(0(0|1)|10)|ne((c|m)\-|on|tf|wf|wg|wt)|nok(6|i)|nzph|o2im|op(ti|wv)|oran|owg1|p800|pan(a|d|t)|pdxg|pg(13|\-([1-8]|c))|phil|pire|pl(ay|uc)|pn\-2|po(ck|rt|se)|prox|psio|pt\-g|qa\-a|qc(07|12|21|32|60|\-[2-7]|i\-)|qtek|r380|r600|raks|rim9|ro(ve|zo)|s55\/|sa(ge|ma|mm|ms|ny|va)|sc(01|h\-|oo|p\-)|sdk\/|se(c(\-|0|1)|47|mc|nd|ri)|sgh\-|shar|sie(\-|m)|sk\-0|sl(45|id)|sm(al|ar|b3|it|t5)|so(ft|ny)|sp(01|h\-|v\-|v )|sy(01|mb)|t2(18|50)|t6(00|10|18)|ta(gt|lk)|tcl\-|tdg\-|tel(i|m)|tim\-|t\-mo|to(pl|sh)|ts(70|m\-|m3|m5)|tx\-9|up(\.b|g1|si)|utst|v400|v750|veri|vi(rg|te)|vk(40|5[0-3]|\-v)|vm40|voda|vulc|vx(52|53|60|61|70|80|81|83|85|98)|w3c(\-| )|webc|whit|wi(g |nc|nw)|wmlb|wonu|x700|yas\-|your|zeto|zte\-/i.test(e.substr(0, 4))) && (t = !0),
    t
}
,
gnav.makeAjaxCall = function(e, t, n) {
    return new ES6Promise(function(a, o) {
        var r = new XMLHttpRequest;
        (r.open(t, e, !0),
        n && n.headers) && n.headers.map(function(e) {
            r.setRequestHeader(e.name, e.value)
        });
        if (n && n.postData)
            var s = n.postData;
        else
            s = n;
        r.send(s),
        r.onreadystatechange = function() {
            if (4 === r.readyState)
                if (200 === r.status) {
                    var e = r.responseText;
                    if (e)
                        try {
                            var t = JSON.parse(e);
                            a(t)
                        } catch (t) {
                            a(e)
                        }
                    else
                        o(r.status)
                } else
                    o(r.status)
        }
    }
    )
}
,
gnav.makeSearchCall = function(e, t, n, a) {
    return new ES6Promise(function(o, r) {
        var s = new XMLHttpRequest;
        s.open(t, e, !0),
        n.map(function(e) {
            s.setRequestHeader(e.name, e.value)
        }),
        s.send(a),
        s.onreadystatechange = function() {
            if (4 === s.readyState)
                if (200 === s.status) {
                    var e = s.responseText
                      , t = JSON.parse(e);
                    o(t)
                } else
                    r(s.status)
        }
    }
    )
}
,
gnav.createCookie = function(e, t, n) {
    var a = "";
    if (n) {
        var o = new Date;
        o.setTime(o.getTime() + 24 * n * 60 * 60 * 1e3),
        a = "; expires=" + o.toUTCString()
    }
    document.cookie = e + "=" + t + a + "; path=/"
}
,
gnav.eraseCookie = function(e) {
    gnav.createCookie(e, "", -1)
}
,
gnav.getCookie = function(e) {
    var t = " " + document.cookie
      , n = t.indexOf(" " + e + "=");
    if (-1 == n)
        t = null;
    else {
        n = t.indexOf("=", n) + 1;
        var a = t.indexOf(";", n);
        -1 == a && (a = t.length),
        t = unescape(t.substring(n, a))
    }
    return t
}
,
gnav.debounce = function(e, t, n) {
    var a;
    return function() {
        var o = this
          , r = arguments
          , s = n && !a;
        clearTimeout(a),
        a = setTimeout(function() {
            a = null,
            n || e.apply(o, r)
        }, t),
        s && e.apply(o, r)
    }
}
,
gnav.dom = function(e) {
    return document.querySelector(e)
}
,
gnav.calculateCartDifference = function(e, t) {
    var n = Date.UTC(e.getFullYear(), e.getMonth(), e.getDate())
      , a = Date.UTC(t.getFullYear(), t.getMonth(), t.getDate());
    return Math.floor((a - n) / 864e5)
}
,
gnav.createStorageFromCart = function() {
    var e = new Date;
    window.cartItemsJSON && window.cartItemsJSON.commerceJSON && (localStorage.setItem("commerceJSON", cartItemsJSON.commerceJSON),
    localStorage.setItem("commerceJSONDate", e))
}
,
gnav.paramVal = function(e) {
    var t = window.location.search + "&";
    if (-1 === t.indexOf(e))
        return null;
    var n = t.substr(t.indexOf(e));
    return n = n.substring(n.indexOf("=") + 1, n.indexOf("&"))
}
,
gnav.initGoogleSearch = function() {
    gnav.googleSearchInitialized = !0;
    var e = document.getElementById("googleSearchInput")
      , t = -1 !== location.host.indexOf("verizonwireless") ? "" : "https://www.verizonwireless.com";
    new google.maps.InfoWindow,
    document.getElementById("googleSearchContent");
    gnav.autocomplete = new google.maps.places.Autocomplete(e),
    gnav.autocomplete.setComponentRestrictions({
        country: ["us"]
    }),
    gnav.autocomplete.setTypes(["geocode"]),
    gnav.autocomplete.addListener("place_changed", function() {
        var e = gnav.autocomplete.getPlace();
        e.geometry ? location.href = t + "/stores/storesearchresults/?allow=1&lat=" + e.geometry.location.lat() + "&long=" + e.geometry.location.lng() + "&result=all&q=" + encodeURI(e.formatted_address) : 5 === e.name.length && parseInt(e.name) / parseInt(e.name) == 1 && (location.href = t + "/stores/interstetialpage/?q=" + e.name)
    })
}
,
gnav.loadGoogleScript = function() {
    if (window.google && window.google.maps)
        gnav.googleSearchInitialized || gnav.initGoogleSearch();
    else {
        var e = gnav.mobilecheck() ? "mobile" : "desktop"
          , t = document.createElement("script");
        t.type = "text/javascript",
        t.rel = "stylesheet",
        t.async = "true",
        t.src = "https://maps.googleapis.com/maps/api/js?client=gme-verizonwireless2&channel=vzw-" + e + "&libraries=places&callback=gnav.initGoogleSearch",
        (document.getElementsByTagName("head")[0] || document.getElementsByTagName("body")[0]).appendChild(t)
    }
}
,
gnav.scrollToBottom = function() {
    var e = document.body.scrollHeight
      , t = window.innerHeight
      , n = window.pageYOffset || document.documentElement.scrollTop;
    n < e - t && (window.scrollTo(0, n + 10),
    setTimeout(gnav.scrollToBottom, 0))
}
,
gnav.stateAbbrev = {
    al: "alabama",
    ak: "alaska",
    az: "arizona",
    ar: "arkansas",
    ca: "california",
    co: "colorado",
    ct: "connecticut",
    de: "delaware",
    dc: "district-of-columbia",
    fl: "florida",
    ga: "georgia",
    hi: "hawaii",
    id: "idaho",
    il: "illinois",
    in: "indiana",
    ia: "iowa",
    ks: "kansas",
    ky: "kentucky",
    la: "louisiana",
    me: "maine",
    md: "maryland",
    ma: "massachusetts",
    mi: "michigan",
    mn: "minnesota",
    ms: "mississippi",
    mo: "missouri",
    mt: "montana",
    ne: "nebraska",
    nv: "nevada",
    nh: "new-hampshire",
    nj: "new-jersey",
    nm: "new-mexico",
    ny: "new-york",
    nc: "north-carolina",
    nd: "north-dakota",
    oh: "ohio",
    ok: "oklahoma",
    or: "oregon",
    pa: "pennsylvania",
    ri: "rhode-island",
    sc: "south-carolina",
    sd: "south-dakota",
    tn: "tennessee",
    tx: "texas",
    ut: "utah",
    vt: "vermont",
    va: "virginia",
    wa: "washington",
    wv: "west-virginia",
    wi: "wisconsin",
    wy: "wyoming",
    statesArray: ["alabama", "alaska", "arizona", "arkansas", "california", "colorado", "connecticut", "delaware", "district of columbia", "florida", "georgia", "hawaii", "idaho", "illinois", "indiana", "iowa", "kansas", "kentucky", "louisiana", "maine", "maryland", "massachusetts", "michigan", "minnesota", "mississippi", "missouri", "montana", "nebraska", "nevada", "new hampshire", "new jersey", "new mexico", "new york", "north carolina", "north dakota", "ohio", "oklahoma", "oregon", "pennsylvania", "rhode island", "south carolina", "south dakota", "tennessee", "texas", "utah", "vermont", "virginia", "washington", "west virginia", "wisconsin", "wyoming"]
};
var MP = {
    Version: "1.0.23",
    Domains: {
        es: "es.verizonwireless.com"
    },
    SrcLang: "en",
    UrlLang: "mp_js_current_lang",
    SrcUrl: decodeURIComponent("mp_js_orgin_url"),
    init: function() {
        1 == MP.UrlLang.indexOf("p_js_") && (MP.SrcUrl = location.href,
        MP.UrlLang = MP.SrcLang)
    },
    getCookie: function(e) {
        var t = document.cookie.indexOf(e + "=");
        if (t < 0)
            return null;
        t = t + e.length + 1;
        var n = document.cookie.indexOf(";", t);
        for (n < 0 && (n = document.cookie.length); " " == document.cookie.charAt(t); )
            t++;
        return decodeURIComponent(document.cookie.substring(t, n))
    },
    setCookie: function(e, t, n, a) {
        var o = e + "=" + encodeURIComponent(t);
        n && (o += "; path=" + n),
        a && (o += "; domain=" + a);
        var r = new Date;
        r.setTime(r.getTime() + 31536e6),
        o += "; expires=" + r.toUTCString(),
        document.cookie = o
    },
    switchLanguage: function(e) {
        if (e != MP.SrcLang)
            (t = document.createElement("SCRIPT")).src = location.protocol + "//" + MP.Domains[e] + "/" + MP.SrcLang + e + "/?1023749632;" + encodeURIComponent(MP.SrcUrl),
            document.body.appendChild(t);
        else if (e == MP.SrcLang && MP.UrlLang != MP.SrcLang) {
            var t;
            (t = document.createElement("SCRIPT")).src = location.protocol + "//" + MP.Domains[MP.UrlLang] + "/" + MP.SrcLang + MP.UrlLang + "/?1023749634;" + encodeURIComponent(location.href),
            document.body.appendChild(t)
        }
        return !1
    },
    switchToLang: function(e) {
        location.href = e
    }
}
  , vzgn_msoList = {
    comcast: {
        logoTitle: "Verizon Wireless - XFINITY",
        linkBackTitle: "Return to Xfinity",
        linkBackUrl: "http://www.comcast.com/wireless"
    }
}
  , _createClass = function() {
    function e(e, t) {
        for (var n = 0; n < t.length; n++) {
            var a = t[n];
            a.enumerable = a.enumerable || !1,
            a.configurable = !0,
            "value"in a && (a.writable = !0),
            Object.defineProperty(e, a.key, a)
        }
    }
    return function(t, n, a) {
        return n && e(t.prototype, n),
        a && e(t, a),
        t
    }
}();
function _classCallCheck(e, t) {
    if (!(e instanceof t))
        throw new TypeError("Cannot call a class as a function")
}
function _possibleConstructorReturn(e, t) {
    if (!e)
        throw new ReferenceError("this hasn't been initialised - super() hasn't been called");
    return !t || "object" != typeof t && "function" != typeof t ? e : t
}
function _inherits(e, t) {
    if ("function" != typeof t && null !== t)
        throw new TypeError("Super expression must either be null or a function, not " + typeof t);
    e.prototype = Object.create(t && t.prototype, {
        constructor: {
            value: e,
            enumerable: !1,
            writable: !0,
            configurable: !0
        }
    }),
    t && (Object.setPrototypeOf ? Object.setPrototypeOf(e, t) : e.__proto__ = t)
}
var h = (preact = window.preact).h
  , Component = preact.Component
  , render = preact.render
  , ModalOverlay = function(e) {
    function t() {
        return _classCallCheck(this, t),
        _possibleConstructorReturn(this, (t.__proto__ || Object.getPrototypeOf(t)).call(this))
    }
    return _inherits(t, Component),
    _createClass(t, [{
        key: "componentDidMount",
        value: function() {
            gnav.dom("#ribbonOverlayClose").focus()
        }
    }, {
        key: "handleTrapTabKey",
        value: function() {
            gnav.dom("#ribbonOverlayClose").focus()
        }
    }, {
        key: "handleEscKey",
        value: function(e) {
            "27" == e.keyCode && this.props.toggleModal()
        }
    }, {
        key: "render",
        value: function(e) {
            var t = this
              , n = e.props
              , a = e.toggleModal
              , o = n.modalHeading
              , r = n.modalSubheading;
            return h("div", {
                className: "gnav-overlay"
            }, h("div", {
                className: "overlay-modal"
            }, h("div", {
                className: "overlay-wrapper"
            }, h("h2", {
                className: "heading"
            }, o), h("div", {
                className: "sub-heading"
            }, h("p", null, r)), h("button", {
                id: "ribbonOverlayClose",
                className: "modal-close",
                onClick: a,
                onKeyDown: function(e) {
                    return t.handleEscKey(e)
                },
                "aria-label": "Close modal",
                role: "button",
                tabindex: "0"
            }, h("svg", {
                xmlns: "http://www.w3.org/2000/svg",
                width: "20",
                height: "20",
                viewBox: "0 0 20 20"
            }, h("g", {
                fill: "none",
                "fill-rule": "evenodd",
                stroke: "#000",
                "stroke-linecap": "square"
            }, h("path", {
                d: "M.665.833l18.82 18.821M.665 19.654L19.485.834"
            })))), h("span", {
                tabIndex: "0",
                onFocus: this.handleTrapTabKey
            }))))
        }
    }]),
    t
}()
  , Facebook = function() {
    return h("svg", {
        xmlns: "http://www.w3.org/2000/svg",
        width: "19",
        height: "19",
        viewBox: "0 0 19 19"
    }, h("path", {
        fill: "#FFF",
        "fill-rule": "nonzero",
        d: "M17.926 0H1.074C.496 0 0 .496 0 1.074v16.852C0 18.504.496 19 1.074 19h9.087v-7.352H7.683V8.757h2.478V6.609c0-2.479 1.487-3.8 3.635-3.8 1.074 0 1.982.082 2.23.082v2.561H14.54c-1.156 0-1.404.578-1.404 1.405v1.817h2.808l-.33 2.891h-2.478v7.352h4.791c.578 0 1.074-.495 1.074-1.074V.991C19 .496 18.504 0 17.926 0z"
    }))
}
  , GooglePlus = function() {
    return h("svg", {
        xmlns: "http://www.w3.org/2000/svg",
        width: "26",
        height: "17",
        viewBox: "0 0 26 17"
    }, h("path", {
        fill: "#FFF",
        "fill-rule": "nonzero",
        d: "M8.193 6.955v3.348h4.424c-.655 2.146-1.72 3.349-4.424 3.349-2.622 0-4.752-2.233-4.752-5.066 0-2.833 2.048-5.066 4.752-5.066 1.393 0 2.294.515 3.113 1.202.656-.687.574-.773 2.294-2.49C12.125.86 10.241 0 8.11 0 3.606 0 0 3.778 0 8.5 0 13.222 3.605 17 8.11 17c6.719 0 8.358-6.096 7.784-10.217-1.475.172-7.701.172-7.701.172zm14.913-.061V4H20.98v2.894H18V9.02h2.979V12h2.127V9.021H26V6.894h-2.894z"
    }))
}
  , Twitter = function() {
    return h("svg", {
        xmlns: "http://www.w3.org/2000/svg",
        width: "20",
        height: "16",
        viewBox: "0 0 20 16"
    }, h("path", {
        fill: "#FFF",
        "fill-rule": "nonzero",
        d: "M6.134 16C13.782 16 17.9 9.814 17.9 4.454v-.495c.84-.578 1.513-1.32 2.101-2.062-.756.33-1.513.577-2.353.66A4.409 4.409 0 0 0 19.496.33c-.84.495-1.68.825-2.605.99A4.103 4.103 0 0 0 13.866 0c-2.27 0-4.118 1.814-4.118 4.041 0 .33 0 .66.084.907A11.862 11.862 0 0 1 1.345.742c-.337.578-.589 1.32-.589 2.062 0 1.402.757 2.64 1.849 3.382-.672 0-1.344-.165-1.849-.495v.082a4.015 4.015 0 0 0 3.362 3.959c-.336.082-.673.165-1.093.165-.252 0-.504 0-.756-.083.504 1.65 2.017 2.805 3.865 2.805-1.428 1.072-3.193 1.732-5.126 1.732-.336 0-.672 0-1.008-.083C1.68 15.34 3.866 16 6.134 16"
    }))
}
  , _extends = Object.assign || function(e) {
    for (var t = 1; t < arguments.length; t++) {
        var n = arguments[t];
        for (var a in n)
            Object.prototype.hasOwnProperty.call(n, a) && (e[a] = n[a])
    }
    return e
}
;
_createClass = function() {
    function e(e, t) {
        for (var n = 0; n < t.length; n++) {
            var a = t[n];
            a.enumerable = a.enumerable || !1,
            a.configurable = !0,
            "value"in a && (a.writable = !0),
            Object.defineProperty(e, a.key, a)
        }
    }
    return function(t, n, a) {
        return n && e(t.prototype, n),
        a && e(t, a),
        t
    }
}();
function _classCallCheck(e, t) {
    if (!(e instanceof t))
        throw new TypeError("Cannot call a class as a function")
}
function _possibleConstructorReturn(e, t) {
    if (!e)
        throw new ReferenceError("this hasn't been initialised - super() hasn't been called");
    return !t || "object" != typeof t && "function" != typeof t ? e : t
}
function _inherits(e, t) {
    if ("function" != typeof t && null !== t)
        throw new TypeError("Super expression must either be null or a function, not " + typeof t);
    e.prototype = Object.create(t && t.prototype, {
        constructor: {
            value: e,
            enumerable: !1,
            writable: !0,
            configurable: !0
        }
    }),
    t && (Object.setPrototypeOf ? Object.setPrototypeOf(e, t) : e.__proto__ = t)
}
var preact;
h = (preact = window.preact).h,
Component = preact.Component,
render = preact.render;
1 === window.location.pathname.indexOf("content/wcms/one-digital/home/business") || 1 === window.location.pathname.indexOf("homepage/business") || 1 === window.location.pathname.indexOf("business") || 1 === window.location.pathname.indexOf("biz") || gnav.dom("input[name=myBusinessDisplay]") && "1" === gnav.dom("input[name=myBusinessDisplay]").value ? gnav.createCookie("mybizCookie", "true") : gnav.eraseCookie("mybizCookie");
var locationIndicator = !1
  , GlobalNav = function(e) {
    function t() {
        _classCallCheck(this, t);
        var e = _possibleConstructorReturn(this, (t.__proto__ || Object.getPrototypeOf(t)).call(this));
        return e.state = {
            cqData: null,
            signInOverlay: !1,
            searchPopularFlag: !0,
            searchResultOverlay: !1,
            location: "Set Location",
            searchPopular: null,
            searchResults: null,
            hamburgerMenu: !1,
            cartCount: null,
            menubarWrapper: !1,
            shiftMe: !1,
            linkToRender: !1,
            businessDropdown: !1,
            searchError: !1,
            searchString: null,
            deskSubMenuDelay: 1e3,
            isFetchingSearch: !1,
            isLoggedIn: gnav.getCookie("loggedIn"),
            isBusiness: gnav.getCookie("mybizCookie"),
            userName: gnav.getCookie("greetingName"),
            userRole: gnav.getCookie("role"),
            accountDropdown: !1,
            businessDropdownNow: (new Date).getTime(),
            searchFocusTime: 0,
            ribbonOverlay: !1
        },
        e.handleNewSearch = gnav.debounce(e.handleNewSearch, 250).bind(e),
        e.handleSignIn = e.handleSignIn.bind(e),
        e.handleSearchFocus = e.handleSearchFocus.bind(e),
        e.checkKeyboardUser = e.checkKeyboardUser.bind(e),
        e.handleOverlayClose = e.handleOverlayClose.bind(e),
        e.handleMenuOverlay = e.handleMenuOverlay.bind(e),
        e.handleHamburgerMenu = e.handleHamburgerMenu.bind(e),
        e.handleMouseLeave = e.handleMouseLeave.bind(e),
        e.handleSubmenuBack = e.handleSubmenuBack.bind(e),
        e.handleBusinessMouseover = e.handleBusinessMouseover.bind(e),
        e.handleBusinessMouseleave = e.handleBusinessMouseleave.bind(e),
        e.handleLogoFocus = e.handleLogoFocus.bind(e),
        e.handleSearchMenuEnd = e.handleSearchMenuEnd.bind(e),
        e.handleAccountMenuEnd = e.handleAccountMenuEnd.bind(e),
        e.handleMenubarKeyup = e.handleMenubarKeyup.bind(e),
        e.handleAccountDropdownOpen = e.handleAccountDropdownOpen.bind(e),
        e.handleAccountDropdownClose = e.handleAccountDropdownClose.bind(e),
        e.handleAccountDropdownToggle = e.handleAccountDropdownToggle.bind(e),
        e.handleSignOutUrl = e.handleSignOutUrl.bind(e),
        e.closeDeskSubMenu = e.closeDeskSubMenu.bind(e),
        e.toggleRibbonOverlayModal = e.toggleRibbonOverlayModal.bind(e),
        e.prepareCartFromStorage = e.prepareCartFromStorage.bind(e),
        e.setGnCartCookie = e.setGnCartCookie.bind(e),
        e
    }
    return _inherits(t, Component),
    _createClass(t, [{
        key: "componentDidMount",
        value: function() {
            var e = this
              , t = this.state.isBusiness ? gnav.HEADER_JSON_URL_BIZ : this.state.isLoggedIn ? gnav.HEADER_JSON_URL_CUSTOMER : gnav.HEADER_JSON_URL_PROSPECT;
            gnav.makeAjaxCall(t, "GET").then(function(t) {
                e.setState({
                    cqData: t
                })
            });
            var n = {};
            n.state = gnav.getCookie("STATE"),
            n.city = gnav.getCookie("CITY"),
            n.state && n.city && e.setState({
                location: n
            });
            var a = gnav.getCookie("gnCartCount");
            a && a > 0 && !isNaN(a) && parseInt(Number(a)) == a && !isNaN(parseInt(a, 10)) ? this.setState({
                cartCount: a
            }) : this.setState({
                cartCount: null
            })
        }
    }, {
        key: "handleCartRetrival",
        value: function() {
            var e = localStorage.getItem("commerceJSON")
              , t = localStorage.getItem("commerceJSONDate")
              , n = gnav.getCookie("vsi")
              , a = gnav.getCookie("persistCart")
              , o = gnav.getCookie("removePerCart")
              , r = gnav.calculateCartDifference(new Date(t), new Date);
            if (null != t && r >= 29 || "true" == o)
                return localStorage.removeItem("commerceJSON"),
                localStorage.removeItem("commerceJSONDate"),
                void ("true" == o && gnav.eraseCookie("removePerCart"));
            if (null != e && "undefined" != e) {
                var s = JSON.parse(e)
                  , i = Number(s.accessoriesqty) + Number(s.devicesqty);
                "true" != a && null == a ? null != i && null != i && (this.prepareCartFromStorage(e),
                this.setGnCartCookie(i)) : (this.setGnCartCookie(i),
                gnav.createStorageFromCart())
            } else
                n && gnav.createStorageFromCart(),
                gnav.createCookie("persistCart", !0, 0)
        }
    }, {
        key: "prepareCartFromStorage",
        value: function(e) {
            var t = this;
            if (null != e && "undefined" != e) {
                var n = {
                    headers: [{
                        name: "Content-type",
                        value: "application/x-www-form-urlencoded; charset=utf-8"
                    }]
                };
                n.postData = "commerceItems=" + encodeURIComponent(e),
                gnav.makeAjaxCall("/vzw/baseajaxservlet?ajaxName=addLocalStorageCartItems", "POST", n).then(function(e) {
                    "success" == e ? gnav.createCookie("persistCart", !0) : (gnav.eraseCookie("persistCart"),
                    gnav.eraseCookie("gnCartCount"),
                    t.setState({
                        cartCount: null
                    }))
                }).catch(function() {
                    gnav.eraseCookie("persistCart"),
                    gnav.eraseCookie("gnCartCount"),
                    t.setState({
                        cartCount: null
                    })
                })
            }
        }
    }, {
        key: "setGnCartCookie",
        value: function(e) {
            var t = "gnCartCount"
              , n = gnav.getCookie(t);
            gnav.getCookie("persistCart");
            void 0 !== e && "" !== e && "0" !== e ? n && n == e || gnav.createCookie(t, e, 0) : void 0 !== n && n.length > 0 && (gnav.eraseCookie(t),
            this.setState({
                cartCount: null
            }))
        }
    }, {
        key: "checkLocation",
        value: function(e) {
            return e.city && e.city.length > 0 && e.state.length ? e.city + "," + e.state : e
        }
    }, {
        key: "checkKeyboardUser",
        value: function(e) {
            var t = -1 !== [9, 13, 32, 37, 38, 39, 40].indexOf(e);
            this.setState({
                isKeyboardUser: t
            }),
            t && -1 === document.body.className.indexOf("isKeyboardUser") && (document.body.className += " isKeyboardUser")
        }
    }, {
        key: "handleMenubarKeyup",
        value: function(e) {
            var t = e.which
              , n = e.target;
            switch (t) {
            case 37:
                n.parentElement.previousSibling ? n.parentElement.previousSibling.firstChild.focus() : this.closeDeskSubMenu(e);
                break;
            case 38:
                break;
            case 39:
                n.parentElement.nextSibling ? n.parentElement.nextSibling.firstChild.focus() : (this.closeDeskSubMenu(e),
                gnav.dom("#navPhoneSearch").focus())
            }
        }
    }, {
        key: "handleSignOutUrl",
        value: function(e) {
            -1 !== e.target.href.indexOf("GLOBALNAV_SIGNOUT_FUNCTION") && (e.preventDefault(),
            location.href = gnav.SIGNOUT_URL)
        }
    }, {
        key: "handleLogoFocus",
        value: function(e) {
            this.state.searchResultOverlay && (this.handleOverlayClose(e),
            setTimeout("gnav.dom('#vzw-gn .global-nav-list.menubar>li:last-of-type a').focus()", 1))
        }
    }, {
        key: "handleSearchMenuEnd",
        value: function(e) {
            this.state.searchResultOverlay && gnav.dom("#gnavCloseSearch").focus()
        }
    }, {
        key: "handleAccountMenuEnd",
        value: function(e) {
            e.target.parentElement.nextSibling || this.handleAccountDropdownClose(e)
        }
    }, {
        key: "handleSearchFocus",
        value: function(e) {
            var t = (new Date).getTime();
            !this.state.searchResultOverlay && t > this.state.searchFocusTime + 10 && (this.setState({
                searchResultOverlay: !0
            }),
            setTimeout("gnav.dom('#navPhoneSearch').focus()", 1)),
            this.state.searchPopularFlag && this.setState({
                searchPopular: this.state.cqData.searchPopular
            })
        }
    }, {
        key: "handleNewSearch",
        value: function(e) {
            var t = this
              , n = e.target.value;
            /\s+$/.test(n) || (this.setState({
                isFetchingSearch: !0
            }),
            n.length > 2 ? gnav.makeAjaxCall("/homepage/gnavsearch/typeAhead/?searchTerm=" + n + "*", "GET").then(function(e) {
                e.typeAheadSummary.TypeAheadSuggestedTerms ? t.setState({
                    searchResults: e,
                    searchString: n,
                    searchError: !1,
                    isFetchingSearch: !1
                }) : t.setState({
                    searchError: !0,
                    searchString: n,
                    isFetchingSearch: !1
                })
            }).catch(function() {
                t.setState({
                    searchError: !0,
                    searchString: n,
                    isFetchingSearch: !1
                })
            }) : t.setState({
                searchError: !0,
                searchString: null,
                isFetchingSearch: !1
            }))
        }
    }, {
        key: "handleOverlayClose",
        value: function(e) {
            gnav.dom("#navPhoneSearch").value = "";
            var t = !(window.innerHeight >= 768 || "close-icon" === e.target.getAttribute("class") || "close-icon" === e.target.parentElement.getAttribute("class") || !gnav.mobilecheck());
            this.setState({
                searchResultOverlay: !1,
                hamburgerMenu: t,
                searchResults: null,
                searchError: !1,
                searchString: null,
                isFetchingSearch: !1,
                accountDropdown: !1,
                searchFocusTime: (new Date).getTime()
            }),
            "gnavCloseSearch" === e.target.id && gnav.dom("#navPhoneSearch").focus()
        }
    }, {
        key: "handleSignIn",
        value: function(e) {
            this.setState({
                signInOverlay: !0
            })
        }
    }, {
        key: "handleLanguageToggle",
        value: function(e) {
            e.preventDefault(),
            MP.init(),
            MP.switchLanguage("es.verizonwireless.com" === location.host ? "en" : "es")
        }
    }, {
        key: "handleMenuOverlay",
        value: function(e) {
            this.state.searchResultOverlay || this.setState({
                searchResultOverlay: !0
            })
        }
    }, {
        key: "handleHamburgerMenu",
        value: function(e) {
            this.setState({
                hamburgerMenu: !0
            })
        }
    }, {
        key: "handlePreventDefaultMobile",
        value: function(e) {
            gnav.mobilecheck() && e.preventDefault()
        }
    }, {
        key: "handleMouseoverWrapper",
        value: function(e) {
            this.setState({
                businessDropdown: !1
            })
        }
    }, {
        key: "animateSumbenu",
        value: function() {
            this.setState({
                shiftMe: !0
            })
        }
    }, {
        key: "handleMouseover",
        value: function(e, t) {
            if (gnav.mobilecheck())
                this.animateSumbenu.bind(this);
            else {
                var n = gnav.paramVal("closedDelay") ? gnav.paramVal("closedDelay") : 100
                  , a = gnav.paramVal("openDelay") ? gnav.paramVal("openDelay") : 600
                  , o = !1 !== this.state.linkToRender ? a : n;
                this.setState({
                    nextLinkToRender: e
                }),
                setTimeout(this.openDeskSubMenu.bind(this, e), o)
            }
        }
    }, {
        key: "openDeskSubMenu",
        value: function(e) {
            this.state.nextLinkToRender !== e || e === this.state.linkToRender || this.state.businessDropdown || (this.setState({
                linkToRender: e,
                shiftMe: !1
            }),
            setTimeout(this.animateSumbenu.bind(this), 10))
        }
    }, {
        key: "handleMouseLeave",
        value: function(e, t) {
            this.setState({
                nextLinkToRender: !1
            })
        }
    }, {
        key: "closeDeskSubMenu",
        value: function(e) {
            this.setState({
                nextLinkToRender: !1,
                linkToRender: !1
            })
        }
    }, {
        key: "handleSubmenuBack",
        value: function() {
            this.setState({
                linkToRender: !1,
                submenuBack: !0
            })
        }
    }, {
        key: "handleBusinessMouseover",
        value: function(e) {
            e.preventDefault();
            var t = (new Date).getTime();
            this.setState({
                businessDropdown: !0,
                businessDropdownNow: t
            })
        }
    }, {
        key: "handleBusinessMouseleave",
        value: function(e) {
            e.preventDefault();
            var t = (new Date).getTime();
            t - this.state.businessDropdownNow > 99 && this.setState({
                businessDropdown: !1,
                businessDropdownNow: t
            })
        }
    }, {
        key: "handleAccountDropdownClose",
        value: function(e) {
            this.setState({
                accountDropdown: !1
            })
        }
    }, {
        key: "handleAccountDropdownOpen",
        value: function(e) {
            gnav.mobilecheck() || this.setState({
                accountDropdown: !0
            })
        }
    }, {
        key: "handleAccountDropdownToggle",
        value: function(e) {
            e.preventDefault(),
            this.setState({
                accountDropdown: !this.state.accountDropdown
            })
        }
    }, {
        key: "handleMobileRender",
        value: function(e, t) {
            gnav.mobilecheck() && (this.setState({
                shiftMe: !0
            }),
            this.state.submenuBack ? this.setState({
                submenuBack: !1
            }) : (window.linkToRender = e,
            window._thisPreact = this,
            setTimeout(function() {
                window._thisPreact.setState({
                    linkToRender: window.linkToRender
                })
            }, 333)))
        }
    }, {
        key: "toggleRibbonOverlayModal",
        value: function() {
            this.state.ribbonOverlay && gnav.dom(".ribbonPromoInfoIcon").focus(),
            this.setState({
                ribbonOverlay: !this.state.ribbonOverlay
            })
        }
    }, {
        key: "handleEraseMybizcookie",
        value: function() {
            gnav.eraseCookie("mybizCookie")
        }
    }, {
        key: "render",
        value: function(e, t) {
            var n = this;
            if (!this.state.cqData || null === this.state.cqData)
                return null;
            var a = this.state.cartCount
              , o = this.state.cqData
              , r = !!(!this.state.searchError && this.state.searchString && this.state.searchString.length > 0)
              , s = this.state.hamburgerMenu ? "hamburger-active" : ""
              , i = this.state.searchResultOverlay ? "search-active" : ""
              , l = !i
              , c = (this.state.businessDropdown || this.state.isBusiness,
            this.state.businessDropdown,
            this.state.businessDropdown ? "business list expanded" : "business list collapsed")
              , u = this.state.cqData.ribbon && this.state.cqData.ribbon.ribbontext ? this.state.cqData.ribbon.ribbontext : null
              , d = u ? " has-promo-ribbon" : ""
              , p = gnav.mobilecheck() ? 22 : 40
              , m = this.state.isLoggedIn ? this.state.isBusiness ? this.state.cqData.accountDropdown.signedIn : this.state.cqData.accountDropdown[this.state.userRole] ? this.state.cqData.accountDropdown[this.state.userRole] : this.state.cqData.accountDropdown.accountholder : this.state.cqData.accountDropdown && this.state.cqData.accountDropdown.signedOut
              , g = this.state.isLoggedIn && this.state.userName && "null" !== this.state.userName ? this.state.userName.length > 10 ? "Hi, " + this.state.userName.substring(0, 10) + "..." : "Hi, " + this.state.userName : m && m.label
              , v = ""
              , f = null
              , b = o.searchPopular && o.searchPopular.RelatedTermLabel ? o.searchPopular.RelatedTermLabel : "Popular Devices"
              , w = o.searchPopular && o.searchPopular.SuggestedTermLabel ? o.searchPopular.SuggestedTermLabel : "Shop Deals";
            return this.state.searchError && this.state.searchString ? v = 'No results found for &nbsp;"' + this.state.searchString + '"' : (v = r ? 'Results &nbsp;"' + this.state.searchString + '"' : b,
            f = r ? null : w),
            h("div", {
                onKeyDown: function(e) {
                    return n.checkKeyboardUser(e.which)
                }
            }, this.state.ribbonOverlay && h(ModalOverlay, {
                props: this.state.cqData.ribbon,
                toggleModal: this.toggleRibbonOverlayModal
            }), h("a", {
                className: "header-accessibility",
                tabindex: "0",
                href: "/aboutus/accessibility/index.html"
            }, h("span", null, "National Accessibility Customer Service")), h("a", {
                className: "header-accessibility",
                tabindex: "0",
                href: "#headerEnd"
            }, h("span", null, "Skip to Main Content")), h("nav", {
                role: "navigation",
                className: "container-gnav clear-float " + s + " " + i + " " + d
            }, u && h("div", {
                className: "promo-ribbon"
            }, h("div", {
                className: "clearfix"
            }, h("div", null, !this.state.cqData.ribbon.ribbonlink && "_Yes" !== this.state.cqData.ribbon.enablemodal && h("span", null, u), this.state.cqData.ribbon.ribbonlink && "_Yes" !== this.state.cqData.ribbon.enablemodal && h("a", {
                className: "ribbonPromoExternalLink",
                href: this.state.cqData.ribbon.ribbonlink
            }, u), "_Yes" === this.state.cqData.ribbon.enablemodal && h("span", {
                className: "pointer",
                onClick: this.toggleRibbonOverlayModal
            }, u, h("a", {
                className: "ribbonPromoInfoIcon",
                "aria-label": "Promotion.  More information tooltip.",
                href: "javascript:void(0)"
            }, h("svg", {
                xmlns: "http://www.w3.org/2000/svg",
                width: "14",
                height: "14",
                viewBox: "0 0 14 14"
            }, h("g", {
                fill: "none",
                "fill-rule": "evenodd"
            }, h("path", {
                stroke: "#FFF",
                d: "M7 .938A6.062 6.062 0 0 0 .937 7 6.062 6.062 0 0 0 7 13.063 6.062 6.062 0 0 0 13.063 7 6.062 6.062 0 0 0 7 .937z"
            }), h("path", {
                fill: "#FFF",
                d: "M6.211 11.375V6.228h1.576v5.147zM7.789 4.503H6.21V3.09h1.576v1.414z"
            })))))))), h("div", {
                className: "sub-container-gnav"
            }, h("div", {
                className: "logo-container"
            }, h("a", {
                href: o.homePageURL ? o.homePageURL : "/",
                onFocus: this.handleLogoFocus
            }, h("img", {
                src: "//ss7.vzw.com/is/image/VerizonWireless/vzw-logo-156-130-c?$pngalpha$&hei=" + p,
                srcset: "//ss7.vzw.com/is/image/VerizonWireless/vzw-logo-156-130-c?$pngalpha$&hei=" + 2 * p + " 2x",
                alt: "Verizon Logo"
            }))), h("div", {
                className: "nav-wrapper clear-float " + i
            }, h("div", {
                className: "nav-rule " + d
            }), h("div", {
                className: "menu-container"
            }, h("div", {
                className: "main-menu"
            }, h("ul", {
                class: "global-nav-list"
            }, o.gnavTop && o.gnavTop.map(function(e, t) {
                var a = n.state.isBusiness ? {
                    href: e.URL
                } : {
                    tabindex: 0
                }
                  , o = n.state.isBusiness ? {} : {
                    href: e.URL
                };
                return 0 === t ? h("li", null, h("a", _extends({
                    className: n.state.isBusiness ? "colorLightDark" : "color_00",
                    target: e.target
                }, a, {
                    onClick: n.handleEraseMybizcookie
                }), e.label)) : 1 === t ? h("li", null, h("a", {
                    className: "colorLightDark",
                    target: e.target,
                    href: e.URL
                }, e.label)) : h("li", {
                    className: "business-wrapper",
                    saveEnter: n.handleBusinessMouseover,
                    saveLeave: n.handleBusinessMouseleave
                }, h("a", _extends({
                    className: n.state.isBusiness ? "color_00" : "colorLightDark",
                    tabindex: "0",
                    "aria-label": c
                }, o, {
                    saveClick: n.state.businessDropdown ? n.handleBusinessMouseleave : n.handleBusinessMouseover
                }), e.label, !n.state.isBusiness && !gnav.mobilecheck() && !1), !n.state.isBusiness && e.subMenu && n.state.businessDropdown && h("div", {
                    className: "business-contents " + d
                }, h("div", {
                    className: "business-maxwidth"
                }, h("div", {
                    className: "business-right"
                }, h("ul", null, e.subMenu && e.subMenu.map(function(e, t) {
                    return h("li", null, e.label, h("ul", null, e.types && e.types.map(function(e, t) {
                        return h("li", null, h("a", {
                            target: e.target,
                            href: e.URL
                        }, e.label))
                    })))
                }))))))
            }), h("li", {
                className: "close-hamburger"
            }, h("span", {
                onClick: this.handleOverlayClose,
                tabindex: "0",
                "aria-label": "close navigation menu"
            }, h("svg", {
                className: "close-icon",
                xmlns: "http://www.w3.org/2000/svg",
                width: "15",
                height: "15",
                viewBox: "0 0 18 18"
            }, h("path", {
                fill: "#000",
                "fill-rule": "nonzero",
                d: "M17.272 1.522l-.794-.794L9 8.205 1.522.728l-.794.794L8.205 9 .728 16.478l.794.794L9 9.795l7.478 7.477.794-.794L9.795 9z"
            })))))), h("div", {
                className: "links-menu " + (this.state.isBusiness ? "isBusiness" : "")
            }, h("ul", {
                className: "global-nav-list menubar",
                tabindex: "0",
                "aria-label": "navigation menu " + (!1 === this.state.linkToRender ? "collapsed" : "expanded"),
                onFocus: this.handleMouseoverWrapper.bind(this),
                onMouseenter: this.handleMouseoverWrapper.bind(this),
                onMouseLeave: this.closeDeskSubMenu.bind(this)
            }, o.gNavMenu && o.gNavMenu.map(function(e, t) {
                return h("li", {
                    "aria-label": e.label + " " + (t === n.state.linkToRender ? "expanded" : "collapsed"),
                    onClick: n.handleMobileRender.bind(n, t),
                    onMouseenter: n.handleMouseover.bind(n, t),
                    onMouseLeave: n.handleMouseLeave.bind(n, t)
                }, h("a", {
                    className: t === n.state.linkToRender ? "hover-active" : "",
                    href: e.URL,
                    target: e.target,
                    onFocus: n.handleMouseover.bind(n, t),
                    onClick: n.handlePreventDefaultMobile,
                    onKeyup: n.handleMenubarKeyup
                }, e.label), h("div", {
                    className: "global-nav-lower position-submenu clear-float " + (t === n.state.linkToRender ? "displayBlock" : "")
                }, h("div", {
                    className: "sub-global-nav-lower"
                }, t === n.state.linkToRender && e.heading && h("div", {
                    className: "lower-left"
                }, h("h2", {
                    className: "gnav-dd-heading"
                }, e.heading), h("a", {
                    className: "gnav-dd-anchor",
                    href: e.headingCTALink,
                    target: e.target
                }, e.headingCTA, h("span", {
                    class: "gnav-right-arrow"
                }))), h("div", {
                    className: "lower-right " + (n.state.shiftMe ? "shiftMe" : "") + " " + (t === n.state.linkToRender ? "displayBlock" : "")
                }, h("div", {
                    role: "button",
                    tabindex: "0",
                    className: "mobile-back",
                    onClick: n.handleSubmenuBack
                }, h("span", {
                    className: "back-carat"
                }), "Back"), e.subMenu.length > 0 && h("ul", {
                    className: "gnav-submenu-list"
                }, e.subMenu.map(function(e, t) {
                    return h("li", null, h("a", {
                        className: "",
                        href: e.URL,
                        target: e.target
                    }, e.label))
                })), e.subBottomMenu && e.subBottomMenu.length > 0 && h("ul", {
                    className: "gnav-submenu-list"
                }, e.subBottomMenu && e.subBottomMenu.map(function(e, t) {
                    return h("li", null, h("a", {
                        className: "",
                        target: e.target,
                        href: e.URL
                    }, e.label))
                }))))))
            })))), h("div", {
                className: "nav-tools-container"
            }, h("ul", {
                className: "global-nav-list search-cart"
            }, h("li", {
                className: "search-container"
            }, h("form", {
                action: "/search/vzwSearch"
            }, h("label", {
                for: "navPhoneSearch",
                className: "hidden-label"
            }, "search"), h("input", {
                className: "search ",
                type: "text",
                name: "Ntt",
                id: "navPhoneSearch",
                placeholder: o.search && o.search.label ? o.search.label : "Search",
                autocomplete: "off",
                onFocus: this.handleSearchFocus,
                onKeyUp: this.handleNewSearch
            }), h("span", {
                className: "search-icon",
                onClick: this.handleSearchFocus
            }, h("svg", {
                xmlns: "http://www.w3.org/2000/svg",
                width: "15",
                height: "15",
                viewBox: "0 0 18 18"
            }, h("path", {
                fill: "#000",
                "fill-rule": "nonzero",
                d: "M17.896 17.101l-5.995-5.994A6.721 6.721 0 0 0 13.5 6.75a6.75 6.75 0 1 0-6.75 6.75c1.661 0 3.18-.603 4.356-1.598l5.995 5.995.795-.796zM6.75 12.375A5.63 5.63 0 0 1 1.125 6.75 5.63 5.63 0 0 1 6.75 1.125a5.63 5.63 0 0 1 5.625 5.625 5.63 5.63 0 0 1-5.625 5.625z"
            }))))), h("li", {
                className: "close-search"
            }, h("span", {
                className: "search-loader " + (this.state.isFetchingSearch ? "loader-active" : "")
            }, "Loading"), h("button", {
                id: "gnavCloseSearch",
                "aria-label": "close search",
                className: "",
                onClick: this.handleOverlayClose
            }, h("svg", {
                xmlns: "http://www.w3.org/2000/svg",
                width: "15",
                height: "15",
                viewBox: "0 0 18 18"
            }, h("path", {
                fill: "#000",
                "fill-rule": "nonzero",
                d: "M17.272 1.522l-.794-.794L9 8.205 1.522.728l-.794.794L8.205 9 .728 16.478l.794.794L9 9.795l7.478 7.477.794-.794L9.795 9z"
            })))), h("li", {
                className: "floatRightMobile cart-icon-wrapper"
            }, h("a", {
                className: "cart-icon",
                href: gnav.mobilecheck() ? o.cart && o.cart.mobURL ? o.cart.mobURL : o.cart.URL : o.cart && o.cart.URL
            }, h("svg", {
                xmlns: "http://www.w3.org/2000/svg",
                width: "18",
                height: "15",
                viewBox: "0 0 18 15"
            }, h("g", {
                fill: "none",
                "fill-rule": "evenodd"
            }, h("path", {
                fill: "#020303",
                d: "M11.354 13.875H.838v-8.99h1.845v1.45h.839v-1.45h5.15v1.45h.837v-1.45h1.845v8.99zM3.522 3.285c0-.794.641-1.439 1.433-1.447h2.283c.791.008 1.433.653 1.433 1.446v.763h-5.15v-.763zm7.14.762H9.51v-.763A2.285 2.285 0 0 0 7.24 1H4.954a2.285 2.285 0 0 0-2.272 2.284v.763H0v10.667h12.192V4.047h-1.53z"
            }), a && h("circle", {
                cx: "5.5",
                cy: "5.5",
                r: "5.5",
                fill: "#D0021B",
                transform: "translate(7)"
            }), a && h("text", {
                fill: "#FFF",
                "font-family": "NHaasGroteskDSStd-75Bd, Neue Haas Grotesk Display Std",
                "font-size": "8",
                "font-weight": "bold",
                transform: "translate(7)"
            }, h("tspan", {
                x: a > 9 ? "2" : "3",
                y: "8"
            }, a)))), o.cart && o.cart.label, a && h("span", {
                className: a > 9 ? "long-char" : ""
            }, a))), !m && h("li", {
                className: "floatMobileLeft"
            }, h("a", {
                className: "bold",
                href: o.login && o.login.URL
            }, o.login && o.login.label)), h("li", {
                className: "menu-icon"
            }, h("div", {
                className: "",
                onClick: this.handleHamburgerMenu,
                tabindex: "0",
                role: "button",
                "aria-label": "open navigation menu"
            }, h("div", null)))), h("ul", {
                className: "global-nav-list language-account"
            }, m && h("li", {
                className: "account-username-icon floatRightMobile"
            }, h("span", {
                tabindex: "0",
                "aria-label": "open account overlay",
                onClick: this.handleAccountDropdownToggle
            }, !this.state.isLoggedIn && h("span", null, g), this.state.isLoggedIn && h("span", null, g))), h("li", {
                className: "language-selector"
            }, h("a", {
                className: "",
                href: o.gnavTopRight && o.gnavTopRight.language && o.gnavTopRight.language.URL,
                onClick: this.handleLanguageToggle
            }, o.gnavTopRight && o.gnavTopRight.language && o.gnavTopRight.language.label)), m && h("li", {
                className: "account-container " + (this.state.accountDropdown ? "dropdown-active" : ""),
                onMouseenter: this.handleAccountDropdownOpen,
                onMouseLeave: this.handleAccountDropdownClose
            }, h("a", {
                href: "javascript:void(0)",
                id: "gnavAccountMenu",
                className: this.state.isLoggedIn ? "loggedin" : "",
                "aria-label": "account list " + (this.state.accountDropdown ? "expanded" : "collapsed"),
                onClick: this.handleAccountDropdownToggle
            }, h("span", null, g)), h("ul", null, m.subMenu.map(function(e) {
                var t = gnav.mobilecheck() && e.mobileURL ? e.mobileURL : e.URL;
                return h("li", null, h("a", {
                    href: t,
                    onClick: n.handleSignOutUrl,
                    onBlur: n.handleAccountMenuEnd
                }, e.label))
            })), this.state.accountDropdown && h("li", {
                class: "close-hamburger"
            }, h("span", {
                onClick: this.handleOverlayClose,
                tabindex: "0",
                "aria-label": "close navigation menu"
            }, h("svg", {
                className: "close-icon",
                xmlns: "http://www.w3.org/2000/svg",
                width: "15",
                height: "15",
                viewBox: "0 0 18 18"
            }, h("path", {
                fill: "#000",
                "fill-rule": "nonzero",
                d: "M17.272 1.522l-.794-.794L9 8.205 1.522.728l-.794.794L8.205 9 .728 16.478l.794.794L9 9.795l7.478 7.477.794-.794L9.795 9z"
            })))))))), (this.state.searchResultOverlay || this.state.hamburgerMenu) && h("div", {
                className: "global-nav-lower position-submenu clear-float search-result " + i + " " + s,
                "aria-hidden": l
            }, h("div", {
                className: "sub-global-nav-lower"
            }, h("div", {
                className: "lower-right"
            }, h("ul", {
                className: "gnav-submenu-list"
            }, null === this.state.searchString && this.state.searchPopular && this.state.searchPopular.summary && this.state.searchPopular.summary.SuggestedTerms && this.state.searchPopular.summary.SuggestedTerms.length > 0 && h("li", null, h("span", {
                className: "",
                dangerouslySetInnerHTML: {
                    __html: f
                }
            })), null === this.state.searchString && this.state.searchPopular && this.state.searchPopular.summary && this.state.searchPopular.summary.SuggestedTerms && this.state.searchPopular.summary.SuggestedTerms.map(function(e) {
                return h("li", null, h("a", {
                    className: "",
                    href: e.URL
                }, e.label))
            }), null === this.state.searchString && this.state.searchPopular && this.state.searchPopular.summary && this.state.searchPopular.summary.RelatedTerms && this.state.searchPopular.summary.RelatedTerms.length > 0 && h("li", {
                className: "bold"
            }, h("span", {
                className: "",
                dangerouslySetInnerHTML: {
                    __html: v
                }
            })), null === this.state.searchString && this.state.searchPopular && this.state.searchPopular.summary && this.state.searchPopular.summary.RelatedTerms && this.state.searchPopular.summary.RelatedTerms.map(function(e) {
                return h("li", null, h("a", {
                    className: "",
                    href: e.URL
                }, e.label))
            }), null != this.state.searchString && !this.state.searchError && this.state.searchResults && this.state.searchResults.typeAheadSummary.TypeAheadSuggestedTerms && this.state.searchResults.typeAheadSummary.TypeAheadSuggestedTerms.map(function(e) {
                return h("li", null, h("a", {
                    className: "",
                    href: e.href
                }, e.name))
            })), h("span", {
                tabindex: "0",
                onFocus: this.handleSearchMenuEnd
            })))))), h("div", {
                className: "sticky-spacer " + d,
                id: "headerEnd",
                tabindex: "-1"
            }))
        }
    }]),
    t
}();
render(h(GlobalNav, null), document.getElementById("vzw-gn"));
_createClass = function() {
    function e(e, t) {
        for (var n = 0; n < t.length; n++) {
            var a = t[n];
            a.enumerable = a.enumerable || !1,
            a.configurable = !0,
            "value"in a && (a.writable = !0),
            Object.defineProperty(e, a.key, a)
        }
    }
    return function(t, n, a) {
        return n && e(t.prototype, n),
        a && e(t, a),
        t
    }
}();
function _classCallCheck(e, t) {
    if (!(e instanceof t))
        throw new TypeError("Cannot call a class as a function")
}
function _possibleConstructorReturn(e, t) {
    if (!e)
        throw new ReferenceError("this hasn't been initialised - super() hasn't been called");
    return !t || "object" != typeof t && "function" != typeof t ? e : t
}
function _inherits(e, t) {
    if ("function" != typeof t && null !== t)
        throw new TypeError("Super expression must either be null or a function, not " + typeof t);
    e.prototype = Object.create(t && t.prototype, {
        constructor: {
            value: e,
            enumerable: !1,
            writable: !0,
            configurable: !0
        }
    }),
    t && (Object.setPrototypeOf ? Object.setPrototypeOf(e, t) : e.__proto__ = t)
}
var GlobalFooter = function(e) {
    function t() {
        _classCallCheck(this, t);
        var e = _possibleConstructorReturn(this, (t.__proto__ || Object.getPrototypeOf(t)).call(this));
        return e.state = {
            isLoggedIn: gnav.getCookie("loggedIn"),
            isBusiness: gnav.getCookie("mybizCookie")
        },
        e.handleStoreLocatorFocus = e.handleStoreLocatorFocus.bind(e),
        e
    }
    return _inherits(t, Component),
    _createClass(t, [{
        key: "componentDidMount",
        value: function() {
            var e = this
              , t = this.state.isBusiness ? gnav.FOOTER_JSON_URL_BIZ : this.state.isLoggedIn ? gnav.FOOTER_JSON_URL_CUSTOMER : gnav.FOOTER_JSON_URL_PROSPECT;
            gnav.makeAjaxCall(t, "GET").then(function(t) {
                e.setState({
                    cqData: t
                })
            })
        }
    }, {
        key: "handleStoreLocatorFocus",
        value: function(e) {
            gnav.loadGoogleScript(),
            gnav.mobilecheck() || gnav.scrollToBottom()
        }
    }, {
        key: "render",
        value: function(e, t) {
            if (!this.state.cqData || null === this.state.cqData)
                return null;
            var n = this.state.cqData;
            return h("footer", {
                role: "contentinfo",
                id: "heroFooter",
                className: "container-fluid"
            }, h("div", {
                className: "row footer-container"
            }, h("div", {
                className: "main-container"
            }, h("div", {
                className: "col-xs-12 col-sm-3 col-md-3 hero-footer"
            }, h("div", {
                className: "hero-wrapper"
            }, h("div", {
                className: "hero-footer-heading"
            }, n.applications && n.applications.heading), h("div", {
                className: "border-content"
            }, h("ul", {
                className: "footer-list"
            }, n.applications && n.applications.contents.map(function(e) {
                return h("li", null, h("a", {
                    className: "",
                    target: e.target,
                    href: e.URL
                }, e.label))
            }))))), h("div", {
                className: "col-xs-12 col-sm-3 col-md-3 hero-footer"
            }, h("div", {
                className: "hero-wrapper"
            }, h("div", {
                className: "hero-footer-heading"
            }, n.aboutVerizon && n.aboutVerizon.heading), h("div", {
                className: "border-content"
            }, h("ul", {
                className: "footer-list"
            }, n.aboutVerizon && n.aboutVerizon.contents.map(function(e) {
                return h("li", null, h("a", {
                    className: "",
                    target: e.target,
                    href: e.URL
                }, e.label))
            }))))), h("div", {
                className: "col-xs-12 col-sm-3 col-md-3 hero-footer"
            }, h("div", {
                className: "hero-wrapper"
            }, h("div", {
                className: "hero-footer-heading"
            }, n.social && n.social.heading), h("div", {
                className: "border-content social-icon"
            }, n.social && n.social.contents && n.social.contents.map(function(e) {
                var t = e.label.split(/-(.+)/)[1];
                return "fa fa-facebook-official" === e.label ? h("a", {
                    href: e.URL,
                    target: e.target
                }, h("span", null, t), h(Facebook, null)) : "fa fa-twitter" === e.label ? h("a", {
                    href: e.URL,
                    target: e.target
                }, h("span", null, t), h(Twitter, null)) : "fa fa-google-plus" === e.label ? h("a", {
                    href: e.URL,
                    target: e.target
                }, h("span", null, t), h(GooglePlus, null)) : h("a", {
                    href: e.URL,
                    target: e.target
                }, h("span", null, t), h("i", {
                    className: e.label,
                    "aria-hidden": "true"
                }))
            }))), h("div", {
                className: "footer-separator"
            }), h("div", {
                className: "hero-wrapper"
            }, h("div", {
                className: "hero-footer-heading"
            }, n.social && n.social.subscribe && n.social.subscribe.label), h("div", {
                className: "border-content"
            }, h("ul", {
                className: "footer-list"
            }, n.social && n.social.subscribe && n.social.subscribe.contents.map(function(e) {
                return h("li", null, h("a", {
                    className: "",
                    href: e.URL,
                    target: e.target
                }, e.label))
            }))))), h("div", {
                className: "col-xs-12 col-sm-3 col-md-3 hero-footer"
            }, h("div", {
                className: "hero-wrapper"
            }, h("div", {
                className: "hero-footer-heading"
            }, n.storeLocator && n.storeLocator.heading), h("div", {
                className: "border-content"
            }, h("input", {
                className: "zip-code",
                id: "googleSearchInput",
                type: "text",
                onFocus: this.handleStoreLocatorFocus,
                maxLength: "32",
                placeholder: n.storeLocator && n.storeLocator.inputPlaceHolder,
                "aria-label": "enter your zip code to find stores near you"
            }), h("div", {
                id: "googleSearchContent"
            })))), h("div", {
                className: "col-xs-12 col-sm-3 col-md-3 footer-level-two"
            }, h("a", {
                href: n.quickLinks && n.quickLinks.logoCTA,
                target: n.quickLinks && n.quickLinks.target
            }, h("img", {
                className: "vzw-footer-logo",
                src: n.quickLinks && n.quickLinks.logoUrl,
                alt: "Verizon logo"
            }))), h("div", {
                className: "col-xs-12 col-sm-9 col-md-9 footer-level-two"
            }, h("ul", {
                className: "footer-list"
            }, n.quickLinks && n.quickLinks.contents.map(function(e) {
                return h("li", null, h("a", {
                    className: "",
                    target: e.target,
                    href: e.URL
                }, e.label))
            }))))))
        }
    }]),
    t
}();
render(h(GlobalFooter, null), document.getElementById("vzw-gf"));
//# sourceMappingURL=lib.js.map