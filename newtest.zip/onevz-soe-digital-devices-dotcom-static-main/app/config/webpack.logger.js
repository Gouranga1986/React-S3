const path = require("path");

module.exports = [
  {
    entry: './src/shared/utilities/logger.js',
    output: {
        path: path.join(__dirname, "../src/assets/ak-cached/2h/scripts/"),
        filename: 'universal_logging_component.js',
        library: 'ULC',
        libraryTarget: 'window'
    }
  }
];
