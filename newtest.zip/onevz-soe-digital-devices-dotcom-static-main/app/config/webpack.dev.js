process.env.NODE_ENV = "dev";

const autoprefixer = require("autoprefixer");
const path = require("path");
const webpack = require("webpack");
const ExtractTextPlugin = require("extract-text-webpack-plugin");
const HtmlWebpackPlugin = require("html-webpack-plugin");
const apiProvider = require('./apiProvider'); 
const history = require('connect-history-api-fallback');

module.exports = {
  devtool: "cheap-module-source-map",
  entry: [
    './src/index.jsx',
  ],
  output: {
    filename: "bundle.js",
    chunkFilename: "[name].devices-[chunkhash].chunk.js",
    publicPath: '/',
  },
  module: {
    loaders: [
      {
        enforce: "pre",
        test: /\.(js)$/,
        exclude: /node_modules/,
        loader: "eslint-loader"
      },
      {
        test: /\.(js|jsx)$/,
        loaders: "babel-loader",
        include: path.join(__dirname, "../src"),
        exclude: "/node_modules/"
      },
      {
        test: /\.css$/,
        use: [
          {
            loader: 'style-loader',
          },
          {
            loader: 'css-loader',
            // options: {
            //   modules: true,
            //   localIdentName: '[name]__[local]___[hash:base64:5]',
            // },
          },
          // {
          //   loader: require.resolve("postcss-loader"),
          //   options: {
          //     // Necessary for external CSS imports to work
          //     // https://github.com/facebookincubator/create-react-app/issues/2677
          //     ident: "postcss",
          //     plugins: () => [
          //       require("postcss-flexbugs-fixes"),
          //       autoprefixer({
          //         browsers: [
          //           ">1%",
          //           "last 4 versions",
          //           "Firefox ESR",
          //           "not ie < 9" // React doesn't support IE8 anyway
          //         ],
          //         flexbox: "no-2009"
          //       })
          //     ]
          //   }
          // }
        ]
      },
      // Add scss loader
      {
        test: /\.scss$/,
        loaders: ['style-loader', 'css-loader', 'sass-loader']
      },       
      {
        test: /\.woff(2)?(\?v=[0-9]\.[0-9]\.[0-9])?$/,
        loader: "url-loader"
      },
      {
        test: /\.(eot|svg|ttf|woff|woff2)$/,
        loader: 'file-loader?name=fonts/[name].[ext]',
        include: [/fonts/]
      },
      {
        test: /\.(jpe?g|png|gif|svg)$/,
        loaders: 'file-loader?name=images/[name].[ext]',
        exclude: [/fonts/]
      },
    ]
  },
  resolve: {
    extensions: [".js", ".jsx", ".css"],
    fallback: {
      "buffer": require.resolve("buffer")
  }
  },
  plugins: [
    new HtmlWebpackPlugin({
      template: "public/index_dev.html",
      inject: true
    }),
    new webpack.HotModuleReplacementPlugin(),
    new ExtractTextPlugin("common.css"),
    new webpack.NoEmitOnErrorsPlugin(),
  ],
  devServer: {
    hot: true,
    contentBase: "./src",
    historyApiFallback: true,
    // stats: "minimal",
    before: function(app) {
      app.get('/onedigital/dsr/desktop/build/fonts/:fileName', (req, res) => {
        const filePath = path.join(
          apiProvider.getFontsPath(req.params.fileName.replace(/^\//, ''))
        );
        res.sendFile(filePath);
      });

      app.get('/onedigital/dsr/desktop/build/images/:fileName', (req, res) => {
        const filePath = path.join(
          apiProvider.getImagesPath,
          req.params.fileName.replace(/^\//, '')
        );
        res.sendFile(filePath);
      });
      app.use(history());
      // Added endpoint listeners for mock APIs (GET/POST)
      app.get('/digital/*', (req, res) => {
        res.json(apiProvider.getApiResponse(req.originalUrl));
      });
  
      app.post('/digital/*', (req, res) => {
        res.json(apiProvider.getApiResponse(req.originalUrl));
      });
  
      app.get('/content/*', (req, res) => {
        res.json(apiProvider.getApiResponse(req.originalUrl));
      });
  
      app.post('/content/*', (req, res) => {
        res.json(apiProvider.getApiResponse(req.originalUrl));
      });
    },
  },
  devtool: "source-map"
};
