/**
 * Format:
 * {
 *  endPoint = apiEndpoint
 *  fileName = mockJSONFile.js
 *  fields: expectedResKey
 * }
 * Field(s):
 *      deviceSelectView = to get only a specific key
 *      *     = to get and load all the keys
 *      deviceSelectView, cqJSON = to get multiple keys
 *
 * TODO: querySting based & HTTP filters
 *
 * NOTE: Restart Dev server whenever this file is modified  /digital/cpc/getTpPlansForMtn
 */
const apiMapping = [{
	endPoint: "/digital/cpc/planFeatures",
    fileName: "plansDetailJSON.js",
    fields: "plansDetailJSON"
},
  {
    endPoint: "/digital/cpc/getTpPlansForMtn",
    fileName: "mtnPlanList.js",
    fields: "mtnPlanList"
 },
  {
    endPoint: "/digital/cpc/planPrice",
    fileName: "priceDetailJSON.js",
    fields: "priceDetailJSON"
 },{
    endPoint: "/digital/cpc/accountHealth",
    fileName: "accountHealthJSON.js",
    fields: "accountHealthJSON"
 },{
    endPoint: '/content/wcms/one-digital/global-header/prospect.globalheader.json',
    fileName: 'gnav.js',
    fields: 'gNavHeaderJSON'
  },{
    endPoint: '/content/wcms/one-digital/global-footer/prospect.globalfooter.json',
    fileName: 'gnav.js',
    fields: 'gNavFooterJSON'
  },{
    endPoint: '/content/wcms/one-digital/global-header/service.globalheader.json',
    fileName: 'gnav.js',
    fields: 'gNavHeaderJSON'
  },{
    endPoint: '/content/wcms/one-digital/global-footer/service.globalfooter.json',
    fileName: 'gnav.js',
    fields: 'gNavFooterJSON'
  },{
	endPoint: "/digital/cpc/plans",
    fileName: "plans.js",
    fields: "plansData"
 },{
   endPoint: '/digital/cpc/planReferenceData',
   fileName: 'cpcMixAndMatch/planReferenceData.js',
   fields: 'planReferenceData'
 },{
	endPoint: "/digital/cpc/getSelectedPlansDetails",
    fileName: "billBreakDown.js",
    fields: "billBreakDownData"
 },{
	endPoint: "/digital/cpc/selectPlanForDevice",
    fileName: "selectPlan.js",
    fields: "selectPlanData"
 },{
	endPoint: "/digital/cpc/seePlanChanges",
    fileName: "seePlanChanges.js",
    fields: "seePlanChangesData"
 },{
	endPoint: "/digital/cpc/parentSelection",
    fileName: "parentalControl.js",
    fields: "parentalControlData"
 },{
	endPoint: "/digital/cpc/selectALPPlanForDevice",
    fileName: "selectPlan.js",
    fields: "selectPlanData"
 }];
module.exports = apiMapping;