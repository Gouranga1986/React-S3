const path = require('path');

const cwd = process.cwd();

const pagesEntryPoints = {
  main: path.join(cwd, 'src/LandingPage/components/Main/LandingPageContainer.js'),
};

module.exports = pagesEntryPoints;
