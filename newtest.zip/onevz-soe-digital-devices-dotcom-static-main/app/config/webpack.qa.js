const path = require('path');
const webpack = require('webpack');
const ExtractTextPlugin = require('extract-text-webpack-plugin');
const HtmlWebpackPlugin = require('html-webpack-plugin');
const UglifyJsPlugin = require('uglifyjs-webpack-plugin');
const CopyWebpackPlugin = require('copy-webpack-plugin');
// const WebpackRequireFrom = require('webpack-require-from');

// const envBundle = String(process.env.BUNDLE) || 'app';

module.exports = [
 /*  {
    entry: './src/shared/utilities/logger.js',
    output: {
      path: path.join(__dirname, '../src/assets/ak-cached/2h/scripts/'),
      filename: 'universal_logging_component.js',
      library: 'ULC',
      libraryTarget: 'window',
    },
  }, */
  {
    entry: {
      root: './src/index.jsx',
    },
    output: {
      path: path.join(__dirname, '../build/'),
      filename: '[name].js',
      chunkFilename: "[name].devices-[chunkhash].chunk.js",
      /* publicPath: '/dotcom/', */
      publicPath: '/digital/nsa/nos/devices/suspendreconnect/dotcom/', 
    },
    module: {
      loaders: [
        {
          enforce: 'pre',
          test: /\.(js)$/,
          exclude: /node_modules/,
          loader: 'eslint-loader',
          options: {
            emitWarning: true,
          },
        },
        {
          test: /\.(js|jsx)$/,
          loaders: 'babel-loader',
          include: path.join(__dirname, '../src'),
          exclude: [/node_modules/],
        },
        {
          test: /\.css$/,
          loader: ExtractTextPlugin.extract({
            fallback: 'style-loader',
            use: 'css-loader',
          })
        },
        {
          test: /\.(eot|svg|ttf|woff|woff2)$/,
          loader: 'file-loader',
          include: [/fonts/],
        },
        {
          test: /\.(jpe?g|png|gif|svg)$/,
          loaders: 'file-loader?name=assets/ak-cached/2h/images/[name].[ext]',
          exclude: [/fonts/],
        }
      ]
    },
    resolve: {
      extensions: ['*', '.js', '.jsx', '.css'],
      fallback: {
        "buffer": require.resolve("buffer")
    }     
    },
    plugins: [
      new webpack.DefinePlugin({
        'process.env': {
          NODE_ENV: JSON.stringify('qa'),
        },
      }),

      // new WebpackRequireFrom({
      //   //path: assetsUrl
      //   variableName: 'chunkURL'
      //   //replaceSrcMethodName: 'replaceSrc',
      //   //methodName: 'getChunkURL'
      // }),

      new UglifyJsPlugin({
        uglifyOptions: {
          output: {
            comments: false, // remove comments
          },
          compress: {
            unused: true,
            dead_code: true, // big one--strip code that will never execute
            warnings: false, // good for prod apps so users can't peek behind curtain
            drop_debugger: true,
            conditionals: true,
            evaluate: true,
            // drop_console: true, // strips console statements
            sequences: true,
            booleans: true,
          },
        },
      }),
      new webpack.IgnorePlugin(/^\.\/locale$/, /moment$/),
      new ExtractTextPlugin('common.css'),
      new CopyWebpackPlugin([
        {
          from: './src/assets/ak-cached/2h/images',
          to: '../build/assets/ak-cached/2h/images',
        },
        {
          from: './src/assets/ak-cached/2h/fonts',
          to: '../build/assets/ak-cached/2h/fonts',
        },
        {
          from: './src/assets/ak-cached/2h/scripts',
          to: '../build/assets/ak-cached/2h/scripts',
        },
        {
          from: './src/assets/ak-cached/2h/stylesheets',
          to: '../build/assets/ak-cached/2h/stylesheets',
        },        
        { from: './src/apiData', to: '../build/apiData' },
      ]),
      new HtmlWebpackPlugin({
        inject: true,
        template: path.join(__dirname, '../public/index.html'),
        minify: {
          removeComments: true,
          collapseWhitespace: true,
          removeRedundantAttributes: true,
          useShortDoctype: true,
          removeEmptyAttributes: true,
          removeStyleLinkTypeAttributes: true,
          keepClosingSlash: true,
          minifyJS: true,
          minifyCSS: true,
          minifyURLs: true,
        },
      }),
    ],
  },
];
