// Husky has a bug regarding line endings, in order to bypass this I'm generating the hooks everytime.
const shelljs = require('shelljs');
const { axe: { enable } } = require('../package.json');

if (process.platform === 'win32') {
  // execSync('echo "for /f "delims=" %i in ("where node") do for /F "delims=" %i in (\'%i\') do set dirname=%~dpi && path|find /i "%dirname%" >nul || set path=%dirname%;%path%" >  %HOMEPATH%/.huskyrc');
  // Pre-commit hook
  shelljs.exec('husky add .husky/pre-commit "cd ./app"');
  shelljs.exec('husky add .husky/pre-commit "printf \'\\n\\nChecking for ESLint issues:\\n\'"');
  shelljs.exec('husky add .husky/pre-commit "npx --no-install lint-staged"');
  shelljs.exec('husky add .husky/pre-commit "printf \'\\n\'"');
  shelljs.exec('husky add .husky/pre-commit "node ./scripts/Axe/cleanAxeReports.js"');
  shelljs.exec('husky add .husky/pre-commit "./scripts/gitusercheck.sh"');
  shelljs.exec('husky add .husky/pre-commit "node scripts/validateTest.js"');
  if (enable) {
    shelljs.exec('husky add .husky/pre-commit "npm run axetest"');
    shelljs.exec('husky add .husky/pre-commit "node ./scripts/Axe/sendAxeReport.js"');
  }
  shelljs.exec('husky add .husky/pre-commit "cd .."');
  shelljs.exec('husky add .husky/pre-commit "node app/scripts/analyzer.js"');

  // commit-msg hook
  shelljs.exec('husky add .husky/commit-msg "cd ./app"');
  shelljs.exec('husky add .husky/commit-msg "printf \'\\n\\nChecking commit message:\\n\'"');
  shelljs.exec('husky add .husky/commit-msg "node scripts/beforecommit.js"');
  // shelljs.exec('husky add .husky/commit-msg "npx --no-install commitlint --edit"');
  shelljs.exec('husky add .husky/commit-msg "printf \'\\n\'"');
  shelljs.exec('husky add .husky/commit-msg "cd .."');
} else {
  shelljs.exec('echo "export PATH="$(dirname $(which node)):$PATH"" > ~/.huskyrc');
}
if (process.platform === 'darwin') {
  // Pre-commit hook
  shelljs.exec('husky add .husky/pre-commit "cd ./app"');
  shelljs.exec('husky add .husky/pre-commit "printf \'\\n\\nChecking for ESLint issues:\\n\'"');
  shelljs.exec('husky add .husky/pre-commit "npx --no-install lint-staged"');
  shelljs.exec('husky add .husky/pre-commit "printf \'\\n\'"');
  shelljs.exec('husky add .husky/pre-commit "node ./scripts/Axe/cleanAxeReports.js"');
  shelljs.exec('husky add .husky/pre-commit "./scripts/gitusercheck.sh"');
  shelljs.exec('husky add .husky/pre-commit "node scripts/validateTest.js"');
  if (enable) {
    shelljs.exec('husky add .husky/pre-commit "npm run axetest"');
    shelljs.exec('husky add .husky/pre-commit "node ./scripts/Axe/sendAxeReport.js"');
  }
  shelljs.exec('husky add .husky/pre-commit "cd .."');
  shelljs.exec('husky add .husky/pre-commit "chmod 755 ./app/scripts/analyzer.sh"');
  shelljs.exec('husky add .husky/pre-commit "./app/scripts/analyzer.sh"');

  // commit-msg hook
  shelljs.exec('npx husky add .husky/commit-msg "cd ./app"');
  shelljs.exec('npx husky add .husky/commit-msg "printf \'\\n\\nChecking commit message:\\n\'"');
  shelljs.exec('npx husky add .husky/commit-msg "node scripts/beforecommit.js"');
  // shelljs.exec('npx husky add .husky/commit-msg "npx --no-install commitlint --edit"');
  shelljs.exec('npx husky add .husky/commit-msg "printf \'\\n\'"');
  shelljs.exec('npx husky add .husky/commit-msg "cd .."');
}
