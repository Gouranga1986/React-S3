window.matchMedia = window.matchMedia || function () {
    return {
        matches: false,
        addListener: function () { },
        removeListener: function () { }
    };
};
var initialData = {
    isMobile: false,
    isTablet: false,
    isBrowser: false,
    isSmartTV: false,
    isConsole: false,
    isWearable: false
};
var reactGlobals = reactGlobals || {};
reactGlobals.envConfig = reactGlobals.envConfig || {};
reactGlobals.envConfig.staticUrl = "/";
reactGlobals.session = {
    warningTimer: 1620,
    logoutTimer: 180,
    renewSessionURL: '"\/digital\/nsa\/secure\/ui\/devices\/suspendreconnect\/status"',
    sessionTimeoutEnabled: true
};
reactGlobals.transitionFallback = false;
reactGlobals.perContentImpression = [];
var _dg_eReqId = "7aa32279-7ec4-4f09-adfd-de30e2078dd6";
var env = "sit1";
var dc = "sit1";
var _dg_channelId = "VZW-DOTCOM";
var _dg_deviceType = "";
var _dg_deviceName = "IPHONE 6 PLUS BLACK 32GB";
var _dg_sessid = null;
var vzwDL = {};
var _supressReqId = false;
var _vzwTagUrl = "\/\/tags.tiqcdn.com\/utag\/vzw\/main\/dev\/utag.js";
var vzdl = {};
//var enableUiLogging = true;
var staticFilePath = "/";
var _isNative = false;
//reactGlobals.isConfirmation = false;
//reactGlobals.envConfig.getCPCsectionsApi = 'https://onevzsoe-east-gz-dev1.ebiz.verizon.com/soe/digital/landingPage';
//reactGlobals.envConfig.getCPCMMPlansectionsApi = '/cpcExploreMMPlan';
reactGlobals.envConfig.loggingApi =
    "https://onevzsoe-east-gz-qa1.ebiz.verizon.com/soe/digital/uilogging";
global._dg_tk = null;
global._dg_channelId = "VZW-DOTCOM";
global._dg_deviceType = null;
global._dg_deviceName = null;
global._dg_eReqId = null;
global._dg_sessid = "";
global.env = "devServer";
global.opalUserRestrict = false;
global.flowData = "";
global.coreFlow = true;
// global.iscpcv2  = true;
// global.iscpcv2_1  = true;
global.isSafetyModeV2 = true;
// iscpcv2_PlanSelection = true;
// isMixAndMatchRecomm = false;
global.testbuild = "";
global.staticFilePath = "/";
global.enableUiLogging = true;

var dotcomConfig = {
    reactStaticFilePath: "/",
    myVzPage: "",
    landingApiUrl: "http://localhost:4003/ApiData/landingPage.json",
    bestActionApiUrl: "http://localhost:4003/ApiData/bestAction.json",
    suspendOptionsApiUrl: "http://localhost:4003/ApiData/suspendOptions.json",
    saveSuspendApiUrlOld: "http://localhost:4003/ApiData/saveSuspend.json",
    saveSuspendApiUrl: "http://localhost:4003/ApiData/suspendConfirmation.json",
    suspendFAQsApiUrl: "http://localhost:4003/ApiData/suspendFAQ.json",
    reconnectFAQsApiUrl: "http://localhost:4003/ApiData/reconnectFAQ.json",
    validateSuspendApiUrl: "http://localhost:4003/ApiData/lostOrStolen.json",
    militaryVerificationApiUrl: "http://localhost:4003/ApiData/militaryVerification.json",
    reconnectOptionsApiUrl: "http://localhost:4003/ApiData/reconnectOptions.json",
    idMeAuthorizationUrl: "https://api.id.me/oauth/authorize?client_id=1c69dce1a5bb5c695d7c1b8e43daa811&redirect_uri=https://vzwqa1.verizonwireless.com/digital/nsa/secure/ui/devices/suspendreconnect/validate&response_type=code&scope=military_suspend",

    updateReconnectIntentApiUrl: "http://localhost:4003/ApiData/updateIntent.json",
    saveReconnectApiUrl: "http://localhost:4003/ApiData/reconnectConfirmation.json",
    aemContentApiUrl: "http://localhost:4003/ApiData/aemContent.json",
    aemContentMobileApiUrl: "http://localhost:4003/ApiData/aemContent_mobile.json",
    updateNickNameUrl: "http://localhost:4003/ApiData/updateNickName.json",
    uiLogging: "/soe/digital/uilogging",
    clickStreamLogging: "/soe/digital/clickstream",
    disconnectLandingApiUrl: "http://localhost:4004/ApiData/disconnectLanding.json",
    //disconnectLandingApiUrl: "/digital/nsa/secure/gw/devices/disconnect/landing",
    offerDetailsApiUrl: "http://localhost:4004/offerDetails.json",
    offerSelectionApiUrl: "http://localhost:4004/ApiData/offerSelection.json",
    reviewApiUrl: "http://localhost:4004/ApiData/disconnectReview.json",
    dpaReasonApiUrl: "http://localhost:4004/ApiData/disconnectDpaReasons.json",
    cancelReviewApiUrl: "http://localhost:4004/ApiData/disconnectReview.json",
    saveDisconnectApiUrl: "http://localhost:4004/ApiData/disconnectConfirmation.json",
    mvoLimitedAccessUrl: "https://vzwqa3.verizonwireless.com/ui/acct/unauthorized#/",
    shareNameIdLandingApiUrl: "http://localhost:4002/ApiData/landing.json",
    shareNameIdFaqApiUrl: "http://localhost:4002/ApiData/faqs.json",
    // shareNameIdFaqApiUrl: "https://vzwqa3.verizonwireless.com/ui/acct/secure/data/shareName/faqs",
    shareNameIdDevicesApiUrl: "/digital/nsa/secure/gw/devices/sharenameid/devices",
    shareNameIdGetApiUrl: "http://localhost:4002/ApiData/getDeviceDetail.json",
    shareNameIdUpdateApiUrl:  "http://localhost:4002/ApiData/postDeviceDetail.json",
    enableUILogging: true,
    enableClickStream: true,
    validateOTPStatusUrl: 'http://localhost:4004/ApiData/validateOtpStatus.json',
    igBackendUrl: 'http://localhost:4004/ApiData/polling.json',
    startStepupAuthUrl: 'http://localhost:4004/ApiData/stepupInit.json',
    smartPhoneUrl: "http://localhost:4005/ApiData/smartphones.json",
    recommendedDeviceUrl: "http://localhost:4005/ApiData/recommendedDevice.json",
    recommendedDeviceNewUrl: "http://localhost:4005/ApiData/getRecommendationTiles.json",
    stepUpAuthFlag: true,

}
var enableUiLogging = dotcomConfig.enableUILogging ? true : false;
var enableClickStream = dotcomConfig.enableClickStream ? true : false;
global.vztag = { api: { dispatch: jest.fn() } };
global.vzwDl = { "page": { "area": "", "authStatus": "authenticated", "channel": "/my verizon", "condition": "", "flowName": "calling plan change", "flowType": "", "globalId": "6c617e3609e84958b05e58b20e1033f5", "hier1": "/my verizon/postpay/cpc/landing", "language": "english", "lineOfBusiness": "postpay", "platform": "desktop", "state": "", "typeIndicator": "customer", "zipCode": "", "mlsExp": "desktop:northstar", "pageName": "/desktop/my verizon/postpay/cpc/landing", "pageType": "my verizon", "section2": "/my verizon/postpay", "section3": "/my verizon/postpay/cpc", "dataCenter": "", "deviceId": "", "deviceManufacturer": "", "deviceModel": "", "deviceType": "", "deviceValue": "", "clientId": "", "categoryName": "", "appointmentId": "", "filter": "", "flowInteraction": "", "microInteraction": "", "microType": "", "mlsContent": "", "contentGroup": "", "conversionType": "", "creditAppNumber": "", "creditResponse": "", "deviceFilter": "", "email": "", "paymentType": "", "perContentImpression": "", "perEngineName": "", "registrationType": "", "returnType": "", "rylToken": "", "selfServiceType": "desktop:cpc:landing", "shopPath": "", "sort": "", "storeNumber": "", "subFlowType": "", "testVersion": "", "sessionId": "", "errorMsg": "", "errorCode": "", "customerType": "", "submissionId": "", "numberofTradeInLines": "", "jaxEnabled": "", "softResponse": "", "hardResponse": "", "planId": "", "planName": "", "vzSelects": "", "numberShare": "", "globalSessionId": "", "accountNumberOfLines": "", "numberOfLinesChanged": "", "currentUserPlanId": "", "paymentMethod": "", "cpcFlag": false, "accBundleFlag": false, "events": "", "promosApplied": "", "shippingStateZip": "", "sddFlag": false, "deviceDollarsApplied": "", "accDiscountApplied": "", "cpcCaseId": "", "itpUnauthFlow": false, "vzCloudBackup": "" }, "authentication": { "collectionsInd": "N", "accountNumber": "0825615516-00001", "greetingName": "Lebowski", "ecpdId": "", "impId": "", "impType": "", "userRole": "accountManager", "mdn": "9515531080", "vzw_survey": "0", "custType": "B2C", "vct": "", "mHash": "4B27F088B7F6E97316199F6CC3DA1018", "eHash": "7756872E381B072B344C392CC9D895A3", "mHash2": "82094539e4bd8d302893a95e10c263899feb44f01f08b18d4a166268751a47ac", "eHash2": "580aa6b84c16c06d967b8a72c838198e1e04b28f5b6267d10f7914ff5f61a812", "prepayInd": "" } };
global.reactGlobals = reactGlobals;
global.dotcomConfig = dotcomConfig;