/**
 * Jest Test Runner Script  (file based)
 *
 * This script allows you to run Jest tests for specific test files based on a
 * comma-separated list of filenames. It constructs the necessary Jest flags
 * for running tests and collecting coverage information.
 *
 * Usage:
 *
 * Example command:
 *   npm run test:file testfile1,testfile2
 *
 */

const jest = require('jest')

process.execArgv.push('--no-deprecation')
process.execArgv.push('--no-warnings')
process.execArgv.push('--experimental-vm-modules')
process.env.NODE_ENV = 'test'

const args = process.argv.slice(2)
const [fileNames] = args

if (!fileNames) {
  console.error('Please provide a comma-separated list of filenames.')
  process.exit(1)
}

const files = fileNames.split(',').map((file) => file.trim())

console.log(`Running test on files`)
console.log("========================")
files.map((file) => console.log(`${file}.test.js`))

const testPathPattern = `/(${files.join('|')}).test.js`
const coveragePathPattern = `**/(${files.join('|')}).(js|jsx)`

const flags = [
  // '--silent',
  // '--watch',
  '--testPathPattern',
  testPathPattern,
  '--coverage',
  '--verbose',
  '--collectCoverageFrom',
  coveragePathPattern,
  '--testResultsProcessor',
  './node_modules/jest-sonar-reporter/index.js'
]

jest.run(flags);
