#!/bin/sh
if [[ "$OSTYPE" == *"darwin"* ]]; then
    set -e
    fortifyPath="$(eval find /Applications/Fortify -type d -name \"Fortify_SCA_*\")"
    if [[ ! -z "$fortifyPath" ]]; then
        export PATH=$PATH:$fortifyPath/bin
    fi
    fortifyToolsPath="$(eval find /Applications/Fortify -type d -name \"Fortify_Apps_*\")"
    if [[ ! -z "$fortifyToolsPath" ]]; then
        export PATH=$PATH:$fortifyToolsPath/bin
    fi
fi
node app/scripts/analyzer.js