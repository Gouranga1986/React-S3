const { exec, echo, exit } = require('shelljs');

if (exec('npm test').code !== 0) {
    echo('');
    echo('******** GIT PUSH FAILED ********');
    echo('Ensure all unit tests pass in your local before pushing code to remote.');
    echo('To run tests, execute \'npm test\'.');
    echo('');
    exit(1);
}