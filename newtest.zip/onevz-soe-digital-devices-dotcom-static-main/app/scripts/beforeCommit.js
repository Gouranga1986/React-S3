const { exec } = require('shelljs');
const {
  axe: {
    enable, enforcement, excludedProducts, severity,
  },
} = require('../package.json');
let SCAStatus = exec('git config --global core.DotCom.FORTIFYRUNSTATUS');
SCAStatus = (`${SCAStatus.toString().replace(/\n/g, '')}`).toString();
SCAStatus = ((SCAStatus === 'PASS') && '[SCA]') || '';
let TestStatus = exec('git config --global core.DotCom.TESTSTATUS');
TestStatus = (`${TestStatus.toString().replace(/\n/g, '')}`).toString();
TestStatus = ((TestStatus === 'PASS') && '[TEST]') || '';
exec('git config --global --unset core.DotCom.FORTIFYRUNSTATUS');
let AxeStatus = exec('git config --global core.DotCom.ACCESSIBILITYSTATUS', { silent: true });
AxeStatus = `${AxeStatus.toString().replace(/\n/g, '')}`;
AxeStatus = (AxeStatus === 'PASS' && enable && enforcement) ? '[A]' : '';

const exeProductExclusion = (gitMsg) => {
  const [productArea, product] = gitMsg.split(' ');
  const isExcluded = excludedProducts.includes(productArea.toLowerCase()) || excludedProducts.includes(product.toLowerCase());
  if (enable && enforcement && AxeStatus !== '[A]' && !isExcluded) {
    const devName = exec('git config --global user.name', { silent: true }).toString().replace('\n', '');
    const repoUrl = exec('git config remote.origin.url', { silent: true }).toString().replace('\n', '');
    const impact = `(impact: "${severity.join('" OR impact: "')}")`;
    console.log(`\nACCESSIBILITY ERROR: Violations have been identified. Please resolve them. \nPlease check logs in Kibana https://onevzsoelogs-np.ebiz.verizon.com/_dashboards/app/discover\nApply this query 'devName: "${devName}" AND repoUrl: "${repoUrl}" AND ${impact} AND NOT html:"-VDS__sc-" AND NOT html:"<div tabindex=\"1\""'\nPlease check "./AxeReports" folder inside <root> folder to check for the errors.\n\n`);
    process.exit(5);
  }
};

if (process.platform === 'win32') {
  const gitMsg = exec('powershell -Command "(gc ../.git/COMMIT_EDITMSG)"');
  exeProductExclusion(gitMsg.toString().replace(/\n/g, ''));
  const msg = (`${gitMsg.toString().replace(/\n/g, '')} [ELT]${SCAStatus}${TestStatus}${AxeStatus}`).toString();
  if (gitMsg) {
    const regExp = /^(Digital|Assisted-CS|Conversational|Marketing-Home|Platform|SOR|x\/CIO)\s(ACT-(\d)*|PCT-(\d)*|VBG)\s(([A-Za-z0-9])*-(\d)*)\s(build|chore|ci|story|defect|fix|perf|refactor|revert|style|test):(.*)$/;
    if (!regExp.test(gitMsg.trim())) {
      console.log('Commit failed.Please check the commit message,it should contain Git Commit Message Standardization like (Product Area) (ACT/PCT number) (defect/story) (jira number) - (commit message)');
      process.exit(5);
    } else {
      exec(`echo ${msg} > ../.git/COMMIT_EDITMSG`);
    }
  } else {
    console.log('Command failed.');
  }
} else {
  const gitMsg = exec('cat ../.git/COMMIT_EDITMSG');
  exeProductExclusion(gitMsg.toString().replace(/\n/g, ''));
  if (gitMsg) {
    const regExp = /^(Digital|Assisted-CS|Conversational|Marketing-Home|Platform|SOR|x\/CIO)\s(ACT-(\d)*|PCT-(\d)*|VBG)\s(([A-Za-z0-9])*-(\d)*)\s(build|chore|ci|story|defect|fix|perf|refactor|revert|style|test):(.*)$/;
    if (!regExp.test(gitMsg.trim())) {
      console.log('Commit failed.Please check the commit message,it should contain Git Commit Message Standardization like (Product Area) (ACT/PCT number) (defect/story) (jira number) - (commit message)');
      process.exit(5);
    } else {
      exec(`echo "${gitMsg.toString().replace(/\n/g, '')} [ELT]${SCAStatus}${TestStatus}${AxeStatus}" > ../.git/COMMIT_EDITMSG`);
    }
  } else {
    console.log('Command failed.');
  }
}
