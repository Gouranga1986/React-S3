const fs = require('fs');
const path = require('path');
const { LocalStorage } = require('node-localstorage');
const { exec } = require('shelljs');

const localStorage = new LocalStorage(path.resolve(__dirname, '../../local-storage'), Number.MAX_VALUE);
localStorage.removeItem('violations');
localStorage.removeItem('outputHtml');
localStorage.setItem('violations', '[]');
localStorage.setItem('outputHtml', '[]');

exec('git config --global --unset core.DotCom.fetchAxeReport', { silent: true });

if (fs.existsSync('AxeReports')) {
  fs.rmSync(('AxeReports'), {
    recursive: true,
  });
}
