
git config --global core.DotCom.fetchAxeReport TRUE
npm test -- $1
npm run axetest
node ./scripts/Axe/sendAxeReport.js
git config --global --unset core.DotCom.fetchAxeReport
