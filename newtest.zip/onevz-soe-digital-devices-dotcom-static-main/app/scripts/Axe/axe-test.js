import { toHaveNoViolations } from 'jest-axe';

const path = require('path');
const { LocalStorage } = require('node-localstorage');
const { axe: { enable } } = require('../../package.json');

if ((process.platform === 'darwin' || process.platform === 'win32') && enable) {
  const storeGeneratedHtmls = ({ testPath, currentTestName }) => {
    try {
      const localStorage = new LocalStorage(path.resolve(__dirname, '../../local-storage'), Number.MAX_VALUE);
      let outputHtml = localStorage.getItem('outputHtml');
      outputHtml = outputHtml ? JSON.parse(outputHtml) : [];
      if (outputHtml?.length > 0) {
        outputHtml.push({
          testPath,
          currentTestName,
          html: document.body.innerHTML,
        });
        localStorage.setItem('outputHtml', JSON.stringify(outputHtml));
      } else {
        localStorage.setItem('outputHtml', JSON.stringify([{
          testPath,
          currentTestName,
          html: document.body.innerHTML,
        }]));
      }
    } catch (e) {
      console.log(e);
    }
  };

  expect.extend(toHaveNoViolations);

  global.afterEach(async () => {
    try {
      const { testPath, currentTestName } = expect.getState();
      const ignorePatterns = testPath.match(/(asset|ApiData|apiData|reducer|action|hook|selector|saga|api|bootstrap|store)/g) || [];
      if (ignorePatterns.length === 0 && document.body.innerHTML) {
        storeGeneratedHtmls({ testPath, currentTestName });
      }
    } catch (e) {
      console.log(e);
    }
  });
}
