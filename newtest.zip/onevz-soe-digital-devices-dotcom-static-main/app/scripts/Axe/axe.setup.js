const fs = require('fs');
const HtmlReporter = require('jest-html-reporters');

class AccessibilityHtmlReporter extends HtmlReporter {
  onTestResult(test, testResult, aggregatedResults) {
    const filteredResults = testResult.testResults.filter(
      (result) => result.ancestorTitles.includes('Accessibility checks') && result.status === 'failed'
    );
    if (filteredResults.length > 0) {
      super.onTestResult(test, { ...testResult, testResults: filteredResults }, aggregatedResults);
    }
  }

  async onRunComplete(contexts, results) {
    const filteredResults = results.testResults.filter((result) => result.failureMessage?.includes(' to have no violations:'));
    if (filteredResults > 0) {
      await super.onRunComplete(contexts, filteredResults);
    } else {
      await super.onRunComplete(contexts, { ...results, testResults: filteredResults });
    }
    fs.renameSync('./jest_html_reporters.html', './axe_html_report.html'); // Rename the HTML report file
  }
}
module.exports = AccessibilityHtmlReporter;
