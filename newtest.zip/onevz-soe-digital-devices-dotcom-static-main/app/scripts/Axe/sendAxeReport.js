const path = require('path');
const { LocalStorage } = require('node-localstorage');
const elasticsearch = require('elasticsearch');
const { exec } = require('shelljs');
const {
  axe: {
    enable, enforcement, severity, ignoreVDS,
  },
} = require('../../package.json');

const ignoreVDSComponents = (violations) => {
  if (violations) {
    const filterResults = violations.filter((vio) => vio.nodes.some((node) => !(node.html.includes('-VDS__sc-')) && !(node.html.includes('<div data-focus-guard="true" tabindex="1"')) && !(node.html.includes('<div tabindex="1"')) && !(node.html.includes('&lt; /ul&gt;')) && !(node.html.includes('StyledInput-sc-')) && !(node.html.includes(' role="option">'))));
    return filterResults;
  }
  return violations;
};

const filterBySeverity = (violations) => {
  if (violations) {
    const filterResults = violations.filter((issue) => !!(severity.find((sev) => sev === issue.impact)));
    return filterResults;
  }
  return violations;
};

const localStorage = new LocalStorage(path.resolve(__dirname, '../../local-storage'), Number.MAX_VALUE);
let violations = localStorage.getItem('violations');
violations = violations ? JSON.parse(violations) : violations;

const allviolations = JSON.parse(JSON.stringify(violations));
if (ignoreVDS) violations = ignoreVDSComponents(violations);
if (severity.length > 0) violations = filterBySeverity(violations);

const devName = exec('git config --global user.name', { silent: true }).toString();
const devEmail = exec('git config --global user.email', { silent: true }).toString();
const repoUrl = exec('git config remote.origin.url', { silent: true }).toString();
const checkedOutBranch = exec('git branch --show-current', { silent: true }).toString();

const NAME = 'grafana_usr';
const IMP = 'Secure@1';
const INDEX = 'hivv_onevz_nsasoe_dev_enforcement_log';
const client = new elasticsearch.Client({
  hosts: [`https://${NAME}:${IMP}@vpc-vz-hivv-soe-opensearch-vzmbpus7eejsel4bk5gjog4zwy.us-east-1.es.amazonaws.com`],
  requestTimeout: 60000,
  ssl: { rejectUnauthorized: false, pfx: [] },
});
const indexObj = { index: { _index: INDEX } };
const data = [];
if (allviolations.length > 0) {
  allviolations.forEach((vio) => {
    const {
      impact, description, help, helpUrl, id, nodes, testPath,
    } = vio;
    nodes.forEach((node) => {
      data.push(indexObj);
      data.push({
        id: Date.now(),
        enforcementType: 'accessibility',
        errorId: id,
        axeTags: vio?.tags?.join(),
        impact,
        description,
        help,
        helpUrl,
        timestamp: new Date(),
        '@timestamp': new Date(),
        devName,
        devEmail,
        repoUrl,
        checkedOutBranch,
        html: node.html,
        failureSummary: node.failureSummary,
        htmlTarget: node.target.join(),
        testPath,
      });
    });
  });
  client.bulk({ index: INDEX, body: data }, (err) => {
    if (err) console.error(err);
    if (violations?.length && enable && enforcement) {
      exec('git config --global core.DotCom.ACCESSIBILITYSTATUS FAIL', { silent: true });
      // console.log('\nACCESSIBILITY ERROR: Violations have been identified. Please resolve them. \nPlease check "./AxeReports" folder inside <root> folder to check for the errors.\n');
      // process.exit(5);
    }
  });
}

if (violations?.length === 0 && enable && enforcement) exec('git config --global core.DotCom.ACCESSIBILITYSTATUS PASS', { silent: true });

module.exports = client;
