#!/bin/sh

devName=$(git config --global user.name)
devEmail=$(git config --global user.email)
if [[ -z "$devName" || -z "$devEmail" ]]; then
    printf "\nYour GIT user name and user email details are not updated. Please execute below steps to update...\n\n\tgit config --global user.name \"firstname lastname\"\n\tgit config --global user.email \"xxxxx.xxxx@one.verizon.com\"\n\nPlease replace \"firstname lastname\" with your actual names\nPlease replace \"xxxxx.xxxx@one.verizon.com\" with your actual verizon email address.\n\n"
    exit 1
fi