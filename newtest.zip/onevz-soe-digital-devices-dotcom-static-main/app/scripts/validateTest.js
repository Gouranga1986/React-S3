const { exec } = require('shelljs')
const xml2js = require('xml2js')
const fs = require('fs')
const micromatch = require('micromatch')
const { qualityGate } = require('../package.json')

/* use 'runTestsFor' to configure files for which all related tests should be run */
const runTestsFor = [
  '**/src/app/callfilter/**/*.{js,jsx,ts,tsx}',
  '**/src/app/deviceoverview/**/*.{js,jsx,ts,tsx}',
  '**/src/app/disconnect/**/*.{js,jsx,ts,tsx}',
  '**/src/app/blocks/**/*.{js,jsx,ts,tsx}',
  '**/src/app/numbershare/**/*.{js,jsx,ts,tsx}',
  '**/src/app/routermgmt/**/*.{js,jsx,ts,tsx}',
  '**/src/app/sharenameid/**/*.{js,jsx,ts,tsx}',
  '**/src/app/suspendreconnect/**/*.{js,jsx,ts,tsx}',
  '!**/src/**/*.d.ts',
  '!**/src/**/__tests__/**/*.[jt]s?(x)',
  // '!**/src/**/?(*.)+(spec|test).[jt]s?(x)',
  '!**/src/**/__mocks__/**/*.[jt]s?(x)',
  '!<rootDir>/node_modules/',
  '!<rootDir>/build/',
  '!<rootDir>/config/',
  '!<rootDir>/cypress/',
  '!<rootDir>/public/',
  '!<rootDir>/scripts/',
  '!<rootDir>/mocks/',
  '!<rootDir>/json/',
  '!**/src/app/shared/**/*.{ts,js,jsx}',
  '!**/src/app/assests/',
  '!**/src/app/utils/',
  '!**/src/shared/',
  '!**/src/assets/',
]

/* use 'collectCoverageFrom' to exclude files/folders from coverage check (same format as jest config) */
/* custom exclusions must be the same as project's jest config */
/* https://jestjs.io/docs/configuration#collectcoveragefrom-array */

const collectCoverageFrom = [
  // default - do not change
  '**/src/app/**/*.{js,jsx,ts,tsx}',
  '**/src/pendingAccountOrders/**/*.{js,jsx,ts,tsx}',
  '**/src/privacy/**/*.{js,jsx,ts,tsx}',
  '**/src/numberTransferPin/**/*.{js,jsx,ts,tsx}',
  '**/src/voicemailPassword/**/*.{js,jsx,ts,tsx}',
  '!**/src/**/*.d.ts',
  '!**/src/**/__tests__/**/*.[jt]s?(x)',
  '!**/src/**/?(*.)+(spec|test).[jt]s?(x)',
  '!**/src/**/__mocks__/**/*.[jt]s?(x)',
  // custom - add your negation pattern after here
  '!<rootDir>/node_modules/',
  '!<rootDir>/build/',
  '!<rootDir>/config/',
  '!<rootDir>/cypress/',
  '!<rootDir>/public/',
  '!<rootDir>/scripts/',
  '!<rootDir>/mocks/',
  '!<rootDir>/json/',
  '!**/src/app/shared/**/*.{ts,js,jsx}',
  '!**/src/app/assests/',
  '!**/src/app/utils/',
  '!**/src/shared/',
  '!**/src/assets/',
]

/* get staged files */
const stagedFiles = exec('git diff --name-only --cached')
const stagedFilesList = micromatch(
  stagedFiles
    .toString()
    .replace(/app\/src/g, 'src')
    .replace(/\n/g, ' ')
    .split(' '),
  runTestsFor
)
  .map((filename) => filename.replace(/\//g, '\\'))
  .map((filename) => (process.platform !== 'win32' ? filename.replace(/\\/g, '/') : filename))
const coverageFilesList = micromatch(stagedFilesList, collectCoverageFrom).filter(
  (file) => !file.includes('.test.js')
)

/* delete coverage folder */
if (fs.existsSync('coverage')) {
  fs.rmdirSync('coverage', { recursive: true })
}
if (stagedFilesList.length > 0) {
  /* run tests and coverage on staged files */
  if (exec(`npm test -- --findRelatedTests ${stagedFilesList.join(' ')} --coverage`).code !== 0) {
    /* exit if some tests failed */
    // exec('npm config set TEST_STATUS FAIL');
    // process.exit(5);
  }

  const fileMetrics = []

  /* Get average metrics for folder/file in percentage */
  const getMetrics = (MetricsData) => {
    const isStatements = !!parseInt(MetricsData.statements, 10)
    const isConditionals = !!parseInt(MetricsData.conditionals, 10)
    const isMethods = !!parseInt(MetricsData.methods, 10)

    const statements =
      isStatements &&
      (parseInt(MetricsData.coveredstatements, 10) / parseInt(MetricsData.statements, 10)) * 100
    const conditionals =
      isConditionals &&
      (parseInt(MetricsData.coveredconditionals, 10) / parseInt(MetricsData.conditionals, 10)) * 100
    const methods =
      isMethods &&
      (parseInt(MetricsData.coveredmethods, 10) / parseInt(MetricsData.methods, 10)) * 100

    return (statements + conditionals + methods) / (isStatements + isConditionals + isMethods) || 0
  }

  /* Track coverage for staged files */
  console.log('\nTest case coverage for staged files')
  const trackFileCoverage = (file) => {
    if (stagedFilesList.some((stagedFilename) => file.$.path.includes(stagedFilename))) {
      const fileCoverage = getMetrics(file.metrics[0].$)
      if (file.metrics.length > 0) {
        fileMetrics.push({
          ...file.$,
          metrics: fileCoverage,
        })
        console.log(` ${file.$.path} :: ${fileCoverage}`)
      }
    }
  }

  /* Parse XML report to get coverage percentage on each file */
  fs.readFile('coverage/clover.xml', 'utf8', (err, xmldata) => {
    console.log('\nCLOVER.xml not created or having some error with the file')
    if (err && err.code === 'ENOENT') {
      console.log(`\nTest file has not been created yet for these files ${stagedFiles}\n`)
      exec('git config --global core.DotCom.TESTSTATUS FAIL')
      process.exit(5)
    }
    xml2js.parseString(xmldata, (error, results) => {
      const projects = results.coverage.project
      if (projects && projects.length > 0 && projects[0].metrics) {
        const packages = projects[0].package
        if (packages) {
          packages.forEach((pkg) => {
            if (pkg.file) {
              pkg.file.forEach((file) => {
                trackFileCoverage(file)
              })
            }
          })
        }
        if (projects[0].file && projects[0].file.length > 0) {
          const pkg = projects[0].file
          pkg.forEach((file) => {
            trackFileCoverage(file)
          })
        }
      }
    })

    let isPass = true

    /* Print files with coverage lesser than threshold */
    const filesWithLessCoverage = fileMetrics
      .filter((coverage) => coverage.metrics < qualityGate)
      .map((coverage) => `${(coverage.metrics || 0).toFixed(2)}% - ${coverage.path}`)
    if (filesWithLessCoverage.length > 0) {
      console.log(
        `\nThe coverage is lesser than the expected ${qualityGate}% for the following files:\n${filesWithLessCoverage.join(
          '\n'
        )}`
      )
      console.log(
        `Kindly write test cases for each file to cover ${qualityGate}% in all Statements, Branches, Functions and Lines.\n`
      )
      isPass = false
    }

    /* Print files with missing test cases */
    const isTestMissing = coverageFilesList.length !== fileMetrics.length
    if (isTestMissing) {
      const filesWithMissingTest = coverageFilesList.filter((filePath) =>
        fileMetrics.every((coverage) => !coverage.path.includes(filePath))
      )
      console.log(
        `\nTest file has not been created yet for these files:\n${filesWithMissingTest.join('\n')}`
      )
      isPass = false
    }

    if (!isPass) {
      exec('git config --global core.DotCom.TESTSTATUS FAIL')
      process.exit(5)
    } else {
      console.log(`\nTest cases have passed with ${qualityGate}% coverage.`)
      exec('git config --global core.DotCom.TESTSTATUS PASS')
    }
  })
} else {
  exec('git config --global core.DotCom.TESTSTATUS PASS')
}
