/**
 * Jest Test Runner Script (folder based)
 *
 * This script allows you to run Jest tests for specific test folder based on a
 * comma-separated list of folders. It constructs the necessary Jest flags
 * for running tests and collecting coverage information.
 *
 * Usage:
 *
 * Example command:
 *   npm run test:folder folder1,folder2
 *
 */

const jest = require('jest')

process.execArgv.push('--no-deprecation')
process.execArgv.push('--no-warnings')
process.execArgv.push('--experimental-vm-modules')
process.env.NODE_ENV = 'test'

const args = process.argv.slice(2)
const [folerNames] = args

if (!folerNames) {
  console.error('Please provide a comma-separated list of folders.')
  process.exit(1)
}

const folders = folerNames.split(',').map((folder) => folder.trim())

console.log(`Running test on folders`)
console.log('========================')
folders.map((folder, index) => console.log(`${index + 1}:  ${folder}`))
console.log('========================')

const testPathPattern = `/(${folders.join('|')})/`
const coveragePathPattern = `**/(${folders.join('|')})/**/*.{js,jsx}`

const flags = [
  '--silent',
  // '--watch',
  '--detectOpenHandles',
  '--testPathPattern',
  testPathPattern,
  '--coverage',
  '--verbose',
  '--collectCoverageFrom',
  coveragePathPattern,
  '--testResultsProcessor',
  './node_modules/jest-sonar-reporter/index.js'
]

jest.run(flags)
