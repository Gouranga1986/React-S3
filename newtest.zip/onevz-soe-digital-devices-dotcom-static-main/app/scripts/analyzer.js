
const { exec } = require('shelljs');
const xml2js = require('xml2js');
const fs = require('fs');

const buildId = Math.floor(Math.random() * 99999);
const gitCommand = exec('git diff --name-only --cached');
let FilesToBeMoved = (`${gitCommand.toString().replace(/\n/g, ' ')}`).toString();
console.log('Generate temp folder to move all the files staged and to be analyzed\n\n');
let checkFortify = exec('sourceanalyzer -version');
checkFortify = checkFortify.toString().includes('Fortify');
if (checkFortify) {
  if (!fs.existsSync('temp')) exec('mkdir temp');
  if (!fs.existsSync('FortifyReport')) exec('mkdir FortifyReport');
  let FilesToBeAnalyzed = '';
  FilesToBeMoved = FilesToBeMoved.split(' ');
  FilesToBeMoved.forEach((file) => {
    if (file) {
      FilesToBeAnalyzed += `temp/${file.replace(/\//g, '_')} `;
      if (process.platform === 'darwin') exec(`cp ${file} temp/${file.replace(/\//g, '_')}`);
      if (process.platform === 'win32') exec(`powershell Copy-Item ${file.replace(/\//g, '\\')} temp\\${file.replace(/\//g, '_')} -PassThru`);
    }
  });
  console.log('Staged files moved to temp folder  ');
  console.log(`sourceanalyzer -b ${buildId} -autoheap -debug -verbose ${FilesToBeAnalyzed}`);
  console.log('Initiating Fortify Static Code Analyzer .................. ');
  console.log('==============================================================');
  exec(`sourceanalyzer -b ${buildId} -autoheap -debug -verbose ${FilesToBeAnalyzed}`);
  console.log('Generating FPR file.............');
  console.log(`sourceanalyzer -b ${buildId} -autoheap -debug -verbose -scan -f FortifyReport/${buildId}.fpr`);
  exec(`sourceanalyzer -b ${buildId} -autoheap -debug -verbose -scan -f FortifyReport/${buildId}.fpr`);
  console.log('Generating XML Report from FPR file........');
  console.log(`ReportGenerator ${buildId} -format xml -f FortifyReport/${buildId}.xml -source FortifyReport/${buildId}.fpr`);
  exec(`ReportGenerator ${buildId} -format xml -f FortifyReport/${buildId}.xml -source FortifyReport/${buildId}.fpr`);
  exec(`sourceanalyzer -b ${buildId} -clean`);
  let ErrorMessage = '';
  fs.readFile(`FortifyReport/${buildId}.xml`, 'utf8', (err, xmldata) => {
    xml2js.parseString(xmldata, (error, results) => {
      const ReportSection = results && results.ReportDefinition && results.ReportDefinition.ReportSection;
      if (ReportSection && ReportSection.length > 0) {
        ReportSection.forEach((ReportSectionItem) => {
          const SubSection = ReportSectionItem && ReportSectionItem.SubSection;
          if (SubSection && SubSection.length > 0) {
            SubSection.forEach((SubSectionItem) => {
              const IssueListing = SubSectionItem && SubSectionItem.IssueListing;
              if (IssueListing && IssueListing.length > 0) {
                IssueListing.forEach((IssueListingItem) => {
                  const Chart = IssueListingItem && IssueListingItem.Chart;
                  if (Chart && Chart.length > 0) {
                    Chart.forEach((ChartItem) => {
                      const GroupingSection = ChartItem && ChartItem.GroupingSection;
                      if (GroupingSection && GroupingSection.length > 0) {
                        GroupingSection.forEach((GroupingSectionItem) => {
                          const Issue = GroupingSectionItem && GroupingSectionItem.Issue;
                          if (Issue && Issue.length > 0) {
                            ErrorMessage = '\n\nFortify Analysis reports errors. Please resolve below errors. \n\n';
                            Issue.forEach((IssueItem) => {
                              ErrorMessage += `Priority: \t\t${IssueItem && IssueItem.Friority && IssueItem.Friority.length && IssueItem.Friority[0]}\n`;
                              ErrorMessage += `Category: \t\t${IssueItem && IssueItem.Category && IssueItem.Friority.length && IssueItem.Category[0]}\n`;
                              ErrorMessage += `File Name: \t\t${IssueItem && IssueItem.Primary && IssueItem.Primary.length && IssueItem.Primary[0] && IssueItem.Primary[0].FileName && IssueItem.Primary[0].FileName.length && IssueItem.Primary[0].FileName[0]}\n`;
                              ErrorMessage += `Description: \t\t${IssueItem && IssueItem.Abstract && IssueItem.Abstract.length && IssueItem.Abstract[0]}\n`;
                              ErrorMessage += `Line Start: \t\t${IssueItem && IssueItem.Primary && IssueItem.Primary.length && IssueItem.Primary[0] && IssueItem.Primary[0].LineStart && IssueItem.Primary[0].LineStart.length && IssueItem.Primary[0].LineStart[0]}\n`;
                              ErrorMessage += `Code Snippet: \t\t${IssueItem && IssueItem.Primary && IssueItem.Primary.length && IssueItem.Primary[0] && IssueItem.Primary[0].Snippet && IssueItem.Primary[0].Snippet.length && IssueItem.Primary[0].Snippet[0]}\n\n`;
                              ErrorMessage += '==============================================================\n\n';
                            });
                          }
                        });
                      }
                    });
                  }
                });
              }
            });
          }
        });
        if (ErrorMessage) {
          console.log(ErrorMessage);
          if (fs.existsSync('temp')) exec(process.platform === 'win32' ? 'rmdir /s /q temp' : 'rm -rf temp');
          if (fs.existsSync('FortifyReport')) exec(process.platform === 'win32' ? 'rmdir /s /q FortifyReport' : 'rm -rf FortifyReport');
          exec('git config --global core.DotCom.FORTIFYRUNSTATUS FAIL');
          process.exit(5);
        }
      }
      if (!ErrorMessage) {
        exec('git config --global core.DotCom.FORTIFYRUNSTATUS PASS');
      }
    });
  });
  if (fs.existsSync('temp')) exec(process.platform === 'win32' ? 'rmdir /s /q temp' : 'rm -rf temp');
  if (fs.existsSync('FortifyReport')) exec(process.platform === 'win32' ? 'rmdir /s /q FortifyReport' : 'rm -rf FortifyReport');
} else {
  console.log('Kindly install fortify before your next commit. Please refer this documentation https://oneconfluence.verizon.com/display/WSSAS/Fortify+Setup');
}