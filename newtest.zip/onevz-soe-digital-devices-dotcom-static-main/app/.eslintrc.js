module.exports = {
  parser: '@babel/eslint-parser',
  extends: 'airbnb',
  env: {
    browser: true,
    node: true,
    mocha: true,
    es6: true,
    jest: true,
  },
  plugins: [
    'react',
    'jsx-a11y',
  ],
  parserOptions: {
    ecmaVersion: 6,
    sourceType: 'module',
    allowImportExportEverywhere: true,
    ecmaFeatures: {
      jsx: true,
      spread: true,
      experimentalObjectRestSpread: true,
    },
  },
  rules: {
    'arrow-parens': [
      'error',
      'always',
    ],
    'arrow-body-style': [
      2,
      'as-needed',
    ],
    'comma-dangle': [
      2,
      'always-multiline',
    ],
    'react/prop-types': ['off'],
    camelcase: 0,
    'linebreak-style': 0,
    'import/no-unresolved': 0,
    'import/extensions': 0,
    'import/imports-first': 1,
    'import/newline-after-import': 0,
    'import/no-dynamic-require': 1,
    'import/no-extraneous-dependencies': 0,
    'import/no-named-as-default': 0,
    'import/prefer-default-export': 0,
    'jsx-a11y/aria-props': 2,
    'jsx-a11y/heading-has-content': 0,
    'jsx-a11y/label-has-for': 2,
    'jsx-a11y/mouse-events-have-key-events': 2,
    'jsx-a11y/role-has-required-aria-props': 2,
    'jsx-a11y/role-supports-aria-props': 2,
    'jsx-a11y/no-static-element-interactions': 0,
    'max-len': 0,
    'newline-per-chained-call': 0,
    'no-console': 0,
    'no-alert': 1,
    'no-use-before-define': 0,
    'no-restricted-syntax': 0,
    'no-shadow': 'off',
    'guard-for-in': 0,
    'prefer-template': 0,
    'class-methods-use-this': 0,
    'react/forbid-prop-types': 0,
    'react/jsx-first-prop-new-line': [
      2,
      'multiline-multiprop',
    ],
    'react/prefer-stateless-function': 1,
    'react/jsx-filename-extension': 0,
    'react/jsx-no-target-blank': 0,
    'react/require-extension': 0,
    'react/self-closing-comp': 2,
    'react/require-default-props': 0,
    'react/jsx-no-bind': 0,
    'react/no-array-index-key': 0,
    'react/no-danger': 0,
    'react/no-danger-with-children': 0,
    'react/no-unescaped-entities': 1,
    'no-underscore-dangle': 0,
    'react/destructuring-assignment': 0,
    'react/no-access-state-in-setstate': 1,
    'react/button-has-type': 1,
    'no-plusplus': [2, { allowForLoopAfterthoughts: true }],
    "jsx-a11y/anchor-is-valid": 0,
    'jsx-a11y/interactive-supports-focus':0,
    'consistent-return': 0,
    'no-unused-expressions':0,
    'array-callback-return':0,
    'react/no-unescaped-entities':0,
    'no-param-reassign':0,
    "react/no-unused-state": 0,
    "react/no-did-update-set-state": 0,
    "jsx-a11y/label-has-associated-control": ["error", {
        "required": {
          "some": ["nesting", "id"]
        }
      }],
      "jsx-a11y/label-has-for": ["error", {
        "required": {
          "some": ["nesting", "id"]
        }
      }]
  },
  globals: {
    __webpack_public_path__: true,
    window: true,
    document: true,
    isNaN: true,
    "reactGlobals":"readonly"
  },
};
