exports.gNavHeaderJSON = {
		"homePageURL": "https://www.verizonwireless.com/",
		"logoUrl": "//ss7.vzw.com/is/image/VerizonWireless/vzw-logo-156-130-c?$pngalpha$&wid=156&hei=35",
		"gnavTop": [{
			"label": "Wireless ",
			"URL": "https://www.verizonwireless.com/",
			"target": null
		},
		{
			"label": "In Home",
			"URL": "https://www.verizon.com/?lid=//global//residential",
			"target": null
		},
		{
			"subMenu": [{
				"types": [{
					"label": "Business Wireless Phones & Solutions",
					"URL": "https://www.verizonwireless.com/business/"
				},
				{
					"label": "Business Phone, Internet, TV & Network Services",
					"URL": "http://www.verizon.com/smallbusiness/mediumbusiness/"
				}],
				"label": "More  than 100 Employees"
			},
			{
				"types": [{
					"label": "Enterprise Technology & Wireless Solutions",
					"URL": "http://www.verizonenterprise.com/"
				},
				{
					"label": "Federal Government",
					"URL": "http://www.verizonenterprise.com/industry/public_sector/federal/"
				},
				{
					"label": "Partners",
					"URL": "http://www.verizonenterprise.com/partnerprogram/"
				}],
				"label": "Less than 100 Employees"
			}],
			"label": "Business",
			"URL": "https://www.verizonwireless.com/homepage/business/",
			"target": null
		}],
		"gnavTopRight": {
			"language": {
				"label": "Español",
				"URL": "https://es.verizonwireless.com/b2c/index.html",
				"target": "yes"
			}
		},
		"accountDropdown": {
			"accountholder": {
				"label": "Account",
				"subMenu": [{
					"label": "Profile settings",
					"URL": "https://myvpostpay.verizonwireless.com/vzw/accountholder/profile/profile.action"
				},
				{
					"label": "Verizon Up",
					"URL": "https://www.verizonwireless.com/rewards/verizon-up/"
				},
				{
					"label": "Verizon Cloud",
					"URL": "https://cloud.verizonwireless.com/vzCloud/home/cloudOverview.action"
				},
				{
					"label": "Text Online",
					"URL": "https://web.vma.vzw.com/vma/web2/Message.do"
				},
				{
					"label": "Discounts",
					"URL": "https://www.verizonwireless.com/discount-program/"
				},
				{
					"label": "Alert Settings",
					"URL": "https://myvpostpay.verizonwireless.com/vzw/accountholder/alerts/home.action##usageAlertsAnchor"
				},
				{
					"label": "Privacy Settings",
					"URL": " https://myvpostpay.verizonwireless.com/ui/acct/secure/profile#/privacypermissions/privacysettings"
				},
				{
					"label": "Manage family and friends",
					"URL": "https://myvpostpay.verizonwireless.com/vzw/secure/myfriend/myFriendDisplayActivation.action"
				},
				{
					"label": "My Referral Rewards",
					"URL": "https://myvpostpay.verizonwireless.com/vzw/secure/services/referrerHistory.action"
				},
				{
					"label": "Notifications",
					"URL": "https://myvpostpay.verizonwireless.com/ui/hub/secure/overview#/notifs"
				},
				{
					"label": "Sign Out",
					"URL": "https://myvpostpay.verizonwireless.com/ui/hub/nos/logout"
				}]
			},
			"prepay": {
				"label": "Account",
				"subMenu": [{
					"label": "My Verizon",
					"URL": "https://myaccount.verizonwireless.com/clp/login?redirect=/myvprepay/home/ "
				},
				{
					"label": "My Devices",
					"URL": "https://myaccount.verizonwireless.com/clp/login?redirect=/myvprepay/device/ "
				},
				{
					"label": "My Plans & Service",
					"URL": "https://myaccount.verizonwireless.com/clp/login?redirect=/myvprepay/plan/https://myvpostpay.verizonwireless.com/ui/hub/ao/myplan "
				},
				{
					"label": "My Profile",
					"URL": "https://myaccount.verizonwireless.com/clp/login?redirect=/myvprepay/settings/ "
				},
				{
					"label": "Sign Out",
					"URL": "https://myvpostpay.verizonwireless.com/ui/hub/nos/logout"
				}]
			},
			"mobilesecure": {
				"label": "Account",
				"subMenu": [{
					"label": "Profile settings",
					"URL": "https://myvpostpay.verizonwireless.com/vzw/mobilesecure/profile/profile.action"
				},
				{
					"label": "Verizon Up",
					"URL": "https://www.verizonwireless.com/rewards/verizon-up/"
				},
				{
					"label": "Verizon Cloud",
					"URL": "https://cloud.verizonwireless.com/vzCloud/home/cloudOverview.action"
				},
				{
					"label": "Text Online",
					"URL": "https://web.vma.vzw.com/vma/web2/Message.do"
				},
				{
					"label": "Discounts",
					"URL": "https://www.verizonwireless.com/discount-program/"
				},
				{
					"label": "Privacy Settings",
					"URL": " https://myvpostpay.verizonwireless.com/ui/acct/secure/profile#/privacypermissions/privacysettings"
				},
				{
					"label": "Manage family and friends",
					"URL": "https://myvpostpay.verizonwireless.com/vzw/secure/myfriend/myFriendDisplayActivation.action"
				},
				{
					"label": "My Referral Rewards",
					"URL": "https://myvpostpay.verizonwireless.com/vzw/secure/services/referrerHistory.action"
				},
				{
					"label": "Notifications",
					"URL": "https://myvpostpay.verizonwireless.com/ui/hub/secure/overview#/notifs"
				},
				{
					"label": "Request Account Manager Role",
					"URL": "https://myvpostpay.verizonwireless.com/vzw/mobilesecure/profile/profile.action?amroleoverlay=true"
				},
				{
					"label": "Sign out",
					"URL": "https://myvpostpay.verizonwireless.com/ui/hub/nos/logout"
				}]
			}
		},
		"cart": {
			"mobURL": "https://www.verizonwireless.com/od/cust/auth/cart/getCartDetails",
			"label": "Cart",
			"URL": "https://www.verizonwireless.com/od/cust/auth/shop?pageName=cart"
		},
		"storeLocator": {
			"label": "Stores",
			"URL": "https://www.verizonwireless.com/stores/"
		},
		"search": {
			"label": "Search"
		},
		"searchPopular": {
			"products": "",
			"SuggestedTermLabel": "Shop Deals",
			"summary": {
				"SuggestedTerms": [{
					"label": "Shop deals",
					"URL": "https://www.verizonwireless.com/deals-landing/"
				},
				{
					"label": "Add a line",
					"URL": "https://www.verizonwireless.com/support/add-a-new-device/"
				},
				{
					"label": "Plans",
					"URL": "https://www.verizonwireless.com/plans/verizon-plan/"
				},
				{
					"label": "Trade in",
					"URL": "https://www.verizonwireless.com/od/trade-in/"
				},
				{
					"label": "Upgrade",
					"URL": "https://www.verizonwireless.com/support/upgrade-device/"
				},
				{
					"label": "Unlimited",
					"URL": "https://www.verizonwireless.com/plans/unlimited/"
				}],
				"RelatedTerms": [{
					"label": "Apple iPhone XS",
					"URL": "https://www.verizonwireless.com/smartphones/apple-iphone-xs/"
				},
				{
					"label": "Apple iPhone XS Max",
					"URL": "https://www.verizonwireless.com/smartphones/apple-iphone-xs-max/"
				},
				{
					"label": "Apple iPhone XR",
					"URL": "https://www.verizonwireless.com/smartphones/apple-iphone-xr/"
				},
				{
					"label": "Samsung Galaxy Note9",
					"URL": "https://www.verizonwireless.com/smartphones/samsung-galaxy-s9/"
				},
				{
					"label": "Samsung Galaxy S9",
					"URL": "https://www.verizonwireless.com/smartphones/samsung-galaxy-s9/"
				},
				{
					"label": "Samsung Galaxy S9 Plus",
					"URL": "https://www.verizonwireless.com/smartphones/samsung-galaxy-s9-plus/"
				},
				{
					"label": "Google Pixel 3",
					"URL": "https://www.verizonwireless.com/smartphones/google-pixel-3/"
				},
				{
					"label": "Google Pixel 3 XL",
					"URL": "https://www.verizonwireless.com/smartphones/google-pixel-3-xl/"
				}]
			}
		},
		"gNavMenu": [{
			"label": "Overview",
			"URL": "https://myvpostpay.verizonwireless.com/ui/hub/secure/overview ",
			"subMenu": [],
			"subBottomMenu": []
		},
		{
			"label": "Bill",
			"URL": "https://myvpostpay.verizonwireless.com/ui/bill/ao/viewbill ",
			"memberurl": "https://myvpostpay.verizonwireless.com/vzw/mobilesecure/displayPaymentPage.action",
			"subMenu": [{
				"label": "Bill overview",
				"conditions": {
					"role": "accountholder"
				},
				"URL": "https://myvpostpay.verizonwireless.com/ui/bill/ao/viewbill"
			},
			{
				"label": "Pay bill",
				"conditions": {
					"role": "accountholder"
				},
				"URL": "https://myvpostpay.verizonwireless.com/vzw/accountholder/payment/displayPaymentPage.action"
			},
			{
				"label": "Pay bill",
				"conditions": {
					"role": "mobilesecure"
				},
				"URL": "https://myvpostpay.verizonwireless.com/vzw/mobilesecure/displayPaymentPage.action"
			},
			{
				"label": "Payment History",
				"conditions": {
					"role": "accountholder"
				},
				"URL": "https://myvpostpay.verizonwireless.com/vzw/accountholder/payment/displayPaymentHistory.action"
			},
			{
				"label": "Settings",
				"conditions": {
					"role": "accountholder"
				},
				"URL": "https://myvpostpay.verizonwireless.com/ui/bill/ao/ps"
			},
			{
				"label": "View media & app purchases",
				"conditions": {

				},
				"URL": "https://myvpostpay.verizonwireless.com/ui/bill/secure/dcb"
			},
			{
				"label": "Documents & receipts",
				"conditions": {
					"role": "accountholder"
				},
				"URL": "https://myvpostpay.verizonwireless.com/vzw/accountholder/digitalocker/MessageCenter.action"
			},
			{
				"label": "Payment arrangements",
				"conditions": {
					"role": "accountholder"
				},
				"URL": "https://myvpostpay.verizonwireless.com/vzw/accountholder/paymentarrangements/payment-arrangements-overview.action"
			}],
			"subBottomMenu": []
		},
		{
			"label": "Data",
			"URL": "https://myvpostpay.verizonwireless.com/myv/myusage/",
			"subMenu": [{
				"label": "Data overview",
				"conditions": {

				},
				"URL": "https://myvpostpay.verizonwireless.com/myv/myusage/"
			},
			{
				"label": "Manage Usage Alerts",
				"conditions": {
					"role": "accountholder"
				},
				"URL": "https://myvpostpay.verizonwireless.com/vzw/accountholder/alerts/home.action##usageAlertsAnchor"
			},
			{
				"label": "Data analysis",
				"conditions": {
					"role": "accountholder"
				},
				"URL": "https://myvpostpay.verizonwireless.com/vzw/accountholder/mybill/waaRouter.action"
			}],
			"subBottomMenu": []
		},
		{
			"label": "Plan",
			"URL": "https://myvpostpay.verizonwireless.com/myv/myplan/",
			"memberurl": "#",
			"subMenu": [{
				"label": "Plan overview",
				"conditions": {
					"role": "accountholder"
				},
				"URL": "https://myvpostpay.verizonwireless.com/myv/myplan/"
			},
			{
				"label": "Manage plan",
				"conditions": {
					"role": "accountholder"
				},
				"URL": "https://www.verizonwireless.com/digital/cpc/cpcLandingPage"
			},
			{
				"label": "Add-ons and apps",
				"conditions": {
					"role": "accountholder"
				},
				"URL": "https://myvpostpay.verizonwireless.com/myv/productsapps/"
			},
			{
				"label": "International details",
				"conditions": {

				},
				"URL": "https://myvpostpay.verizonwireless.com/ui/hub/secure/international#/"
			},
			{
				"label": "Blocks",
				"conditions": {

				},
				"URL": "https://myvpostpay.verizonwireless.com/blocks/homepage#/blocks/devicelist"
			},
			{
				"label": "My offers",
				"conditions": {
					"role": "accountholder"
				},
				"URL": "https://myvpostpay.verizonwireless.com/myv/myoffers/"
			},
			{
				"label": "Family controls",
				"conditions": {

				},
				"URL": "https://myvpostpay.verizonwireless.com/vzw/secure/safeguards/securitySuite.action"
			},
			{
				"label": "Security & privacy dashboard",
				"conditions": {

				},
				"URL": "https://devicesecurityandprivacyservices.verizonwireless.com/"
			},
			{
				"label": "Manage Verizon Smart Family",
				"conditions": {
					"role": "accountholder",
					"feature": "FamilyBase_ON"
				},
				"URL": "https://myvpostpay.verizonwireless.com/ui/ntwk/fb#/manageByLines/summary/AllLines"
			},
			{
				"label": "Verizon Smart Family",
				"conditions": {
					"role": "accountholder",
					"feature": "FamilyBase_OFF"
				},
				"URL": "https://myvpostpay.verizonwireless.com/ui/ntwk/fb#/manageByLines/summary/AllLines"
			},
			{
				"label": "Why Choose Verizon",
				"conditions": {

				},
				"URL": "https://www.verizonwireless.com/featured/better-matters/"
			}],
			"subBottomMenu": []
		},
		{
			"label": "Devices",
			"URL": "https://myvpostpay.verizonwireless.com/ui/hub/secure/mydevices",
			"subMenu": [{
				"label": "Device overview",
				"conditions": {

				},
				"URL": "https://myvpostpay.verizonwireless.com/ui/hub/secure/mydevices"
			},
			{
				"label": "Activate or switch device",
				"conditions": {
					"role": "accountholder"
				},
				"URL": "https://www.verizonwireless.com/vzw/secure/authDecision.jsp?amLogin=true&flow=DC"
			},
			{
				"label": "Upgrade device",
				"conditions": {
					"role": "accountholder"
				},
				"URL": "https://www.verizonwireless.com/od/cust/auth/shop?flow=EUP"
			},
			{
				"label": "Orders",
				"conditions": {

				},
				"URL": "https://myvpostpay.verizonwireless.com/vzw/secure/orderhistory/myorders-overview.action"
			},
			{
				"label": "File an insurance claim",
				"conditions": {
					"feature": "Insurance_ON"
				},
				"URL": "https://www.phoneclaim.com/verizon/"
			},
			{
				"label": "Suspend or reconnect",
				"conditions": {
					"role": "accountholder"
				},
				"URL": "https://myvpostpay.verizonwireless.com/vzw/accountholder/services/suspendResumeService.action"
			},
			{
				"label": "Add Insurance",
				"conditions": {
					"role": "accountholder",
					"feature": "Insurance_OFF"
				},
				"URL": "https://www.verizonwireless.com/solutions-and-services/total-mobile-protection/"
			}],
			"subBottomMenu": []
		},
		{
			"label": "Shop",
			"URL": "https://www.verizonwireless.com/featured/shop-phones-devices/",
			"subMenu": [{
				"label": "Smartphones",
				"conditions": {

				},
				"URL": "https://www.verizonwireless.com/smartphones/"
			},
			{
				"label": "Accessories",
				"conditions": {

				},
				"URL": "https://www.verizonwireless.com/products/"
			},
			{
				"label": "Tablets & Laptops",
				"conditions": {

				},
				"URL": "https://www.verizonwireless.com/tablets/"
			},
			{
				"label": "Smart watches",
				"conditions": {

				},
				"URL": "https://www.verizonwireless.com/products/smart-watches/"
			},
			{
				"label": "Cases & protection",
				"conditions": {

				},
				"URL": "https://www.verizonwireless.com/products/cases-and-protection/"
			},
			{
				"label": "Jetpacks & hotspots",
				"conditions": {

				},
				"URL": "https://www.verizonwireless.com/internet-devices/"
			},
			{
				"label": "Wearable tech",
				"conditions": {

				},
				"URL": "https://www.verizonwireless.com/wearable-tech/"
			},
			{
				"label": "Car & travel",
				"conditions": {

				},
				"URL": "https://www.verizonwireless.com/car-and-travel/"
			},
			{
				"label": "Smart home",
				"conditions": {

				},
				"URL": "https://www.verizonwireless.com/smart-home/"
			},
			{
				"label": "Family tech",
				"conditions": {

				},
				"URL": "https://www.verizonwireless.com/family-tech/"
			},
			{
				"label": "Tech store",
				"conditions": {

				},
				"URL": "https://www.verizonwireless.com/tech-store/"
			},
			{
				"label": "Fitness",
				"conditions": {

				},
				"URL": "https://www.verizonwireless.com/fitness/"
			},
			{
				"label": "My offers",
				"conditions": {

				},
				"URL": "https://myvpostpay.verizonwireless.com/myv/myoffers/"
			},
			{
				"label": "Speakers & headphones",
				"conditions": {

				},
				"URL": "https://www.verizonwireless.com/audio/"
			},
			{
				"label": "Batteries & chargers",
				"conditions": {

				},
				"URL": "https://www.verizonwireless.com/batteries-and-chargers/"
			}],
			"subBottomMenu": [{
				"label": "Apple Watch Series 4",
				"conditions": {

				},
				"URL": "https://www.verizonwireless.com/products/smart-watches/apple/"
			},
			{
				"label": " iPad",
				"conditions": {

				},
				"URL": "https://www.verizonwireless.com/tablets/ipad-9-7/"
			},
			{
				"label": "5G Home",
				"conditions": {

				},
				"URL": "https://www.verizonwireless.com/5g/home/"
			}]
		},
		{
			"label": "Support",
			"URL": "https://www.verizonwireless.com/support/",
			"subMenu": [{
				"label": "Support Overview",
				"conditions": {

				},
				"URL": "https://www.verizonwireless.com/support/"
			},
			{
				"label": "Billing and payments",
				"conditions": {

				},
				"URL": "https://www.verizonwireless.com/support/billing-and-payments/"
			},
			{
				"label": "Plan and account",
				"conditions": {

				},
				"URL": "https://www.verizonwireless.com/support/plans/"
			},
			{
				"label": "Device support",
				"conditions": {

				},
				"URL": "https://www.verizonwireless.com/support/phones-and-devices/"
			},
			{
				"label": "Device repair",
				"conditions": {

				},
				"URL": "https://www.verizonwireless.com/solutions-and-services/insurance-and-repair/"
			},
			{
				"label": "Troubleshooting assistant",
				"conditions": {

				},
				"URL": "https://www.verizonwireless.com/support/troubleshooting-tool/"
			},
			{
				"label": "Services and apps",
				"conditions": {

				},
				"URL": "https://www.verizonwireless.com/support/services-and-apps/"
			},
			{
				"label": "International services",
				"conditions": {

				},
				"URL": " https://www.verizonwireless.com/solutions-and-services/international-travel/?tab=support"
			},
			{
				"label": "Trip Planner",
				"conditions": {

				},
				"URL": "https://www.verizonwireless.com/support/trip-planner-tool/"
			},
			{
				"label": "Smart Setup",
				"conditions": {

				},
				"URL": "https://www.verizonwireless.com/support/smart-setup/"
			}],
			"subBottomMenu": [{
				"label": "Contact us",
				"conditions": {

				},
				"URL": "https://www.verizonwireless.com/support/contact-us/"
			},
			{
				"label": "Order status",
				"conditions": {

				},
				"URL": "https://myvpostpay.verizonwireless.com/vzw/secure/orderhistory/myorders-overview.action#/getorders"
			},
			{
				"label": "Community forums",
				"conditions": {

				},
				"URL": "https://community.verizonwireless.com/"
			}]
		}],
		"ribbon": {
			"ribbontext": "Choose free 2-day shipping or in-store pickup.",
			"modalHeading": "Order online, pick up in store, or get free 2-day shipping.",
			"modalSubheading": "Free 2-day shipping available for device and accessory orders of $49 or more. Accessory only orders will ship in 3-5 days. Free 2-day shipping when you order online M-F by 8 PM EST, Sat by 2PM EST (excluding holidays), will deliver in two business days within the U.S. only (excluding AK & HI). 2-day orders placed after 2 PM EST on Sat will deliver by Wednesday. Orders that contain a pre-order or backorder will ship via 2-day shipping on or prior to the committed date. Subject to credit authorization, verification and inventory availability. Order online and pick up at a Verizon Wireless store for no additional charge. Orders with multiple shipments don\u2019t qualify for In-Store Pickup. Orders must be placed from 8 AM to 5 PM, Mon - Sat, Sun before 2 (excluding Holidays). Order will be held for 3 days from the time it was placed. Please bring photo ID and credit/debit card only if used as payment. In-Store Pickup is available across the U.S. at participating Verizon Wireless stores. Prepaid devices are not eligible for In-Store Pickup. ",
			"ribbonlink": "#",
			"enablemodal": "_Yes"
		}
	};
	exports.gNavFooterJSON = {
		"applications": {
			"heading": "Apps & Services",
			"contents": [{
				"label": "My Verizon",
				"URL": "https://www.verizonwireless.com/solutions-and-services/my-verizon-mobile/",
				"target": "_self"
			},
			{
				"label": "Verizon Cloud",
				"URL": "https://www.verizonwireless.com/solutions-and-services/verizon-cloud/",
				"target": "_self"
			},
			{
				"label": "Verizon Smart Family",
				"URL": "https://www.verizonwireless.com/solutions-and-services/verizon-smart-family/",
				"target": "_self"
			},
			{
				"label": "Device trade-in",
				"URL": "https://www.verizonwireless.com/od/trade-in/auth/",
				"target": "_self"
			},
			{
				"label": "Call Filter",
				"URL": "https://www.verizonwireless.com/solutions-and-services/call-filter/",
				"target": "_blank"
			},
			{
				"label": "Apple Music",
				"URL": "https://www.verizonwireless.com/solutions-and-services/apple-music/",
				"target": "_self"
			},
			{
				"label": "Premium Visual Voicemail",
				"URL": "https://www.verizonwireless.com/solutions-and-services/visual-voicemail/",
				"target": "_self"
			},
			{
				"label": "Hum",
				"URL": "https://www.verizonwireless.com/solutions-and-services/hum/",
				"target": "_self"
			},
			{
				"label": "See More Apps",
				"URL": "https://www.verizonwireless.com/solutions-and-services/products/",
				"target": "_self"
			}]
		},
		"aboutVerizon": {
			"heading": "Brands",
			"contents": [{
				"label": "Apple",
				"URL": "https://www.verizonwireless.com/wireless-devices/apple-products/",
				"target": "_self"
			},
			{
				"label": "ASUS",
				"URL": "https://www.verizonwireless.com/devices/asus/",
				"target": "_self"
			},
			{
				"label": "Google",
				"URL": "https://www.verizonwireless.com/wireless-devices/smartphones/google/",
				"target": "_self"
			},
			{
				"label": "LG",
				"URL": "https://www.verizonwireless.com/smartphones/lg/",
				"target": "_self"
			},
			{
				"label": "Motorola",
				"URL": "https://www.verizonwireless.com/wireless-devices/smartphones/motorola/",
				"target": "_self"
			},
			{
				"label": "Palm",
				"URL": "https://www.verizonwireless.com/connected-devices/palm-companion-device/",
				"target": "_self"
			},
			{
				"label": "Samsung",
				"URL": "https://www.verizonwireless.com/wireless-devices/samsung/",
				"target": "_self"
			}]
		},
		"social": {
			"heading": "Follow ",
			"contents": [{
				"label": "fa fa-facebook-official",
				"URL": "https://www.facebook.com/verizon",
				"target": "_self"
			},
			{
				"label": "fa fa-twitter",
				"URL": "https://twitter.com/verizon?ref_src=twsrc%5Egoogle%7Ctwcamp%5Eserp%7Ctwgr%5Eauthor",
				"target": "_self"
			},
			{
				"label": "fa fa-google-plus",
				"URL": "https://plus.google.com/+verizon",
				"target": "_self"
			}],
			"subscribe": {
				"label": "Subscribe",
				"contents": [{
					"label": "Sign Up",
					"URL": " https://forms.verizonwireless.com/dgf/optin/2012/08282012_general_optin/index.html?SOURCEID=14_08_General_Optin_HP&NAV=alt",
					"target": "_self"
				}]
			}
		},
		"storeLocator": {
			"heading": "Store Locator",
			"inputPlaceHolder": "Enter a location",
			"formCTA": "https://www.verizonwireless.com/stores/"
		},
		"quickLinks": {
			"logoUrl": "//ss7.vzw.com/is/image/VerizonWireless/VZ_Logo-white?$pngalpha$",
			"logoCTA": "http://www.verizonwireless.com",
			"contents": [{
				"label": "Site Map",
				"URL": "https://www.verizonwireless.com/featured/sitemap/",
				"target": "_self"
			},
			{
				"label": "About us",
				"URL": "http://www.verizon.com/about/",
				"target": "_self"
			},
			{
				"label": "News",
				"URL": "http://www.verizon.com/about/news",
				"target": "_self"
			},
			{
				"label": "Careers",
				"URL": "http://www.verizon.com/about/careers",
				"target": "_self"
			},
			{
				"label": "Responsibility",
				"URL": "http://www.verizon.com/about/responsibility",
				"target": "_self"
			},
			{
				"label": "Verizon Innovation Program",
				"URL": "http://innovation.verizon.com/",
				"target": "_self"
			},
			{
				"label": "Privacy",
				"URL": "http://www.verizon.com/about/privacy/privacy-policy-summary",
				"target": "_self"
			},
			{
				"label": "Legal Notices",
				"URL": "https://www.verizonwireless.com/legal/notices/legal-notices/",
				"target": "_self"
			},
			{
				"label": "Customer Agreement",
				"URL": "https://www.verizonwireless.com/legal/notices/customer-agreement/",
				"target": "_self"
			},
			{
				"label": "Brochures",
				"URL": "https://www.verizonwireless.com/support/collateraldownload/",
				"target": "_self"
			},
			{
				"label": "Important Wireless issues",
				"URL": "http://www.verizon.com/about/consumer-safety/overview",
				"target": "_self"
			},
			{
				"label": "Radio Frequency Emissions",
				"URL": "https://www.verizonwireless.com/support/radio-emissions/",
				"target": "_self"
			},
			{
				"label": "Avoid Potential Hearing Loss",
				"URL": "http://www.verizon.com/about/consumer-safety/avoiding-potential-hearing-loss",
				"target": "_self"
			},
			{
				"label": "Website Use",
				"URL": "https://www.verizonwireless.com/one-support/web-use/",
				"target": "_self"
			},
			{
				"label": "Return Policy",
				"URL": "https://www.verizonwireless.com/support/return-policy/",
				"target": "_self"
			},
			{
				"label": "Accessibility",
				"URL": "http://www.verizon.com/about/accessibility/overview",
				"target": "_self"
			},
			{
				"label": "Product Terms",
				"URL": "https://www.verizonwireless.com/support/other-wireless-topics/legal-notices-and-industry-information/",
				"target": "_self"
			},
			{
				"label": "My Verizon Terms & Conditions",
				"URL": "https://www.verizonwireless.com/wcms/myverizon/terms.html",
				"target": "_self"
			},
			{
				"label": "Device Payment Terms & Conditions",
				"URL": "https://ss7.vzw.com/is/content/VerizonWireless/Legal/Documents/Footer/device-payment-t-c-122016.pdf",
				"target": "_self"
			},
			{
				"label": "Open Internet",
				"URL": "https://www.verizon.com/about/our-company/open-internet",
				"target": "_self"
			},
			{
				"label": "Lifeline/Link-Up",
				"URL": "https://www.verizonwireless.com/solutions-and-services/lifeline/",
				"target": "_self"
			},
			{
				"label": "About Our Ads",
				"URL": "http://www.verizon.com/about/privacy/about-our-ads",
				"target": "_self"
			},
			{
				"label": "Advertise With us",
				"URL": "https://www.verizonwireless.com/solutions-and-services/apps/advertise-with-us/",
				"target": "_self"
			}]
		}
	}
