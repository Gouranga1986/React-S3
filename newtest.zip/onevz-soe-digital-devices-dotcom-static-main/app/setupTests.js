// fix: define variables under window object
import './scripts/Axe/axe-test';
import { TextEncoder, TextDecoder } from 'util';

global.TextEncoder = TextEncoder;
global.TextDecoder = TextDecoder;
global.staticFilePath   = '/'
global.__webpack_public_path__ = '/'
Object.defineProperties(window, {
  globalConfig: {
    writable: true,
    value: {
      universalProfileFiosLinkingUrl: './digital/nsa',
      isUniversalProfile: 'Y',
      role: 'accountHolder',
      mobile: '8042013842',
    },
  },
  addEventListener: {
    writable: true,
    value: jest.fn(),
  },
  matchMedia: {
    writable: true,
    value: jest.fn().mockImplementation((query) => ({
      matches: false,
      media: query,
      onchange: null,
      addEventListener: jest.fn(),
      removeEventListener: jest.fn(),
      dispatchEvent: jest.fn(),
      addListener: jest.fn(), // deprecated
      removeListener: jest.fn(), // deprecated
    })),
  },
  scroll: {
    writable: false,
    value: jest.fn(),
  },
  vzdl: {
    writable: true,
    value: {},
  },
  vztag: {
    writable: true,
    value: {},
  },
  location: {
    writable: true,
    value: {
      href: '/',
      replace: jest.fn(),
    },
  },
  history: {
    writable: true,
    value: {},
  },
  newrelic: {
    writable: true,
    value: {
      setCustomAttribute: jest.fn(),
      interaction: jest.fn(),
      setName: jest.fn(),
      save: jest.fn(),
    },
  },
});

Object.defineProperty(
  window.navigator,
  'userAgent',
  ((value) => ({
    get() {
      return value;
    },
    set(v) {
      value = v;
    },
  }))(window.navigator.userAgent)
);

const mockSessionStorage = (() => {
  let store = {};
  return {
    getItem(key) {
      return store[key] || null;
    },
    setItem(key, value) {
      store[key] = value.toString();
    },
    removeItem(key) {
      delete store[key];
    },
    clear() {
      store = {};
    },
  };
})();

Object.defineProperty(window, 'sessionStorage', {
  value: mockSessionStorage,
});
