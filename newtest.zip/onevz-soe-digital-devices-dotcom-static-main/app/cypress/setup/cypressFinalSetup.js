// const os = require('os');
// const fs = require('fs-extra');

// if (process.platform === 'win32' && !fs.existsSync(`${os.homedir()}\\AppData\\Local\\Cypress\\Cache\\9.5.2\\`)) {
//   fs.copySync('C:\\Cypress_BINARY\\9.5.2\\', `${os.homedir()}\\AppData\\Local\\Cypress\\Cache\\9.5.2\\`);
// }

const os = require('os');
const fs = require('fs-extra');
const {logger} = require('../utils/cypressUtils');

const env = process.env;
console.log(env.CYPRESS_INSTALL_BINARY)
if (process.platform === 'win32' && !fs.existsSync(`${os.homedir()}\\AppData\\Local\\Cypress\\Cache\\9.5.2\\`)) {
  fs.copySync('C:\\Cypress_BINARY\\9.5.2\\', `${os.homedir()}\\AppData\\Local\\Cypress\\Cache\\9.5.2\\`);
}
const preCommitPath = `./.husky/pre-commit`;

if (fs.existsSync(preCommitPath)) {
  fs.readFile(preCommitPath, 'utf8', function (err, data) {
        if (err) throw err;
        if(data.indexOf('cypressRunner') == -1) {
          data += "\nnode app/cypress/cypressRunner.js";
          fs.writeFile (preCommitPath, data, function(err) {
            if (err) throw err;
            console.log('added cypress command to hooks.');
          });
        }
    });
    logger.info('Husky hooks are found.');
} else {
  logger.error("Husky hooks are not found. Make sure husky hooks are configured.");
  process.exit(1); //check preCommitPath
}
