// const os = require('os');
// const fs = require('fs');
// const env = process.env;
// const sh = require('shelljs');
// const {appFolder, logger, mkDirs} = require('../utils/cypressUtils');
// const artiUrl = 'https://oneartifactoryprod.verizon.com/artifactory/HIVV_CYPRESS';

// if (process.platform === 'win32') {
//   env.CYPRESS_CACHE_FOLDER = `${os.homedir()}\\AppData\\Local\\Cypress\\Cache`;
//   env.CYPRESS_INSTALL_BINARY = `${artiUrl}/win/cypress.zip`;
//   console.log('Configured windows cypress installation binary.');
//   sh.exec(`npm config set PUPPETEER_SKIP_DOWNLOAD 0`);
// }
// else if(process.platform === 'darwin') {
//   env.CYPRESS_CACHE_FOLDER = `${os.homedir()}/Library/Caches/Cypress/`;
//   if (!fs.existsSync(env.CYPRESS_CACHE_FOLDER)) {
//     fs.mkdirSync(env.CYPRESS_CACHE_FOLDER, { recursive: true });
//   }
//   env.CYPRESS_INSTALL_BINARY = `${artiUrl}/darwin/cypress.zip`;
//   console.log('Configured mac os cypress installation binary.');
// }
// const preCommitPath = `./.husky/pre-commit`;
// if (fs.existsSync(preCommitPath)) {
//   fs.readFile(preCommitPath, 'utf8', function (err, data) {
//         if (err) throw err;
//         if(data.indexOf('cypressRunner') == -1) {
//           data += "\nnode app/cypress/cypressRunner.js";
//           fs.writeFile (preCommitPath, data, function(err) {
//             if (err) throw err;
//             console.log('added cypress command to hooks.');
//           });
//         }
//     });
//     logger.info('Husky hooks are found.');
// } else {
//   logger.error("Husky hooks are not found. Make sure husky hooks are configured.");
//   process.exit(1); //check preCommitPath
// }
// console.log(env.CYPRESS_INSTALL_BINARY);

const os = require('os');
const fs = require('fs');

const sh = require('shelljs');
const {appFolder, logger, mkDirs} = require('../utils/cypressUtils');

const artiUrl = 'https://oneartifactoryprod.verizon.com/artifactory/HIVV_CYPRESS';

if (process.platform === 'win32') {
  
  const CYPRESS_CACHE_FOLDER = `${os.homedir()}\\AppData\\Local\\Cypress\\Cache`;
  const CYPRESS_INSTALL_BINARY = `${artiUrl}/win/cypress.zip`;
  sh.exec(`npm config set CYPRESS_CACHE_FOLDER ${CYPRESS_CACHE_FOLDER}`);
  sh.exec(`npm config set CYPRESS_INSTALL_BINARY ${CYPRESS_INSTALL_BINARY}`);
  console.log('Configured windows cypress installation binary.');
}
else if(process.platform === 'darwin') {
  const CYPRESS_CACHE_FOLDER = `${os.homedir()}/Library/Caches/Cypress/`;
  if (!fs.existsSync(CYPRESS_CACHE_FOLDER)) {
    fs.mkdirSync(CYPRESS_CACHE_FOLDER, { recursive: true });
  }
  const CYPRESS_INSTALL_BINARY = `${artiUrl}/darwin/cypress.zip`;
  sh.exec(`npm config set CYPRESS_CACHE_FOLDER ${CYPRESS_CACHE_FOLDER}`);
  sh.exec(`npm config set CYPRESS_INSTALL_BINARY ${CYPRESS_INSTALL_BINARY}`);
  console.log('Configured mac os cypress installation binary.');
}