module.exports = [
  {
    route: '/',
    pageSrc: 'app/src/app/suspendreconnect/home',
  },
  {
    route: '/',
    pageSrc: 'app/src/app/disconnect/home',
  },
  {
    route: '/',
    pageSrc: 'app/src/app/blocks/home',
  },
  {
    route: '/',
    pageSrc: 'app/src/app/deviceoverview/home',
  },
  {
    route: '/deviceDetail',
    pageSrc: 'app/src/app/deviceoverview/deviceDetail',
  },
  {
    route: '/bestbuy',
    pageSrc: 'app/src/app/suspendreconnect/bestAction',
  },
  {
    route: '/suspendoptions',
    pageSrc: 'app/src/app/suspendreconnect/suspendOptions',
  },
  {
    route: '/confirmation',
    pageSrc: 'app/src/app/suspendreconnect/confirmation',
  },
  {
    route: '/confirmation',
    pageSrc: 'app/src/app/disconnect/confirmation',
  },
  {
    route: '/needtoknow',
    pageSrc: 'app/src/app/suspendreconnect/confirmation',
  },
  {
    route: '/deploymentlocation',
    pageSrc: 'app/src/app/suspendreconnect/confirmation',
  },
  {
    route: '/reconnectoptions',
    pageSrc: 'app/src/app/suspendreconnect/reconnectOptions',
  },
  {
    route: '/reconnectconfirmation',
    pageSrc: 'app/src/app/suspendreconnect/reconnectConfirmation',
  },
  {
    route: '/internal',
    pageSrc: 'app/src/app/suspendreconnect/internal',
  },
  // {
  //   route: '/validate',
  //   pageSrc: 'app/src/app/suspendreconnect/confirmation'
  // },
  {
    route: '/review',
    pageSrc: 'app/src/app/disconnect/review',
  },
  {
    route: '/selectReason',
    pageSrc: 'app/src/app/disconnect/reason',
  },
  {
    pageSrc: 'app/src/shared',
    testSpecs: [], // specify the cases which you want to run or empty to run all existing cases.
  },
]
