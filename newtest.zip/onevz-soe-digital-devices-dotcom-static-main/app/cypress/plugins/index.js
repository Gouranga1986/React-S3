// ***********************************************************
// This example plugins/index.js can be used to load plugins
//
// You can change the location of this file or turn off loading
// the plugins file with the 'pluginsFile' configuration option.
//
// You can read more here:
// https://on.cypress.io/plugins-guide
// ***********************************************************

// This function is called when a project is opened or re-opened (e.g. due to
// the project's config changing)

const { lighthouse, pa11y, prepareAudit } = require('cypress-audit');
const fs = require('fs');
const {mkDirs} = require('../utils/cypressUtils');
const ReportGenerator = require('lighthouse/report/generator/report-generator');

let specName = 'report';
let dateNow = new Date().toDateString();
let myData = {};
/**
 * @type {Cypress.PluginConfig}
 */
// eslint-disable-next-line no-unused-vars
module.exports = (on, config) => {
  // `on` is used to hook into various events Cypress emits
  // `config` is the resolved Cypress config
  // eslint-disable-next-line no-unused-vars
  on('before:browser:launch', (browser = {}, launchOptions) => {
    //launchOptions.args.push('--proxy-bypass-list=<-loopback>,localhost:8081')
    launchOptions.args.push('----disable-web-security');
    launchOptions.args.push('--disable-extensions');
    for (let index = 0; index < launchOptions.args.length; index++) {
      const element = launchOptions.args[index];
      if(element.startsWith('--proxy-bypass-list=<-loopback>')) {
        //launchOptions.args[index] = '--proxy-bypass-list=localhost,.verizonwireless.com,.verizon.com,*.verizon.com,*.vzw.com,.vzw.com,scache.vzw.com,scache2.vzw.com,<-loopback>';
      }
    }
    prepareAudit(launchOptions);
    return launchOptions;
  });
  on('before:spec', (spec) => {
    specName = spec.name;
  });
  on('after:spec', (spec, results) => {
    
  });
  on('task', {
   setMyData: function(data) {
      myData = data;
      console.log("setMyDataxxx");
      return null;
   },
   getMyData: function(data) {
      console.log("getMyDataxxx");
      return myData;
  }, 
    lighthouse: lighthouse((lighthouseReport) => {
      const fileName = `cypress/reports/lighthousemetrices/${dateNow}/${specName}`;
      mkDirs(fileName);
      fs.writeFileSync(fileName + '.html', ReportGenerator.generateReport(lighthouseReport.lhr, 'html'), { flag: 'w' });
      // fs.writeFileSync(fileName + '.json', JSON.stringify(lighthouseReport.lhr));
    }), // calling the function is important
    pa11y: pa11y() // calling the function is important
  });
};
