const sh = require('shelljs');
const path = require('path');
const appDir = path.dirname(require.main.filename);
const fs = require('fs');
const cypress = require('cypress');
const {logger, mkDirs} = require('./utils/cypressUtils');
const pagesConfig = require('./config/pagesConfig');
const getTestTemplateData = require('./config/cypressTestFileTemplate');
const http = require('http');
const url = require('url').URL;
const buildId = Math.floor(Math.random() * 99999);
//fetchs staged files.
const gitCommand = sh.exec('git diff --name-only --cached');
const changedFiles = gitCommand.split(/\n/g);
const configFile = 'cypress/config/cypressDevConfig.json';
const appFolderPath = path.join(appDir, '..');
if(!fs.existsSync(path.join(appFolderPath, 'package.json'))) {
  logger.error('Unable to find the node project.');
  process.exit(1);
}
sh.cd(appFolderPath);
console.log('Making sure spec files created for all pages defined in pagesConfig');
for(const pageConfig of pagesConfig) {
  if(pageConfig.route) {
    const route = pageConfig;
    const specPath = `cypress/integration/lighthouseTests${route=='/'?'/home':route}.spec.js`;
    if(!route) continue;
    try {
      fs.accessSync(specPath);
    } catch (error) {
      // console.log(process.cwd());
      mkDirs(specPath);
      fs.writeFileSync(specPath, getTestTemplateData({ route }), { flag: 'wx'});
      sh.exec(`git add ${specPath}`);
      console.log("Generated cypress spec: " + specPath);
    }
  }
}
const configObj = JSON.parse(fs.readFileSync(configFile));
let specFiles = new Set();
let testAll = false;
//Finding spec/test files to run for the committed files.
for(let changedFilePath of changedFiles) {
  changedFilePath = changedFilePath.trim();
  if(changedFilePath) {
    for(const pageConfig of pagesConfig) {
        if(changedFilePath.startsWith(pageConfig.pageSrc)) {
          const route = pageConfig;
          const specPath = `cypress/integration/lighthouseTests${route=='/'?'/home':route}.spec.js`;
          if(!route) {
            let testSpecs = pageConfig.testSpecs;
            if(testSpecs?.length) {
              testSpecs.forEach(specFiles.add, specFiles);
            } else {
              testAll = true;
            }
            break;
          }
          specFiles.add(specPath);
          break;
        }
    } 
  }
}
if(testAll) {
  logger.info(`Planned for all cypress tests for executing`);
  specFiles = new Set();
}
else if(specFiles.size) {
  logger.info(`Planned cypress tests for executing (${[...specFiles].join(",")})`);
} else {
  logger.info(`No related routes/page found for the committed files.`);
  logger.warn(`Make sure to run atleast a test case if any changes are done at source level which affect live environment.`);
  process.exit(0);
}

const baseUrl = new url(configObj.baseUrl);
const req = http.request({
  method: 'HEAD',
  host: baseUrl.hostname,
  port: baseUrl.port
}, (res) =>  runCypress());
req.on('error', (error) => {
  //Run server command here.
  //runCypress();
  logger.error("Unable to connect with the server. Check if the server is up and running");
  sh.exec('git config --global core.DotCom.CYPRESSSTATUS FAIL');
  process.exit(1);
});
req.end();


const options = [
  'cypress', 'run', 
  '--config-file',  configFile, 
  ...configObj.runnerConfig.options,
  specFiles.size?'--spec':'', [...specFiles].join(","),
  // '--key', 'cpc','--parallel', '--record', 
  // ...args
]; 
let runCypress = function() {
  cypress.cli.parseRunArguments(options).then((runOptions) => {
    // logger.info('runOptions', runOptions);
    logger.info("Cypress run: Started");
    // console.log(process.cwd())
    cypress.run(runOptions).then((result) => {
      if(result.totalFailed) {
        logger.error(`Cypress run: ${result.totalFailed} Failed`);
        logger.error(`${result.totalFailed} Failed out of ${result.totalTests} tests!`);
      } else {
        logger.success(
          `Cypress run: Successful.\nTotal test cases: ${result.totalTests}.`
        );
      }
      sh.exec('git config --global core.DotCom.CYPRESSSTATUS PASS');
      process.exit(0);
    }).catch(error => {
      logger.error(error);
      sh.exec('git config --global core.DotCom.CYPRESSSTATUS FAIL');
    })
  }).catch(error => {
    logger.error(error);
    sh.exec('git config --global core.DotCom.CYPRESSSTATUS FAIL');
  });
}