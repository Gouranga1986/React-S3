
import * as cyConfig from '../../config/lighthouseConfig';

describe('Testing lighthouse metrices for the route/page: /bestbuy', () => {
    const intercept = (hostname) => {
      cy.intercept({
        // method: 'GET',
        url: '/**',
        hostname: hostname,
      }, {
        statusCode: 200,
        body: ''
      });
    };
    const skipUrls = () => {
      // intercept("scache.vzw.com");
      // intercept("scache1.vzw.com");
      // intercept("scache2.vzw.com");
      // intercept("respframework.verizon.com");
      // intercept("www.verizon.com");
      intercept("sandbox.paywithmybank.com");
      intercept("stats.g.doubleclick.net");
      intercept("api-qa.ebiz.verizon.com");
    }
    const failFunction = (error, runnable) => {
  
    };
    Cypress.on('fail', failFunction);
    beforeEach(() => {
        skipUrls();
    });
    before(() => {
        skipUrls();
        cy.visit('#/bestbuy');
    });
   
    it('Lighthouse audit on desktop', () => {
      Cypress.removeListener('fail', failFunction);
      cy.lighthouse(cyConfig.thresholdConfig, cyConfig.desktopConfig);
    });

    // it('audit the page on mobile', () => {
    //     cy.lighthouse(cyConfig.thresholdConfig, cyConfig.mobileConfig);
    // });

    // it.skip('validates accessibility', () => {
    //     //accessiablity tests.
    //     cy.pa11y();
    // });
});
